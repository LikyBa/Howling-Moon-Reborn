/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WerewolfStorage
/*     */   implements Capability.IStorage<IWerewolfCapability>
/*     */ {
/*     */   public NBTTagCompound writeNBT(Capability<IWerewolfCapability> capability, IWerewolfCapability instance, EnumFacing side) {
/*  24 */     NBTTagCompound properties = new NBTTagCompound();
/*  25 */     properties.func_74757_a("IsWerewolf", instance.isWerewolf());
/*  26 */     properties.func_74757_a("IsTransformed", instance.isTransformed());
/*  27 */     properties.func_74768_a("Infection", instance.getInfected());
/*  28 */     properties.func_74768_a("WerewolfTexture", instance.getTexture());
/*  29 */     properties.func_74768_a("WerewolfModel", instance.getModel());
/*  30 */     properties.func_74757_a("MoonTransform", instance.getMoonTransformation());
/*     */     
/*  32 */     properties.func_74768_a("PawSlot", instance.getPawSlot());
/*  33 */     properties.func_74757_a("NightVision", instance.getNightVision());
/*  34 */     properties.func_74757_a("ScentTracking", instance.getScentTracking());
/*  35 */     properties.func_74768_a("LeapState", instance.getLeapState());
/*  36 */     properties.func_74768_a("SneakJump", instance.getSneakJump());
/*  37 */     properties.func_74768_a("SprintJump", instance.getSprintJump());
/*  38 */     properties.func_74768_a("SprintClimb", instance.getSprintClimb());
/*  39 */     properties.func_74768_a("SprintRam", instance.getSprintRam());
/*     */     
/*  41 */     if (instance.getAbilitySlot1() != null)
/*  42 */       properties.func_74778_a("AbilitySlot1", instance.getAbilitySlot1().getKey()); 
/*  43 */     if (instance.getAbilitySlot2() != null) {
/*  44 */       properties.func_74778_a("AbilitySlot2", instance.getAbilitySlot2().getKey());
/*     */     }
/*     */     
/*  47 */     properties.func_74768_a("Level", instance.getLevel());
/*  48 */     properties.func_74768_a("Exp", instance.getExp());
/*     */ 
/*     */ 
/*     */     
/*  52 */     properties.func_74768_a("UsedAttP", instance.getUsedAttributePoints());
/*  53 */     properties.func_74768_a("UsedAbilityP", instance.getUsedAbilityPoints());
/*     */     
/*  55 */     properties.func_74768_a("Inclination", instance.getInclinationType());
/*  56 */     properties.func_74768_a("Quests", instance.getQuestsDone());
/*     */     
/*  58 */     for (String key : instance.getBasicTree().keySet())
/*     */     {
/*  60 */       properties.func_74757_a(key, instance.getBasicTreeAbility(key));
/*     */     }
/*  62 */     for (String key : instance.getAttributeTree().keySet())
/*     */     {
/*  64 */       properties.func_74768_a(key, instance.getAttributeTreeAbility(key));
/*     */     }
/*  66 */     for (String key : instance.getAbilityTree().keySet())
/*     */     {
/*  68 */       properties.func_74757_a(key, instance.getAbilityTreeAbility(key));
/*     */     }
/*  70 */     for (Class<? extends Entity> key : instance.getScentTree().keySet())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  75 */       properties.func_74768_a(key.getName(), instance.getScentColor(key));
/*     */     }
/*     */     
/*  78 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readNBT(Capability<IWerewolfCapability> capability, IWerewolfCapability instance, EnumFacing side, NBTBase nbt) {
/*  88 */     NBTTagCompound properties = (NBTTagCompound)nbt;
/*  89 */     instance.setWerewolf(properties.func_74767_n("IsWerewolf"));
/*  90 */     instance.setTransformed(properties.func_74767_n("IsTransformed"));
/*  91 */     instance.setInfected(properties.func_74762_e("Infection"));
/*  92 */     instance.setTexture(properties.func_74762_e("WerewolfTexture"));
/*  93 */     instance.setModel(properties.func_74762_e("WerewolfModel"));
/*  94 */     instance.setMoonTransformation(properties.func_74767_n("MoonTransform"));
/*     */     
/*  96 */     instance.setPawSlot(properties.func_74762_e("PawSlot"));
/*  97 */     instance.setNightVision(properties.func_74767_n("NightVision"));
/*  98 */     instance.setScentTracking(properties.func_74767_n("ScentTracking"));
/*  99 */     instance.setLeapState(properties.func_74762_e("LeapState"));
/* 100 */     instance.setSneakJump(properties.func_74762_e("SneakJump"));
/* 101 */     instance.setSprintJump(properties.func_74762_e("SprintJump"));
/* 102 */     instance.setSprintClimb(properties.func_74762_e("SprintClimb"));
/* 103 */     instance.setSprintRam(properties.func_74762_e("SprintRam"));
/*     */     
/* 105 */     instance.setAbilitySlot1(WereList.getAbilityFromKey(properties.func_74779_i("AbilitySlot1")));
/* 106 */     instance.setAbilitySlot2(WereList.getAbilityFromKey(properties.func_74779_i("AbilitySlot2")));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     instance.setLevel(properties.func_74762_e("Level"));
/* 112 */     instance.setExp(properties.func_74762_e("Exp"));
/*     */     
/* 114 */     instance.setUsedAttributePoints(properties.func_74762_e("UsedAttP"));
/* 115 */     instance.setUsedAbilityPoints(properties.func_74762_e("UsedAbilityP"));
/*     */     
/* 117 */     for (String key : instance.getBasicTree().keySet())
/*     */     {
/* 119 */       instance.setBasicTreeAbility(key, properties.func_74767_n(key));
/*     */     }
/* 121 */     for (String key : instance.getAttributeTree().keySet())
/*     */     {
/* 123 */       instance.setAttributeTreeAbility(key, properties.func_74762_e(key));
/*     */     }
/* 125 */     for (String key : instance.getAbilityTree().keySet())
/*     */     {
/* 127 */       instance.setAbilityTreeAbility(key, properties.func_74767_n(key));
/*     */     }
/* 129 */     for (Class<? extends Entity> key : instance.getScentTree().keySet())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 134 */       instance.setScentColor(key, properties.func_74762_e(key.getName()));
/*     */     }
/*     */     
/* 137 */     instance.setInclinationType(properties.func_74762_e("Inclination"));
/* 138 */     instance.setQuestsDone(properties.func_74762_e("Quests"));
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WerewolfStorage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */