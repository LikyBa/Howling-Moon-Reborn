/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.SoundEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMSounds
/*    */ {
/* 14 */   public static final List<SoundEvent> SOUNDS = new ArrayList<>();
/*    */   
/* 16 */   public static final SoundEvent howl = (SoundEvent)(new SoundEvent(new ResourceLocation("howlingmoon", "howl"))).setRegistryName("howl");
/* 17 */   public static final SoundEvent heartbeat_delay = (SoundEvent)(new SoundEvent(new ResourceLocation("howlingmoon", "heartbeat_delay"))).setRegistryName("heartbeat_delay");
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\HMSounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */