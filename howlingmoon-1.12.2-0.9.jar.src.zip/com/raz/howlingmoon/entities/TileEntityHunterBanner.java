/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class TileEntityHunterBanner
/*     */   extends TileEntity
/*     */   implements ITickable {
/*     */   private int lodgeRadius;
/*     */   private int tickCounter;
/*     */   private int numHunters;
/*     */   private boolean isGuild;
/*     */   
/*     */   public TileEntityHunterBanner() {
/*  23 */     this.tickCounter = 0;
/*  24 */     this.lodgeRadius = 36;
/*  25 */     this.numHunters = 0;
/*  26 */     this.isGuild = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public TileEntityHunterBanner(BlockPos pos) {
/*  31 */     this.tickCounter = 0;
/*  32 */     this.lodgeRadius = 36;
/*  33 */     this.numHunters = 0;
/*  34 */     this.isGuild = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73660_a() {
/*  40 */     if (!(func_145831_w()).field_72995_K && this.isGuild) {
/*     */ 
/*     */       
/*  43 */       this.tickCounter++;
/*     */       
/*  45 */       if (this.tickCounter % 30 == 0)
/*     */       {
/*  47 */         updateNumHunters();
/*     */       }
/*     */       
/*  50 */       if (this.field_145850_b.func_72935_r() && this.numHunters < 3 && this.field_145850_b.field_73012_v.nextInt(7000) == 0) {
/*     */         
/*  52 */         Vec3d vec3d = findRandomSpawnPos(func_174877_v(), 2, 4, 2);
/*     */         
/*  54 */         if (vec3d != null) {
/*     */           
/*  56 */           EntityHunter hunter = new EntityHunter(this.field_145850_b, true, func_174877_v());
/*  57 */           hunter.func_70107_b(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
/*  58 */           hunter.func_180482_a(this.field_145850_b.func_175649_E(new BlockPos((Entity)hunter)), (IEntityLivingData)null);
/*  59 */           this.field_145850_b.func_72838_d((Entity)hunter);
/*  60 */           this.numHunters++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateNumHunters() {
/*  69 */     List<EntityHunter> list = this.field_145850_b.func_72872_a(EntityHunter.class, new AxisAlignedBB((func_174877_v().func_177958_n() - this.lodgeRadius), (func_174877_v().func_177956_o() - 2), (func_174877_v().func_177952_p() - this.lodgeRadius), (func_174877_v().func_177958_n() + this.lodgeRadius), (func_174877_v().func_177956_o() + 8), (func_174877_v().func_177952_p() + this.lodgeRadius)));
/*  70 */     this.numHunters = list.size();
/*     */   }
/*     */ 
/*     */   
/*     */   private Vec3d findRandomSpawnPos(BlockPos pos, int x, int y, int z) {
/*  75 */     for (int i = 0; i < 10; i++) {
/*     */       
/*  77 */       BlockPos blockpos = pos.func_177982_a(this.field_145850_b.field_73012_v.nextInt(10) - 5, this.field_145850_b.field_73012_v.nextInt(6) - 3, this.field_145850_b.field_73012_v.nextInt(10) - 5);
/*     */       
/*  79 */       if (isBlockPosWithinSqLodgeRadius(blockpos) && isAreaClearAround(new BlockPos(x, y, z), blockpos))
/*     */       {
/*  81 */         return new Vec3d(blockpos.func_177958_n(), blockpos.func_177956_o(), blockpos.func_177952_p());
/*     */       }
/*     */     } 
/*     */     
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBlockPosWithinSqLodgeRadius(BlockPos pos) {
/*  94 */     return (func_174877_v().func_177951_i((Vec3i)pos) < (this.lodgeRadius * this.lodgeRadius));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAreaClearAround(BlockPos blockSize, BlockPos blockLocation) {
/* 102 */     if (!this.field_145850_b.func_180495_p(blockLocation.func_177977_b()).func_185896_q())
/*     */     {
/* 104 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 108 */     int i = blockLocation.func_177958_n() - blockSize.func_177958_n() / 2;
/* 109 */     int j = blockLocation.func_177952_p() - blockSize.func_177952_p() / 2;
/*     */     
/* 111 */     for (int k = i; k < i + blockSize.func_177958_n(); k++) {
/*     */       
/* 113 */       for (int l = blockLocation.func_177956_o(); l < blockLocation.func_177956_o() + blockSize.func_177956_o(); l++) {
/*     */         
/* 115 */         for (int i1 = j; i1 < j + blockSize.func_177952_p(); i1++) {
/*     */           
/* 117 */           if (this.field_145850_b.func_180495_p(new BlockPos(k, l, i1)).func_185915_l())
/*     */           {
/* 119 */             return false;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound compound) {
/* 132 */     super.func_189515_b(compound);
/* 133 */     compound.func_74757_a("Guild", this.isGuild);
/* 134 */     compound.func_74768_a("Radius", this.lodgeRadius);
/* 135 */     compound.func_74768_a("Hunters", this.numHunters);
/* 136 */     return compound;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound compound) {
/* 142 */     super.func_145839_a(compound);
/* 143 */     this.isGuild = compound.func_74767_n("Guild");
/* 144 */     this.lodgeRadius = compound.func_74762_e("Radius");
/* 145 */     this.numHunters = compound.func_74762_e("Hunters");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLodgeRadius() {
/* 150 */     return this.lodgeRadius;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumHunters() {
/* 155 */     return this.numHunters;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGuild() {
/* 160 */     return this.isGuild;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIsGuild(boolean guild) {
/* 165 */     this.isGuild = guild;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\TileEntityHunterBanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */