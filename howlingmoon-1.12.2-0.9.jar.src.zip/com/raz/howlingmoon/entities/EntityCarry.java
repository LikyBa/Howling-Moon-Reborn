/*    */ package com.raz.howlingmoon.entities;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.monster.EntityCreeper;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityCarry
/*    */   extends Entity
/*    */ {
/*    */   public EntityCarry(World world) {
/* 14 */     super(world);
/* 15 */     func_70105_a(0.0F, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_70088_a() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_70039_c(NBTTagCompound compound) {
/* 28 */     String s = func_70022_Q();
/*    */     
/* 30 */     if (!this.field_70128_L && s != null) {
/*    */       
/* 32 */       compound.func_74778_a("id", s);
/* 33 */       func_189511_e(compound);
/* 34 */       return true;
/*    */     } 
/*    */ 
/*    */     
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_70037_a(NBTTagCompound p_70037_1_) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_70014_b(NBTTagCompound p_70014_1_) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70071_h_() {
/* 55 */     super.func_70071_h_();
/*    */     
/* 57 */     if (!func_184207_aI() || !func_184218_aH()) {
/*    */       
/* 59 */       if (!this.field_70170_p.field_72995_K)
/*    */       {
/* 61 */         if (this.field_70173_aa > 6) {
/* 62 */           func_70106_y();
/*    */         }
/*    */       }
/*    */     } else {
/*    */       
/* 67 */       for (Entity entity : func_184188_bt()) {
/*    */         
/* 69 */         if (entity instanceof EntityCreeper)
/*    */         {
/* 71 */           if (((EntityCreeper)entity).func_70832_p() != -1) {
/* 72 */             ((EntityCreeper)entity).func_70829_a(-1);
/*    */           }
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public double func_70042_X() {
/* 81 */     return 0.6D;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_70106_y() {
/* 88 */     super.func_70106_y();
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityCarry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */