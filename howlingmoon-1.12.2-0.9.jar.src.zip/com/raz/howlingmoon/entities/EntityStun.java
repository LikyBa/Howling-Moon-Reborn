/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityStun
/*     */   extends Entity
/*     */ {
/*     */   public float riderHeight;
/*     */   public float renderYawOffset;
/*     */   public float prevRenderYawOffset;
/*     */   public float rotationYawHead;
/*     */   public float prevRotationYawHead;
/*     */   protected float prevOnGroundSpeedFactor;
/*     */   protected float onGroundSpeedFactor;
/*     */   protected float movedDistance;
/*     */   protected float prevMovedDistance;
/*     */   public float moveStrafing;
/*     */   public float moveVertical;
/*     */   public float moveForward;
/*     */   public float randomYawVelocity;
/*     */   protected int newPosRotationIncrements;
/*     */   protected double interpTargetX;
/*     */   protected double interpTargetY;
/*     */   protected double interpTargetZ;
/*     */   protected double interpTargetYaw;
/*     */   protected double interpTargetPitch;
/*     */   private boolean potionsNeedUpdate = true;
/*     */   private float landMovementFactor;
/*     */   
/*     */   public EntityStun(World world) {
/*  70 */     super(world);
/*  71 */     func_70105_a(0.6F, 0.1F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {}
/*     */ 
/*     */   
/*     */   public void changeSize(float width, float height) {
/*  80 */     this.riderHeight = height;
/*  81 */     func_70105_a(width, 0.1F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 147 */     super.func_70071_h_();
/*     */     
/* 149 */     onLivingUpdate();
/* 150 */     if (!func_184207_aI()) {
/*     */       
/* 152 */       if (!this.field_70170_p.field_72995_K)
/*     */       {
/* 154 */         if (this.field_70173_aa > 6) {
/* 155 */           func_70106_y();
/*     */         }
/*     */       }
/* 158 */     } else if (this.field_70173_aa > 60) {
/*     */       
/* 160 */       func_70106_y();
/*     */     }
/*     */     else {
/*     */       
/* 164 */       for (Entity entity : func_184188_bt()) {
/*     */         
/* 166 */         if (entity instanceof EntityCreeper)
/*     */         {
/* 168 */           if (((EntityCreeper)entity).func_70832_p() != -1)
/* 169 */             ((EntityCreeper)entity).func_70829_a(-1); 
/*     */         }
/* 171 */         if (entity instanceof EntityLiving)
/*     */         {
/* 173 */           if (((EntityLiving)entity).func_70638_az() != null)
/*     */           {
/*     */             
/* 176 */             ((EntityLiving)entity).func_70624_b(null);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 181 */     double d0 = this.field_70165_t - this.field_70169_q;
/* 182 */     double d1 = this.field_70161_v - this.field_70166_s;
/* 183 */     float f1 = (float)(d0 * d0 + d1 * d1);
/* 184 */     float f2 = this.renderYawOffset;
/* 185 */     float f3 = 0.0F;
/* 186 */     this.prevOnGroundSpeedFactor = this.onGroundSpeedFactor;
/* 187 */     float f = 0.0F;
/*     */     
/* 189 */     if (f1 > 0.0025000002F) {
/*     */       
/* 191 */       f = 1.0F;
/* 192 */       f3 = (float)Math.sqrt(f1) * 3.0F;
/* 193 */       f2 = (float)MathHelper.func_181159_b(d1, d0) * 57.295776F - 90.0F;
/*     */     } 
/*     */     
/* 196 */     if (!this.field_70122_E)
/*     */     {
/* 198 */       f = 0.0F;
/*     */     }
/*     */     
/* 201 */     this.onGroundSpeedFactor += (f - this.onGroundSpeedFactor) * 0.3F;
/* 202 */     this.field_70170_p.field_72984_F.func_76320_a("headTurn");
/* 203 */     f3 = updateDistance(f2, f3);
/* 204 */     this.field_70170_p.field_72984_F.func_76319_b();
/* 205 */     this.field_70170_p.field_72984_F.func_76320_a("rangeChecks");
/*     */     
/* 207 */     while (this.field_70177_z - this.field_70126_B < -180.0F)
/*     */     {
/* 209 */       this.field_70126_B -= 360.0F;
/*     */     }
/*     */     
/* 212 */     while (this.field_70177_z - this.field_70126_B >= 180.0F)
/*     */     {
/* 214 */       this.field_70126_B += 360.0F;
/*     */     }
/*     */     
/* 217 */     while (this.renderYawOffset - this.prevRenderYawOffset < -180.0F)
/*     */     {
/* 219 */       this.prevRenderYawOffset -= 360.0F;
/*     */     }
/*     */     
/* 222 */     while (this.renderYawOffset - this.prevRenderYawOffset >= 180.0F)
/*     */     {
/* 224 */       this.prevRenderYawOffset += 360.0F;
/*     */     }
/*     */     
/* 227 */     while (this.field_70125_A - this.field_70127_C < -180.0F)
/*     */     {
/* 229 */       this.field_70127_C -= 360.0F;
/*     */     }
/*     */     
/* 232 */     while (this.field_70125_A - this.field_70127_C >= 180.0F)
/*     */     {
/* 234 */       this.field_70127_C += 360.0F;
/*     */     }
/*     */     
/* 237 */     while (this.rotationYawHead - this.prevRotationYawHead < -180.0F)
/*     */     {
/* 239 */       this.prevRotationYawHead -= 360.0F;
/*     */     }
/*     */     
/* 242 */     while (this.rotationYawHead - this.prevRotationYawHead >= 180.0F)
/*     */     {
/* 244 */       this.prevRotationYawHead += 360.0F;
/*     */     }
/*     */     
/* 247 */     this.field_70170_p.field_72984_F.func_76319_b();
/* 248 */     this.movedDistance += f3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected float updateDistance(float p_110146_1_, float p_110146_2_) {
/* 253 */     float f = MathHelper.func_76142_g(p_110146_1_ - this.renderYawOffset);
/* 254 */     this.renderYawOffset += f * 0.3F;
/* 255 */     float f1 = MathHelper.func_76142_g(this.field_70177_z - this.renderYawOffset);
/* 256 */     boolean flag = (f1 < -90.0F || f1 >= 90.0F);
/*     */     
/* 258 */     if (f1 < -75.0F)
/*     */     {
/* 260 */       f1 = -75.0F;
/*     */     }
/*     */     
/* 263 */     if (f1 >= 75.0F)
/*     */     {
/* 265 */       f1 = 75.0F;
/*     */     }
/*     */     
/* 268 */     this.renderYawOffset = this.field_70177_z - f1;
/*     */     
/* 270 */     if (f1 * f1 > 2500.0F)
/*     */     {
/* 272 */       this.renderYawOffset += f1 * 0.2F;
/*     */     }
/*     */     
/* 275 */     if (flag)
/*     */     {
/* 277 */       p_110146_2_ *= -1.0F;
/*     */     }
/*     */     
/* 280 */     return p_110146_2_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLivingUpdate() {
/* 290 */     if (this.newPosRotationIncrements > 0 && !func_184186_bw()) {
/*     */       
/* 292 */       double d0 = this.field_70165_t + (this.interpTargetX - this.field_70165_t) / this.newPosRotationIncrements;
/* 293 */       double d1 = this.field_70163_u + (this.interpTargetY - this.field_70163_u) / this.newPosRotationIncrements;
/* 294 */       double d2 = this.field_70161_v + (this.interpTargetZ - this.field_70161_v) / this.newPosRotationIncrements;
/* 295 */       double d3 = MathHelper.func_76138_g(this.interpTargetYaw - this.field_70177_z);
/* 296 */       this.field_70177_z = (float)(this.field_70177_z + d3 / this.newPosRotationIncrements);
/* 297 */       this.field_70125_A = (float)(this.field_70125_A + (this.interpTargetPitch - this.field_70125_A) / this.newPosRotationIncrements);
/* 298 */       this.newPosRotationIncrements--;
/* 299 */       func_70107_b(d0, d1, d2);
/* 300 */       func_70101_b(this.field_70177_z, this.field_70125_A);
/*     */     }
/* 302 */     else if (!isServerWorld()) {
/*     */       
/* 304 */       this.field_70159_w *= 0.98D;
/* 305 */       this.field_70181_x *= 0.98D;
/* 306 */       this.field_70179_y *= 0.98D;
/*     */     } 
/*     */     
/* 309 */     if (Math.abs(this.field_70159_w) < 0.003D)
/*     */     {
/* 311 */       this.field_70159_w = 0.0D;
/*     */     }
/*     */     
/* 314 */     if (Math.abs(this.field_70181_x) < 0.003D)
/*     */     {
/* 316 */       this.field_70181_x = 0.0D;
/*     */     }
/*     */     
/* 319 */     if (Math.abs(this.field_70179_y) < 0.003D)
/*     */     {
/* 321 */       this.field_70179_y = 0.0D;
/*     */     }
/*     */     
/* 324 */     this.field_70170_p.field_72984_F.func_76320_a("travel");
/* 325 */     this.moveStrafing *= 0.98F;
/* 326 */     this.moveForward *= 0.98F;
/* 327 */     this.randomYawVelocity *= 0.9F;
/* 328 */     travel(this.moveStrafing, this.moveVertical, this.moveForward);
/*     */     
/* 330 */     this.field_70170_p.field_72984_F.func_76319_b();
/* 331 */     this.field_70170_p.field_72984_F.func_76320_a("push");
/*     */     
/* 333 */     this.field_70170_p.field_72984_F.func_76319_b();
/*     */   }
/*     */ 
/*     */   
/*     */   public void knockBack(Entity entityIn, float strenght, double xRatio, double zRatio) {
/* 338 */     this.field_70160_al = true;
/* 339 */     float f = MathHelper.func_76133_a(xRatio * xRatio + zRatio * zRatio);
/* 340 */     this.field_70159_w /= 2.0D;
/* 341 */     this.field_70179_y /= 2.0D;
/* 342 */     this.field_70159_w -= xRatio / f * strenght;
/* 343 */     this.field_70179_y -= zRatio / f * strenght;
/*     */ 
/*     */ 
/*     */     
/* 347 */     this.field_70181_x /= 2.0D;
/* 348 */     this.field_70181_x += strenght;
/*     */     
/* 350 */     if (this.field_70181_x > 0.4000000059604645D)
/*     */     {
/* 352 */       this.field_70181_x = 0.4000000059604645D;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double func_70042_X() {
/* 360 */     return -0.3D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70106_y() {
/* 367 */     super.func_70106_y();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70037_a(NBTTagCompound compound) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70014_b(NBTTagCompound compound) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isServerWorld() {
/* 387 */     return !this.field_70170_p.field_72995_K;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70098_U() {
/* 395 */     super.func_70098_U();
/* 396 */     this.prevOnGroundSpeedFactor = this.onGroundSpeedFactor;
/* 397 */     this.onGroundSpeedFactor = 0.0F;
/* 398 */     this.field_70143_R = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_180426_a(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
/* 407 */     this.interpTargetX = x;
/* 408 */     this.interpTargetY = y;
/* 409 */     this.interpTargetZ = z;
/* 410 */     this.interpTargetYaw = yaw;
/* 411 */     this.interpTargetPitch = pitch;
/* 412 */     this.newPosRotationIncrements = posRotationIncrements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void travel(float strafe, float vertical, float forward) {
/* 420 */     if (isServerWorld() || func_184186_bw())
/*     */     {
/* 422 */       if (!func_70090_H()) {
/*     */         
/* 424 */         if (!func_180799_ab())
/*     */         {
/* 426 */           float f6 = 0.91F;
/* 427 */           BlockPos.PooledMutableBlockPos blockpos$pooledmutableblockpos = BlockPos.PooledMutableBlockPos.func_185345_c(this.field_70165_t, (func_174813_aQ()).field_72338_b - 1.0D, this.field_70161_v);
/*     */           
/* 429 */           if (this.field_70122_E)
/*     */           {
/* 431 */             f6 = (this.field_70170_p.func_180495_p((BlockPos)blockpos$pooledmutableblockpos).func_177230_c()).field_149765_K * 0.91F;
/*     */           }
/*     */           
/* 434 */           float f7 = 0.16277136F / f6 * f6 * f6;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 439 */           float f8 = getAIMoveSpeed() * f7;
/*     */ 
/*     */           
/* 442 */           func_191958_b(strafe, vertical, forward, f8);
/* 443 */           f6 = 0.91F;
/*     */           
/* 445 */           if (this.field_70122_E)
/*     */           {
/* 447 */             f6 = (this.field_70170_p.func_180495_p((BlockPos)blockpos$pooledmutableblockpos.func_189532_c(this.field_70165_t, (func_174813_aQ()).field_72338_b - 1.0D, this.field_70161_v)).func_177230_c()).field_149765_K * 0.91F;
/*     */           }
/*     */           
/* 450 */           func_70091_d(MoverType.SELF, this.field_70159_w, this.field_70181_x, this.field_70179_y);
/*     */           
/* 452 */           blockpos$pooledmutableblockpos.func_189532_c(this.field_70165_t, 0.0D, this.field_70161_v);
/*     */           
/* 454 */           if (!this.field_70170_p.field_72995_K || (this.field_70170_p.func_175667_e((BlockPos)blockpos$pooledmutableblockpos) && this.field_70170_p.func_175726_f((BlockPos)blockpos$pooledmutableblockpos).func_177410_o())) {
/*     */             
/* 456 */             if (!func_189652_ae())
/*     */             {
/* 458 */               this.field_70181_x -= 0.08D;
/*     */             }
/*     */           }
/* 461 */           else if (this.field_70163_u > 0.0D) {
/*     */             
/* 463 */             this.field_70181_x = -0.1D;
/*     */           }
/*     */           else {
/*     */             
/* 467 */             this.field_70181_x = 0.0D;
/*     */           } 
/*     */ 
/*     */           
/* 471 */           this.field_70181_x *= 0.9800000190734863D;
/* 472 */           this.field_70159_w *= f6;
/* 473 */           this.field_70179_y *= f6;
/* 474 */           blockpos$pooledmutableblockpos.func_185344_t();
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 479 */           double d4 = this.field_70163_u;
/* 480 */           func_191958_b(strafe, vertical, forward, 0.02F);
/* 481 */           func_70091_d(MoverType.SELF, this.field_70159_w, this.field_70181_x, this.field_70179_y);
/* 482 */           this.field_70159_w *= 0.5D;
/* 483 */           this.field_70181_x *= 0.5D;
/* 484 */           this.field_70179_y *= 0.5D;
/*     */           
/* 486 */           if (!func_189652_ae())
/*     */           {
/* 488 */             this.field_70181_x -= 0.02D;
/*     */           }
/*     */           
/* 491 */           if (this.field_70123_F && func_70038_c(this.field_70159_w, this.field_70181_x + 0.6000000238418579D - this.field_70163_u + d4, this.field_70179_y))
/*     */           {
/* 493 */             this.field_70181_x = 0.30000001192092896D;
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 499 */         double d0 = this.field_70163_u;
/* 500 */         float f1 = getWaterSlowDown();
/* 501 */         float f2 = 0.02F;
/* 502 */         float f3 = 0.0F;
/*     */         
/* 504 */         if (f3 > 3.0F)
/*     */         {
/* 506 */           f3 = 3.0F;
/*     */         }
/*     */         
/* 509 */         if (!this.field_70122_E)
/*     */         {
/* 511 */           f3 *= 0.5F;
/*     */         }
/*     */         
/* 514 */         if (f3 > 0.0F) {
/*     */           
/* 516 */           f1 += (0.54600006F - f1) * f3 / 3.0F;
/* 517 */           f2 += (getAIMoveSpeed() - f2) * f3 / 3.0F;
/*     */         } 
/*     */         
/* 520 */         func_191958_b(strafe, vertical, forward, f2);
/* 521 */         func_70091_d(MoverType.SELF, this.field_70159_w, this.field_70181_x, this.field_70179_y);
/* 522 */         this.field_70159_w *= f1;
/* 523 */         this.field_70181_x *= 0.800000011920929D;
/* 524 */         this.field_70179_y *= f1;
/*     */         
/* 526 */         if (!func_189652_ae())
/*     */         {
/* 528 */           this.field_70181_x -= 0.02D;
/*     */         }
/*     */         
/* 531 */         if (this.field_70123_F && func_70038_c(this.field_70159_w, this.field_70181_x + 0.6000000238418579D - this.field_70163_u + d0, this.field_70179_y))
/*     */         {
/* 533 */           this.field_70181_x = 0.30000001192092896D;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAIMoveSpeed() {
/* 541 */     return this.landMovementFactor;
/*     */   }
/*     */ 
/*     */   
/*     */   protected float getWaterSlowDown() {
/* 546 */     return 0.8F;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityStun.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */