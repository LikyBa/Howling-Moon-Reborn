/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.raz.howlingmoon.ai.EntityAINearestNonWereTarget;
/*     */ import com.raz.howlingmoon.ai.EntityAIWereBreakDoor;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackMelee;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAIHurtByTarget;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAIWander;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.monster.EntitySkeleton;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.passive.EntityVillager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.pathfinding.PathNavigateGround;
/*     */ import net.minecraft.pathfinding.PathNodeType;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityWerewolf
/*     */   extends EntityTameWere
/*     */ {
/*     */   private float field_70926_e;
/*     */   private float field_70924_f;
/*     */   
/*     */   public EntityWerewolf(World world) {
/*  41 */     super(world);
/*  42 */     setupAI();
/*  43 */     setTamed(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70088_a() {
/*  49 */     super.func_70088_a();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  55 */     super.func_110147_ax();
/*     */     
/*  57 */     func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(40.0D);
/*  58 */     if (hasAgile()) {
/*  59 */       func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.6D);
/*     */     } else {
/*  61 */       func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.4D);
/*  62 */     }  if (hasKnockbackResistance()) {
/*  63 */       func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0D);
/*     */     } else {
/*  65 */       func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(0.0D);
/*  66 */     }  func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(40.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(5.0D + getSavageryLevel());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupAI() {
/*  76 */     if (getAvoidWater()) {
/*  77 */       func_184644_a(PathNodeType.WATER, -1.0F);
/*     */     }
/*  79 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*     */     
/*  81 */     if (getBreakDoors())
/*  82 */       ((PathNavigateGround)func_70661_as()).func_179688_b(true); 
/*  83 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIWereBreakDoor(this));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAIAttackMelee(this, 1.0D, true));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAIWander(this, 1.0D));
/*  95 */     this.field_70714_bg.func_75776_a(11, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 8.0F));
/*  96 */     this.field_70714_bg.func_75776_a(11, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/*     */ 
/*     */     
/*  99 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget(this, true, new Class[0]));
/* 100 */     this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget(this, EntityHunter.class, false));
/* 101 */     this.field_70715_bh.func_75776_a(4, (EntityAIBase)new EntityAINearestNonWereTarget(this, EntityPlayer.class, false));
/* 102 */     this.field_70715_bh.func_75776_a(5, (EntityAIBase)new EntityAINearestNonWereTarget(this, EntityVillager.class, false));
/* 103 */     this.field_70715_bh.func_75776_a(6, (EntityAIBase)new EntityAINearestNonWereTarget(this, EntityAnimal.class, false));
/* 104 */     this.field_70715_bh.func_75776_a(7, (EntityAIBase)new EntityAINearestNonWereTarget(this, EntitySkeleton.class, false));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void clearAITasks() {
/* 109 */     this.field_70714_bg.field_75782_a.clear();
/* 110 */     this.field_70715_bh.field_75782_a.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70624_b(@Nullable EntityLivingBase entitylivingbaseIn) {
/* 119 */     super.func_70624_b(entitylivingbaseIn);
/*     */     
/* 121 */     if (entitylivingbaseIn == null) {
/*     */       
/* 123 */       setAngry(false);
/*     */     }
/* 125 */     else if (!isTamed()) {
/*     */       
/* 127 */       setAngry(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public float getInterestedAngle(float p_70917_1_) {
/* 133 */     return (this.field_70924_f + (this.field_70926_e - this.field_70924_f) * p_70917_1_) * 0.15F * 3.1415927F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70601_bi() {
/* 139 */     BlockPos blockpos = new BlockPos(this.field_70165_t, Math.round(this.field_70163_u), this.field_70161_v);
/* 140 */     return ((this.field_70163_u > 60.0D || this.field_70170_p.func_175678_i(blockpos)) && this.field_70170_p.func_130001_d() == 1.0F && !this.field_70170_p.func_72935_r() && super.func_70601_bi());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_70692_ba() {
/* 149 */     return (!isTamed() && (this.field_70173_aa > 5000 || this.field_70170_p.func_130001_d() != 1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent func_184639_G() {
/* 241 */     if (isAngry()) {
/* 242 */       return SoundEvents.field_187861_gG;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double func_70033_W() {
/* 266 */     return super.func_70033_W() - 0.5D;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */