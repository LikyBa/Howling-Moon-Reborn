/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.raz.howlingmoon.HMPotions;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.ai.EntityAIAttackWerewolf;
/*     */ import com.raz.howlingmoon.ai.EntityAIHunterRanged;
/*     */ import com.raz.howlingmoon.ai.EntityAIHurtByTargetPeace;
/*     */ import com.raz.howlingmoon.ai.EntityAIMoveAroundLodge;
/*     */ import com.raz.howlingmoon.ai.EntityAIMoveAroundVillage;
/*     */ import com.raz.howlingmoon.ai.EntityAIMoveToLodge;
/*     */ import com.raz.howlingmoon.ai.EntityAINearestAttackableTargetPeace;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.IRangedAttackMob;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackMelee;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAIOpenDoor;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAIWander;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.monster.EntityZombie;
/*     */ import net.minecraft.entity.monster.IMob;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityArrow;
/*     */ import net.minecraft.entity.projectile.EntityPotion;
/*     */ import net.minecraft.entity.projectile.EntityTippedArrow;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.PotionTypes;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.pathfinding.PathNavigateGround;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.potion.PotionUtils;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.DifficultyInstance;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityHunter
/*     */   extends EntityCreature
/*     */   implements IRangedAttackMob, IMob
/*     */ {
/*  69 */   private static final DataParameter<Integer> HUNTER_TYPE = EntityDataManager.func_187226_a(EntityHunter.class, DataSerializers.field_187192_b);
/*  70 */   private static final DataParameter<Boolean> PERSIST = EntityDataManager.func_187226_a(EntityHunter.class, DataSerializers.field_187198_h);
/*  71 */   private static final DataParameter<BlockPos> SPAWN = EntityDataManager.func_187226_a(EntityHunter.class, DataSerializers.field_187200_j);
/*  72 */   private final EntityAIHunterRanged aiArrowAttack = new EntityAIHunterRanged(this, 1.0D, 20, 15.0F);
/*  73 */   private final EntityAIAttackMelee aiAttackOnCollide = new EntityAIAttackMelee(this, 1.2D, false);
/*  74 */   private final EntityAIMoveAroundLodge aiMoveAroundLodge = new EntityAIMoveAroundLodge(this, 0.5D, false);
/*  75 */   private final EntityAIMoveAroundVillage aiMoveAroundVillage = new EntityAIMoveAroundVillage(this, 1.0D, true);
/*  76 */   private final EntityAIMoveToLodge aiMoveToLodge = new EntityAIMoveToLodge(this, 1.0D);
/*     */   
/*     */   private int potionUsedTimer;
/*     */ 
/*     */   
/*     */   public EntityHunter(World worldIn) {
/*  82 */     super(worldIn);
/*  83 */     setCombatTask();
/*  84 */     this.potionUsedTimer = 0;
/*     */   }
/*     */   
/*     */   public EntityHunter(World worldIn, boolean persist, BlockPos spawn) {
/*  88 */     super(worldIn);
/*  89 */     setCombatTask();
/*  90 */     setPersist(persist);
/*  91 */     setPersistTask();
/*  92 */     setSpawn(spawn);
/*  93 */     this.potionUsedTimer = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70088_a() {
/*  99 */     super.func_70088_a();
/* 100 */     this.field_70180_af.func_187214_a(HUNTER_TYPE, Integer.valueOf(0));
/* 101 */     this.field_70180_af.func_187214_a(PERSIST, Boolean.valueOf(false));
/* 102 */     this.field_70180_af.func_187214_a(SPAWN, BlockPos.field_177992_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/* 108 */     super.func_110147_ax();
/* 109 */     func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e);
/*     */     
/* 111 */     Random rnd = new Random();
/* 112 */     this.field_70180_af.func_187227_b(HUNTER_TYPE, Integer.valueOf(rnd.nextInt(2)));
/*     */     
/* 114 */     func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0D);
/* 115 */     func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.3D);
/* 116 */     func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(0.0D);
/* 117 */     func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(30.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound tagCompound) {
/* 123 */     super.func_70014_b(tagCompound);
/*     */     
/* 125 */     tagCompound.func_74768_a("HUNTER_TYPE", ((Integer)func_184212_Q().func_187225_a(HUNTER_TYPE)).intValue());
/* 126 */     tagCompound.func_74757_a("Persist", getPersist());
/* 127 */     tagCompound.func_74768_a("XPos", getSpawn().func_177958_n());
/* 128 */     tagCompound.func_74768_a("YPos", getSpawn().func_177956_o());
/* 129 */     tagCompound.func_74768_a("ZPos", getSpawn().func_177952_p());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound tagCompound) {
/* 135 */     super.func_70037_a(tagCompound);
/*     */     
/* 137 */     this.field_70180_af.func_187227_b(HUNTER_TYPE, Integer.valueOf(tagCompound.func_74762_e("HUNTER_TYPE")));
/* 138 */     setPersist(tagCompound.func_74767_n("Persist"));
/* 139 */     setSpawn(new BlockPos(tagCompound.func_74762_e("XPos"), tagCompound.func_74762_e("YPos"), tagCompound.func_74762_e("ZPos")));
/*     */     
/* 141 */     setCombatTask();
/* 142 */     setPersistTask();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/* 148 */     ((PathNavigateGround)func_70661_as()).func_179688_b(true);
/*     */     
/* 150 */     this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/*     */     
/* 152 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIOpenDoor((EntityLiving)this, true));
/*     */     
/* 154 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAIWander(this, 0.7D));
/* 155 */     this.field_70714_bg.func_75776_a(11, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 8.0F));
/* 156 */     this.field_70714_bg.func_75776_a(11, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/* 157 */     this.field_70715_bh.func_75776_a(0, (EntityAIBase)new EntityAIHurtByTargetPeace(this, true, new Class[0]));
/* 158 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAINearestAttackableTargetPeace(this, EntityWerewolf.class, true));
/* 159 */     this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAIAttackWerewolf(this, EntityPlayer.class, true));
/* 160 */     this.field_70715_bh.func_75776_a(3, (EntityAIBase)new EntityAINearestAttackableTargetPeace(this, EntityZombie.class, true, true));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void clearAITasks() {
/* 165 */     this.field_70714_bg.field_75782_a.clear();
/* 166 */     this.field_70715_bh.field_75782_a.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 172 */     super.func_70071_h_();
/*     */     
/* 174 */     if (!this.field_70170_p.field_72995_K)
/*     */     {
/* 176 */       if (getPersist()) {
/*     */         
/* 178 */         if (func_180425_c().func_177951_i((Vec3i)getSpawn()) > 6400.0D) {
/*     */           
/* 180 */           setPersist(false);
/* 181 */           setPersistTask();
/*     */         }
/* 183 */         else if (func_180425_c().func_177951_i((Vec3i)getSpawn()) < 10.0D) {
/*     */           
/* 185 */           if (!(this.field_70170_p.func_180495_p(getSpawn()).func_177230_c() instanceof com.raz.howlingmoon.blocks.BlockHunterBanner))
/*     */           {
/* 187 */             setPersist(false);
/* 188 */             setPersistTask();
/*     */           }
/*     */         
/*     */         } 
/* 192 */       } else if (this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL) {
/*     */         
/* 194 */         func_70106_y();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/* 202 */     super.func_70636_d();
/* 203 */     if (!this.field_70170_p.field_72995_K)
/*     */     {
/* 205 */       if (this.potionUsedTimer > 0) {
/* 206 */         this.potionUsedTimer--;
/* 207 */       } else if (func_110143_aJ() < func_110138_aP() && (func_70638_az() == null || func_70638_az().func_70662_br()) && (
/* 208 */         func_70643_av() == null || func_70643_av().func_70662_br())) {
/*     */         
/* 210 */         EntityPotion entitypotion = new EntityPotion(this.field_70170_p, (EntityLivingBase)this, PotionUtils.func_185188_a(new ItemStack((Item)Items.field_185155_bH), PotionTypes.field_185250_v));
/* 211 */         entitypotion.field_70125_A -= -20.0F;
/*     */         
/* 213 */         this.field_70170_p.func_184148_a((EntityPlayer)null, this.field_70165_t, this.field_70163_u, this.field_70161_v, SoundEvents.field_187924_gx, func_184176_by(), 1.0F, 0.8F + this.field_70146_Z.nextFloat() * 0.4F);
/* 214 */         this.field_70170_p.func_72838_d((Entity)entitypotion);
/* 215 */         this.potionUsedTimer = 600;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70652_k(Entity entityIn) {
/* 222 */     float f = (float)func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
/* 223 */     int i = 0;
/*     */     
/* 225 */     if (entityIn instanceof EntityLivingBase) {
/*     */       
/* 227 */       f += EnchantmentHelper.func_152377_a(func_184614_ca(), ((EntityLivingBase)entityIn).func_70668_bt());
/* 228 */       i += EnchantmentHelper.func_77501_a((EntityLivingBase)this);
/*     */     } 
/*     */     
/* 231 */     boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), f);
/*     */     
/* 233 */     if (flag) {
/*     */       
/* 235 */       if (i > 0 && entityIn instanceof EntityLivingBase) {
/*     */         
/* 237 */         ((EntityLivingBase)entityIn).func_70653_a((Entity)this, i * 0.5F, MathHelper.func_76126_a(this.field_70177_z * 0.017453292F), -MathHelper.func_76134_b(this.field_70177_z * 0.017453292F));
/* 238 */         this.field_70159_w *= 0.6D;
/* 239 */         this.field_70179_y *= 0.6D;
/*     */       } 
/*     */       
/* 242 */       int j = EnchantmentHelper.func_90036_a((EntityLivingBase)this);
/*     */       
/* 244 */       if (j > 0)
/*     */       {
/* 246 */         entityIn.func_70015_d(j * 4);
/*     */       }
/*     */       
/* 249 */       if (entityIn instanceof EntityPlayer) {
/*     */         
/* 251 */         EntityPlayer entityplayer = (EntityPlayer)entityIn;
/* 252 */         ItemStack itemstack = func_184614_ca();
/* 253 */         ItemStack itemstack1 = entityplayer.func_184587_cr() ? entityplayer.func_184607_cu() : ItemStack.field_190927_a;
/*     */         
/* 255 */         if (!itemstack.func_190926_b() && !itemstack1.func_190926_b() && itemstack.func_77973_b() instanceof net.minecraft.item.ItemAxe && itemstack1.func_77973_b() == Items.field_185159_cQ) {
/*     */           
/* 257 */           float f1 = 0.25F + EnchantmentHelper.func_185293_e((EntityLivingBase)this) * 0.05F;
/*     */           
/* 259 */           if (this.field_70146_Z.nextFloat() < f1) {
/*     */             
/* 261 */             entityplayer.func_184811_cZ().func_185145_a(Items.field_185159_cQ, 100);
/* 262 */             this.field_70170_p.func_72960_a((Entity)entityplayer, (byte)30);
/*     */           } 
/*     */         } 
/*     */         
/* 266 */         if (((IWerewolfCapability)((EntityPlayer)entityIn).getCapability(WereEventHandler.WERE_CAP, null)).isWerewolf())
/*     */         {
/* 268 */           if (this.field_70170_p.func_175659_aa() == EnumDifficulty.HARD) {
/* 269 */             ((EntityPlayer)entityIn).func_70690_d(new PotionEffect((Potion)HMPotions.WOLFSBANE, 200, 0, false, true));
/*     */           }
/*     */         }
/* 272 */       } else if (entityIn instanceof EntityWere) {
/*     */         
/* 274 */         if (this.field_70170_p.func_175659_aa() == EnumDifficulty.HARD) {
/* 275 */           ((EntityWere)entityIn).func_70690_d(new PotionEffect((Potion)HMPotions.WOLFSBANE, 200, 0, false, true));
/*     */         }
/*     */       } 
/* 278 */       func_174815_a((EntityLivingBase)this, entityIn);
/*     */     } 
/*     */     
/* 281 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70601_bi() {
/* 289 */     BlockPos blockpos = new BlockPos(this.field_70165_t, Math.round(this.field_70163_u), this.field_70161_v);
/* 290 */     return (this.field_70170_p.func_175659_aa() != EnumDifficulty.PEACEFUL && (this.field_70163_u > 60.0D || this.field_70170_p.func_175678_i(blockpos)) && super.func_70601_bi());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_146066_aG() {
/* 298 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_70692_ba() {
/* 307 */     return (this.field_70173_aa > 5000 && !getPersist());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_180481_a(DifficultyInstance difficulty) {
/* 315 */     super.func_180481_a(difficulty);
/* 316 */     func_184201_a(EntityEquipmentSlot.MAINHAND, new ItemStack((Item)Items.field_151031_f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public IEntityLivingData func_180482_a(DifficultyInstance difficulty, @Nullable IEntityLivingData livingdata) {
/* 326 */     livingdata = super.func_180482_a(difficulty, livingdata);
/*     */ 
/*     */     
/* 329 */     if (((Integer)this.field_70180_af.func_187225_a(HUNTER_TYPE)).intValue() == 0) {
/*     */       
/* 331 */       this.field_70714_bg.func_75776_a(4, (EntityAIBase)this.aiAttackOnCollide);
/* 332 */       func_184201_a(EntityEquipmentSlot.MAINHAND, new ItemStack(HMItems.silverSword));
/* 333 */       Random rand = new Random();
/* 334 */       if (rand.nextBoolean()) {
/* 335 */         func_184201_a(EntityEquipmentSlot.OFFHAND, new ItemStack(HMItems.moonstone));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 340 */       this.field_70714_bg.func_75776_a(4, (EntityAIBase)this.aiArrowAttack);
/* 341 */       func_180481_a(difficulty);
/* 342 */       func_180483_b(difficulty);
/*     */     } 
/*     */     
/* 345 */     func_98053_h((this.field_70146_Z.nextFloat() < 0.55F * difficulty.func_180170_c()));
/*     */     
/* 347 */     return livingdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCombatTask() {
/* 355 */     if (this.field_70170_p != null && !this.field_70170_p.field_72995_K) {
/*     */       
/* 357 */       this.field_70714_bg.func_85156_a((EntityAIBase)this.aiAttackOnCollide);
/* 358 */       this.field_70714_bg.func_85156_a((EntityAIBase)this.aiArrowAttack);
/* 359 */       ItemStack itemstack = func_184614_ca();
/*     */       
/* 361 */       if (!itemstack.func_190926_b() && itemstack.func_77973_b() == Items.field_151031_f) {
/*     */         
/* 363 */         int i = 20;
/*     */         
/* 365 */         if (this.field_70170_p.func_175659_aa() != EnumDifficulty.HARD)
/*     */         {
/* 367 */           i = 40;
/*     */         }
/*     */         
/* 370 */         this.aiArrowAttack.setAttackCooldown(i);
/* 371 */         this.field_70714_bg.func_75776_a(4, (EntityAIBase)this.aiArrowAttack);
/*     */       }
/*     */       else {
/*     */         
/* 375 */         this.field_70714_bg.func_75776_a(4, (EntityAIBase)this.aiAttackOnCollide);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistTask() {
/* 385 */     if (this.field_70170_p != null && !this.field_70170_p.field_72995_K) {
/*     */       
/* 387 */       this.field_70714_bg.func_85156_a((EntityAIBase)this.aiMoveAroundVillage);
/* 388 */       this.field_70714_bg.func_85156_a((EntityAIBase)this.aiMoveAroundLodge);
/* 389 */       this.field_70714_bg.func_85156_a((EntityAIBase)this.aiMoveToLodge);
/*     */ 
/*     */       
/* 392 */       if (getPersist()) {
/*     */         
/* 394 */         this.field_70714_bg.func_75776_a(1, (EntityAIBase)this.aiMoveAroundVillage);
/* 395 */         this.field_70714_bg.func_75776_a(2, (EntityAIBase)this.aiMoveAroundLodge);
/* 396 */         this.field_70714_bg.func_75776_a(3, (EntityAIBase)this.aiMoveToLodge);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_82196_d(EntityLivingBase target, float distanceFactor) {
/* 407 */     EntityArrow entityarrow = getArrow(distanceFactor);
/* 408 */     if (target instanceof EntityPlayer)
/*     */     {
/* 410 */       if (((IWerewolfCapability)((EntityPlayer)target).getCapability(WereEventHandler.WERE_CAP, null)).isWerewolf())
/* 411 */         entityarrow.func_70239_b(entityarrow.func_70242_d() + 2.0D); 
/*     */     }
/* 413 */     double d0 = target.field_70165_t - this.field_70165_t;
/* 414 */     double d1 = (target.func_174813_aQ()).field_72338_b + (target.field_70131_O / 3.0F) - entityarrow.field_70163_u;
/* 415 */     double d2 = target.field_70161_v - this.field_70161_v;
/* 416 */     double d3 = MathHelper.func_76133_a(d0 * d0 + d2 * d2);
/* 417 */     entityarrow.func_70186_c(d0, d1 + d3 * 0.20000000298023224D, d2, 1.6F, (14 - this.field_70170_p.func_175659_aa().func_151525_a() * 4));
/* 418 */     func_184185_a(SoundEvents.field_187866_fi, 1.0F, 1.0F / (func_70681_au().nextFloat() * 0.4F + 0.8F));
/* 419 */     this.field_70170_p.func_72838_d((Entity)entityarrow);
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityArrow getArrow(float p_190726_1_) {
/* 424 */     EntityTippedArrow entitytippedarrow = new EntityTippedArrow(this.field_70170_p, (EntityLivingBase)this);
/* 425 */     entitytippedarrow.func_190547_a((EntityLivingBase)this, p_190726_1_);
/* 426 */     if (this.field_70170_p.func_175659_aa() == EnumDifficulty.HARD)
/*     */     {
/* 428 */       entitytippedarrow.func_184558_a(new PotionEffect((Potion)HMPotions.WOLFSBANE, 200));
/*     */     }
/* 430 */     return (EntityArrow)entitytippedarrow;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70628_a(boolean wasRecentlyHit, int lootingModifier) {
/* 435 */     if (!func_184592_cb().func_190926_b())
/*     */     {
/* 437 */       if (func_184592_cb().func_77973_b() == HMItems.moonstone)
/* 438 */         func_145779_a(HMItems.moonstone, 1); 
/*     */     }
/* 440 */     Random rand = new Random();
/* 441 */     if (rand.nextInt(15) < lootingModifier) {
/* 442 */       func_70099_a(PotionUtils.func_185188_a(new ItemStack((Item)Items.field_185155_bH), PotionTypes.field_185250_v), 0.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_184724_a(boolean swingingArms) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersist(boolean persist) {
/* 454 */     this.field_70180_af.func_187227_b(PERSIST, Boolean.valueOf(persist));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getPersist() {
/* 459 */     return ((Boolean)this.field_70180_af.func_187225_a(PERSIST)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpawn(BlockPos spawn) {
/* 464 */     this.field_70180_af.func_187227_b(SPAWN, spawn);
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockPos getSpawn() {
/* 469 */     return (BlockPos)this.field_70180_af.func_187225_a(SPAWN);
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceFromSpawn() {
/* 474 */     return func_180425_c().func_177951_i((Vec3i)getSpawn());
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityHunter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */