/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import com.raz.howlingmoon.ai.EntityAIFollowOwnerHM;
/*     */ import com.raz.howlingmoon.ai.EntityAIOwnerHurtByTargetHM;
/*     */ import com.raz.howlingmoon.ai.EntityAIOwnerHurtTargetHM;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityOwnable;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackMelee;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAIHurtByTarget;
/*     */ import net.minecraft.entity.ai.EntityAILeapAtTarget;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAISwimming;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.server.management.PreYggdrasilConverter;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityWolfSpirit
/*     */   extends EntityCreature
/*     */   implements IEntityOwnable
/*     */ {
/*  47 */   protected static final DataParameter<Optional<UUID>> OWNER_UNIQUE_ID = EntityDataManager.func_187226_a(EntityTameable.class, DataSerializers.field_187203_m);
/*  48 */   private static final DataParameter<Integer> FUR_COLOR = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  49 */   private static final DataParameter<Integer> LEVEL = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  50 */   private static final DataParameter<Integer> INCLINATION = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityWolfSpirit(World worldIn) {
/*  57 */     super(worldIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityWolfSpirit(World worldIn, EntityPlayer player, int color, int level, int inclination) {
/*  62 */     super(worldIn);
/*     */     
/*  64 */     setOwner(player);
/*  65 */     setFurColor(color);
/*  66 */     setLevel(level);
/*  67 */     setInclination(inclination);
/*  68 */     applyAdditionalAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  74 */     super.func_70088_a();
/*     */     
/*  76 */     this.field_70180_af.func_187214_a(OWNER_UNIQUE_ID, Optional.absent());
/*  77 */     this.field_70180_af.func_187214_a(FUR_COLOR, Integer.valueOf(0));
/*  78 */     this.field_70180_af.func_187214_a(LEVEL, Integer.valueOf(0));
/*  79 */     this.field_70180_af.func_187214_a(INCLINATION, Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  87 */     super.func_110147_ax();
/*     */     
/*  89 */     func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e);
/*     */     
/*  91 */     func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(1.0D);
/*  92 */     func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(30.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyAdditionalAttributes() {
/*  98 */     if (getInclination() == 1) {
/*  99 */       func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a((getLevel() / 2 + getLevel() / 4));
/*     */     } else {
/* 101 */       func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a((getLevel() / 2));
/* 102 */     }  func_70606_j(func_110138_aP());
/* 103 */     func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.4D + getLevel() / 100.0D);
/* 104 */     if (getInclination() == -1) {
/* 105 */       func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(2.0D + (getLevel() / 2));
/*     */     } else {
/* 107 */       func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a((getLevel() / 2));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void func_184651_r() {
/* 112 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
/* 113 */     this.field_70714_bg.func_75776_a(4, (EntityAIBase)new EntityAILeapAtTarget((EntityLiving)this, 0.4F));
/* 114 */     this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIAttackMelee(this, 1.0D, true));
/* 115 */     this.field_70714_bg.func_75776_a(6, (EntityAIBase)new EntityAIFollowOwnerHM(this, 1.0D, 10.0F, 2.0F));
/* 116 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 8.0F));
/* 117 */     this.field_70714_bg.func_75776_a(10, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/*     */     
/* 119 */     this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIOwnerHurtByTargetHM(this));
/* 120 */     this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAIOwnerHurtTargetHM(this));
/* 121 */     this.field_70715_bh.func_75776_a(3, (EntityAIBase)new EntityAIHurtByTarget(this, true, new Class[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 127 */     super.func_70071_h_();
/*     */     
/* 129 */     if (!this.field_70170_p.field_72995_K)
/*     */     {
/* 131 */       if (this.field_70173_aa > 60 * getLevel())
/*     */       {
/* 133 */         func_70106_y();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70652_k(Entity entityIn) {
/* 140 */     boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), (int)func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e());
/*     */     
/* 142 */     if (flag)
/*     */     {
/* 144 */       func_174815_a((EntityLivingBase)this, entityIn);
/*     */     }
/*     */     
/* 147 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_70692_ba() {
/* 153 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound tagCompound) {
/* 159 */     super.func_70014_b(tagCompound);
/*     */     
/* 161 */     tagCompound.func_74768_a("FurColor", getFurColor());
/* 162 */     tagCompound.func_74768_a("Level", getLevel());
/*     */     
/* 164 */     tagCompound.func_74768_a("Inclination", getInclination());
/* 165 */     if (func_184753_b() == null) {
/*     */       
/* 167 */       tagCompound.func_74778_a("OwnerUUID", "");
/*     */     }
/*     */     else {
/*     */       
/* 171 */       tagCompound.func_74778_a("OwnerUUID", func_184753_b().toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound tagCompound) {
/*     */     String s;
/* 181 */     super.func_70037_a(tagCompound);
/*     */     
/* 183 */     setFurColor(tagCompound.func_74762_e("FurColor"));
/* 184 */     setLevel(tagCompound.func_74762_e("Level"));
/*     */     
/* 186 */     setInclination(tagCompound.func_74762_e("Inclination"));
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (tagCompound.func_150297_b("OwnerUUID", 8)) {
/*     */       
/* 192 */       s = tagCompound.func_74779_i("OwnerUUID");
/*     */     }
/*     */     else {
/*     */       
/* 196 */       String s1 = tagCompound.func_74779_i("Owner");
/* 197 */       s = PreYggdrasilConverter.func_187473_a(func_184102_h(), s1);
/*     */     } 
/*     */     
/* 200 */     if (!s.isEmpty()) {
/*     */       
/*     */       try {
/*     */         
/* 204 */         setOwnerId(UUID.fromString(s));
/*     */       }
/* 206 */       catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFurColor(int color) {
/* 214 */     this.field_70180_af.func_187227_b(FUR_COLOR, Integer.valueOf(color));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFurColor() {
/* 219 */     return ((Integer)this.field_70180_af.func_187225_a(FUR_COLOR)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLevel(int level) {
/* 224 */     this.field_70180_af.func_187227_b(LEVEL, Integer.valueOf(level));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLevel() {
/* 229 */     return ((Integer)this.field_70180_af.func_187225_a(LEVEL)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInclination(int inclination) {
/* 244 */     this.field_70180_af.func_187227_b(INCLINATION, Integer.valueOf(inclination));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInclination() {
/* 249 */     return ((Integer)this.field_70180_af.func_187225_a(INCLINATION)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOwner(EntityPlayer player) {
/* 254 */     setOwnerId(player.func_110124_au());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOwnerId(@Nullable UUID p_184754_1_) {
/* 259 */     this.field_70180_af.func_187227_b(OWNER_UNIQUE_ID, Optional.fromNullable(p_184754_1_));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public UUID func_184753_b() {
/* 266 */     return (UUID)((Optional)this.field_70180_af.func_187225_a(OWNER_UNIQUE_ID)).orNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityLivingBase getOwner() {
/*     */     try {
/* 275 */       UUID uuid = func_184753_b();
/* 276 */       return (uuid == null) ? null : (EntityLivingBase)this.field_70170_p.func_152378_a(uuid);
/*     */     }
/* 278 */     catch (IllegalArgumentException var2) {
/*     */       
/* 280 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityWolfSpirit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */