/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.ai.EntityAIMoveToSpawn;
/*     */ import com.raz.howlingmoon.handler.ConfigHandler;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.EntityAILookIdle;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityWerewolfGuide
/*     */   extends EntityCreature
/*     */ {
/*  43 */   private static final DataParameter<Integer> FUR_COLOR = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  44 */   private static final DataParameter<Integer> LEVEL = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  45 */   private static final DataParameter<Integer> INCLINATION = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  46 */   private static final DataParameter<Integer> MODEL = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187192_b);
/*  47 */   private static final DataParameter<Boolean> PROMOTE = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187198_h);
/*  48 */   private static final DataParameter<BlockPos> SPAWN = EntityDataManager.func_187226_a(EntityWerewolfGuide.class, DataSerializers.field_187200_j);
/*     */   
/*  50 */   private long nextKeyTriggerTime = 0L;
/*     */ 
/*     */   
/*     */   public EntityWerewolfGuide(World worldIn) {
/*  54 */     super(worldIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityWerewolfGuide(World worldIn, int color, int level, int inclination, int model, boolean promote, BlockPos spawn) {
/*  59 */     super(worldIn);
/*  60 */     setFurColor(color);
/*  61 */     setLevel(level);
/*  62 */     setInclination(inclination);
/*  63 */     setModel(model);
/*  64 */     setPromote(promote);
/*  65 */     setSpawn(spawn);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  70 */     super.func_70088_a();
/*     */     
/*  72 */     this.field_70180_af.func_187214_a(FUR_COLOR, Integer.valueOf(0));
/*  73 */     this.field_70180_af.func_187214_a(LEVEL, Integer.valueOf(0));
/*  74 */     this.field_70180_af.func_187214_a(INCLINATION, Integer.valueOf(0));
/*  75 */     this.field_70180_af.func_187214_a(MODEL, Integer.valueOf(0));
/*  76 */     this.field_70180_af.func_187214_a(PROMOTE, Boolean.valueOf(false));
/*  77 */     this.field_70180_af.func_187214_a(SPAWN, BlockPos.field_177992_a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  83 */     super.func_110147_ax();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_184651_r() {
/*  95 */     this.field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIMoveToSpawn(this, 2, 0.5D, 81));
/*  96 */     this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, EntityPlayer.class, 8.0F));
/*  97 */     this.field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
/* 103 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 104 */     if (wolf.isWerewolf()) {
/*     */       
/* 106 */       if (wolf.getQuestsDone() == getLevel() - 1 && wolf.getQuestsDone() < wolf.getLevel() / 5 * 2) {
/*     */         
/* 108 */         wolf.setQuestsDone(getLevel());
/* 109 */         if (!player.field_70170_p.field_72995_K)
/* 110 */           player.func_145747_a((ITextComponent)new TextComponentTranslation("guide.message.level" + getLevel(), new Object[0])); 
/*     */       } 
/* 112 */       if (getPromote() && wolf.getInclinationType() != getInclination()) {
/*     */         
/* 114 */         wolf.setInclinationType(getInclination());
/* 115 */         if (!player.field_70170_p.field_72995_K)
/* 116 */           player.func_145747_a((ITextComponent)new TextComponentTranslation("guide.message.inclination", new Object[] { wolf.getInclinationTitle() })); 
/*     */       } 
/* 118 */       return true;
/*     */     } 
/*     */     
/* 121 */     return super.func_184645_a(player, hand);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource source, float amount) {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound tagCompound) {
/* 133 */     super.func_70014_b(tagCompound);
/*     */     
/* 135 */     tagCompound.func_74768_a("FurColor", getFurColor());
/* 136 */     tagCompound.func_74768_a("Level", getLevel());
/* 137 */     tagCompound.func_74768_a("Model", getModel());
/* 138 */     tagCompound.func_74768_a("Inclination", getInclination());
/* 139 */     tagCompound.func_74757_a("Promote", getPromote());
/* 140 */     tagCompound.func_74768_a("XPos", getSpawn().func_177958_n());
/* 141 */     tagCompound.func_74768_a("YPos", getSpawn().func_177956_o());
/* 142 */     tagCompound.func_74768_a("ZPos", getSpawn().func_177952_p());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound tagCompound) {
/* 151 */     super.func_70037_a(tagCompound);
/*     */     
/* 153 */     setFurColor(tagCompound.func_74762_e("FurColor"));
/* 154 */     setLevel(tagCompound.func_74762_e("Level"));
/* 155 */     setModel(tagCompound.func_74762_e("Model"));
/* 156 */     setInclination(tagCompound.func_74762_e("Inclination"));
/* 157 */     setPromote(tagCompound.func_74767_n("Promote"));
/* 158 */     setSpawn(new BlockPos(tagCompound.func_74762_e("XPos"), tagCompound.func_74762_e("YPos"), tagCompound.func_74762_e("ZPos")));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 164 */     super.func_70071_h_();
/*     */     
/* 166 */     if (!this.field_70170_p.field_72995_K) {
/*     */       
/* 168 */       if (this.field_71093_bK != ConfigHandler.dimID) {
/* 169 */         func_70106_y();
/* 170 */       } else if (func_180425_c().func_177951_i((Vec3i)getSpawn()) > 36.0D) {
/*     */         
/* 172 */         func_70012_b(getSpawn().func_177958_n(), getSpawn().func_177956_o() + 0.1D, getSpawn().func_177952_p(), 180.0F, 0.0F);
/*     */       }
/*     */     
/* 175 */     } else if (System.currentTimeMillis() >= this.nextKeyTriggerTime) {
/*     */ 
/*     */       
/* 178 */       this.nextKeyTriggerTime = System.currentTimeMillis() + 10000L;
/* 179 */       this.field_70170_p.func_180500_c(EnumSkyBlock.BLOCK, func_180425_c());
/* 180 */       this.field_70170_p.func_180500_c(EnumSkyBlock.BLOCK, new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v - 1.0D));
/* 181 */       this.field_70170_p.func_180500_c(EnumSkyBlock.BLOCK, new BlockPos(this.field_70165_t - 1.0D, this.field_70163_u, this.field_70161_v));
/* 182 */       this.field_70170_p.func_180500_c(EnumSkyBlock.BLOCK, new BlockPos(this.field_70165_t - 1.0D, this.field_70163_u, this.field_70161_v - 1.0D));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_70692_ba() {
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_184228_n(Entity entityIn) {
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFurColor(int color) {
/* 202 */     this.field_70180_af.func_187227_b(FUR_COLOR, Integer.valueOf(color));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFurColor() {
/* 207 */     return ((Integer)this.field_70180_af.func_187225_a(FUR_COLOR)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLevel(int level) {
/* 212 */     this.field_70180_af.func_187227_b(LEVEL, Integer.valueOf(level));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLevel() {
/* 217 */     return ((Integer)this.field_70180_af.func_187225_a(LEVEL)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setModel(int model) {
/* 222 */     this.field_70180_af.func_187227_b(MODEL, Integer.valueOf(model));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModel() {
/* 227 */     return ((Integer)this.field_70180_af.func_187225_a(MODEL)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInclination(int inclination) {
/* 232 */     this.field_70180_af.func_187227_b(INCLINATION, Integer.valueOf(inclination));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInclination() {
/* 237 */     return ((Integer)this.field_70180_af.func_187225_a(INCLINATION)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPromote(boolean promote) {
/* 242 */     this.field_70180_af.func_187227_b(PROMOTE, Boolean.valueOf(promote));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getPromote() {
/* 247 */     return ((Boolean)this.field_70180_af.func_187225_a(PROMOTE)).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpawn(BlockPos spawn) {
/* 252 */     this.field_70180_af.func_187227_b(SPAWN, spawn);
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockPos getSpawn() {
/* 257 */     return (BlockPos)this.field_70180_af.func_187225_a(SPAWN);
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityWerewolfGuide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */