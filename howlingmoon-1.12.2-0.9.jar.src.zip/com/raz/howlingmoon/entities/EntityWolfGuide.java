/*    */ package com.raz.howlingmoon.entities;
/*    */ 
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityWolfGuide
/*    */   extends EntityWerewolfGuide
/*    */ {
/*    */   public EntityWolfGuide(World worldIn) {
/* 10 */     super(worldIn);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityWolfGuide(World worldIn, int color, int level, int inclination, boolean promote, BlockPos spawn) {
/* 15 */     super(worldIn, color, level, inclination, 1, promote, spawn);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityWolfGuide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */