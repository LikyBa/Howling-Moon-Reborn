/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.google.common.base.Optional;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityOwnable;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.scoreboard.Team;
/*     */ import net.minecraft.server.management.PreYggdrasilConverter;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.EnumSkyBlock;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityTameWere
/*     */   extends EntityWere
/*     */   implements IEntityOwnable
/*     */ {
/*  48 */   protected static final DataParameter<Byte> TAMED = EntityDataManager.func_187226_a(EntityTameWere.class, DataSerializers.field_187191_a);
/*  49 */   protected static final DataParameter<Optional<UUID>> OWNER_UNIQUE_ID = EntityDataManager.func_187226_a(EntityTameWere.class, DataSerializers.field_187203_m);
/*     */   
/*     */   private int tickTimer;
/*     */ 
/*     */   
/*     */   public EntityTameWere(World worldIn) {
/*  55 */     super(worldIn);
/*  56 */     this.tickTimer = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  62 */     super.func_70088_a();
/*     */ 
/*     */     
/*  65 */     this.field_70180_af.func_187214_a(TAMED, Byte.valueOf((byte)0));
/*  66 */     this.field_70180_af.func_187214_a(OWNER_UNIQUE_ID, Optional.absent());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound compound) {
/*  74 */     super.func_70014_b(compound);
/*     */     
/*  76 */     if (func_184753_b() == null) {
/*     */       
/*  78 */       compound.func_74778_a("OwnerUUID", "");
/*     */     }
/*     */     else {
/*     */       
/*  82 */       compound.func_74778_a("OwnerUUID", func_184753_b().toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound compound) {
/*     */     String s;
/*  93 */     super.func_70037_a(compound);
/*     */ 
/*     */     
/*  96 */     if (compound.func_150297_b("OwnerUUID", 8)) {
/*     */       
/*  98 */       s = compound.func_74779_i("OwnerUUID");
/*     */     }
/*     */     else {
/*     */       
/* 102 */       String s1 = compound.func_74779_i("Owner");
/* 103 */       s = PreYggdrasilConverter.func_187473_a(func_184102_h(), s1);
/*     */     } 
/*     */     
/* 106 */     if (!s.isEmpty()) {
/*     */       
/*     */       try {
/*     */         
/* 110 */         setOwnerId(UUID.fromString(s));
/* 111 */         setTamed(true);
/*     */       }
/* 113 */       catch (Throwable var4) {
/*     */         
/* 115 */         setTamed(false);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/* 166 */     super.func_70636_d();
/*     */     
/* 168 */     if (!this.field_70170_p.field_72995_K) {
/*     */       
/* 170 */       if (func_70638_az() == null && isAngry()) {
/*     */         
/* 172 */         setAngry(false);
/*     */       }
/* 174 */       else if (func_70638_az() instanceof EntityTameWere) {
/*     */       
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       if (isTamed()) {
/*     */         
/* 184 */         this.tickTimer++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 212 */         if (this.tickTimer > 2400) {
/*     */           
/* 214 */           this.tickTimer = getHunger() - 1;
/* 215 */           if (this.tickTimer < 0)
/* 216 */             this.tickTimer = 0; 
/* 217 */           setHunger(this.tickTimer);
/* 218 */           this.tickTimer = 0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70071_h_() {
/* 227 */     super.func_70071_h_();
/*     */     
/* 229 */     if (!this.field_70170_p.field_72995_K && !isTamed() && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/*     */     {
/* 231 */       func_70106_y();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent func_184184_Z() {
/* 238 */     return SoundEvents.field_187593_cC;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent func_184181_aa() {
/* 244 */     return SoundEvents.field_187591_cB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent getHurtSound() {
/* 253 */     return SoundEvents.field_187863_gH;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent func_184615_bR() {
/* 259 */     return SoundEvents.field_187859_gF;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected SoundEvent func_184588_d(int heightIn) {
/* 265 */     return (heightIn > 4) ? SoundEvents.field_187735_cx : SoundEvents.field_187589_cA;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float func_180484_a(BlockPos pos) {
/* 271 */     return 0.5F - this.field_70170_p.func_175724_o(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValidLightLevel() {
/* 276 */     BlockPos blockpos = new BlockPos(this.field_70165_t, (func_174813_aQ()).field_72338_b, this.field_70161_v);
/*     */     
/* 278 */     if (this.field_70170_p.func_175642_b(EnumSkyBlock.SKY, blockpos) > this.field_70146_Z.nextInt(32))
/*     */     {
/* 280 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 284 */     int i = this.field_70170_p.func_175671_l(blockpos);
/*     */     
/* 286 */     if (this.field_70170_p.func_72911_I()) {
/*     */       
/* 288 */       int j = this.field_70170_p.func_175657_ab();
/* 289 */       this.field_70170_p.func_175692_b(10);
/* 290 */       i = this.field_70170_p.func_175671_l(blockpos);
/* 291 */       this.field_70170_p.func_175692_b(j);
/*     */     } 
/*     */     
/* 294 */     return (i <= this.field_70146_Z.nextInt(8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70601_bi() {
/* 301 */     return (this.field_70170_p.func_175659_aa() != EnumDifficulty.PEACEFUL && isValidLightLevel() && super.func_70601_bi());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void playTameEffect(boolean p_70908_1_) {
/* 309 */     EnumParticleTypes enumparticletypes = EnumParticleTypes.HEART;
/*     */     
/* 311 */     if (!p_70908_1_)
/*     */     {
/* 313 */       enumparticletypes = EnumParticleTypes.SMOKE_NORMAL;
/*     */     }
/*     */     
/* 316 */     for (int i = 0; i < 7; i++) {
/*     */       
/* 318 */       double d0 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 319 */       double d1 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 320 */       double d2 = this.field_70146_Z.nextGaussian() * 0.02D;
/* 321 */       this.field_70170_p.func_175688_a(enumparticletypes, this.field_70165_t + (this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0F) - this.field_70130_N, this.field_70163_u + 0.5D + (this.field_70146_Z.nextFloat() * this.field_70131_O), this.field_70161_v + (this.field_70146_Z.nextFloat() * this.field_70130_N * 2.0F) - this.field_70130_N, d0, d1, d2, new int[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_70103_a(byte id) {
/* 328 */     if (id == 7) {
/*     */       
/* 330 */       playTameEffect(true);
/*     */     }
/* 332 */     else if (id == 6) {
/*     */       
/* 334 */       playTameEffect(false);
/*     */     }
/*     */     else {
/*     */       
/* 338 */       super.func_70103_a(id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAngry() {
/* 347 */     return ((((Byte)this.field_70180_af.func_187225_a(TAMED)).byteValue() & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngry(boolean angry) {
/* 355 */     byte b0 = ((Byte)this.field_70180_af.func_187225_a(TAMED)).byteValue();
/*     */     
/* 357 */     if (angry) {
/*     */       
/* 359 */       this.field_70180_af.func_187227_b(TAMED, Byte.valueOf((byte)(b0 | 0x2)));
/*     */     }
/*     */     else {
/*     */       
/* 363 */       this.field_70180_af.func_187227_b(TAMED, Byte.valueOf((byte)(b0 & 0xFFFFFFFD)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTamed() {
/* 393 */     return ((((Byte)this.field_70180_af.func_187225_a(TAMED)).byteValue() & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTamed(boolean tamed) {
/* 398 */     byte b0 = ((Byte)this.field_70180_af.func_187225_a(TAMED)).byteValue();
/*     */     
/* 400 */     if (tamed) {
/*     */       
/* 402 */       this.field_70180_af.func_187227_b(TAMED, Byte.valueOf((byte)(b0 | 0x4)));
/*     */     }
/*     */     else {
/*     */       
/* 406 */       this.field_70180_af.func_187227_b(TAMED, Byte.valueOf((byte)(b0 & 0xFFFFFFFB)));
/*     */     } 
/*     */     
/* 409 */     setupTamedAI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupTamedAI() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public UUID func_184753_b() {
/* 472 */     return (UUID)((Optional)this.field_70180_af.func_187225_a(OWNER_UNIQUE_ID)).orNull();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOwnerId(@Nullable UUID p_184754_1_) {
/* 477 */     this.field_70180_af.func_187227_b(OWNER_UNIQUE_ID, Optional.fromNullable(p_184754_1_));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityLivingBase getOwner() {
/*     */     try {
/* 485 */       UUID uuid = func_184753_b();
/* 486 */       return (uuid == null) ? null : (EntityLivingBase)this.field_70170_p.func_152378_a(uuid);
/*     */     }
/* 488 */     catch (IllegalArgumentException var2) {
/*     */       
/* 490 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOwner(EntityLivingBase entityIn) {
/* 496 */     return (entityIn == getOwner());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_142018_a(EntityLivingBase p_142018_1_, EntityLivingBase p_142018_2_) {
/* 504 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Team func_96124_cp() {
/* 509 */     if (isTamed()) {
/*     */       
/* 511 */       EntityLivingBase entitylivingbase = getOwner();
/*     */       
/* 513 */       if (entitylivingbase != null)
/*     */       {
/* 515 */         return entitylivingbase.func_96124_cp();
/*     */       }
/*     */     } 
/*     */     
/* 519 */     return super.func_96124_cp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184191_r(Entity entityIn) {
/* 527 */     if (isTamed()) {
/*     */       
/* 529 */       EntityLivingBase entitylivingbase = getOwner();
/*     */       
/* 531 */       if (entityIn == entitylivingbase)
/*     */       {
/* 533 */         return true;
/*     */       }
/*     */       
/* 536 */       if (entitylivingbase != null)
/*     */       {
/* 538 */         return entitylivingbase.func_184191_r(entityIn);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 558 */     return super.func_184191_r(entityIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70645_a(DamageSource cause) {
/* 571 */     if (!this.field_70170_p.field_72995_K && this.field_70170_p.func_82736_K().func_82766_b("showDeathMessages") && getOwner() instanceof net.minecraft.entity.player.EntityPlayerMP)
/*     */     {
/* 573 */       getOwner().func_145747_a(func_110142_aN().func_151521_b());
/*     */     }
/*     */     
/* 576 */     super.func_70645_a(cause);
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityTameWere.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */