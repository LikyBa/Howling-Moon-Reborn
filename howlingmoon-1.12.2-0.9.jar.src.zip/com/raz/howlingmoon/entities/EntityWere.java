/*     */ package com.raz.howlingmoon.entities;
/*     */ 
/*     */ import com.raz.howlingmoon.HMPotions;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncInfectedMessage;
/*     */ import com.raz.howlingmoon.packets.SyncWerewolfTextureMessage;
/*     */ import java.util.Random;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.monster.IMob;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.datasync.DataParameter;
/*     */ import net.minecraft.network.datasync.DataSerializers;
/*     */ import net.minecraft.network.datasync.EntityDataManager;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityWere
/*     */   extends EntityCreature
/*     */   implements IMob
/*     */ {
/*  44 */   private static final DataParameter<Integer> AI = EntityDataManager.func_187226_a(EntityWere.class, DataSerializers.field_187192_b);
/*  45 */   private static final DataParameter<Integer> AI2 = EntityDataManager.func_187226_a(EntityWere.class, DataSerializers.field_187192_b);
/*  46 */   private static final DataParameter<Integer> FUR_COLOR = EntityDataManager.func_187226_a(EntityWere.class, DataSerializers.field_187192_b);
/*  47 */   private static final DataParameter<Integer> HUNGER = EntityDataManager.func_187226_a(EntityWere.class, DataSerializers.field_187192_b);
/*     */   
/*     */   public int rally;
/*     */   private int regenTick;
/*     */   
/*     */   public EntityWere(World worldIn) {
/*  53 */     super(worldIn);
/*  54 */     this.rally = 0;
/*  55 */     this.regenTick = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  61 */     super.func_70088_a();
/*     */     
/*  63 */     this.field_70180_af.func_187214_a(AI, Integer.valueOf(0));
/*  64 */     this.field_70180_af.func_187214_a(AI2, Integer.valueOf(0));
/*  65 */     this.field_70180_af.func_187214_a(FUR_COLOR, Integer.valueOf(0));
/*  66 */     this.field_70180_af.func_187214_a(HUNGER, Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_110147_ax() {
/*  91 */     super.func_110147_ax();
/*  92 */     func_110140_aT().func_111150_b(SharedMonsterAttributes.field_111264_e);
/*     */ 
/*     */ 
/*     */     
/*  96 */     Random rnd = new Random();
/*  97 */     int temp = 0;
/*     */     
/*  99 */     if (rnd.nextInt(5) > 0)
/* 100 */       temp++; 
/* 101 */     if (rnd.nextInt(5) > 1)
/* 102 */       temp += 2; 
/* 103 */     if (rnd.nextInt(5) > 2)
/* 104 */       temp += 4; 
/* 105 */     if (rnd.nextInt(5) > 3)
/* 106 */       temp += 8; 
/* 107 */     if (rnd.nextInt(5) > 2) {
/* 108 */       temp += 16;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 113 */     if (rnd.nextInt(10) > 6)
/* 114 */       temp += 32; 
/* 115 */     if (rnd.nextInt(10) == 0)
/* 116 */       temp += 64; 
/* 117 */     if (rnd.nextInt(25) == 0) {
/* 118 */       temp += 128;
/* 119 */     } else if (rnd.nextInt(20) == 0) {
/* 120 */       temp += 256;
/*     */     } 
/*     */     
/* 123 */     this.field_70180_af.func_187227_b(AI, Integer.valueOf(temp));
/*     */     
/* 125 */     temp = 0;
/*     */     
/* 127 */     if (rnd.nextInt(20) == 0)
/* 128 */       temp++; 
/* 129 */     if (rnd.nextInt(20) == 0)
/* 130 */       temp += 2; 
/* 131 */     if (rnd.nextInt(50) == 0)
/* 132 */       temp += 4; 
/* 133 */     if (rnd.nextInt(30) == 0) {
/* 134 */       temp += 8;
/* 135 */     } else if (rnd.nextInt(20) == 0) {
/* 136 */       temp += 16;
/* 137 */     }  if (rnd.nextInt(3) > 1)
/* 138 */       temp += 32; 
/* 139 */     if (rnd.nextInt(5) > 2) {
/* 140 */       temp += 64;
/* 141 */     } else if (rnd.nextInt(100) == 0) {
/* 142 */       temp += 128;
/* 143 */     }  this.field_70180_af.func_187227_b(AI2, Integer.valueOf(temp));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     setFurColor(rnd.nextInt(4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound tagCompound) {
/* 155 */     super.func_70014_b(tagCompound);
/*     */     
/* 157 */     tagCompound.func_74768_a("AI", ((Integer)func_184212_Q().func_187225_a(AI)).intValue());
/* 158 */     tagCompound.func_74768_a("AI2", ((Integer)func_184212_Q().func_187225_a(AI2)).intValue());
/* 159 */     tagCompound.func_74768_a("FurColor", getFurColor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound tagCompound) {
/* 173 */     super.func_70037_a(tagCompound);
/*     */     
/* 175 */     this.field_70180_af.func_187227_b(AI, Integer.valueOf(tagCompound.func_74762_e("AI")));
/* 176 */     this.field_70180_af.func_187227_b(AI2, Integer.valueOf(tagCompound.func_74762_e("AI2")));
/* 177 */     setFurColor(tagCompound.func_74762_e("FurColor"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70652_k(Entity entityIn) {
/* 189 */     float f = (float)func_110148_a(SharedMonsterAttributes.field_111264_e).func_111126_e();
/* 190 */     int i = 0;
/*     */     
/* 192 */     if (this.rally > 0) {
/* 193 */       f += 2.0F;
/*     */     }
/* 195 */     if (entityIn instanceof EntityLivingBase) {
/*     */       
/* 197 */       f += EnchantmentHelper.func_152377_a(func_184614_ca(), ((EntityLivingBase)entityIn).func_70668_bt());
/* 198 */       i += EnchantmentHelper.func_77501_a((EntityLivingBase)this);
/* 199 */       if (hasKnockback()) {
/* 200 */         i += 2;
/*     */       }
/*     */     } 
/* 203 */     boolean flag = entityIn.func_70097_a(DamageSource.func_76358_a((EntityLivingBase)this), f);
/*     */     
/* 205 */     if (flag) {
/*     */       
/* 207 */       if (i > 0 && entityIn instanceof EntityLivingBase) {
/*     */         
/* 209 */         ((EntityLivingBase)entityIn).func_70653_a((Entity)this, i * 0.5F, MathHelper.func_76126_a(this.field_70177_z * 0.017453292F), -MathHelper.func_76134_b(this.field_70177_z * 0.017453292F));
/* 210 */         this.field_70159_w *= 0.6D;
/* 211 */         this.field_70179_y *= 0.6D;
/*     */       } 
/*     */       
/* 214 */       int j = EnchantmentHelper.func_90036_a((EntityLivingBase)this);
/*     */       
/* 216 */       if (j > 0)
/*     */       {
/* 218 */         entityIn.func_70015_d(j * 4);
/*     */       }
/*     */       
/* 221 */       if (entityIn instanceof EntityPlayer) {
/*     */         
/* 223 */         EntityPlayer entityplayer = (EntityPlayer)entityIn;
/* 224 */         ItemStack itemstack = func_184614_ca();
/* 225 */         ItemStack itemstack1 = entityplayer.func_184587_cr() ? entityplayer.func_184607_cu() : ItemStack.field_190927_a;
/*     */         
/* 227 */         if (!itemstack.func_190926_b() && !itemstack1.func_190926_b() && itemstack.func_77973_b() instanceof net.minecraft.item.ItemAxe && itemstack1.func_77973_b() == Items.field_185159_cQ) {
/*     */           
/* 229 */           float f1 = 0.25F + EnchantmentHelper.func_185293_e((EntityLivingBase)this) * 0.05F;
/*     */           
/* 231 */           if (this.field_70146_Z.nextFloat() < f1) {
/*     */             
/* 233 */             entityplayer.func_184811_cZ().func_185145_a(Items.field_185159_cQ, 100);
/* 234 */             this.field_70170_p.func_72960_a((Entity)entityplayer, (byte)30);
/*     */           } 
/*     */         } 
/*     */         
/* 238 */         IWerewolfCapability wolf = (IWerewolfCapability)entityplayer.getCapability(WereEventHandler.WERE_CAP, null);
/* 239 */         if (!wolf.isWerewolf() && wolf.getInfected() == 0) {
/*     */           
/* 241 */           wolf.setInfected(1);
/* 242 */           PacketDispatcher.sendTo((IMessage)new SyncInfectedMessage(entityplayer), (EntityPlayerMP)entityplayer);
/* 243 */           entityplayer.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.infected", new Object[0]));
/* 244 */           wolf.setTexture(getFurColor());
/* 245 */           PacketDispatcher.sendTo((IMessage)new SyncWerewolfTextureMessage(entityplayer), (EntityPlayerMP)entityplayer);
/*     */         } 
/*     */       } 
/*     */       
/* 249 */       func_174815_a((EntityLivingBase)this, entityIn);
/*     */     } 
/*     */     
/* 252 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70097_a(DamageSource source, float amount) {
/* 335 */     if (func_180431_b(source))
/*     */     {
/* 337 */       return false;
/*     */     }
/* 339 */     return super.func_70097_a(source, amount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70636_d() {
/* 363 */     super.func_70636_d();
/*     */     
/* 365 */     if (!this.field_70170_p.field_72995_K) {
/*     */       
/* 367 */       if (!func_70644_a((Potion)HMPotions.SILVERPOISON)) {
/*     */         
/* 369 */         this.regenTick++;
/* 370 */         if (this.regenTick > 24) {
/*     */           
/* 372 */           if (func_110143_aJ() < func_110138_aP())
/* 373 */             func_70691_i(1.0F); 
/* 374 */           this.regenTick = 0;
/*     */         } 
/*     */       } 
/* 377 */       if (this.rally > 0) {
/* 378 */         this.rally--;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int numberOfSetBits(int i) {
/* 386 */     i -= i >>> 1 & 0x55555555;
/* 387 */     i = (i & 0x33333333) + (i >>> 2 & 0x33333333);
/* 388 */     return (i + (i >>> 4) & 0xF0F0F0F) * 16843009 >>> 24;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStaticBehaviors() {
/* 393 */     return ((Integer)this.field_70180_af.func_187225_a(AI)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDynamicBehaviors() {
/* 398 */     return ((Integer)this.field_70180_af.func_187225_a(AI2)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAvoidWater() {
/* 403 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 5 & 0x1) == 1)
/*     */     {
/* 405 */       return true;
/*     */     }
/* 407 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAvoidWater(boolean set) {
/* 412 */     int temp = ((Integer)this.field_70180_af.func_187225_a(AI2)).intValue();
/* 413 */     int to = set ? 1 : 0;
/* 414 */     if ((temp >> 5 & 0x1) != to) {
/*     */       
/* 416 */       if (set) {
/* 417 */         temp += 32;
/*     */       } else {
/* 419 */         temp -= 32;
/*     */       } 
/* 421 */       this.field_70180_af.func_187227_b(AI2, Integer.valueOf(temp));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBreakDoors() {
/* 427 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 6 & 0x1) == 1)
/*     */     {
/* 429 */       return true;
/*     */     }
/* 431 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBreakDoors(boolean set) {
/* 436 */     int temp = ((Integer)this.field_70180_af.func_187225_a(AI2)).intValue();
/* 437 */     int to = set ? 1 : 0;
/* 438 */     if ((temp >> 6 & 0x1) != to) {
/*     */       
/* 440 */       if (set) {
/* 441 */         temp += 64;
/*     */       } else {
/* 443 */         temp -= 64;
/*     */       } 
/* 445 */       this.field_70180_af.func_187227_b(AI2, Integer.valueOf(temp));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getOpenDoors() {
/* 451 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 7 & 0x1) == 1)
/*     */     {
/* 453 */       return true;
/*     */     }
/* 455 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOpenDoors(boolean set) {
/* 460 */     int temp = ((Integer)this.field_70180_af.func_187225_a(AI2)).intValue();
/* 461 */     int to = set ? 1 : 0;
/* 462 */     if ((temp >> 7 & 0x1) != to) {
/*     */       
/* 464 */       if (set) {
/* 465 */         temp += 128;
/*     */       } else {
/* 467 */         temp -= 128;
/*     */       } 
/* 469 */       this.field_70180_af.func_187227_b(AI2, Integer.valueOf(temp));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAvoidFire() {
/* 475 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 5 & 0x1) == 1)
/*     */     {
/* 477 */       return true;
/*     */     }
/* 479 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesAttackPlayers() {
/* 484 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() & 0x1) == 1)
/*     */     {
/* 486 */       return true;
/*     */     }
/* 488 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesAttackAnimals() {
/* 493 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 1 & 0x1) == 1)
/*     */     {
/* 495 */       return true;
/*     */     }
/* 497 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesAttackVillagers() {
/* 502 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 2 & 0x1) == 1)
/*     */     {
/* 504 */       return true;
/*     */     }
/* 506 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesAttackBones() {
/* 511 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 3 & 0x1) == 1)
/*     */     {
/* 513 */       return true;
/*     */     }
/* 515 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesLeap() {
/* 520 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 4 & 0x1) == 1)
/*     */     {
/* 522 */       return true;
/*     */     }
/* 524 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getHatesFire() {
/* 529 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 5 & 0x1) == 1)
/*     */     {
/* 531 */       return true;
/*     */     }
/* 533 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getLikesMusic() {
/* 538 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 6 & 0x1) == 1)
/*     */     {
/* 540 */       return true;
/*     */     }
/* 542 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getLovesCake() {
/* 547 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 7 & 0x1) == 1)
/*     */     {
/* 549 */       return true;
/*     */     }
/* 551 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getLikesCake() {
/* 556 */     if ((((Integer)this.field_70180_af.func_187225_a(AI)).intValue() >> 8 & 0x1) == 1)
/*     */     {
/* 558 */       return true;
/*     */     }
/* 560 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKnockback() {
/* 565 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() & 0x1) == 1)
/*     */     {
/* 567 */       return true;
/*     */     }
/* 569 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKnockbackResistance() {
/* 574 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 1 & 0x1) == 1)
/*     */     {
/* 576 */       return true;
/*     */     }
/* 578 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAgile() {
/* 583 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 2 & 0x1) == 1)
/*     */     {
/* 585 */       return true;
/*     */     }
/* 587 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubmissve() {
/* 592 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 3 & 0x1) == 1)
/*     */     {
/* 594 */       return true;
/*     */     }
/* 596 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWild() {
/* 601 */     if ((((Integer)this.field_70180_af.func_187225_a(AI2)).intValue() >> 4 & 0x1) == 1)
/*     */     {
/* 603 */       return true;
/*     */     }
/* 605 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSavageryLevel() {
/* 610 */     int temp = 1;
/* 611 */     if (doesAttackPlayers())
/* 612 */       temp++; 
/* 613 */     if (doesAttackAnimals())
/* 614 */       temp++; 
/* 615 */     if (doesAttackVillagers())
/* 616 */       temp += 2; 
/* 617 */     return temp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHunger() {
/* 622 */     return ((Integer)this.field_70180_af.func_187225_a(HUNGER)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean needsToFeed() {
/* 627 */     if (getHunger() < 1)
/* 628 */       return true; 
/* 629 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFood(int amount) {
/* 634 */     int temp = getHunger() + amount;
/* 635 */     if (temp > 20)
/* 636 */       temp = 20; 
/* 637 */     this.field_70180_af.func_187227_b(HUNGER, Integer.valueOf(temp));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHunger(int amount) {
/* 642 */     if (amount > 20)
/* 643 */       amount = 20; 
/* 644 */     this.field_70180_af.func_187227_b(HUNGER, Integer.valueOf(amount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFurColor(int color) {
/* 658 */     this.field_70180_af.func_187227_b(FUR_COLOR, Integer.valueOf(color));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFurColor() {
/* 663 */     return ((Integer)this.field_70180_af.func_187225_a(FUR_COLOR)).intValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\entities\EntityWere.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */