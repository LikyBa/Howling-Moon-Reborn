/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import com.raz.howlingmoon.blocks.HMBlocks;
/*    */ import com.raz.howlingmoon.items.HMItems;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.NonNullList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMCreativeTab
/*    */   extends CreativeTabs
/*    */ {
/* 18 */   public static HMCreativeTab INSTANCE = new HMCreativeTab();
/*    */   NonNullList<ItemStack> list;
/*    */   
/*    */   public HMCreativeTab() {
/* 22 */     super("howlingmoon");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack func_151244_d() {
/* 28 */     return new ItemStack(Items.field_151122_aG);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemStack func_78016_d() {
/* 33 */     return func_151244_d();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_78018_a(NonNullList<ItemStack> p_78018_1_) {
/* 39 */     this.list = p_78018_1_;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     addBlock((Block)HMBlocks.silverOre);
/* 45 */     addBlock((Block)HMBlocks.wolfsbane);
/* 46 */     addBlock((Block)HMBlocks.hunterBanner);
/* 47 */     addItem(HMItems.silverIngot);
/* 48 */     addItem(HMItems.silverSword);
/* 49 */     addItem(HMItems.moonstone);
/* 50 */     addItem(HMItems.potionWolfsbane);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void addItem(Item item) {
/* 81 */     item.func_150895_a(this, this.list);
/*    */   }
/*    */   
/*    */   private void addBlock(Block block) {
/* 85 */     ItemStack stack = new ItemStack(block);
/* 86 */     block.func_149666_a(this, this.list);
/*    */   }
/*    */   
/*    */   private void addStack(ItemStack stack) {
/* 90 */     this.list.add(stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\HMCreativeTab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */