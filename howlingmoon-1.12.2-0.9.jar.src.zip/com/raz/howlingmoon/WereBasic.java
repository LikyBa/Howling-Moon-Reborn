/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WereBasic
/*    */   extends WereBase
/*    */ {
/*    */   private final String key;
/*    */   private final ResourceLocation texture;
/*    */   
/*    */   public WereBasic(String key, String unlocalizedName, ResourceLocation texture) {
/* 15 */     super(unlocalizedName);
/* 16 */     this.key = key;
/* 17 */     this.texture = texture;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WereBasic registerStat() {
/* 26 */     WereList.BASIC.add(this);
/* 27 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 32 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceLocation getTexture() {
/* 37 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereBasic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */