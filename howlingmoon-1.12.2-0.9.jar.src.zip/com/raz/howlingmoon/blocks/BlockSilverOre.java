/*    */ package com.raz.howlingmoon.blocks;
/*    */ 
/*    */ import com.raz.howlingmoon.HowlingMoon;
/*    */ import com.raz.howlingmoon.IModelRegister;
/*    */ import com.raz.howlingmoon.items.HMItems;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockSilverOre
/*    */   extends Block
/*    */   implements IModelRegister
/*    */ {
/*    */   public BlockSilverOre() {
/* 18 */     super(Material.field_151576_e);
/* 19 */     func_149663_c("howlingmoon.ore_silver");
/* 20 */     setHarvestLevel("pickaxe", 2);
/* 21 */     setRegistryName("ore_silver");
/*    */     
/* 23 */     HMBlocks.BLOCKS.add(this);
/* 24 */     HMItems.ITEMS.add((new ItemBlock(this)).setRegistryName(getRegistryName()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerModels() {
/* 33 */     HowlingMoon.proxy.registerItemRenderer(Item.func_150898_a(this), 0, "inventory");
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\blocks\BlockSilverOre.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */