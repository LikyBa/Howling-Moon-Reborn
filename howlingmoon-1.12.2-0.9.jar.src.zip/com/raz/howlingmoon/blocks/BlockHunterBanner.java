/*     */ package com.raz.howlingmoon.blocks;
/*     */ 
/*     */ import com.raz.howlingmoon.HMCreativeTab;
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IModelRegister;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.entities.TileEntityHunterBanner;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.BlockFaceShape;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockHunterBanner
/*     */   extends Block
/*     */   implements IModelRegister, ITileEntityProvider
/*     */ {
/*  44 */   private final String name = "hunter_banner";
/*     */ 
/*     */   
/*     */   protected BlockHunterBanner() {
/*  48 */     super(Material.field_151575_d);
/*  49 */     setRegistryName("hunter_banner");
/*  50 */     func_149663_c("howlingmoon.hunter_banner");
/*  51 */     func_149711_c(2.0F);
/*     */     
/*  53 */     HMBlocks.BLOCKS.add(this);
/*  54 */     HMItems.ITEMS.add((new ItemBlock(this)).setRegistryName(getRegistryName()));
/*     */     
/*  56 */     func_149647_a((CreativeTabs)HMCreativeTab.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerModels() {
/*  62 */     HowlingMoon.proxy.registerItemRenderer(Item.func_150898_a(this), 0, "inventory");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AxisAlignedBB func_180646_a(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
/*  68 */     return field_185506_k;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d(IBlockState state) {
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176205_b(IBlockAccess worldIn, BlockPos pos) {
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c(IBlockState state) {
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_181623_g() {
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasTileEntity(IBlockState state) {
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World worldIn, int meta) {
/* 110 */     return (TileEntity)new TileEntityHunterBanner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180633_a(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
/* 116 */     super.func_180633_a(worldIn, pos, state, placer, stack);
/* 117 */     if (placer instanceof EntityPlayer) {
/*     */       
/* 119 */       IWerewolfCapability wolf = (IWerewolfCapability)((EntityPlayer)placer).getCapability(WereEventHandler.WERE_CAP, null);
/* 120 */       if (wolf.isWerewolf()) {
/*     */         
/* 122 */         TileEntity tileentity = worldIn.func_175625_s(pos);
/* 123 */         if (tileentity instanceof TileEntityHunterBanner) {
/* 124 */           TileEntityHunterBanner tileEntityData = (TileEntityHunterBanner)tileentity;
/* 125 */           tileEntityData.setIsGuild(false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BlockRenderLayer func_180664_k() {
/* 134 */     return BlockRenderLayer.CUTOUT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockFaceShape func_193383_a(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
/* 148 */     return BlockFaceShape.UNDEFINED;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\blocks\BlockHunterBanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */