/*     */ package com.raz.howlingmoon.blocks;
/*     */ 
/*     */ import com.raz.howlingmoon.HMCreativeTab;
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IModelRegister;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockBush;
/*     */ import net.minecraft.block.IGrowable;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class BlockWolfsbane
/*     */   extends BlockBush
/*     */   implements IGrowable, IModelRegister
/*     */ {
/*  26 */   private final String name = "wolfsbane";
/*     */ 
/*     */   
/*     */   public BlockWolfsbane() {
/*  30 */     super(Material.field_151585_k);
/*  31 */     setRegistryName("wolfsbane");
/*  32 */     func_149663_c("howlingmoon.wolfsbane");
/*     */     
/*  34 */     HMBlocks.BLOCKS.add(this);
/*  35 */     HMItems.ITEMS.add((new ItemBlock((Block)this)).setRegistryName(getRegistryName()));
/*     */     
/*  37 */     func_149647_a((CreativeTabs)HMCreativeTab.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerModels() {
/*  43 */     HowlingMoon.proxy.registerItemRenderer(Item.func_150898_a((Block)this), 0, "inventory");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  48 */     return "wolfsbane";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176473_a(World worldIn, BlockPos pos, IBlockState state, boolean isClient) {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180670_a(World worldIn, Random rand, BlockPos pos, IBlockState state) {
/*  60 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_176474_b(World worldIn, Random rand, BlockPos pos, IBlockState state) {
/*  66 */     BlockPos blockpos1 = pos.func_177984_a();
/*  67 */     int i = 0;
/*     */     
/*  69 */     label22: while (i < 128) {
/*     */       
/*  71 */       BlockPos blockpos2 = blockpos1;
/*  72 */       int j = 0;
/*     */ 
/*     */ 
/*     */       
/*  76 */       while (j < i / 16) {
/*     */         
/*  78 */         blockpos2 = blockpos2.func_177982_a(rand.nextInt(3) - 1, (rand.nextInt(3) - 1) * rand.nextInt(3) / 2, rand.nextInt(3) - 1);
/*     */         
/*  80 */         if (worldIn.func_180495_p(blockpos2.func_177977_b()).func_177230_c() == Blocks.field_150349_c) { if (!worldIn.func_180495_p(blockpos2).func_177230_c().isNormalCube(worldIn.func_180495_p(blockpos2), (IBlockAccess)worldIn, blockpos2)) {
/*     */             
/*  82 */             j++; continue;
/*     */           }  continue label22; }
/*     */          continue label22;
/*     */       } 
/*  86 */       if (worldIn.func_175623_d(blockpos2))
/*     */       {
/*  88 */         if (rand.nextInt(8) == 0) {
/*     */ 
/*     */           
/*  91 */           IBlockState iblockstate2 = HMBlocks.wolfsbane.func_176223_P();
/*     */           
/*  93 */           if (HMBlocks.wolfsbane.func_180671_f(worldIn, blockpos2, iblockstate2))
/*     */           {
/*  95 */             worldIn.func_180501_a(blockpos2, iblockstate2, 3);
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 100 */       i++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\blocks\BlockWolfsbane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */