/*    */ package com.raz.howlingmoon.blocks;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMBlocks
/*    */ {
/* 19 */   public static final List<Block> BLOCKS = new ArrayList<>();
/*    */   
/* 21 */   public static final BlockSilverOre silverOre = new BlockSilverOre();
/* 22 */   public static final BlockWolfsbane wolfsbane = new BlockWolfsbane();
/* 23 */   public static final BlockHunterBanner hunterBanner = new BlockHunterBanner();
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\blocks\HMBlocks.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */