/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public class WereAbility
/*    */   extends WereBase
/*    */ {
/*    */   private final String key;
/*    */   private boolean unlockable;
/*    */   public final List<WereAbility> parentAbilities;
/*    */   private final ResourceLocation texture;
/*    */   
/*    */   public WereAbility(String key, String unlocalizedName, ResourceLocation texture, boolean unlockable) {
/* 17 */     this(key, unlocalizedName, (WereAbility)null, texture, unlockable);
/*    */   }
/*    */   
/*    */   public WereAbility(String key, String unlocalizedName, WereAbility parent, ResourceLocation texture, boolean unlockable) {
/* 21 */     this(key, unlocalizedName, Arrays.asList(new WereAbility[] { parent }, ), texture, unlockable);
/*    */   }
/*    */   
/*    */   public WereAbility(String key, String unlocalizedName, List<WereAbility> parents, ResourceLocation texture, boolean unlockable) {
/* 25 */     super(unlocalizedName);
/* 26 */     this.key = key;
/* 27 */     this.parentAbilities = parents;
/* 28 */     this.texture = texture;
/* 29 */     this.unlockable = unlockable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WereAbility registerStat() {
/* 38 */     WereList.ABILITIES.add(this);
/* 39 */     if (this.unlockable) {
/* 40 */       WereList.UNLOCKABILITIES.add(this);
/*    */     } else {
/* 42 */       WereList.QUESTABILITIES.add(this);
/* 43 */     }  return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 48 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canUnlock(IWerewolfCapability wolf) {
/* 53 */     if (!this.unlockable || wolf.getAbilityTreeAbility(getKey()))
/* 54 */       return false; 
/* 55 */     if (this.parentAbilities == null)
/* 56 */       return true; 
/* 57 */     for (int i = 0; i < this.parentAbilities.size(); i++) {
/*    */       
/* 59 */       if (this.parentAbilities.get(i) != null)
/*    */       {
/* 61 */         if (!wolf.getAbilityTreeAbility(((WereAbility)this.parentAbilities.get(i)).getKey()))
/*    */         {
/* 63 */           return false;
/*    */         }
/*    */       }
/*    */     } 
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean havePointsFor(IWerewolfCapability wolf) {
/* 72 */     if (wolf.getUsuableAbilityPoints() > 0)
/* 73 */       return true; 
/* 74 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceLocation getTexture() {
/* 79 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereAbility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */