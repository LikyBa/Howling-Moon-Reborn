/*    */ package com.raz.howlingmoon.dimension;
/*    */ 
/*    */ import net.minecraft.world.DimensionType;
/*    */ import net.minecraft.world.WorldProvider;
/*    */ import net.minecraft.world.gen.IChunkGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMWorldProvider
/*    */   extends WorldProvider
/*    */ {
/*    */   public IChunkGenerator func_186060_c() {
/* 22 */     return new HMChunkGenerator(this.field_76579_a);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_76567_e() {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_76569_d() {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float func_76563_a(long worldTime, float partialTicks) {
/* 66 */     return 0.5F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_76559_b(long worldTime) {
/* 72 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSaveFolder() {
/* 84 */     return "DIM-HM-FOREST";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DimensionType func_186058_p() {
/* 90 */     return HMDimension.testDimensionType;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\dimension\HMWorldProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */