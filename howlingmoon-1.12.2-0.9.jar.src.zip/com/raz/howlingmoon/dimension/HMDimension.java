/*    */ package com.raz.howlingmoon.dimension;
/*    */ 
/*    */ import com.raz.howlingmoon.handler.ConfigHandler;
/*    */ import net.minecraft.world.DimensionType;
/*    */ import net.minecraftforge.common.DimensionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMDimension
/*    */ {
/*    */   public static DimensionType testDimensionType;
/*    */   
/*    */   public static void init() {
/* 14 */     registerDimensionTypes();
/* 15 */     registerDimensions();
/*    */   }
/*    */   
/*    */   private static void registerDimensionTypes() {
/* 19 */     testDimensionType = DimensionType.register("howlingmoon", "_howling", ConfigHandler.dimID, HMWorldProvider.class, false);
/*    */   }
/*    */   
/*    */   private static void registerDimensions() {
/* 23 */     DimensionManager.registerDimension(ConfigHandler.dimID, testDimensionType);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\dimension\HMDimension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */