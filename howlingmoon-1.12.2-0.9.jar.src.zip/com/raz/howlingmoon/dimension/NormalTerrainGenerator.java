/*     */ package com.raz.howlingmoon.dimension;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraft.world.chunk.ChunkPrimer;
/*     */ import net.minecraft.world.gen.IChunkGenerator;
/*     */ import net.minecraft.world.gen.NoiseGeneratorOctaves;
/*     */ import net.minecraft.world.gen.NoiseGeneratorPerlin;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ import net.minecraftforge.event.terraingen.InitNoiseGensEvent;
/*     */ import net.minecraftforge.event.terraingen.TerrainGen;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NormalTerrainGenerator
/*     */ {
/*     */   private World world;
/*     */   private Random random;
/*     */   private final double[] heightMap;
/*     */   private double[] mainNoiseRegion;
/*     */   private double[] minLimitRegion;
/*     */   private double[] maxLimitRegion;
/*     */   private double[] depthRegion;
/*     */   private NoiseGeneratorOctaves minLimitPerlinNoise;
/*     */   private NoiseGeneratorOctaves maxLimitPerlinNoise;
/*     */   private NoiseGeneratorOctaves mainPerlinNoise;
/*     */   private NoiseGeneratorPerlin surfaceNoise;
/*     */   private NoiseGeneratorOctaves depthNoise;
/*     */   private final float[] biomeWeights;
/*  33 */   private double[] depthBuffer = new double[256];
/*     */   
/*     */   private Biome[] biomesForGeneration;
/*     */   
/*     */   public NormalTerrainGenerator() {
/*  38 */     this.heightMap = new double[825];
/*     */     
/*  40 */     this.biomeWeights = new float[25];
/*  41 */     for (int j = -2; j <= 2; j++) {
/*  42 */       for (int k = -2; k <= 2; k++) {
/*  43 */         float f = 10.0F / MathHelper.func_76129_c((j * j + k * k) + 0.2F);
/*  44 */         this.biomeWeights[j + 2 + (k + 2) * 5] = f;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBiomesForGeneration(Biome[] biomesForGeneration) {
/*  50 */     this.biomesForGeneration = biomesForGeneration;
/*     */   }
/*     */   
/*     */   public void setup(World world, Random rand) {
/*  54 */     this.world = world;
/*  55 */     this.random = rand;
/*     */     
/*  57 */     this.minLimitPerlinNoise = new NoiseGeneratorOctaves(rand, 16);
/*  58 */     this.maxLimitPerlinNoise = new NoiseGeneratorOctaves(rand, 16);
/*  59 */     this.mainPerlinNoise = new NoiseGeneratorOctaves(rand, 8);
/*  60 */     this.surfaceNoise = new NoiseGeneratorPerlin(rand, 4);
/*  61 */     NoiseGeneratorOctaves noiseGen5 = new NoiseGeneratorOctaves(rand, 10);
/*  62 */     this.depthNoise = new NoiseGeneratorOctaves(rand, 16);
/*  63 */     NoiseGeneratorOctaves mobSpawnerNoise = new NoiseGeneratorOctaves(rand, 8);
/*     */     
/*  65 */     InitNoiseGensEvent.ContextOverworld ctx = new InitNoiseGensEvent.ContextOverworld(this.minLimitPerlinNoise, this.maxLimitPerlinNoise, this.mainPerlinNoise, this.surfaceNoise, noiseGen5, this.depthNoise, mobSpawnerNoise);
/*     */     
/*  67 */     ctx = (InitNoiseGensEvent.ContextOverworld)TerrainGen.getModdedNoiseGenerators(world, rand, (InitNoiseGensEvent.Context)ctx);
/*  68 */     this.minLimitPerlinNoise = ctx.getLPerlin1();
/*  69 */     this.maxLimitPerlinNoise = ctx.getLPerlin2();
/*  70 */     this.mainPerlinNoise = ctx.getPerlin();
/*  71 */     this.surfaceNoise = ctx.getHeight();
/*     */     
/*  73 */     this.depthNoise = ctx.getDepth();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateHeightmap(int chunkX4, int chunkY4, int chunkZ4) {
/*  79 */     this.depthRegion = this.depthNoise.func_76305_a(this.depthRegion, chunkX4, chunkZ4, 5, 5, 200.0D, 200.0D, 0.5D);
/*  80 */     this.mainNoiseRegion = this.mainPerlinNoise.func_76304_a(this.mainNoiseRegion, chunkX4, chunkY4, chunkZ4, 5, 33, 5, 8.555150000000001D, 4.277575000000001D, 8.555150000000001D);
/*  81 */     this.minLimitRegion = this.minLimitPerlinNoise.func_76304_a(this.minLimitRegion, chunkX4, chunkY4, chunkZ4, 5, 33, 5, 684.412D, 684.412D, 684.412D);
/*  82 */     this.maxLimitRegion = this.maxLimitPerlinNoise.func_76304_a(this.maxLimitRegion, chunkX4, chunkY4, chunkZ4, 5, 33, 5, 684.412D, 684.412D, 684.412D);
/*  83 */     int l = 0;
/*  84 */     int i1 = 0;
/*     */     
/*  86 */     for (int j1 = 0; j1 < 5; j1++) {
/*  87 */       for (int k1 = 0; k1 < 5; k1++) {
/*  88 */         float f = 0.0F;
/*  89 */         float f1 = 0.0F;
/*  90 */         float f2 = 0.0F;
/*  91 */         byte b0 = 2;
/*     */         
/*  93 */         for (int l1 = -b0; l1 <= b0; l1++) {
/*  94 */           for (int i2 = -b0; i2 <= b0; i2++) {
/*  95 */             Biome biome = this.biomesForGeneration[0];
/*  96 */             float baseHeight = biome.func_185355_j();
/*  97 */             float variation = biome.func_185360_m();
/*     */             
/*  99 */             float f5 = this.biomeWeights[l1 + 2 + (i2 + 2) * 5] / (baseHeight + 2.0F);
/* 100 */             f += variation * f5;
/* 101 */             f1 += baseHeight * f5;
/* 102 */             f2 += f5;
/*     */           } 
/*     */         } 
/*     */         
/* 106 */         f /= f2;
/* 107 */         f1 /= f2;
/* 108 */         f = f * 0.9F + 0.1F;
/* 109 */         f1 = (f1 * 4.0F - 1.0F) / 8.0F;
/* 110 */         double d12 = this.depthRegion[i1] / 8000.0D;
/*     */         
/* 112 */         if (d12 < 0.0D) {
/* 113 */           d12 = -d12 * 0.3D;
/*     */         }
/*     */         
/* 116 */         d12 = d12 * 3.0D - 2.0D;
/*     */         
/* 118 */         if (d12 < 0.0D) {
/* 119 */           d12 /= 2.0D;
/*     */           
/* 121 */           if (d12 < -1.0D) {
/* 122 */             d12 = -1.0D;
/*     */           }
/*     */           
/* 125 */           d12 /= 1.4D;
/* 126 */           d12 /= 2.0D;
/*     */         } else {
/* 128 */           if (d12 > 1.0D) {
/* 129 */             d12 = 1.0D;
/*     */           }
/*     */           
/* 132 */           d12 /= 8.0D;
/*     */         } 
/*     */         
/* 135 */         i1++;
/* 136 */         double d13 = f1;
/* 137 */         double d14 = f;
/* 138 */         d13 += d12 * 0.2D;
/* 139 */         d13 = d13 * 8.5D / 8.0D;
/* 140 */         double d5 = 8.5D + d13 * 4.0D;
/*     */         
/* 142 */         for (int j2 = 0; j2 < 33; j2++) {
/* 143 */           double d6 = (j2 - d5) * 12.0D * 128.0D / 256.0D / d14;
/*     */           
/* 145 */           if (d6 < 0.0D) {
/* 146 */             d6 *= 4.0D;
/*     */           }
/*     */           
/* 149 */           double d7 = this.minLimitRegion[l] / 512.0D;
/* 150 */           double d8 = this.maxLimitRegion[l] / 512.0D;
/* 151 */           double d9 = (this.mainNoiseRegion[l] / 10.0D + 1.0D) / 2.0D;
/* 152 */           double d10 = MathHelper.func_151237_a(d7, d8, d9) - d6;
/*     */           
/* 154 */           if (j2 > 29) {
/* 155 */             double d11 = ((j2 - 29) / 3.0F);
/* 156 */             d10 = d10 * (1.0D - d11) + -10.0D * d11;
/*     */           } 
/*     */           
/* 159 */           this.heightMap[l] = d10;
/* 160 */           l++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generate(int chunkX, int chunkZ, ChunkPrimer primer) {
/* 168 */     generateHeightmap(chunkX * 4, 0, chunkZ * 4);
/*     */     
/* 170 */     byte waterLevel = 63;
/* 171 */     for (int x4 = 0; x4 < 4; x4++) {
/* 172 */       int l = x4 * 5;
/* 173 */       int i1 = (x4 + 1) * 5;
/*     */       
/* 175 */       for (int z4 = 0; z4 < 4; z4++) {
/* 176 */         int k1 = (l + z4) * 33;
/* 177 */         int l1 = (l + z4 + 1) * 33;
/* 178 */         int i2 = (i1 + z4) * 33;
/* 179 */         int j2 = (i1 + z4 + 1) * 33;
/*     */         
/* 181 */         for (int height32 = 0; height32 < 32; height32++) {
/* 182 */           double d0 = 0.125D;
/* 183 */           double d1 = this.heightMap[k1 + height32];
/* 184 */           double d2 = this.heightMap[l1 + height32];
/* 185 */           double d3 = this.heightMap[i2 + height32];
/* 186 */           double d4 = this.heightMap[j2 + height32];
/* 187 */           double d5 = (this.heightMap[k1 + height32 + 1] - d1) * d0;
/* 188 */           double d6 = (this.heightMap[l1 + height32 + 1] - d2) * d0;
/* 189 */           double d7 = (this.heightMap[i2 + height32 + 1] - d3) * d0;
/* 190 */           double d8 = (this.heightMap[j2 + height32 + 1] - d4) * d0;
/*     */           
/* 192 */           for (int h = 0; h < 8; h++) {
/* 193 */             double d9 = 0.25D;
/* 194 */             double d10 = d1;
/* 195 */             double d11 = d2;
/* 196 */             double d12 = (d3 - d1) * d9;
/* 197 */             double d13 = (d4 - d2) * d9;
/* 198 */             int height = height32 * 8 + h;
/*     */             
/* 200 */             for (int x = 0; x < 4; x++) {
/* 201 */               double d14 = 0.25D;
/* 202 */               double d16 = (d11 - d10) * d14;
/* 203 */               double d15 = d10 - d16;
/*     */               
/* 205 */               for (int z = 0; z < 4; z++) {
/* 206 */                 if (height < 2) {
/* 207 */                   primer.func_177855_a(x4 * 4 + x, height32 * 8 + h, z4 * 4 + z, Blocks.field_150357_h.func_176223_P());
/* 208 */                 } else if ((d15 += d16) > 0.0D) {
/* 209 */                   primer.func_177855_a(x4 * 4 + x, height32 * 8 + h, z4 * 4 + z, Blocks.field_150348_b.func_176223_P());
/*     */                 } 
/*     */               } 
/*     */               
/* 213 */               d10 += d12;
/* 214 */               d11 += d13;
/*     */             } 
/*     */             
/* 217 */             d1 += d5;
/* 218 */             d2 += d6;
/* 219 */             d3 += d7;
/* 220 */             d4 += d8;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void replaceBiomeBlocks(int x, int z, ChunkPrimer primer, IChunkGenerator generator, Biome[] biomes) {
/* 228 */     if (!ForgeEventFactory.onReplaceBiomeBlocks(generator, x, z, primer, this.world))
/* 229 */       return;  this.depthBuffer = this.surfaceNoise.func_151599_a(this.depthBuffer, (x * 16), (z * 16), 16, 16, 0.0625D, 0.0625D, 1.0D);
/*     */     
/* 231 */     for (int i = 0; i < 16; i++) {
/* 232 */       for (int j = 0; j < 16; j++) {
/* 233 */         Biome biome = biomes[j + i * 16];
/* 234 */         biome.func_180622_a(this.world, this.random, primer, x * 16 + i, z * 16 + j, this.depthBuffer[j + i * 16]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\dimension\NormalTerrainGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */