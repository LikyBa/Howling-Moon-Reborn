/*     */ package com.raz.howlingmoon.dimension;
/*     */ 
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.raz.howlingmoon.entities.EntityWerewolfGuide;
/*     */ import com.raz.howlingmoon.entities.EntityWolfGuide;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.Mirror;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.ChunkPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraft.world.chunk.ChunkPrimer;
/*     */ import net.minecraft.world.gen.IChunkGenerator;
/*     */ import net.minecraft.world.gen.structure.template.PlacementSettings;
/*     */ import net.minecraft.world.gen.structure.template.Template;
/*     */ import net.minecraft.world.gen.structure.template.TemplateManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HMChunkGenerator
/*     */   implements IChunkGenerator
/*     */ {
/*     */   private final World worldObj;
/*     */   private Random random;
/*     */   private Biome[] biomesForGeneration;
/*  52 */   private NormalTerrainGenerator terraingen = new NormalTerrainGenerator();
/*     */ 
/*     */   
/*     */   public HMChunkGenerator(World worldObj) {
/*  56 */     this.worldObj = worldObj;
/*  57 */     long seed = worldObj.func_72905_C();
/*  58 */     this.random = new Random((seed + 516L) * 314L);
/*  59 */     this.terraingen.setup(worldObj, this.random);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_185931_b(int x, int z) {
/*  83 */     int i = x * 16;
/*  84 */     int j = z * 16;
/*     */     
/*  86 */     if (x > -1 && x < 2 && z > -1 && z < 2) {
/*     */       
/*  88 */       i = 0; j = 0;
/*  89 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "spawn");
/*  90 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/*  92 */     else if (x > -1 && x < 2 && z > 1 && z < 4) {
/*     */       
/*  94 */       i = 0; j = 32;
/*  95 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "wolf1");
/*  96 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/*  98 */     else if (x > -1 && x < 2 && z > 3 && z < 6) {
/*     */       
/* 100 */       i = 0; j = 64;
/* 101 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "end");
/* 102 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 104 */     else if (x > 49 && x < 52 && z > -1 && z < 2) {
/*     */       
/* 106 */       i = 800; j = 0;
/* 107 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "spawn");
/* 108 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 110 */     else if (x > 49 && x < 52 && z > 1 && z < 4) {
/*     */       
/* 112 */       i = 800; j = 32;
/* 113 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "forest_dark");
/* 114 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 116 */     else if (x > 49 && x < 52 && z > 3 && z < 6) {
/*     */       
/* 118 */       i = 800; j = 64;
/* 119 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "labyrinth");
/* 120 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 122 */     else if (x > 49 && x < 52 && z > 5 && z < 8) {
/*     */       
/* 124 */       i = 800; j = 96;
/* 125 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "end2");
/* 126 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 128 */     else if (x > 99 && x < 102 && z > -1 && z < 2) {
/*     */       
/* 130 */       i = 1600; j = 0;
/* 131 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "spawn");
/* 132 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 134 */     else if (x > 99 && x < 102 && z > 1 && z < 4) {
/*     */       
/* 136 */       i = 1600; j = 32;
/* 137 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "dash1");
/* 138 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 140 */     else if (x > 99 && x < 102 && z > 3 && z < 6) {
/*     */       
/* 142 */       i = 1600; j = 64;
/* 143 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "dash2");
/* 144 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 146 */     else if (x > 99 && x < 102 && z > 5 && z < 8) {
/*     */       
/* 148 */       i = 1600; j = 96;
/* 149 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "end3");
/* 150 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 152 */     else if (x > 197 && x < 200 && z > 1 && z < 4) {
/*     */       
/* 154 */       i = 3168; j = 32;
/* 155 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "start_speed_trial");
/* 156 */       if (x != 198 || z != 2)
/*     */       {
/*     */         
/* 159 */         spawnStructure(i, j, loc, x, z);
/*     */       }
/* 161 */     } else if (x > 197 && x < 200 && z > 3 && z < 6) {
/*     */       
/* 163 */       i = 3168; j = 64;
/* 164 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "wolf_dash1");
/* 165 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 167 */     else if (x > 197 && x < 200 && z > 5 && z < 8) {
/*     */       
/* 169 */       i = 3168; j = 96;
/* 170 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "wolf_dash2");
/* 171 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 173 */     else if (x > 197 && x < 200 && z > 7 && z < 10) {
/*     */       
/* 175 */       i = 3168; j = 128;
/* 176 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "wolf_dash_end");
/* 177 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 179 */     else if (x > 199 && x < 202 && z > -1 && z < 2) {
/*     */       
/* 181 */       i = 3200; j = 0;
/* 182 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "spawn");
/* 183 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 185 */     else if (x > 199 && x < 202 && z > 1 && z < 4) {
/*     */       
/* 187 */       i = 3200; j = 32;
/* 188 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "start_lava_trial");
/* 189 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 191 */     else if (x > 199 && x < 202 && z > 3 && z < 6) {
/*     */       
/* 193 */       i = 3200; j = 64;
/* 194 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "lava_pit");
/* 195 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 197 */     else if (x > 199 && x < 202 && z > 5 && z < 8) {
/*     */       
/* 199 */       i = 3200; j = 96;
/* 200 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "lava_pit_end");
/* 201 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 203 */     else if (x > 199 && x < 202 && z > 7 && z < 10) {
/*     */       
/* 205 */       i = 3200; j = 128;
/* 206 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "trial_end");
/* 207 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 209 */     else if (x > 199 && x < 202 && z > 9 && z < 12) {
/*     */       
/* 211 */       i = 3200; j = 160;
/* 212 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "end4");
/* 213 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 215 */     else if (x > 201 && x < 204 && z > 1 && z < 4) {
/*     */       
/* 217 */       i = 3232; j = 32;
/* 218 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "start_height_trial");
/* 219 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 221 */     else if (x > 201 && x < 204 && z > 3 && z < 6) {
/*     */       
/* 223 */       i = 3232; j = 64;
/* 224 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "climb_trial");
/* 225 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 227 */     else if (x > 201 && x < 204 && z > 5 && z < 8) {
/*     */       
/* 229 */       i = 3232; j = 96;
/* 230 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "climb_trial2");
/* 231 */       spawnStructure(i, j, loc, x, z);
/*     */     }
/* 233 */     else if (x > 201 && x < 204 && z > 7 && z < 10) {
/*     */       
/* 235 */       i = 3232; j = 128;
/* 236 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "climb_end");
/* 237 */       spawnStructure(i, j, loc, x, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void spawnStructure(int i, int j, ResourceLocation loc, int x, int z) {
/* 243 */     WorldServer worldserver = (WorldServer)this.worldObj;
/* 244 */     MinecraftServer minecraftserver = this.worldObj.func_73046_m();
/* 245 */     TemplateManager templatemanager = worldserver.func_184163_y();
/* 246 */     Template template = templatemanager.func_186237_a(minecraftserver, loc);
/* 247 */     ChunkPos chunkPos = null;
/* 248 */     if (this.worldObj.func_72964_e(x, z) != null) {
/* 249 */       chunkPos = this.worldObj.func_72964_e(x, z).func_76632_l();
/*     */     }
/* 251 */     if (template != null) {
/* 252 */       BlockPos pos = new BlockPos(i, 61, j);
/* 253 */       IBlockState iblockstate = this.worldObj.func_180495_p(pos);
/* 254 */       this.worldObj.func_184138_a(pos, iblockstate, iblockstate, 3);
/*     */ 
/*     */       
/* 257 */       PlacementSettings placementsettings = (new PlacementSettings()).func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE).func_186222_a(false).func_186218_a(chunkPos).func_186225_a((Block)null).func_186226_b(false);
/*     */ 
/*     */ 
/*     */       
/* 261 */       if (chunkPos != null) {
/*     */         
/* 263 */         template.func_186260_a(this.worldObj, pos, placementsettings);
/* 264 */         if (x == 1 && z == 1) {
/*     */           
/* 266 */           BlockPos guideSpawn = new BlockPos(16.0D, 64.0D, 25.0D);
/* 267 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 1, 0, 0, false, guideSpawn);
/* 268 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 269 */           wolf.field_70759_as = wolf.field_70177_z;
/* 270 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 272 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 274 */         else if (x == 1 && z == 5) {
/*     */           
/* 276 */           BlockPos guideSpawn = new BlockPos(16.0D, 64.0D, 80.0D);
/* 277 */           EntityWolfGuide wolf = new EntityWolfGuide(this.worldObj, 2, 2, 0, false, guideSpawn);
/* 278 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 279 */           wolf.field_70759_as = wolf.field_70177_z;
/* 280 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 282 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 284 */         else if (x == 51 && z == 1) {
/*     */           
/* 286 */           BlockPos guideSpawn = new BlockPos(816.0D, 64.0D, 25.0D);
/* 287 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 3, 0, 0, false, guideSpawn);
/* 288 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 289 */           wolf.field_70759_as = wolf.field_70177_z;
/* 290 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 292 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 294 */         else if (x == 51 && z == 6) {
/*     */           
/* 296 */           BlockPos guideSpawn = new BlockPos(816.0D, 64.0D, 108.0D);
/* 297 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 4, 0, 0, true, guideSpawn);
/* 298 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 299 */           wolf.field_70759_as = wolf.field_70177_z;
/* 300 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 302 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 304 */         else if (x == 51 && z == 7) {
/*     */           
/* 306 */           BlockPos guideSpawn = new BlockPos(821.0D, 64.0D, 113.0D);
/* 307 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 0, 4, 1, 0, true, guideSpawn);
/* 308 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 309 */           wolf.field_70759_as = wolf.field_70177_z;
/* 310 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 312 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 314 */         else if (x == 50 && z == 7) {
/*     */           
/* 316 */           BlockPos guideSpawn = new BlockPos(811.0D, 64.0D, 113.0D);
/* 317 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 1, 4, -1, 0, true, guideSpawn);
/* 318 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 319 */           wolf.field_70759_as = wolf.field_70177_z;
/* 320 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 322 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 324 */         else if (x == 101 && z == 1) {
/*     */           
/* 326 */           BlockPos guideSpawn = new BlockPos(1616.0D, 64.0D, 25.0D);
/* 327 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 5, 0, 0, false, guideSpawn);
/* 328 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 329 */           wolf.field_70759_as = wolf.field_70177_z;
/* 330 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 332 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 334 */         else if (x == 101 && z == 6) {
/*     */           
/* 336 */           BlockPos guideSpawn = new BlockPos(1616.0D, 64.0D, 112.0D);
/* 337 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 6, 0, 0, false, guideSpawn);
/* 338 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 339 */           wolf.field_70759_as = wolf.field_70177_z;
/* 340 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 342 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 344 */         else if (x == 201 && z == 1) {
/*     */           
/* 346 */           BlockPos guideSpawn = new BlockPos(3216.0D, 64.0D, 25.0D);
/* 347 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 7, 0, 0, false, guideSpawn);
/* 348 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 349 */           wolf.field_70759_as = wolf.field_70177_z;
/* 350 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 352 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         }
/* 354 */         else if (x == 201 && z == 11) {
/*     */           
/* 356 */           BlockPos guideSpawn = new BlockPos(3216.0D, 64.0D, 176.0D);
/* 357 */           EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 8, 0, 0, false, guideSpawn);
/* 358 */           wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 359 */           wolf.field_70759_as = wolf.field_70177_z;
/* 360 */           wolf.field_70761_aq = wolf.field_70177_z;
/*     */           
/* 362 */           this.worldObj.func_72838_d((Entity)wolf);
/*     */         } 
/*     */       } else {
/*     */         
/* 366 */         System.err.println("Error, could not find Chunk Position. Did not generate structure!");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_185933_a(Chunk chunkIn, int x, int z) {
/* 376 */     if (x == 1 && z == 1) {
/*     */       
/* 378 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 22.0D, (x * 16 + 3), 65.0D, 28.0D));
/*     */ 
/*     */       
/* 381 */       if (entities.isEmpty())
/*     */       {
/* 383 */         BlockPos guideSpawn = new BlockPos(16.0D, 64.0D, 25.0D);
/* 384 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 1, 0, 0, false, guideSpawn);
/* 385 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 386 */         wolf.field_70759_as = wolf.field_70177_z;
/* 387 */         wolf.field_70761_aq = wolf.field_70177_z;
/* 388 */         this.worldObj.func_72838_d((Entity)wolf);
/* 389 */         return true;
/*     */       }
/*     */     
/* 392 */     } else if (x == 1 && z == 5) {
/*     */       
/* 394 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, (z * 16 - 3), (x * 16 + 3), 65.0D, (z * 16 + 3)));
/*     */ 
/*     */       
/* 397 */       if (entities.isEmpty())
/*     */       {
/* 399 */         BlockPos guideSpawn = new BlockPos(16.0D, 64.0D, 80.0D);
/* 400 */         EntityWolfGuide wolf = new EntityWolfGuide(this.worldObj, 2, 2, 0, false, guideSpawn);
/* 401 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 402 */         wolf.field_70759_as = wolf.field_70177_z;
/* 403 */         wolf.field_70761_aq = wolf.field_70177_z;
/* 404 */         this.worldObj.func_72838_d((Entity)wolf);
/* 405 */         return true;
/*     */       }
/*     */     
/* 408 */     } else if (x == 51 && z == 1) {
/*     */       
/* 410 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 22.0D, (x * 16 + 3), 65.0D, 28.0D));
/*     */ 
/*     */       
/* 413 */       if (entities.isEmpty())
/*     */       {
/* 415 */         BlockPos guideSpawn = new BlockPos(816.0D, 64.0D, 25.0D);
/* 416 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 3, 0, 0, false, guideSpawn);
/* 417 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 418 */         wolf.field_70759_as = wolf.field_70177_z;
/* 419 */         wolf.field_70761_aq = wolf.field_70177_z;
/* 420 */         this.worldObj.func_72838_d((Entity)wolf);
/* 421 */         return true;
/*     */       }
/*     */     
/* 424 */     } else if (x == 51 && z == 6) {
/*     */       
/* 426 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 105.0D, (x * 16 + 3), 65.0D, 111.0D));
/*     */ 
/*     */       
/* 429 */       if (entities.isEmpty())
/*     */       {
/* 431 */         BlockPos guideSpawn = new BlockPos(816.0D, 64.0D, 108.0D);
/* 432 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 4, 0, 0, true, guideSpawn);
/* 433 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 434 */         wolf.field_70759_as = wolf.field_70177_z;
/* 435 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 437 */         this.worldObj.func_72838_d((Entity)wolf);
/* 438 */         return true;
/*     */       }
/*     */     
/* 441 */     } else if (x == 51 && z == 7) {
/*     */       
/* 443 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB(818.0D, 63.0D, 110.0D, 824.0D, 65.0D, 116.0D));
/*     */ 
/*     */       
/* 446 */       if (entities.isEmpty())
/*     */       {
/* 448 */         BlockPos guideSpawn = new BlockPos(821.0D, 64.0D, 113.0D);
/* 449 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 0, 4, 1, 0, true, guideSpawn);
/* 450 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 451 */         wolf.field_70759_as = wolf.field_70177_z;
/* 452 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 454 */         this.worldObj.func_72838_d((Entity)wolf);
/* 455 */         return true;
/*     */       }
/*     */     
/* 458 */     } else if (x == 50 && z == 7) {
/*     */       
/* 460 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB(808.0D, 63.0D, 110.0D, 814.0D, 65.0D, 116.0D));
/*     */ 
/*     */       
/* 463 */       if (entities.isEmpty())
/*     */       {
/* 465 */         BlockPos guideSpawn = new BlockPos(811.0D, 64.0D, 113.0D);
/* 466 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 1, 4, -1, 0, true, guideSpawn);
/* 467 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 468 */         wolf.field_70759_as = wolf.field_70177_z;
/* 469 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 471 */         this.worldObj.func_72838_d((Entity)wolf);
/* 472 */         return true;
/*     */       }
/*     */     
/* 475 */     } else if (x == 101 && z == 1) {
/*     */       
/* 477 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 22.0D, (x * 16 + 3), 65.0D, 28.0D));
/*     */ 
/*     */       
/* 480 */       if (entities.isEmpty())
/*     */       {
/* 482 */         BlockPos guideSpawn = new BlockPos(1616.0D, 64.0D, 25.0D);
/* 483 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 5, 0, 0, false, guideSpawn);
/* 484 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 485 */         wolf.field_70759_as = wolf.field_70177_z;
/* 486 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 488 */         this.worldObj.func_72838_d((Entity)wolf);
/* 489 */         return true;
/*     */       }
/*     */     
/* 492 */     } else if (x == 101 && z == 6) {
/*     */       
/* 494 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 109.0D, (x * 16 + 3), 65.0D, 115.0D));
/*     */ 
/*     */       
/* 497 */       if (entities.isEmpty())
/*     */       {
/* 499 */         BlockPos guideSpawn = new BlockPos(1616.0D, 64.0D, 112.0D);
/* 500 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 6, 0, 0, false, guideSpawn);
/* 501 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 502 */         wolf.field_70759_as = wolf.field_70177_z;
/* 503 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 505 */         this.worldObj.func_72838_d((Entity)wolf);
/* 506 */         return true;
/*     */       }
/*     */     
/* 509 */     } else if (x == 201 && z == 1) {
/*     */       
/* 511 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 22.0D, (x * 16 + 3), 65.0D, 28.0D));
/*     */ 
/*     */       
/* 514 */       if (entities.isEmpty())
/*     */       {
/* 516 */         BlockPos guideSpawn = new BlockPos(3216.0D, 64.0D, 25.0D);
/* 517 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 7, 0, 0, false, guideSpawn);
/* 518 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 519 */         wolf.field_70759_as = wolf.field_70177_z;
/* 520 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 522 */         this.worldObj.func_72838_d((Entity)wolf);
/* 523 */         return true;
/*     */       }
/*     */     
/* 526 */     } else if (x == 201 && z == 11) {
/*     */       
/* 528 */       List<EntityWerewolfGuide> entities = this.worldObj.func_72872_a(EntityWerewolfGuide.class, new AxisAlignedBB((x * 16 - 3), 63.0D, 173.0D, (x * 16 + 3), 65.0D, 179.0D));
/*     */ 
/*     */       
/* 531 */       if (entities.isEmpty()) {
/*     */         
/* 533 */         BlockPos guideSpawn = new BlockPos(3216.0D, 64.0D, 176.0D);
/* 534 */         EntityWerewolfGuide wolf = new EntityWerewolfGuide(this.worldObj, 2, 8, 0, 0, false, guideSpawn);
/* 535 */         wolf.func_70012_b(guideSpawn.func_177958_n(), guideSpawn.func_177956_o() + 0.1D, guideSpawn.func_177952_p(), 180.0F, 0.0F);
/* 536 */         wolf.field_70759_as = wolf.field_70177_z;
/* 537 */         wolf.field_70761_aq = wolf.field_70177_z;
/*     */         
/* 539 */         this.worldObj.func_72838_d((Entity)wolf);
/* 540 */         return true;
/*     */       } 
/*     */     } 
/* 543 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Biome.SpawnListEntry> func_177458_a(EnumCreatureType creatureType, BlockPos pos) {
/* 556 */     return (List<Biome.SpawnListEntry>)ImmutableList.of();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180514_a(Chunk chunkIn, int x, int z) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Chunk func_185932_a(int x, int z) {
/* 567 */     ChunkPrimer chunkprimer = new ChunkPrimer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     Chunk chunk = new Chunk(this.worldObj, chunkprimer, x, z);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 589 */     chunk.func_76603_b();
/* 590 */     return chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos func_180513_a(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
/* 597 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_193414_a(World worldIn, String structureName, BlockPos pos) {
/* 603 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\dimension\HMChunkGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */