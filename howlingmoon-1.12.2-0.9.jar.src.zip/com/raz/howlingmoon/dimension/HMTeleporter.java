/*     */ package com.raz.howlingmoon.dimension;
/*     */ 
/*     */ import com.raz.howlingmoon.handler.ConfigHandler;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.Teleporter;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HMTeleporter
/*     */   extends Teleporter
/*     */ {
/*     */   private final WorldServer worldServer;
/*     */   private double x;
/*     */   private double y;
/*     */   private double z;
/*     */   
/*     */   public HMTeleporter(WorldServer world, double x, double y, double z) {
/*  27 */     super(world);
/*  28 */     this.worldServer = world;
/*  29 */     this.x = x;
/*  30 */     this.y = y;
/*  31 */     this.z = z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180266_a(@Nonnull Entity entity, float rotationYaw) {
/*  41 */     this.worldServer.func_180495_p(new BlockPos((int)this.x, (int)this.y, (int)this.z));
/*     */     
/*  43 */     entity.func_70107_b(this.x, this.y, this.z);
/*  44 */     entity.field_70159_w = 0.0D;
/*  45 */     entity.field_70181_x = 0.0D;
/*  46 */     entity.field_70179_y = 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleportToDimension(EntityPlayer player, int dimension, double x, double y, double z) {
/*  51 */     int oldDimension = player.field_70170_p.field_73011_w.getDimension();
/*  52 */     player.field_70143_R = 0.0F;
/*  53 */     EntityPlayerMP entityPlayerMP = (EntityPlayerMP)player;
/*  54 */     MinecraftServer server = ((EntityPlayerMP)player).field_70170_p.func_73046_m();
/*  55 */     WorldServer worldServer = server.func_71218_a(dimension);
/*  56 */     player.func_82242_a(0);
/*     */     
/*  58 */     if (worldServer == null || worldServer.func_73046_m() == null) {
/*  59 */       throw new IllegalArgumentException("Dimension: " + dimension + " doesn't exist!");
/*     */     }
/*     */     
/*  62 */     worldServer.func_73046_m().func_184103_al().transferPlayerToDimension(entityPlayerMP, dimension, new HMTeleporter(worldServer, x, y, z));
/*  63 */     player.func_70634_a(x, y + 0.10000000149011612D, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void teleportToHMDimension(EntityPlayer player, int state) {
/*  73 */     int oldDimension = player.field_70170_p.field_73011_w.getDimension();
/*  74 */     player.field_70143_R = 0.0F;
/*  75 */     EntityPlayerMP entityPlayerMP = (EntityPlayerMP)player;
/*  76 */     MinecraftServer server = ((EntityPlayerMP)player).field_70170_p.func_73046_m();
/*  77 */     WorldServer worldServer = server.func_71218_a(ConfigHandler.dimID);
/*  78 */     player.func_82242_a(0);
/*     */     
/*  80 */     if (worldServer == null || worldServer.func_73046_m() == null) {
/*  81 */       throw new IllegalArgumentException("Dimension: " + ConfigHandler.dimID + " doesn't exist!");
/*     */     }
/*     */     
/*  84 */     BlockPos spawn = new BlockPos(16, 64, 16);
/*  85 */     switch (state) {
/*     */       case 1:
/*  87 */         spawn = new BlockPos(816, 64, 16); break;
/*     */       case 2:
/*  89 */         spawn = new BlockPos(1616, 64, 16); break;
/*     */       case 3:
/*  91 */         spawn = new BlockPos(3216, 64, 16);
/*     */         break;
/*     */     } 
/*  94 */     double x = spawn.func_177958_n();
/*  95 */     double y = spawn.func_177956_o();
/*  96 */     double z = spawn.func_177952_p();
/*     */     
/*  98 */     worldServer.func_73046_m().func_184103_al().transferPlayerToDimension(entityPlayerMP, ConfigHandler.dimID, new HMTeleporter(worldServer, x, y, z));
/*  99 */     player.func_70634_a(x, y + 0.10000000149011612D, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void returnFromDimension(EntityPlayer player) {
/* 113 */     player.field_70143_R = 0.0F;
/* 114 */     player.field_70181_x = 0.0D;
/* 115 */     EntityPlayerMP entityPlayerMP = (EntityPlayerMP)player;
/* 116 */     MinecraftServer server = ((EntityPlayerMP)player).field_70170_p.func_73046_m();
/* 117 */     WorldServer worldServer = server.func_71218_a(0);
/* 118 */     BlockPos spawnPosition = entityPlayerMP.getBedLocation(0);
/* 119 */     player.func_82242_a(0);
/*     */     
/* 121 */     double x = worldServer.func_175694_M().func_177958_n();
/* 122 */     double y = worldServer.func_175694_M().func_177956_o();
/* 123 */     double z = worldServer.func_175694_M().func_177952_p();
/*     */     
/* 125 */     if (spawnPosition != null) {
/*     */       
/* 127 */       BlockPos blockpos1 = EntityPlayer.func_180467_a((World)worldServer, spawnPosition, false);
/* 128 */       if (blockpos1 != null) {
/*     */         
/* 130 */         x = blockpos1.func_177958_n();
/* 131 */         y = blockpos1.func_177956_o();
/* 132 */         z = blockpos1.func_177952_p();
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     if (worldServer == null || worldServer.func_73046_m() == null) {
/* 137 */       throw new IllegalArgumentException("Dimension: 0 doesn't exist!");
/*     */     }
/*     */     
/* 140 */     worldServer.func_73046_m().func_184103_al().transferPlayerToDimension(entityPlayerMP, 0, new HMTeleporter(worldServer, x, y, z));
/* 141 */     player.func_70634_a(x + 0.5D, y + 0.10000000149011612D, z + 0.5D);
/* 142 */     while (!worldServer.func_184144_a((Entity)entityPlayerMP, entityPlayerMP.func_174813_aQ()).isEmpty() && entityPlayerMP.field_70163_u < 256.0D)
/*     */     {
/* 144 */       entityPlayerMP.func_70107_b(entityPlayerMP.field_70165_t, entityPlayerMP.field_70163_u + 1.0D, entityPlayerMP.field_70161_v);
/*     */     }
/* 146 */     entityPlayerMP.field_71135_a.func_147364_a(entityPlayerMP.field_70165_t, entityPlayerMP.field_70163_u, entityPlayerMP.field_70161_v, entityPlayerMP.field_70177_z, entityPlayerMP.field_70125_A);
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\dimension\HMTeleporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */