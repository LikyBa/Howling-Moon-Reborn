/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraftforge.registries.IForgeRegistry;
/*    */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMPotions
/*    */ {
/* 19 */   public static final PotionBase BLEEDING = new PotionBase(true, 9699346, "bleeding");
/* 20 */   public static final PotionBase WOLFSBANE = new PotionBase(true, 11665663, "wolfsbane");
/* 21 */   public static final PotionBase SILVERPOISON = new PotionBase(true, 11119017, "silverpoison");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void register(IForgeRegistry<Potion> registry) {
/* 29 */     registry.registerAll((IForgeRegistryEntry[])new Potion[] { BLEEDING, WOLFSBANE, SILVERPOISON });
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\HMPotions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */