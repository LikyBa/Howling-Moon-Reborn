/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ 
/*    */ public class WereScent
/*    */ {
/*    */   public Class entity;
/*    */   public int color;
/*    */   
/*    */   public WereScent(Class entity, int color) {
/* 10 */     this.entity = entity;
/* 11 */     this.color = color;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereScent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */