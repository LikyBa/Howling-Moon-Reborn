/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.MobEffects;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaimEntity
/*    */   extends AbstractMessage.AbstractServerMessage<MaimEntity>
/*    */ {
/*    */   private int data;
/*    */   
/*    */   public MaimEntity() {}
/*    */   
/*    */   public MaimEntity(EntityPlayer player, EntityLiving target) {
/* 28 */     this.data = target.func_145782_y();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 34 */     this.data = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 39 */     buffer.writeInt(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 44 */     Entity target = player.field_70170_p.func_73045_a(this.data);
/* 45 */     if (target != null && target instanceof EntityLiving)
/*    */     {
/* 47 */       if (!(target instanceof EntityPlayer) || FMLCommonHandler.instance().getMinecraftServerInstance().func_71219_W()) {
/*    */         
/* 49 */         ((EntityLiving)target).func_70690_d(new PotionEffect(MobEffects.field_76419_f, 300, 0, false, true));
/* 50 */         ((EntityLiving)target).func_70690_d(new PotionEffect(MobEffects.field_76421_d, 300, 1, false, true));
/* 51 */         player.func_71059_n(target);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\MaimEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */