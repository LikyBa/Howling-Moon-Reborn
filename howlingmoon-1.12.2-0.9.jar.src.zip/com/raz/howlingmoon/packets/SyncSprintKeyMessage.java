/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ public class SyncSprintKeyMessage
/*    */   extends AbstractMessage<SyncSprintKeyMessage>
/*    */ {
/*    */   private boolean data;
/*    */   
/*    */   public SyncSprintKeyMessage() {}
/*    */   
/*    */   public SyncSprintKeyMessage(EntityPlayer player) {
/* 19 */     this.data = ((IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null)).isSprintKey();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 24 */     this.data = buffer.readBoolean();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 29 */     buffer.writeBoolean(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 34 */     ((IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null)).setSprintKey(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SyncSprintKeyMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */