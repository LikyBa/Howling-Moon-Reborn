/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrackingMessage
/*    */   extends AbstractMessage.AbstractClientMessage<TrackingMessage>
/*    */ {
/*    */   private boolean data;
/*    */   private int playerID;
/*    */   private int texture;
/*    */   private int model;
/*    */   
/*    */   public TrackingMessage() {}
/*    */   
/*    */   public TrackingMessage(EntityPlayer player) {
/* 26 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 27 */     this.data = wolf.isTransformed();
/* 28 */     this.playerID = player.func_145782_y();
/* 29 */     this.texture = wolf.getTexture();
/* 30 */     this.model = wolf.getModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 35 */     this.data = buffer.readBoolean();
/* 36 */     this.playerID = buffer.readInt();
/* 37 */     this.texture = buffer.readInt();
/* 38 */     this.model = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 43 */     buffer.writeBoolean(this.data);
/* 44 */     buffer.writeInt(this.playerID);
/* 45 */     buffer.writeInt(this.texture);
/* 46 */     buffer.writeInt(this.model);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 53 */     if ((Minecraft.func_71410_x()).field_71441_e != null) {
/*    */       
/* 55 */       EntityPlayer playerC = (EntityPlayer)(Minecraft.func_71410_x()).field_71441_e.func_73045_a(this.playerID);
/* 56 */       if (playerC != null) {
/*    */         
/* 58 */         IWerewolfCapability wolf = (IWerewolfCapability)playerC.getCapability(WereEventHandler.WERE_CAP, null);
/* 59 */         wolf.setTexture(this.texture);
/* 60 */         wolf.setModel(this.model);
/* 61 */         wolf.setTransformed(this.data, false, side, playerC);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\TrackingMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */