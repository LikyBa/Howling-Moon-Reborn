/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityCarry;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiftEntity
/*    */   extends AbstractMessage.AbstractServerMessage<LiftEntity>
/*    */ {
/*    */   private int data;
/*    */   
/*    */   public LiftEntity() {}
/*    */   
/*    */   public LiftEntity(EntityPlayer player, Entity entity) {
/* 22 */     this.data = entity.func_145782_y();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 34 */     this.data = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 39 */     buffer.writeInt(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 44 */     Entity e = player.field_70170_p.func_73045_a(this.data);
/*    */     
/* 46 */     if (e != null)
/*    */     {
/*    */       
/* 49 */       if (!player.func_184188_bt().isEmpty()) {
/*    */ 
/*    */         
/* 52 */         player.func_184226_ay();
/*    */       }
/*    */       else {
/*    */         
/* 56 */         EntityCarry wolf = new EntityCarry(player.field_70170_p);
/*    */         
/* 58 */         wolf.func_70012_b(player.field_70165_t, player.field_70163_u, player.field_70161_v, 0.0F, 0.0F);
/* 59 */         player.field_70170_p.func_72838_d((Entity)wolf);
/* 60 */         wolf.func_184220_m((Entity)player);
/* 61 */         e.func_184220_m((Entity)wolf);
/* 62 */         PacketDispatcher.sendTo(new LiftEntity2(player, e, (Entity)wolf), (EntityPlayerMP)player);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\LiftEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */