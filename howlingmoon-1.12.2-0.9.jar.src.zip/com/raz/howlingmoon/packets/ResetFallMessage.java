/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResetFallMessage
/*    */   extends AbstractMessage.AbstractServerMessage<ResetFallMessage>
/*    */ {
/*    */   private double data;
/*    */   
/*    */   public ResetFallMessage() {}
/*    */   
/*    */   public ResetFallMessage(EntityPlayer player) {
/* 18 */     this.data = player.field_70181_x;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 23 */     this.data = buffer.readDouble();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 28 */     buffer.writeDouble(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 33 */     player.field_70181_x = this.data;
/* 34 */     player.field_70143_R = 0.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\ResetFallMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */