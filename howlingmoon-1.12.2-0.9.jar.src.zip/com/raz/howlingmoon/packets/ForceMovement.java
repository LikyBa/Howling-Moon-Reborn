/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ public class ForceMovement
/*    */   extends AbstractMessage.AbstractClientMessage<ForceMovement>
/*    */ {
/*    */   double motionX;
/*    */   double motionY;
/*    */   double motionZ;
/*    */   
/*    */   public ForceMovement() {}
/*    */   
/*    */   public ForceMovement(EntityPlayer player, double x, double y, double z) {
/* 19 */     this.motionX = x;
/* 20 */     this.motionY = y;
/* 21 */     this.motionZ = z;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 26 */     this.motionX = buffer.readDouble();
/* 27 */     this.motionY = buffer.readDouble();
/* 28 */     this.motionZ = buffer.readDouble();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 33 */     buffer.writeDouble(this.motionX);
/* 34 */     buffer.writeDouble(this.motionY);
/* 35 */     buffer.writeDouble(this.motionZ);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 40 */     player.func_70024_g(this.motionX, this.motionY, this.motionZ);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\ForceMovement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */