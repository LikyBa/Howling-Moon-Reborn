/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncScentTrackingMessage
/*    */   extends AbstractMessage<SyncScentTrackingMessage>
/*    */ {
/*    */   private boolean data;
/*    */   
/*    */   public SyncScentTrackingMessage() {}
/*    */   
/*    */   public SyncScentTrackingMessage(EntityPlayer player) {
/* 20 */     this.data = ((IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null)).getScentTracking();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 25 */     this.data = buffer.readBoolean();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 30 */     buffer.writeBoolean(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 36 */     ((IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null)).setScentTracking(this.data);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SyncScentTrackingMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */