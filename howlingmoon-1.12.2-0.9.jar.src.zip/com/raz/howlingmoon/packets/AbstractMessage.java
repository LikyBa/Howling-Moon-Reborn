/*     */ package com.raz.howlingmoon.packets;
/*     */ 
/*     */ import com.google.common.base.Throwables;
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.io.IOException;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMessage<T extends AbstractMessage<T>>
/*     */   implements IMessage, IMessageHandler<T, IMessage>
/*     */ {
/*     */   protected boolean isValidOnSide(Side side) {
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean requiresMainThread() {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void fromBytes(ByteBuf buffer) {
/*     */     try {
/*  60 */       read(new PacketBuffer(buffer));
/*  61 */     } catch (IOException e) {
/*  62 */       throw Throwables.propagate(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void toBytes(ByteBuf buffer) {
/*     */     try {
/*  69 */       write(new PacketBuffer(buffer));
/*  70 */     } catch (IOException e) {
/*  71 */       throw Throwables.propagate(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IMessage onMessage(final T msg, final MessageContext ctx) {
/*     */     Minecraft minecraft;
/*  87 */     if (!msg.isValidOnSide(ctx.side)) {
/*  88 */       throw new RuntimeException("Invalid side " + ctx.side.name() + " for " + msg.getClass().getSimpleName());
/*     */     }
/*     */     
/*  91 */     if (ctx.side.isServer()) {
/*  92 */       WorldServer worldServer = (WorldServer)(ctx.getServerHandler()).field_147369_b.field_70170_p;
/*     */     } else {
/*  94 */       minecraft = Minecraft.func_71410_x();
/*  95 */     }  minecraft.func_152344_a(new Runnable()
/*     */         {
/*     */           public void run() {
/*  98 */             msg.process(HowlingMoon.proxy.getPlayerEntity(ctx), ctx.side);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void read(PacketBuffer paramPacketBuffer) throws IOException;
/*     */ 
/*     */   
/*     */   protected abstract void write(PacketBuffer paramPacketBuffer) throws IOException;
/*     */ 
/*     */   
/*     */   public abstract void process(EntityPlayer paramEntityPlayer, Side paramSide);
/*     */ 
/*     */   
/*     */   public static abstract class AbstractClientMessage<T extends AbstractMessage<T>>
/*     */     extends AbstractMessage<T>
/*     */   {
/*     */     protected final boolean isValidOnSide(Side side) {
/* 121 */       return side.isClient();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class AbstractServerMessage<T extends AbstractMessage<T>>
/*     */     extends AbstractMessage<T>
/*     */   {
/*     */     protected final boolean isValidOnSide(Side side) {
/* 131 */       return side.isServer();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\AbstractMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */