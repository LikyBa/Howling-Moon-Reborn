/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityStun;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ public class StunEntity
/*    */   extends AbstractMessage.AbstractClientMessage<StunEntity>
/*    */ {
/*    */   private int data;
/*    */   private int data2;
/*    */   
/*    */   public StunEntity() {}
/*    */   
/*    */   public StunEntity(EntityPlayer player, Entity entity, Entity stun) {
/* 20 */     this.data = entity.func_145782_y();
/* 21 */     this.data2 = stun.func_145782_y();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 33 */     this.data = buffer.readInt();
/* 34 */     this.data2 = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 39 */     buffer.writeInt(this.data);
/* 40 */     buffer.writeInt(this.data2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 45 */     Entity e = player.field_70170_p.func_73045_a(this.data);
/* 46 */     Entity e2 = player.field_70170_p.func_73045_a(this.data2);
/*    */ 
/*    */ 
/*    */     
/* 50 */     if (e != null && e2 != null)
/*    */     {
/*    */ 
/*    */       
/* 54 */       ((EntityStun)e2).changeSize(e.field_70130_N, e.field_70131_O);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\StunEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */