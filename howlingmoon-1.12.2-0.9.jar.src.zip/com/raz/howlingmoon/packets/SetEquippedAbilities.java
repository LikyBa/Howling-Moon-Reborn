/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import com.raz.howlingmoon.WereList;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ public class SetEquippedAbilities
/*    */   extends AbstractMessage.AbstractServerMessage<SetEquippedAbilities>
/*    */ {
/*    */   private String a1;
/*    */   private String a2;
/*    */   
/*    */   public SetEquippedAbilities() {}
/*    */   
/*    */   public SetEquippedAbilities(EntityPlayer player) {
/* 21 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 22 */     if (wolf.getAbilitySlot1() != null) {
/* 23 */       this.a1 = wolf.getAbilitySlot1().getKey();
/*    */     } else {
/* 25 */       this.a1 = "null";
/* 26 */     }  if (wolf.getAbilitySlot2() != null) {
/* 27 */       this.a2 = wolf.getAbilitySlot2().getKey();
/*    */     } else {
/* 29 */       this.a2 = "null";
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 34 */     this.a1 = buffer.func_150789_c(40);
/* 35 */     this.a2 = buffer.func_150789_c(40);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 40 */     buffer.func_180714_a(this.a1);
/* 41 */     buffer.func_180714_a(this.a2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 46 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 47 */     wolf.setAbilitySlot1(WereList.getAbilityFromKey(this.a1));
/* 48 */     wolf.setAbilitySlot2(WereList.getAbilityFromKey(this.a2));
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SetEquippedAbilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */