/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ public class SetPlayerHitBox
/*    */   extends AbstractMessage<SetPlayerHitBox>
/*    */ {
/*    */   private float data;
/*    */   
/*    */   public SetPlayerHitBox() {}
/*    */   
/*    */   public SetPlayerHitBox(EntityPlayer player, float height) {
/* 17 */     this.data = height;
/* 18 */     player.field_70131_O = height;
/* 19 */     System.out.println("Changed hieght");
/* 20 */     player.func_174826_a(new AxisAlignedBB((player.func_174813_aQ()).field_72340_a, (player.func_174813_aQ()).field_72338_b, (player.func_174813_aQ()).field_72339_c, 
/* 21 */           (player.func_174813_aQ()).field_72340_a + player.field_70130_N, (player.func_174813_aQ()).field_72338_b + height, (player.func_174813_aQ()).field_72339_c + player.field_70130_N));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 26 */     this.data = buffer.readFloat();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 31 */     buffer.writeFloat(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 37 */     player.field_70131_O = this.data;
/* 38 */     player.func_174826_a(new AxisAlignedBB((player.func_174813_aQ()).field_72340_a, (player.func_174813_aQ()).field_72338_b, (player.func_174813_aQ()).field_72339_c, 
/* 39 */           (player.func_174813_aQ()).field_72340_a + player.field_70130_N, (player.func_174813_aQ()).field_72338_b + this.data, (player.func_174813_aQ()).field_72339_c + player.field_70130_N));
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SetPlayerHitBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */