/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DismountEntity
/*    */   extends AbstractMessage<DismountEntity>
/*    */ {
/*    */   public DismountEntity() {}
/*    */   
/*    */   public DismountEntity(EntityPlayer player) {}
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 26 */     if (!player.func_184188_bt().isEmpty())
/*    */     {
/* 28 */       player.func_184226_ay();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\DismountEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */