/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiftEntity2
/*    */   extends AbstractMessage.AbstractClientMessage<LiftEntity2>
/*    */ {
/*    */   private int data;
/*    */   private int data2;
/*    */   
/*    */   public LiftEntity2() {}
/*    */   
/*    */   public LiftEntity2(EntityPlayer player, Entity entity, Entity carry) {
/* 20 */     this.data = entity.func_145782_y();
/* 21 */     this.data2 = carry.func_145782_y();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 33 */     this.data = buffer.readInt();
/* 34 */     this.data2 = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 39 */     buffer.writeInt(this.data);
/* 40 */     buffer.writeInt(this.data2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 45 */     Entity e = player.field_70170_p.func_73045_a(this.data);
/* 46 */     Entity e2 = player.field_70170_p.func_73045_a(this.data2);
/*    */     
/* 48 */     if (!player.func_184188_bt().isEmpty())
/*    */     {
/*    */       
/* 51 */       player.func_184226_ay();
/*    */     }
/*    */ 
/*    */     
/* 55 */     if (e != null && e2 != null) {
/*    */ 
/*    */       
/* 58 */       e2.func_184220_m((Entity)player);
/* 59 */       e.func_184220_m(e2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\LiftEntity2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */