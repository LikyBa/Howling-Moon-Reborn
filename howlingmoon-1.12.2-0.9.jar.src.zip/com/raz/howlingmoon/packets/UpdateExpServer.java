/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateExpServer
/*    */   extends AbstractMessage.AbstractServerMessage<UpdateExpServer>
/*    */ {
/*    */   private int data;
/*    */   
/*    */   public UpdateExpServer() {}
/*    */   
/*    */   public UpdateExpServer(EntityPlayer player) {
/* 20 */     this.data = player.field_71068_ca;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 25 */     this.data = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 30 */     buffer.writeInt(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 35 */     player.field_71068_ca = this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\UpdateExpServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */