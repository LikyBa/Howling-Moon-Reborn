/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextComponentTranslation;
/*    */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BiteEntity
/*    */   extends AbstractMessage.AbstractServerMessage<BiteEntity>
/*    */ {
/*    */   private UUID data;
/*    */   
/*    */   public BiteEntity() {}
/*    */   
/*    */   public BiteEntity(EntityPlayer target) {
/* 28 */     this.data = target.getPersistentID();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 33 */     this.data = buffer.func_179253_g();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 38 */     buffer.func_179252_a(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 43 */     EntityPlayerMP entityPlayerMP = FMLCommonHandler.instance().getMinecraftServerInstance().func_184103_al().func_177451_a(this.data);
/* 44 */     if (entityPlayerMP != null) {
/*    */       
/* 46 */       IWerewolfCapability wolf = (IWerewolfCapability)entityPlayerMP.getCapability(WereEventHandler.WERE_CAP, null);
/* 47 */       if (!wolf.isWerewolf() && wolf.getInfected() == 0) {
/*    */         
/* 49 */         wolf.setInfected(1);
/* 50 */         PacketDispatcher.sendTo(new SyncInfectedMessage((EntityPlayer)entityPlayerMP), entityPlayerMP);
/* 51 */         entityPlayerMP.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.infected", new Object[0]));
/* 52 */         wolf.setTexture(2);
/* 53 */         PacketDispatcher.sendTo(new SyncWerewolfTextureMessage((EntityPlayer)entityPlayerMP), entityPlayerMP);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\BiteEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */