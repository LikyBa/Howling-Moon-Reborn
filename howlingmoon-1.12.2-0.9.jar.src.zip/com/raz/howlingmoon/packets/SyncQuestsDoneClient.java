/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncQuestsDoneClient
/*    */   extends AbstractMessage.AbstractClientMessage<SyncQuestsDoneClient>
/*    */ {
/*    */   private int quest;
/*    */   
/*    */   public SyncQuestsDoneClient() {}
/*    */   
/*    */   public SyncQuestsDoneClient(EntityPlayer player) {
/* 22 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*    */     
/* 24 */     this.quest = wolf.getQuestsDone();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 30 */     this.quest = buffer.readInt();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 36 */     buffer.writeInt(this.quest);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 41 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*    */     
/* 43 */     wolf.setQuestsDone(this.quest);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SyncQuestsDoneClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */