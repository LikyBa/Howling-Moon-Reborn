/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LaunchEntity
/*    */   extends AbstractMessage.AbstractServerMessage<LaunchEntity>
/*    */ {
/*    */   public LaunchEntity() {}
/*    */   
/*    */   public LaunchEntity(EntityPlayer player) {}
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 42 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 43 */     if (!player.func_184188_bt().isEmpty())
/*    */     {
/* 45 */       for (Entity carry : player.func_184188_bt()) {
/* 46 */         if (carry instanceof com.raz.howlingmoon.entities.EntityCarry) {
/*    */           
/* 48 */           if (carry.func_184188_bt().get(0) != null)
/*    */           {
/* 50 */             if (((Entity)carry.func_184188_bt().get(0)).func_70089_S()) {
/*    */               
/* 52 */               Entity rider = carry.func_184188_bt().get(0);
/* 53 */               rider.func_184210_p();
/* 54 */               carry.func_184210_p();
/* 55 */               int i = 2;
/* 56 */               float f = 0.4F;
/* 57 */               double motionX = (-MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F) * f);
/* 58 */               double motionZ = (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F) * f);
/* 59 */               double motionY = (-MathHelper.func_76126_a(player.field_70125_A / 180.0F * 3.1415927F) * f);
/*    */ 
/*    */               
/* 62 */               float f2 = MathHelper.func_76133_a(motionX * motionX + motionY * motionY + motionZ * motionZ);
/* 63 */               Random rand = new Random();
/* 64 */               motionX /= f2;
/* 65 */               motionY /= f2;
/* 66 */               motionZ /= f2;
/* 67 */               motionX += rand.nextGaussian() * 0.007499999832361937D;
/* 68 */               motionY += rand.nextGaussian() * 0.007499999832361937D;
/* 69 */               motionZ += rand.nextGaussian() * 0.007499999832361937D;
/* 70 */               motionX *= i;
/* 71 */               motionY *= i;
/* 72 */               motionZ *= i;
/*    */ 
/*    */ 
/*    */ 
/*    */               
/* 77 */               if (rider instanceof EntityPlayer) {
/* 78 */                 PacketDispatcher.sendTo(new ForceMovement((EntityPlayer)rider, motionX, motionY, motionZ), (EntityPlayerMP)rider); continue;
/*    */               } 
/* 80 */               rider.func_70024_g(motionX, motionY, motionZ);
/*    */             } 
/*    */           }
/*    */           
/*    */           continue;
/*    */         } 
/* 86 */         carry.func_184210_p();
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\LaunchEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */