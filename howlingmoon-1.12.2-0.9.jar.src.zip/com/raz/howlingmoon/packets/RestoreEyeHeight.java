/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ public class RestoreEyeHeight
/*    */   extends AbstractMessage<RestoreEyeHeight>
/*    */ {
/*    */   private float data;
/*    */   
/*    */   public RestoreEyeHeight() {}
/*    */   
/*    */   public RestoreEyeHeight(EntityPlayer player) {
/* 17 */     this.data = player.getDefaultEyeHeight();
/* 18 */     player.eyeHeight = player.getDefaultEyeHeight();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 23 */     this.data = buffer.readFloat();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 28 */     buffer.writeFloat(this.data);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 33 */     player.eyeHeight = this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\RestoreEyeHeight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */