/*     */ package com.raz.howlingmoon.packets;
/*     */ 
/*     */ import java.util.Set;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketDispatcher
/*     */ {
/*  18 */   private static byte packetId = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  25 */   private static final SimpleNetworkWrapper dispatcher = NetworkRegistry.INSTANCE.newSimpleChannel("howlingmoon");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void registerPackets() {
/*  32 */     registerMessage(SyncWereCapsMessage.class);
/*  33 */     registerMessage(TrackingMessage.class);
/*  34 */     registerMessage(SyncExpLevelClient.class);
/*  35 */     registerMessage(SyncQuestsDoneClient.class);
/*     */     
/*  37 */     registerMessage(ClientClimbMessage.class);
/*     */ 
/*     */     
/*  40 */     registerMessage(ForceMovement.class);
/*     */     
/*  42 */     registerMessage(LiftEntity2.class);
/*  43 */     registerMessage(SpawnParticle.class);
/*  44 */     registerMessage(StunEntity.class);
/*     */ 
/*     */     
/*  47 */     registerMessage(UpdateExpServer.class);
/*     */     
/*  49 */     registerMessage(TryTransformServerMessage.class);
/*     */     
/*  51 */     registerMessage(PlaySoundPacket.class);
/*  52 */     registerMessage(SyncLeapMessage.class);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     registerMessage(ResetFallMessage.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     registerMessage(LaunchEntity.class);
/*     */ 
/*     */     
/*  67 */     registerMessage(SetEquippedAbilities.class);
/*  68 */     registerMessage(LiftEntity.class);
/*  69 */     registerMessage(SneakJumpToggle.class);
/*  70 */     registerMessage(SprintJumpToggle.class);
/*  71 */     registerMessage(SprintClimbToggle.class);
/*  72 */     registerMessage(BiteEntity.class);
/*  73 */     registerMessage(MaimEntity.class);
/*  74 */     registerMessage(PawSlot.class);
/*     */     
/*  76 */     registerMessage(SyncRamStateMessage.class);
/*  77 */     registerMessage(SummonWolves.class);
/*     */ 
/*     */     
/*  80 */     registerMessage(SyncIsWerewolfMessage.class);
/*  81 */     registerMessage(SyncTransformMessage.class);
/*  82 */     registerMessage(SyncNightVisionMessage.class);
/*  83 */     registerMessage(SyncScentTrackingMessage.class);
/*     */ 
/*     */     
/*  86 */     registerMessage(SyncWerewolfTextureMessage.class);
/*     */     
/*  88 */     registerMessage(SyncWerewolfModelMessage.class);
/*     */     
/*  90 */     registerMessage(SyncInfectedMessage.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     registerMessage(SyncSprintKeyMessage.class);
/*  98 */     registerMessage(DismountEntity.class);
/*     */ 
/*     */     
/* 101 */     registerMessage(RestoreEyeHeight.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final <T extends AbstractMessage<T> & net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler<T, IMessage>> void registerMessage(Class<T> clazz) {
/* 114 */     if (AbstractMessage.AbstractClientMessage.class.isAssignableFrom(clazz)) {
/* 115 */       packetId = (byte)(packetId + 1); dispatcher.registerMessage(clazz, clazz, packetId, Side.CLIENT);
/* 116 */     } else if (AbstractMessage.AbstractServerMessage.class.isAssignableFrom(clazz)) {
/* 117 */       packetId = (byte)(packetId + 1); dispatcher.registerMessage(clazz, clazz, packetId, Side.SERVER);
/*     */     } else {
/*     */       
/* 120 */       dispatcher.registerMessage(clazz, clazz, packetId, Side.CLIENT);
/* 121 */       packetId = (byte)(packetId + 1); dispatcher.registerMessage(clazz, clazz, packetId, Side.SERVER);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendTo(IMessage message, EntityPlayerMP player) {
/* 136 */     dispatcher.sendTo(message, player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendToAll(IMessage message) {
/* 144 */     dispatcher.sendToAll(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToAllAround(IMessage message, NetworkRegistry.TargetPoint point) {
/* 152 */     dispatcher.sendToAllAround(message, point);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToAllAround(IMessage message, int dimension, double x, double y, double z, double range) {
/* 160 */     sendToAllAround(message, new NetworkRegistry.TargetPoint(dimension, x, y, z, range));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToAllAround(IMessage message, EntityPlayer player, double range) {
/* 168 */     sendToAllAround(message, player.field_70170_p.field_73011_w.getDimension(), player.field_70165_t, player.field_70163_u, player.field_70161_v, range);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToDimension(IMessage message, int dimensionId) {
/* 176 */     dispatcher.sendToDimension(message, dimensionId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToServer(IMessage message) {
/* 184 */     dispatcher.sendToServer(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void sendToPlayers(IMessage message, Set<? extends EntityPlayer> players) {
/* 202 */     for (EntityPlayer player : players)
/* 203 */       dispatcher.sendTo(message, (EntityPlayerMP)player); 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\PacketDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */