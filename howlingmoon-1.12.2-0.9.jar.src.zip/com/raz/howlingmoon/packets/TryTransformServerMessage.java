/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TryTransformServerMessage
/*    */   extends AbstractMessage.AbstractServerMessage<TryTransformServerMessage>
/*    */ {
/*    */   public TryTransformServerMessage() {}
/*    */   
/*    */   public TryTransformServerMessage(EntityPlayer player) {}
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 30 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 31 */     wolf.tryTransform(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\TryTransformServerMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */