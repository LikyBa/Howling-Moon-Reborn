/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.HMSounds;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.SoundCategory;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaySoundPacket
/*    */   extends AbstractMessage.AbstractServerMessage<PlaySoundPacket>
/*    */ {
/*    */   private float data;
/*    */   
/*    */   public PlaySoundPacket() {}
/*    */   
/*    */   public PlaySoundPacket(EntityPlayer player, float volume) {
/* 24 */     this.data = volume;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 30 */     this.data = buffer.readFloat();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 35 */     buffer.writeFloat(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 41 */     player.field_70170_p.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, HMSounds.howl, SoundCategory.NEUTRAL, this.data, 1.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\PlaySoundPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */