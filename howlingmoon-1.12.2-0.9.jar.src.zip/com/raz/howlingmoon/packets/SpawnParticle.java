/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.HowlingMoon;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpawnParticle
/*    */   extends AbstractMessage.AbstractClientMessage<SpawnParticle>
/*    */ {
/*    */   private float height;
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public SpawnParticle() {}
/*    */   
/*    */   public SpawnParticle(EntityPlayer player, Entity entity) {
/* 28 */     this.height = entity.field_70131_O;
/* 29 */     this.x = entity.field_70165_t;
/* 30 */     this.y = entity.field_70163_u;
/* 31 */     this.z = entity.field_70161_v;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 36 */     this.height = buffer.readFloat();
/* 37 */     this.x = buffer.readDouble();
/* 38 */     this.y = buffer.readDouble();
/* 39 */     this.z = buffer.readDouble();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 44 */     buffer.writeFloat(this.height);
/* 45 */     buffer.writeDouble(this.x);
/* 46 */     buffer.writeDouble(this.y);
/* 47 */     buffer.writeDouble(this.z);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 53 */     HowlingMoon.proxy.generateMoonPearlParticles(this.x, this.y + this.height + 0.5D, this.z, 0.0F, 0.6F + 0.4F * (float)Math.random(), 0.6F + 0.4F * (float)Math.random(), 0.4F);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SpawnParticle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */