/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import com.raz.howlingmoon.entities.EntityWolfSpirit;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SummonWolves
/*    */   extends AbstractMessage.AbstractServerMessage<SummonWolves>
/*    */ {
/*    */   private int data;
/*    */   
/*    */   public SummonWolves() {}
/*    */   
/*    */   public SummonWolves(EntityPlayer player) {}
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {}
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 37 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*    */     
/* 39 */     for (int i = 0; i < 1 + wolf.getLevel() / 10; i++) {
/*    */       
/* 41 */       EntityWolfSpirit spirit = new EntityWolfSpirit(player.field_70170_p, player, 0, wolf.getLevel(), wolf.getInclinationType());
/* 42 */       Vec3d pos = player.func_174791_d().func_178787_e(player.func_70040_Z().func_186678_a(1.5D));
/* 43 */       spirit.func_70012_b(pos.field_72450_a, player.field_70163_u + 0.1D, pos.field_72449_c, player.field_70177_z, 0.0F);
/* 44 */       spirit.field_70759_as = spirit.field_70177_z;
/* 45 */       spirit.field_70761_aq = spirit.field_70177_z;
/* 46 */       player.field_70170_p.func_72838_d((Entity)spirit);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SummonWolves.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */