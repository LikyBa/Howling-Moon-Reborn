/*    */ package com.raz.howlingmoon.packets;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import java.io.IOException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncExpLevelClient
/*    */   extends AbstractMessage.AbstractClientMessage<SyncExpLevelClient>
/*    */ {
/*    */   private int level;
/*    */   private int exp;
/*    */   
/*    */   public SyncExpLevelClient() {}
/*    */   
/*    */   public SyncExpLevelClient(EntityPlayer player) {
/* 24 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 25 */     this.level = wolf.getLevel();
/* 26 */     this.exp = wolf.getExp();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void read(PacketBuffer buffer) throws IOException {
/* 31 */     this.level = buffer.readInt();
/* 32 */     this.exp = buffer.readInt();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void write(PacketBuffer buffer) throws IOException {
/* 37 */     buffer.writeInt(this.level);
/* 38 */     buffer.writeInt(this.exp);
/*    */   }
/*    */ 
/*    */   
/*    */   public void process(EntityPlayer player, Side side) {
/* 43 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 44 */     wolf.setLevel(this.level);
/* 45 */     wolf.setExp(this.exp);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\packets\SyncExpLevelClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */