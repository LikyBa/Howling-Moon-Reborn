package com.raz.howlingmoon.reference;

public final class Names {
  public static final class Keys {
    public static final String CATEGORY = "keys.howlingmoon.category";
    
    public static final String MENU = "keys.howlingmoon.menu";
    
    public static final String TRANSFORM = "keys.howlingmoon.transform";
    
    public static final String ABILITY1 = "keys.howlingmoon.ability1";
    
    public static final String ABILITY2 = "keys.howlingmoon.ability2";
  }
}


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\reference\Names.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */