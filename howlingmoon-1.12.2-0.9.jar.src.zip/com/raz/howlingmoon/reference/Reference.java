package com.raz.howlingmoon.reference;

public class Reference {
  public static final String MOD_ID = "howlingmoon";
  
  public static final String MOD_NAME = "Howling Moon";
  
  public static final String VERSION = "0.9";
  
  public static final String DEPENDENCIES = "";
  
  public static final String CLIENT_PROXY_CLASS = "com.raz.howlingmoon.client.ClientProxy";
  
  public static final String COMMON_PROXY_CLASS = "com.raz.howlingmoon.CommonProxy";
}


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\reference\Reference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */