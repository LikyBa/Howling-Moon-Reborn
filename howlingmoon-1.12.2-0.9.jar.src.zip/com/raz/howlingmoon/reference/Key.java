/*   */ package com.raz.howlingmoon.reference;
/*   */ 
/*   */ public enum Key
/*   */ {
/* 5 */   UNKNOWN, TRANSFORM, MENU, ABILITY1, ABILITY2;
/*   */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\reference\Key.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */