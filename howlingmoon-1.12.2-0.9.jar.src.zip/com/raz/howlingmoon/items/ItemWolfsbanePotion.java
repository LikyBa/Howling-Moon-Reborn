/*     */ package com.raz.howlingmoon.items;
/*     */ 
/*     */ import com.raz.howlingmoon.HMCreativeTab;
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IModelRegister;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncInfectedMessage;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.stats.StatList;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.EnumActionResult;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ public class ItemWolfsbanePotion
/*     */   extends Item
/*     */   implements IModelRegister {
/*     */   public ItemWolfsbanePotion(String name) {
/*  34 */     setRegistryName(name);
/*  35 */     func_77655_b("howlingmoon." + name);
/*  36 */     func_77625_d(1);
/*  37 */     func_77637_a((CreativeTabs)HMCreativeTab.INSTANCE);
/*  38 */     HMItems.ITEMS.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ItemStack func_77654_b(ItemStack stack, World worldIn, EntityLivingBase entityLiving) {
/*  50 */     EntityPlayer entityplayer = (entityLiving instanceof EntityPlayer) ? (EntityPlayer)entityLiving : null;
/*     */     
/*  52 */     if (entityplayer == null || !entityplayer.field_71075_bZ.field_75098_d)
/*     */     {
/*  54 */       stack.func_190918_g(1);
/*     */     }
/*     */     
/*  57 */     if (!worldIn.field_72995_K)
/*     */     {
/*  59 */       if (entityLiving instanceof EntityPlayer) {
/*     */         
/*  61 */         EntityPlayer player = (EntityPlayer)entityLiving;
/*  62 */         IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*     */         
/*  64 */         if (wolf.isWerewolf()) {
/*     */           
/*  66 */           wolf.setWerewolf(false, player);
/*  67 */           player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.cure", new Object[0]));
/*     */         }
/*     */         else {
/*     */           
/*  71 */           if (wolf.getInfected() == -1) {
/*     */             
/*  73 */             wolf.setInfected(0);
/*  74 */             player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.antiimmune", new Object[0]));
/*     */           }
/*  76 */           else if (wolf.getInfected() == 0) {
/*     */             
/*  78 */             wolf.setInfected(-1);
/*  79 */             player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.immune", new Object[0]));
/*     */           }
/*     */           else {
/*     */             
/*  83 */             wolf.setInfected(0);
/*  84 */             player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.cure.infection", new Object[0]));
/*     */           } 
/*  86 */           PacketDispatcher.sendTo((IMessage)new SyncInfectedMessage(player), (EntityPlayerMP)player);
/*     */         } 
/*  88 */         player.func_70690_d(new PotionEffect(MobEffects.field_76436_u, 600, 0, true, true));
/*  89 */         player.func_70690_d(new PotionEffect(MobEffects.field_76431_k, 600, 0, true, false));
/*     */       } 
/*     */     }
/*     */     
/*  93 */     if (entityplayer != null)
/*     */     {
/*  95 */       entityplayer.func_71029_a(StatList.func_188057_b(this));
/*     */     }
/*     */     
/*  98 */     if (entityplayer == null || !entityplayer.field_71075_bZ.field_75098_d) {
/*     */       
/* 100 */       if (stack.func_190926_b())
/*     */       {
/* 102 */         return new ItemStack(Items.field_151069_bo);
/*     */       }
/*     */       
/* 105 */       if (entityplayer != null)
/*     */       {
/* 107 */         entityplayer.field_71071_by.func_70441_a(new ItemStack(Items.field_151069_bo));
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
/* 119 */     playerIn.func_184598_c(handIn);
/* 120 */     return new ActionResult(EnumActionResult.SUCCESS, playerIn.func_184586_b(handIn));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77626_a(ItemStack item) {
/* 126 */     return 32;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumAction func_77661_b(ItemStack item) {
/* 132 */     return EnumAction.DRINK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77636_d(ItemStack item) {
/* 138 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerModels() {
/* 144 */     HowlingMoon.proxy.registerItemRenderer(this, 0, "inventory");
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\items\ItemWolfsbanePotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */