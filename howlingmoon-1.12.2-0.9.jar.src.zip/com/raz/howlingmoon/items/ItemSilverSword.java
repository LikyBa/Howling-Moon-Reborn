/*    */ package com.raz.howlingmoon.items;
/*    */ 
/*    */ import com.raz.howlingmoon.HMCreativeTab;
/*    */ import com.raz.howlingmoon.HowlingMoon;
/*    */ import com.raz.howlingmoon.IModelRegister;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemSword;
/*    */ 
/*    */ public class ItemSilverSword
/*    */   extends ItemSword
/*    */   implements IModelRegister
/*    */ {
/*    */   public ItemSilverSword(Item.ToolMaterial material, String name) {
/* 15 */     super(material);
/* 16 */     setRegistryName(name);
/* 17 */     func_77655_b("howlingmoon." + name);
/* 18 */     func_77637_a((CreativeTabs)HMCreativeTab.INSTANCE);
/* 19 */     HMItems.ITEMS.add(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerModels() {
/* 25 */     HowlingMoon.proxy.registerItemRenderer((Item)this, 0, "inventory");
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\items\ItemSilverSword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */