/*    */ package com.raz.howlingmoon.items;
/*    */ 
/*    */ import com.raz.howlingmoon.HMCreativeTab;
/*    */ import com.raz.howlingmoon.HowlingMoon;
/*    */ import com.raz.howlingmoon.IModelRegister;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemSilverIngot
/*    */   extends Item
/*    */   implements IModelRegister
/*    */ {
/*    */   public ItemSilverIngot(String name) {
/* 14 */     setRegistryName(name);
/* 15 */     func_77655_b("howlingmoon." + name);
/* 16 */     func_77637_a((CreativeTabs)HMCreativeTab.INSTANCE);
/* 17 */     HMItems.ITEMS.add(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerModels() {
/* 23 */     HowlingMoon.proxy.registerItemRenderer(this, 0, "inventory");
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\items\ItemSilverIngot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */