/*    */ package com.raz.howlingmoon.items;
/*    */ 
/*    */ import com.raz.howlingmoon.HMCreativeTab;
/*    */ import com.raz.howlingmoon.HowlingMoon;
/*    */ import com.raz.howlingmoon.IModelRegister;
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*    */ import com.raz.howlingmoon.packets.SpawnParticle;
/*    */ import java.util.List;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemMoonstone
/*    */   extends Item
/*    */   implements IModelRegister
/*    */ {
/*    */   public ItemMoonstone(String name) {
/* 34 */     setRegistryName(name);
/* 35 */     func_77655_b("howlingmoon." + name);
/* 36 */     func_77637_a((CreativeTabs)HMCreativeTab.INSTANCE);
/* 37 */     HMItems.ITEMS.add(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_77663_a(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
/* 43 */     super.func_77663_a(stack, worldIn, entityIn, itemSlot, isSelected);
/* 44 */     if (entityIn instanceof EntityPlayer && !worldIn.field_72995_K) {
/*    */       
/* 46 */       EntityPlayer player = (EntityPlayer)entityIn;
/* 47 */       if (isSelected || player.func_184592_cb() == stack) {
/*    */         
/* 49 */         int range = 4;
/* 50 */         List<EntityPlayer> entities = entityIn.field_70170_p.func_72872_a(EntityPlayer.class, new AxisAlignedBB(entityIn.field_70165_t - range, entityIn.field_70163_u - range, entityIn.field_70161_v - range, entityIn.field_70165_t + range, entityIn.field_70163_u + range, entityIn.field_70161_v + range));
/* 51 */         for (EntityPlayer e : entities) {
/*    */ 
/*    */           
/* 54 */           IWerewolfCapability wolf = (IWerewolfCapability)e.getCapability(WereEventHandler.WERE_CAP, null);
/* 55 */           if (wolf.isWerewolf())
/*    */           {
/* 57 */             PacketDispatcher.sendTo((IMessage)new SpawnParticle(player, (Entity)e), (EntityPlayerMP)player);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerModels() {
/* 82 */     HowlingMoon.proxy.registerItemRenderer(this, 0, "inventory");
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\items\ItemMoonstone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */