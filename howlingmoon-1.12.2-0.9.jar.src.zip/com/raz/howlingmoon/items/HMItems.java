/*    */ package com.raz.howlingmoon.items;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraftforge.common.util.EnumHelper;
/*    */ 
/*    */ 
/*    */ public class HMItems
/*    */ {
/* 11 */   public static final List<Item> ITEMS = new ArrayList<>();
/*    */   
/* 13 */   public static final Item.ToolMaterial SILVER = EnumHelper.addToolMaterial("silver", 0, 32, 6.0F, 1.0F, 32);
/*    */   
/* 15 */   public static final Item moonstone = new ItemMoonstone("moonstone");
/* 16 */   public static final Item silverIngot = new ItemSilverIngot("ingot_silver");
/* 17 */   public static final Item silverSword = (Item)new ItemSilverSword(SILVER, "silver_sword");
/* 18 */   public static final Item potionWolfsbane = new ItemWolfsbanePotion("potion_wolfsbane");
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\items\HMItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */