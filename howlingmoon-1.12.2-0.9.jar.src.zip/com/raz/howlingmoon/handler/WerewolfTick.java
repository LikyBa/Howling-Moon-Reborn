/*     */ package com.raz.howlingmoon.handler;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import com.raz.howlingmoon.HMPotions;
/*     */ import com.raz.howlingmoon.HMSounds;
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.WereList;
/*     */ import com.raz.howlingmoon.dimension.HMTeleporter;
/*     */ import com.raz.howlingmoon.entities.EntityStun;
/*     */ import com.raz.howlingmoon.packets.ClientClimbMessage;
/*     */ import com.raz.howlingmoon.packets.DismountEntity;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.ResetFallMessage;
/*     */ import com.raz.howlingmoon.packets.StunEntity;
/*     */ import com.raz.howlingmoon.packets.SyncInfectedMessage;
/*     */ import com.raz.howlingmoon.packets.SyncSprintKeyMessage;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.common.ForgeHooks;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WerewolfTick
/*     */ {
/*  69 */   private static Set climbableBlocks = Sets.newHashSet((Object[])new Block[] { (Block)Blocks.field_150349_c, Blocks.field_150346_d, Blocks.field_150433_aE, Blocks.field_150435_aG, Blocks.field_150458_ak, Blocks.field_150425_aM, (Block)Blocks.field_150391_bh });
/*  70 */   private static Set climbableBlocks2 = Sets.newHashSet((Object[])new Block[] { (Block)Blocks.field_150349_c, Blocks.field_150346_d, Blocks.field_150433_aE, Blocks.field_150435_aG, Blocks.field_150458_ak, Blocks.field_150425_aM, (Block)Blocks.field_150391_bh, Blocks.field_150344_f, Blocks.field_150342_X, Blocks.field_150364_r, Blocks.field_150363_s, Blocks.field_150325_L, Blocks.field_150360_v });
/*     */   
/*  72 */   private static Set climbableBlocks3 = Sets.newHashSet((Object[])new Block[] { (Block)Blocks.field_150349_c, Blocks.field_150346_d, Blocks.field_150433_aE, Blocks.field_150435_aG, Blocks.field_150458_ak, Blocks.field_150425_aM, (Block)Blocks.field_150391_bh, Blocks.field_150344_f, Blocks.field_150342_X, Blocks.field_150364_r, Blocks.field_150363_s, Blocks.field_150325_L, Blocks.field_150360_v, Blocks.field_180399_cE, (Block)Blocks.field_150354_m, Blocks.field_150351_n, Blocks.field_150407_cf, Blocks.field_150428_aP, Blocks.field_150423_aK, Blocks.field_150440_ba, Blocks.field_150420_aW, Blocks.field_150419_aX });
/*     */ 
/*     */   
/*  75 */   private static Set climbableBlocks4 = Sets.newHashSet((Object[])new Block[] { (Block)Blocks.field_150349_c, Blocks.field_150346_d, Blocks.field_150433_aE, Blocks.field_150435_aG, Blocks.field_150458_ak, Blocks.field_150425_aM, (Block)Blocks.field_150391_bh, Blocks.field_150344_f, Blocks.field_150342_X, Blocks.field_150364_r, Blocks.field_150363_s, Blocks.field_150325_L, Blocks.field_150360_v, Blocks.field_180399_cE, (Block)Blocks.field_150354_m, Blocks.field_150351_n, Blocks.field_150407_cf, Blocks.field_150428_aP, Blocks.field_150423_aK, Blocks.field_150440_ba, Blocks.field_150420_aW, Blocks.field_150419_aX, Blocks.field_150347_e, Blocks.field_150463_bK, Blocks.field_150341_Y, Blocks.field_180397_cI });
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static Set climbableBlocks5 = Sets.newHashSet((Object[])new Block[] { (Block)Blocks.field_150349_c, Blocks.field_150346_d, Blocks.field_150433_aE, Blocks.field_150435_aG, Blocks.field_150458_ak, Blocks.field_150425_aM, (Block)Blocks.field_150391_bh, Blocks.field_150344_f, Blocks.field_150342_X, Blocks.field_150364_r, Blocks.field_150363_s, Blocks.field_150325_L, Blocks.field_150360_v, Blocks.field_180399_cE, (Block)Blocks.field_150354_m, Blocks.field_150351_n, Blocks.field_150407_cf, Blocks.field_150428_aP, Blocks.field_150423_aK, Blocks.field_150440_ba, Blocks.field_150420_aW, Blocks.field_150419_aX, Blocks.field_150347_e, Blocks.field_150463_bK, Blocks.field_150341_Y, Blocks.field_180397_cI, Blocks.field_150343_Z, Blocks.field_150411_aY, Blocks.field_150386_bk, Blocks.field_150417_aV, (Block)Blocks.field_150333_U, (Block)Blocks.field_180389_cP });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerTick(TickEvent.PlayerTickEvent event) {
/*  95 */     if (event.phase == TickEvent.Phase.START) {
/*     */       
/*  97 */       EntityPlayer player = event.player;
/*  98 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*     */       
/* 100 */       if (wolf.isTransformed() && wolf.getModel() != 1 && wolf.getAbilityTreeAbility(WereList.CLIMB.getKey()) && wolf.getClimb())
/*     */       {
/* 102 */         if (climbingHold(player) && !player.field_70122_E) {
/*     */           
/* 104 */           if (player.field_70181_x < -0.6D) {
/*     */             
/* 106 */             if (player.func_70658_aO() < 1) {
/* 107 */               player.field_70181_x *= 0.85D;
/*     */             } else {
/* 109 */               player.field_70181_x *= 0.7D;
/*     */             } 
/* 111 */           } else if (player.field_70181_x < 0.0D) {
/* 112 */             player.field_70181_x = 0.0D;
/* 113 */           }  player.field_70143_R = 0.0F;
/*     */         }
/* 115 */         else if (player.field_70170_p.field_72995_K && !climbingHold(player) && climbAllowed(player)) {
/*     */           
/* 117 */           if ((wolf.getSprintClimb() == 4 || (wolf.getSprintClimb() == 5 && !player.field_70122_E)) && wolf.isSprintKey()) {
/*     */             
/* 119 */             if (player.field_70181_x < -0.6D)
/*     */             {
/* 121 */               if (player.func_70658_aO() < 1) {
/* 122 */                 player.field_70181_x *= 0.85D;
/*     */               } else {
/* 124 */                 player.field_70181_x *= 0.7D;
/*     */               } 
/*     */             }
/* 127 */             player.func_70107_b(player.field_70169_q, player.field_70163_u, player.field_70166_s);
/* 128 */             if (player.field_191988_bg != 0.0F) {
/*     */               
/* 130 */               if (player.field_191988_bg > 0.0F) {
/*     */                 
/* 132 */                 if (player.func_70658_aO() < 1) {
/* 133 */                   player.field_70181_x = getClimbSpeed(wolf);
/*     */                 } else {
/* 135 */                   player.field_70181_x = getClimbSpeed(wolf) / 2.0D;
/*     */                 } 
/*     */               } else {
/*     */                 
/* 139 */                 player.field_191988_bg = 0.0F;
/* 140 */                 if (player.func_70658_aO() < 1) {
/* 141 */                   player.field_70181_x = -getClimbSpeed(wolf);
/*     */                 } else {
/* 143 */                   player.field_70181_x = -getClimbSpeed(wolf) / 2.0D;
/*     */                 } 
/*     */               } 
/* 146 */             } else if (player.field_70181_x < 0.0D) {
/* 147 */               player.field_70181_x = 0.0D;
/* 148 */             }  player.field_70143_R = 0.0F;
/* 149 */             PacketDispatcher.sendToServer((IMessage)new ResetFallMessage(player));
/*     */           }
/* 151 */           else if (player.field_70123_F && wolf.getSprintClimb() != 4) {
/*     */             
/* 153 */             if (player.field_70181_x < -0.6D) {
/*     */               
/* 155 */               if (player.func_70658_aO() < 1) {
/* 156 */                 player.field_70181_x *= 0.85D;
/*     */               } else {
/* 158 */                 player.field_70181_x *= 0.7D;
/*     */               } 
/* 160 */             } else if (player.func_70658_aO() < 1) {
/* 161 */               player.field_70181_x = getClimbSpeed(wolf);
/*     */             } else {
/* 163 */               player.field_70181_x = getClimbSpeed(wolf) / 2.0D;
/* 164 */             }  player.field_70143_R = 0.0F;
/* 165 */             PacketDispatcher.sendToServer((IMessage)new ResetFallMessage(player));
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 170 */       if (!event.player.field_70170_p.field_72995_K) {
/*     */ 
/*     */         
/* 173 */         if (event.player.field_71093_bK == ConfigHandler.dimID)
/*     */         {
/*     */           
/* 176 */           if (event.player.field_70163_u < 55.0D || !wolf.isWerewolf())
/*     */           {
/* 178 */             HMTeleporter.returnFromDimension(event.player);
/*     */           }
/*     */         }
/*     */         
/* 182 */         if (wolf.isTransformed() && wolf.getModel() != 1 && wolf.getAbilityTreeAbility(WereList.CLIMB.getKey()) && canClimb(player, (int)Math.floor((wolf.getLevel() / 5))) != wolf.getClimb()) {
/*     */           
/* 184 */           wolf.setClimb(!wolf.getClimb());
/* 185 */           PacketDispatcher.sendTo((IMessage)new ClientClimbMessage(player), (EntityPlayerMP)player);
/*     */         } 
/*     */         
/* 188 */         if (!player.field_70170_p.func_72935_r()) {
/*     */           
/* 190 */           if (player.field_70170_p.func_130001_d() == 1.0F) {
/*     */             
/* 192 */             if (wolf.isWerewolf())
/*     */             {
/* 194 */               if (!wolf.isTransformed())
/*     */               {
/*     */                 
/* 197 */                 wolf.setTransformed(true, true, event.side, player);
/* 198 */                 player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.fullmoon", new Object[0]));
/* 199 */                 if (event.player.field_71093_bK == ConfigHandler.dimID)
/*     */                 {
/*     */                   
/* 202 */                   player.func_145747_a((ITextComponent)new TextComponentTranslation("guide.message.welcome" + wolf.getQuestsDone(), new Object[0]));
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/* 207 */             else if (wolf.getInfected() == 2)
/*     */             {
/* 209 */               wolf.setWerewolf(true, player);
/* 210 */               wolf.setTransformed(true, true, event.side, player);
/* 211 */               player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.fullmoon", new Object[0]));
/*     */             }
/*     */           
/* 214 */           } else if (wolf.isWerewolf() && !wolf.isTransformed() && wolf.getQuestsDone() > 7 && wolf.getInclinationType() == -1) {
/*     */             
/* 216 */             wolf.setTransformed(true, true, event.side, player);
/* 217 */             player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.night", new Object[0]));
/*     */           }
/*     */         
/* 220 */         } else if (wolf.getMoonTransformation()) {
/*     */           
/* 222 */           if (wolf.isTransformed()) {
/* 223 */             wolf.setTransformed(false, true, event.side, player);
/*     */           }
/* 225 */         } else if (wolf.getInfected() == 1) {
/*     */           
/* 227 */           wolf.setInfected(2);
/* 228 */           PacketDispatcher.sendTo((IMessage)new SyncInfectedMessage(player), (EntityPlayerMP)player);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 245 */         if (wolf.isTransformed()) {
/*     */           
/* 247 */           if (!wolf.getAbilityTreeAbility(WereList.PAW.getKey()) && !emptyPaws(player)) {
/*     */             
/* 249 */             player.func_71040_bB(true);
/* 250 */             if (player.func_184592_cb() != null)
/* 251 */               ForgeHooks.onPlayerTossEvent(player, player.field_71071_by.func_70298_a(player.field_71071_by.func_70302_i_() - 1, player.func_184592_cb().func_190916_E()), true); 
/*     */           } 
/* 253 */           if (!player.func_184812_l_() && (!wolf.getAbilityTreeAbility(WereList.ARMOR.getKey()) || wolf.getModel() > 0 || (wolf.getInclinationType() < 0 && wolf.getQuestsDone() > 7))) {
/*     */             
/* 255 */             if (!player.func_184582_a(EntityEquipmentSlot.HEAD).func_190926_b()) {
/*     */               
/* 257 */               ItemStack stack = player.func_184582_a(EntityEquipmentSlot.HEAD);
/* 258 */               int slot = getFirstNonPawEmptyStack(player, wolf);
/* 259 */               if (wolf.getAbilityTreeAbility(WereList.ARMOR.getKey()) && slot != -1) {
/*     */                 
/* 261 */                 player.field_71071_by.func_70299_a(slot, player.field_71071_by.func_70304_b(player.field_71071_by.func_70302_i_() - 2));
/*     */               }
/* 263 */               else if (stack.func_77973_b().onDroppedByPlayer(stack, player)) {
/*     */                 
/* 265 */                 ForgeHooks.onPlayerTossEvent(player, player.field_71071_by.func_70298_a(player.field_71071_by.func_70302_i_() - 2, 1), true);
/*     */               } 
/*     */             } 
/* 268 */             if (!player.func_184582_a(EntityEquipmentSlot.CHEST).func_190926_b()) {
/*     */               
/* 270 */               ItemStack stack = player.func_184582_a(EntityEquipmentSlot.CHEST);
/* 271 */               int slot = getFirstNonPawEmptyStack(player, wolf);
/* 272 */               if (wolf.getAbilityTreeAbility(WereList.ARMOR.getKey()) && slot != -1) {
/*     */                 
/* 274 */                 player.field_71071_by.func_70299_a(slot, player.field_71071_by.func_70304_b(player.field_71071_by.func_70302_i_() - 3));
/*     */               }
/* 276 */               else if (stack.func_77973_b().onDroppedByPlayer(stack, player)) {
/*     */                 
/* 278 */                 ForgeHooks.onPlayerTossEvent(player, player.field_71071_by.func_70298_a(player.field_71071_by.func_70302_i_() - 3, 1), true);
/*     */               } 
/*     */             } 
/* 281 */             if (!player.func_184582_a(EntityEquipmentSlot.LEGS).func_190926_b()) {
/*     */               
/* 283 */               ItemStack stack = player.func_184582_a(EntityEquipmentSlot.LEGS);
/* 284 */               int slot = getFirstNonPawEmptyStack(player, wolf);
/* 285 */               if (wolf.getAbilityTreeAbility(WereList.ARMOR.getKey()) && slot != -1) {
/*     */                 
/* 287 */                 player.field_71071_by.func_70299_a(slot, player.field_71071_by.func_70304_b(player.field_71071_by.func_70302_i_() - 4));
/*     */               }
/* 289 */               else if (stack.func_77973_b().onDroppedByPlayer(stack, player)) {
/*     */                 
/* 291 */                 ForgeHooks.onPlayerTossEvent(player, player.field_71071_by.func_70298_a(player.field_71071_by.func_70302_i_() - 4, 1), true);
/*     */               } 
/*     */             } 
/* 294 */             if (!player.func_184582_a(EntityEquipmentSlot.FEET).func_190926_b()) {
/*     */               
/* 296 */               ItemStack stack = player.func_184582_a(EntityEquipmentSlot.FEET);
/* 297 */               int slot = getFirstNonPawEmptyStack(player, wolf);
/* 298 */               if (wolf.getAbilityTreeAbility(WereList.ARMOR.getKey()) && slot != -1) {
/*     */                 
/* 300 */                 player.field_71071_by.func_70299_a(slot, player.field_71071_by.func_70304_b(player.field_71071_by.func_70302_i_() - 5));
/*     */               }
/* 302 */               else if (stack.func_77973_b().onDroppedByPlayer(stack, player)) {
/*     */                 
/* 304 */                 ForgeHooks.onPlayerTossEvent(player, player.field_71071_by.func_70298_a(player.field_71071_by.func_70302_i_() - 5, 1), true);
/*     */               } 
/*     */             } 
/*     */           } 
/* 308 */           int resist = wolf.getAttributeTreeAbility(WereList.RESISTANCE.getKey());
/* 309 */           if (resist > 0)
/*     */           {
/* 311 */             switch (resist) {
/*     */               
/*     */               case 5:
/* 314 */                 if (player.func_70644_a(MobEffects.field_82731_v))
/*     */                 {
/* 316 */                   player.func_184589_d(MobEffects.field_82731_v);
/*     */                 }
/*     */               case 4:
/* 319 */                 if (player.func_70644_a(MobEffects.field_76419_f))
/*     */                 {
/* 321 */                   player.func_184589_d(MobEffects.field_76419_f);
/*     */                 }
/*     */               case 3:
/* 324 */                 if (player.func_70644_a(MobEffects.field_76421_d))
/*     */                 {
/* 326 */                   player.func_184589_d(MobEffects.field_76421_d);
/*     */                 }
/*     */               case 2:
/* 329 */                 if (player.func_70644_a(MobEffects.field_76436_u))
/*     */                 {
/* 331 */                   player.func_184589_d(MobEffects.field_76436_u);
/*     */                 }
/*     */               case 1:
/* 334 */                 if (player.func_70644_a(MobEffects.field_76437_t))
/*     */                 {
/* 336 */                   player.func_184589_d(MobEffects.field_76437_t); } 
/*     */                 break;
/*     */             } 
/*     */           }
/*     */         } 
/* 341 */         if (wolf.isWerewolf()) {
/*     */           
/* 343 */           wolf.incTick();
/* 344 */           if (wolf.getTick() % 20 == 0) {
/*     */ 
/*     */             
/* 347 */             wolf.deincCDExhil();
/* 348 */             wolf.deincCDBerserk();
/* 349 */             if (wolf.isTransformed()) {
/*     */               
/* 351 */               if (player.field_71093_bK == ConfigHandler.dimID) {
/* 352 */                 player.func_71024_bL().func_75122_a(1, 4.0F);
/*     */               } else {
/*     */                 
/* 355 */                 float hunger = (6.0F - wolf.getAttributeTreeAbility(WereList.HUNGER.getKey())) / 60.0F;
/* 356 */                 hunger *= Math.min(wolf.getLevel(), 25.0F);
/* 357 */                 if (wolf.getModel() == 2)
/* 358 */                   hunger *= 2.0F; 
/* 359 */                 player.func_71020_j(hunger);
/*     */               } 
/*     */               
/* 362 */               if (!player.func_70644_a((Potion)HMPotions.SILVERPOISON)) {
/*     */                 
/* 364 */                 int regen = wolf.getAttributeTreeAbility(WereList.REGENERATION.getKey());
/*     */                 
/* 366 */                 if (wolf.getTick() > 299.0D * Math.pow(0.5D, regen)) {
/*     */                   
/* 368 */                   wolf.resetTick();
/* 369 */                   player.func_70691_i(1.0F);
/*     */                 } 
/*     */               } else {
/*     */                 
/* 373 */                 wolf.resetTick();
/*     */               } 
/*     */             } else {
/* 376 */               wolf.resetTick();
/*     */             } 
/*     */           } 
/* 379 */           if (wolf.isTransformed() && player.func_70051_ag() && wolf.getAbilityTreeAbility(WereList.RAM.getKey()) && (wolf
/* 380 */             .getSprintRam() == 2 || (wolf.getSprintRam() == 1 && wolf.isSprintKey()))) {
/*     */             
/* 382 */             int range = 1;
/* 383 */             List<EntityLivingBase> entities = player.field_70170_p.func_72872_a(EntityLivingBase.class, new AxisAlignedBB(player.field_70165_t - range, player.field_70163_u - range, player.field_70161_v - range, player.field_70165_t + range, player.field_70163_u + range, player.field_70161_v + range));
/*     */ 
/*     */             
/* 386 */             for (int i = 0; i < entities.size(); i++) {
/*     */               
/* 388 */               EntityLivingBase entity = entities.get(i);
/*     */               
/* 390 */               if (!entity.func_184218_aH())
/*     */               {
/* 392 */                 if (!(entity instanceof EntityPlayer)) {
/*     */                   
/* 394 */                   double d1 = player.field_70165_t - entity.field_70165_t;
/*     */                   
/*     */                   double d0;
/* 397 */                   for (d0 = player.field_70161_v - entity.field_70161_v; d1 * d1 + d0 * d0 < 1.0E-4D; d0 = (Math.random() - Math.random()) * 0.01D)
/*     */                   {
/* 399 */                     d1 = (Math.random() - Math.random()) * 0.01D;
/*     */                   }
/* 401 */                   EntityStun stun = new EntityStun(player.field_70170_p);
/* 402 */                   stun.changeSize(entity.field_70130_N, entity.field_70131_O);
/* 403 */                   stun.func_70012_b(entity.field_70165_t, entity.field_70163_u + 0.5D, entity.field_70161_v, 0.0F, 0.0F);
/* 404 */                   player.field_70170_p.func_72838_d((Entity)stun);
/* 405 */                   PacketDispatcher.sendTo((IMessage)new StunEntity(player, (Entity)entity, (Entity)stun), (EntityPlayerMP)player);
/* 406 */                   if (entity.func_184220_m((Entity)stun)) {
/* 407 */                     stun.knockBack((Entity)stun, 1.0F, d1, d0);
/*     */                   }
/* 409 */                 } else if (entity instanceof EntityPlayer && FMLCommonHandler.instance().getMinecraftServerInstance() != null && FMLCommonHandler.instance().getMinecraftServerInstance().func_71219_W()) {
/*     */                   
/* 411 */                   if (!((EntityPlayer)entity).equals(player)) {
/*     */                     
/* 413 */                     double d1 = player.field_70165_t - entity.field_70165_t;
/*     */                     
/*     */                     double d0;
/* 416 */                     for (d0 = player.field_70161_v - entity.field_70161_v; d1 * d1 + d0 * d0 < 1.0E-4D; d0 = (Math.random() - Math.random()) * 0.01D)
/*     */                     {
/* 418 */                       d1 = (Math.random() - Math.random()) * 0.01D;
/*     */                     }
/* 420 */                     EntityStun stun = new EntityStun(player.field_70170_p);
/* 421 */                     stun.changeSize(entity.field_70130_N, entity.field_70131_O);
/* 422 */                     stun.func_70012_b(entity.field_70165_t, entity.field_70163_u + 0.5D, entity.field_70161_v, 0.0F, 0.0F);
/* 423 */                     player.field_70170_p.func_72838_d((Entity)stun);
/* 424 */                     PacketDispatcher.sendTo((IMessage)new StunEntity(player, (Entity)entity, (Entity)stun), (EntityPlayerMP)player);
/*     */                     
/* 426 */                     if (entity.func_184220_m((Entity)stun)) {
/* 427 */                       stun.knockBack((Entity)stun, 1.0F, d1, d0);
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 435 */         if (!player.func_184188_bt().isEmpty() && (!emptyPaws(player) || !wolf.getAbilityTreeAbility(WereList.LIFT.getKey()) || !wolf.isWerewolf()))
/*     */         {
/*     */           
/* 438 */           for (Entity e : player.func_184188_bt()) {
/*     */             
/* 440 */             if (e instanceof com.raz.howlingmoon.entities.EntityCarry) {
/*     */               
/* 442 */               player.func_184226_ay();
/* 443 */               PacketDispatcher.sendTo((IMessage)new DismountEntity(player), (EntityPlayerMP)player);
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } else {
/* 451 */         if (wolf.isTransformed()) {
/*     */ 
/*     */           
/* 454 */           wolf.incTick();
/* 455 */           if (wolf.getTick() > 19) {
/*     */             
/* 457 */             wolf.deincCDHowl();
/* 458 */             if (wolf.getAbilityTreeAbility(WereList.SCENTRACKING.getKey()) && wolf.getScentTracking() && !player.func_70055_a(Material.field_151586_h)) {
/*     */               
/* 460 */               int range = Math.min(40, wolf.getLevel() * 2);
/* 461 */               List<EntityLiving> entities = player.field_70170_p.func_72872_a(EntityLiving.class, new AxisAlignedBB(player.field_70165_t - range, player.field_70163_u - range, player.field_70161_v - range, player.field_70165_t + range, player.field_70163_u + range, player.field_70161_v + range));
/*     */               
/* 463 */               for (Entity e : entities) {
/* 464 */                 int color = wolf.getScentColor(e.getClass());
/*     */ 
/*     */                 
/* 467 */                 if (e instanceof EntityMob) {
/*     */                   
/* 469 */                   int i = wolf.getScentColor(EntityMob.class);
/* 470 */                   if (i != 1) {
/*     */                     
/* 472 */                     if (color == 0) {
/* 473 */                       HowlingMoon.proxy.generateScentParticles(e, i); continue;
/* 474 */                     }  if (color != 1)
/* 475 */                       HowlingMoon.proxy.generateScentParticles(e, color); 
/*     */                   }  continue;
/*     */                 } 
/* 478 */                 if (e instanceof EntityAnimal) {
/*     */                   
/* 480 */                   int i = wolf.getScentColor(EntityAnimal.class);
/* 481 */                   if (i != 1) {
/*     */                     
/* 483 */                     if (color == 0) {
/* 484 */                       HowlingMoon.proxy.generateScentParticles(e, i); continue;
/* 485 */                     }  if (color != 1)
/* 486 */                       HowlingMoon.proxy.generateScentParticles(e, color); 
/*     */                   }  continue;
/*     */                 } 
/* 489 */                 if (e instanceof EntityCreature) {
/*     */                   
/* 491 */                   int i = wolf.getScentColor(EntityCreature.class);
/* 492 */                   if (i != 1) {
/*     */                     
/* 494 */                     if (color == 0) {
/* 495 */                       HowlingMoon.proxy.generateScentParticles(e, i); continue;
/* 496 */                     }  if (color != 1) {
/* 497 */                       HowlingMoon.proxy.generateScentParticles(e, color);
/*     */                     }
/*     */                   } 
/*     */                   continue;
/*     */                 } 
/* 502 */                 int colorParent = wolf.getScentColor(EntityLiving.class);
/* 503 */                 if (colorParent != 1) {
/*     */                   
/* 505 */                   if (color == 0) {
/* 506 */                     HowlingMoon.proxy.generateScentParticles(e, colorParent); continue;
/* 507 */                   }  if (color != 1) {
/* 508 */                     HowlingMoon.proxy.generateScentParticles(e, color);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/* 513 */             wolf.resetTick();
/*     */           } 
/*     */         } 
/*     */         
/* 517 */         if (!wolf.isWerewolf() && wolf.getInfected() == 2 && player.field_70170_p.func_130001_d() == 1.0F) {
/*     */           
/* 519 */           wolf.incTick();
/* 520 */           if (wolf.getTick() > 2400 && !wolf.getDisplayRage()) {
/*     */             
/* 522 */             wolf.setDisplayRage(true);
/* 523 */             player.field_70170_p.func_184148_a(player, player.field_70165_t, player.field_70163_u, player.field_70161_v, HMSounds.heartbeat_delay, SoundCategory.NEUTRAL, 1.0F, 1.0F);
/*     */           } 
/* 525 */           if (wolf.getTick() > 2500) {
/*     */             
/* 527 */             wolf.resetTick();
/* 528 */             if (wolf.getDisplayRage())
/*     */             {
/* 530 */               wolf.setDisplayRage(false);
/*     */             }
/*     */           } 
/*     */         } 
/* 534 */         if ((Minecraft.func_71410_x()).field_71474_y.field_151444_V.func_151470_d()) {
/*     */           
/* 536 */           if (!wolf.isSprintKey())
/*     */           {
/* 538 */             wolf.setSprintKey(true);
/* 539 */             PacketDispatcher.sendToServer((IMessage)new SyncSprintKeyMessage(player));
/*     */           }
/*     */         
/* 542 */         } else if (wolf.isSprintKey()) {
/*     */           
/* 544 */           wolf.setSprintKey(false);
/* 545 */           PacketDispatcher.sendToServer((IMessage)new SyncSprintKeyMessage(player));
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 550 */       EntityPlayer player = event.player;
/* 551 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 552 */       if (wolf.isTransformed()) {
/*     */         
/* 554 */         if (wolf.getModel() == 1)
/*     */         {
/*     */           
/* 557 */           updateSize((EntityLivingBase)player, 0.6F, wolf.getModelHeight());
/*     */         }
/* 559 */         if (wolf.getModel() == 2)
/*     */         {
/* 561 */           if (!player.func_70093_af() && !player.func_70051_ag()) {
/*     */             
/* 563 */             updateSize((EntityLivingBase)player, 0.8F, wolf.getModelHeight());
/*     */           } else {
/*     */             
/* 566 */             updateSize((EntityLivingBase)player, 1.2F, 1.8F);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void werewolfItemPickup(PlayerEvent.ItemPickupEvent event) {
/* 589 */     IWerewolfCapability wolf = (IWerewolfCapability)event.player.getCapability(WereEventHandler.WERE_CAP, null);
/* 590 */     if (wolf.getPawSlot() > -1 && wolf.getPawSlot() < 9)
/*     */     {
/* 592 */       if (wolf.isTransformed()) {
/*     */         
/* 594 */         EntityPlayer player = event.player;
/* 595 */         if (player.field_71071_by.func_70301_a(wolf.getPawSlot()) != null) {
/*     */           
/* 597 */           int slot = getFirstNonPawEmptyStack(player, wolf);
/* 598 */           if (slot != -1)
/*     */           {
/* 600 */             player.field_71071_by.func_70299_a(slot, player.field_71071_by.func_70304_b(wolf.getPawSlot()));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstNonPawEmptyStack(EntityPlayer player, IWerewolfCapability wolf) {
/* 613 */     for (int i = 0; i < player.field_71071_by.field_70462_a.size(); i++) {
/*     */       
/* 615 */       if (((ItemStack)player.field_71071_by.field_70462_a.get(i)).func_190926_b())
/*     */       {
/* 617 */         if (wolf.getPawSlot() != i) {
/* 618 */           return i;
/*     */         }
/*     */       }
/*     */     } 
/* 622 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canClimb(EntityPlayer player, int tier) {
/* 645 */     for (int i = -1; i <= 1; i++) {
/* 646 */       for (int k = -1; k <= 1; k++) {
/* 647 */         for (int y = 0; y < 2; y++) {
/*     */           
/* 649 */           if (Math.abs(i) != Math.abs(k)) {
/*     */             
/* 651 */             BlockPos blockPos = new BlockPos((int)Math.floor(player.field_70165_t) + i, (int)player.field_70163_u + y, (int)Math.floor(player.field_70161_v) + k);
/* 652 */             Block block = player.field_70170_p.func_180495_p(blockPos).func_177230_c();
/* 653 */             switch (tier) {
/*     */               
/*     */               case 0:
/* 656 */                 if (climbableBlocks.contains(block))
/* 657 */                   return true; 
/*     */                 break;
/*     */               case 1:
/* 660 */                 if (climbableBlocks2.contains(block))
/* 661 */                   return true; 
/*     */                 break;
/*     */               case 2:
/* 664 */                 if (climbableBlocks3.contains(block))
/* 665 */                   return true; 
/*     */                 break;
/*     */               case 3:
/* 668 */                 if (climbableBlocks4.contains(block))
/* 669 */                   return true; 
/*     */                 break;
/*     */               case 4:
/* 672 */                 if (climbableBlocks5.contains(block))
/* 673 */                   return true; 
/*     */                 break;
/*     */               default:
/* 676 */                 if (climbableBlocks5.contains(block))
/* 677 */                   return true;  break;
/*     */             } 
/* 679 */             if (((block.func_176223_P() == Material.field_151575_d && tier > 0) || block.func_176223_P() == Material.field_151584_j) && block
/* 680 */               .func_176223_P().func_185900_c((IBlockAccess)player.field_70170_p, blockPos) != null)
/* 681 */               return true; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 686 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getClimbSpeed(IWerewolfCapability wolf) {
/* 691 */     int speed = wolf.getAttributeTreeAbility(WereList.MOVEMENT.getKey());
/* 692 */     return 0.0588D + speed * 0.02352D;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean emptyPaws(EntityPlayer player) {
/* 697 */     if (player.func_184614_ca().func_190926_b() && player.func_184592_cb().func_190926_b()) {
/* 698 */       return true;
/*     */     }
/*     */     
/* 701 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean climbingHold(EntityPlayer player) {
/* 706 */     if (player.func_70093_af())
/* 707 */       return true; 
/* 708 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 709 */     if (wolf.isSprintKey() && wolf.getSprintClimb() == 3)
/* 710 */       return true; 
/* 711 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean climbAllowed(EntityPlayer player) {
/* 716 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/* 717 */     switch (wolf.getSprintClimb()) {
/*     */       case 0:
/* 719 */         return true;
/*     */       case 1:
/* 721 */         if (wolf.isSprintKey())
/* 722 */           return true; 
/* 723 */         return false;
/*     */       case 2:
/* 725 */         if (wolf.isSprintKey())
/* 726 */           return false; 
/* 727 */         return true;
/*     */       case 3:
/* 729 */         if (wolf.isSprintKey())
/* 730 */           return false; 
/* 731 */         return true;
/* 732 */       case 4: return true;
/* 733 */       case 5: return true;
/* 734 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateSize(EntityLivingBase target, float width, float height) {
/* 740 */     if (target instanceof EntityPlayer)
/*     */     {
/* 742 */       ((EntityPlayer)target).eyeHeight = height * 0.9F;
/*     */     }
/*     */     
/* 745 */     if (width != target.field_70130_N || height != target.field_70131_O) {
/*     */       
/* 747 */       AxisAlignedBB aabb = target.func_174813_aQ();
/*     */       
/* 749 */       target.field_70130_N = width;
/* 750 */       target.field_70131_O = height;
/* 751 */       target.func_174826_a(new AxisAlignedBB(target.field_70165_t - (width / 2.0F), aabb.field_72338_b, target.field_70161_v - (width / 2.0F), target.field_70165_t + (width / 2.0F), aabb.field_72338_b + height, target.field_70161_v + (width / 2.0F)));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\handler\WerewolfTick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */