/*    */ package com.raz.howlingmoon.handler;
/*    */ 
/*    */ import net.minecraftforge.common.config.Config;
/*    */ import net.minecraftforge.common.config.Config.Comment;
/*    */ import net.minecraftforge.common.config.Config.LangKey;
/*    */ import net.minecraftforge.common.config.ConfigManager;
/*    */ import net.minecraftforge.fml.client.event.ConfigChangedEvent;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Config(modid = "howlingmoon")
/*    */ public class ConfigHandler
/*    */ {
/*    */   @LangKey("werewolf.config.setLevelCap.name")
/*    */   @Comment({"Configure player werewolves level cap. I highly recommend not increasing it past the default 20."})
/* 22 */   public static int setLevelCap = 20;
/*    */   
/*    */   @LangKey("werewolf.config.spawnSilverOre.name")
/*    */   @Comment({"Generate silver ore in world."})
/*    */   public static boolean spawnSilverOre = true;
/*    */   
/*    */   @LangKey("werewolf.config.wolfSleep.name")
/*    */   @Comment({"Configure if werewolves are allowed to sleep while transformed."})
/*    */   public static boolean wolfSleep = false;
/*    */   
/*    */   @LangKey("werewolf.config.dimID.name")
/*    */   @Comment({"Set the mod's Dimension ID."})
/* 34 */   public static int dimID = 24;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventBusSubscriber(modid = "howlingmoon")
/*    */   private static class Handler
/*    */   {
/*    */     @SubscribeEvent
/*    */     public static void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
/* 80 */       if (event.getModID().equals("howlingmoon"))
/*    */       {
/* 82 */         ConfigManager.sync("howlingmoon", Config.Type.INSTANCE);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\handler\ConfigHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */