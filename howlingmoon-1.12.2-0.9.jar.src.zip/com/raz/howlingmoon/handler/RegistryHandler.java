/*    */ package com.raz.howlingmoon.handler;
/*    */ 
/*    */ import com.raz.howlingmoon.HMPotions;
/*    */ import com.raz.howlingmoon.HMSounds;
/*    */ import com.raz.howlingmoon.IModelRegister;
/*    */ import com.raz.howlingmoon.blocks.HMBlocks;
/*    */ import com.raz.howlingmoon.items.HMItems;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.util.SoundEvent;
/*    */ import net.minecraftforge.client.event.ModelRegistryEvent;
/*    */ import net.minecraftforge.event.RegistryEvent;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.registries.IForgeRegistryEntry;
/*    */ 
/*    */ @EventBusSubscriber
/*    */ public class RegistryHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void onItemRegister(RegistryEvent.Register<Item> event) {
/* 23 */     event.getRegistry().registerAll((IForgeRegistryEntry[])HMItems.ITEMS.toArray((Object[])new Item[0]));
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void onBlockRegister(RegistryEvent.Register<Block> event) {
/* 29 */     event.getRegistry().registerAll((IForgeRegistryEntry[])HMBlocks.BLOCKS.toArray((Object[])new Block[0]));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void onSoundRegister(RegistryEvent.Register<SoundEvent> event) {
/* 36 */     event.getRegistry().register((IForgeRegistryEntry)HMSounds.howl);
/* 37 */     event.getRegistry().register((IForgeRegistryEntry)HMSounds.heartbeat_delay);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void onModelRegister(ModelRegistryEvent event) {
/* 43 */     for (Item item : HMItems.ITEMS) {
/*    */       
/* 45 */       if (item instanceof IModelRegister)
/*    */       {
/* 47 */         ((IModelRegister)item).registerModels();
/*    */       }
/*    */     } 
/*    */     
/* 51 */     for (Block block : HMBlocks.BLOCKS) {
/*    */       
/* 53 */       if (block instanceof IModelRegister)
/*    */       {
/* 55 */         ((IModelRegister)block).registerModels();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void registerPotions(RegistryEvent.Register<Potion> event) {
/* 62 */     HMPotions.register(event.getRegistry());
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\handler\RegistryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */