/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WereList
/*     */ {
/*  13 */   public static final List<WereBasic> BASIC = Lists.newArrayList();
/*  14 */   public static final List<WereAttribute> ATTRIBUTES = Lists.newArrayList();
/*  15 */   public static final List<WereAbility> ABILITIES = Lists.newArrayList();
/*  16 */   public static final List<WereAbility> QUESTABILITIES = Lists.newArrayList();
/*  17 */   public static final List<WereAbility> UNLOCKABILITIES = Lists.newArrayList();
/*  18 */   public static final List<WereInclination> INCLINATION = Lists.newArrayList();
/*     */ 
/*     */   
/*  21 */   public static final WereBasic WEREWOLF = (new WereBasic("WEREWOLF", "ability.Werewolf", new ResourceLocation("howlingmoon:textures/abilities/werewolf.png"))).registerStat();
/*  22 */   public static final WereBasic EMPTYPAW = (new WereBasic("EMPTYPAW", "skills.emptyPaw", new ResourceLocation("howlingmoon:textures/abilities/paw.png"))).registerStat();
/*  23 */   public static final WereBasic WOLF = (new WereBasic("WOLF", "ability.Wolf", new ResourceLocation("howlingmoon:textures/abilities/werewolf.png"))).registerStat();
/*  24 */   public static final WereBasic BEAST = (new WereBasic("BEAST", "ability.Beast", new ResourceLocation("howlingmoon:textures/abilities/werewolf.png"))).registerStat();
/*     */ 
/*     */ 
/*     */   
/*  28 */   public static final WereAttribute STRENGTH = (new WereAttribute("STRENGTH", "attribute.Strength", 10)).registerStat();
/*  29 */   public static final WereAttribute REND = (new WereAttribute("REND", "attribute.Rend", 2)).registerStat();
/*  30 */   public static final WereAttribute PROTECTION = (new WereAttribute("PROTECTION", "attribute.Protection", 5)).registerStat();
/*  31 */   public static final WereAttribute MOVEMENT = (new WereAttribute("MOVEMENT", "attribute.Movement", 10)).registerStat();
/*  32 */   public static final WereAttribute JUMP = (new WereAttribute("JUMP", "attribute.Jump", 5)).registerStat();
/*  33 */   public static final WereAttribute FALL = (new WereAttribute("FALL", "attribute.Fall", 5)).registerStat();
/*  34 */   public static final WereAttribute KNOCKBACK = (new WereAttribute("KNOCKBACK", "attribute.Knockback", 2)).registerStat();
/*  35 */   public static final WereAttribute KNOCKRESIST = (new WereAttribute("KNOCKRESIST", "attribute.KnockResist", 2)).registerStat();
/*  36 */   public static final WereAttribute HUNGER = (new WereAttribute("HUNGER", "attribute.Hunger", 5)).registerStat();
/*  37 */   public static final WereAttribute REGENERATION = (new WereAttribute("REGENERATION", "attribute.Regeneration", 3)).registerStat();
/*  38 */   public static final WereAttribute CLARITY = (new WereAttribute("CLARITY", "attribute.Clarity", 3)).registerStat();
/*  39 */   public static final WereAttribute EXHILARATING = (new WereAttribute("EXHILARATING", "attribute.Exhilarating", 3)).registerStat();
/*  40 */   public static final WereAttribute RESISTANCE = (new WereAttribute("RESISTANCE", "attribute.Resistance", 5)).registerStat();
/*  41 */   public static final WereAttribute DEXTERITY = (new WereAttribute("DEXTERITY", "attribute.Dexterity", 5)).registerStat();
/*     */ 
/*     */   
/*  44 */   public static final WereAbility HOWL = (new WereAbility("HOWL", "ability.Howl", new ResourceLocation("howlingmoon:textures/abilities/howl.png"), false)).registerStat();
/*  45 */   public static final WereAbility NIGHTVISION = (new WereAbility("NIGHTVISION", "ability.NightVision", new ResourceLocation("howlingmoon:textures/abilities/night_vision.png"), false)).registerStat();
/*  46 */   public static final WereAbility BITE = (new WereAbility("BITE", "ability.Bite", new ResourceLocation("howlingmoon:textures/abilities/bite.png"), false)).registerStat();
/*     */   
/*  48 */   public static final WereAbility CLIMB = (new WereAbility("CLIMB", "ability.Climbing", new ResourceLocation("howlingmoon:textures/abilities/climb.png"), true)).registerStat();
/*  49 */   public static final WereAbility LEAP = (new WereAbility("LEAP", "ability.Leap", new ResourceLocation("howlingmoon:textures/abilities/leap.png"), true)).registerStat();
/*     */   
/*  51 */   public static final WereAbility RAM = (new WereAbility("RAM", "ability.Ram", new ResourceLocation("howlingmoon:textures/abilities/ram.png"), true)).registerStat();
/*  52 */   public static final WereAbility LIFT = (new WereAbility("LIFT", "ability.Lift", new ResourceLocation("howlingmoon:textures/abilities/lift.png"), true)).registerStat();
/*  53 */   public static final WereAbility SHRED = (new WereAbility("SHRED", "ability.Shred", new ResourceLocation("howlingmoon:textures/abilities/shred.png"), true)).registerStat();
/*  54 */   public static final WereAbility PAW = (new WereAbility("PAW", "ability.Paw", new ResourceLocation("howlingmoon:textures/abilities/paw.png"), true)).registerStat();
/*  55 */   public static final WereAbility ARMOR = (new WereAbility("ARMOR", "ability.Armor", new ResourceLocation("howlingmoon:textures/abilities/armor.png"), true)).registerStat();
/*     */   
/*  57 */   public static final WereAbility SCENTRACKING = (new WereAbility("SCENTRACKING", "ability.ScentTracking", new ResourceLocation("howlingmoon:textures/abilities/scent_tracking.png"), true)).registerStat();
/*  58 */   public static final WereAbility MAIM = (new WereAbility("MAIM", "ability.Maim", new ResourceLocation("howlingmoon:textures/abilities/maim.png"), true)).registerStat();
/*     */ 
/*     */   
/*  61 */   public static final WereInclination TRANQUILITY = (new WereInclination("TRANQUILITY", "ability.Tranquility", 1, Inclination.CALM, new ResourceLocation("howlingmoon:textures/abilities/tranquility.png"))).registerStat();
/*  62 */   public static final WereInclination SILVERBLOOD = (new WereInclination("SILVERBLOOD", "ability.SilverBlood", 2, Inclination.CALM, new ResourceLocation("howlingmoon:textures/abilities/silver_blood.png"))).registerStat();
/*  63 */   public static final WereInclination HUMANITY = (new WereInclination("HUMANITY", "ability.Humanity", 3, Inclination.CALM, new ResourceLocation("howlingmoon:textures/abilities/humanity.png"))).registerStat();
/*     */   
/*  65 */   public static final WereInclination FEAR = (new WereInclination("FEAR", "ability.Fear", 1, Inclination.SAVAGE, new ResourceLocation("howlingmoon:textures/abilities/fear.png"))).registerStat();
/*  66 */   public static final WereInclination BERSERK = (new WereInclination("BERSERK", "ability.Berserk", 2, Inclination.SAVAGE, new ResourceLocation("howlingmoon:textures/abilities/berserk.png"))).registerStat();
/*  67 */   public static final WereInclination FERAL = (new WereInclination("FERAL", "ability.Feral", 3, Inclination.SAVAGE, new ResourceLocation("howlingmoon:textures/abilities/feral.png"))).registerStat();
/*     */   
/*  69 */   public static final WereInclination INGENUITY = (new WereInclination("INGENUITY", "ability.Ingenuity", 1, Inclination.NEUTRAL, new ResourceLocation("howlingmoon:textures/abilities/neutral.png"))).registerStat();
/*  70 */   public static final WereInclination SKILLFUL = (new WereInclination("SKILLFUL", "ability.Skillful", 2, Inclination.NEUTRAL, new ResourceLocation("howlingmoon:textures/abilities/neutral.png"))).registerStat();
/*  71 */   public static final WereInclination MASTERY = (new WereInclination("MASTERY", "ability.Mastery", 3, Inclination.NEUTRAL, new ResourceLocation("howlingmoon:textures/abilities/neutral.png"))).registerStat();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void init() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WereAbility getAbilityFromKey(String key) {
/*  83 */     for (WereAbility a : ABILITIES) {
/*     */       
/*  85 */       if (a.getKey().equals(key))
/*  86 */         return a; 
/*     */     } 
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static WereAttribute getAttributeFromKey(String key) {
/*  93 */     for (WereAttribute a : ATTRIBUTES) {
/*     */       
/*  95 */       if (a.getKey().equals(key))
/*  96 */         return a; 
/*     */     } 
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   public enum Inclination {
/* 102 */     CALM,
/* 103 */     NEUTRAL,
/* 104 */     SAVAGE;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */