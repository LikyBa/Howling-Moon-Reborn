/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WereAttribute
/*    */   extends WereBase
/*    */ {
/*    */   private final String key;
/*    */   private final int cap;
/*    */   
/*    */   public WereAttribute(String key, String unlocalizedName, int cap) {
/* 12 */     super(unlocalizedName);
/* 13 */     this.key = key;
/* 14 */     this.cap = cap;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WereAttribute registerStat() {
/* 23 */     WereList.ATTRIBUTES.add(this);
/* 24 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 29 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCap() {
/* 34 */     return this.cap;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean havePointsFor(IWerewolfCapability wolf) {
/* 39 */     if (wolf.getUsuableAttributePoints() > 0)
/* 40 */       return true; 
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canUnlock(IWerewolfCapability wolf) {
/* 46 */     if (havePointsFor(wolf))
/*    */     {
/* 48 */       if (wolf.getAttributeTreeAbility(getKey()) < getCap())
/* 49 */         return true; 
/*    */     }
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */