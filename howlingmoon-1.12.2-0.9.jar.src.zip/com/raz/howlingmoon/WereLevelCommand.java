/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncExpLevelClient;
/*     */ import com.raz.howlingmoon.packets.SyncWereCapsMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ public class WereLevelCommand
/*     */   implements ICommand
/*     */ {
/*     */   private List aliases;
/*     */   
/*     */   public WereLevelCommand() {
/*  26 */     this.aliases = new ArrayList();
/*  27 */     this.aliases.add("werelevel");
/*  28 */     this.aliases.add("werelevels");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ICommand o) {
/*  34 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/*  54 */     if (args.length <= 0) {
/*     */       
/*  56 */       sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werelevel.usage", new Object[0]));
/*     */ 
/*     */     
/*     */     }
/*  60 */     else if (sender instanceof EntityPlayer) {
/*     */       
/*  62 */       String s = args[0];
/*  63 */       int i = CommandBase.func_175755_a(s);
/*  64 */       if (i > 0) {
/*     */         
/*  66 */         EntityPlayer entityplayer = (EntityPlayer)sender;
/*  67 */         IWerewolfCapability wolf = (IWerewolfCapability)entityplayer.getCapability(WereEventHandler.WERE_CAP, null);
/*  68 */         if (wolf.isWerewolf())
/*     */         {
/*  70 */           int currentLevel = wolf.getLevel();
/*  71 */           wolf.setLevel(i);
/*  72 */           wolf.setExp(0);
/*  73 */           if (currentLevel > wolf.getLevel()) {
/*     */             
/*  75 */             wolf.setUsedAttributePoints(0);
/*  76 */             wolf.setUsedAbilityPoints(0);
/*  77 */             wolf.resetAttributeTree();
/*  78 */             wolf.resetAbilityTree();
/*  79 */             PacketDispatcher.sendTo((IMessage)new SyncWereCapsMessage(entityplayer), (EntityPlayerMP)entityplayer);
/*     */           } else {
/*     */             
/*  82 */             PacketDispatcher.sendTo((IMessage)new SyncExpLevelClient(entityplayer), (EntityPlayerMP)entityplayer);
/*  83 */           }  sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werelevel.success", new Object[] { Integer.valueOf(wolf.getLevel()), entityplayer.func_70005_c_() }));
/*     */         }
/*     */         else
/*     */         {
/*  87 */           sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werelevel.failure", new Object[0]));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  92 */         sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werelevel.failure.levels", new Object[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184882_a(MinecraftServer server, ICommandSender sender) {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71517_b() {
/* 119 */     return "werelevel";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/* 125 */     return "commands.werelevel.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_71514_a() {
/* 131 */     return this.aliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args, BlockPos targetPos) {
/* 138 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereLevelCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */