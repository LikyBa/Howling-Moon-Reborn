/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PotionBase
/*    */   extends Potion
/*    */ {
/*    */   private final ResourceLocation iconTexture;
/*    */   
/*    */   protected PotionBase(boolean isBadEffectIn, int liquidColorIn, String name) {
/* 20 */     super(isBadEffectIn, liquidColorIn);
/* 21 */     setPotionName(this, name);
/* 22 */     this.iconTexture = new ResourceLocation("howlingmoon", "textures/potions/" + name + ".png");
/*    */   }
/*    */   
/*    */   public PotionBase(boolean isBadEffect, int liquidR, int liquidG, int liquidB, String name) {
/* 26 */     this(isBadEffect, (new Color(liquidR, liquidG, liquidB)).getRGB(), name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setPotionName(Potion potion, String potionName) {
/* 36 */     potion.setRegistryName(potionName);
/* 37 */     potion.func_76390_b("effect." + potion.getRegistryName().toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_76400_d() {
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderInventoryEffect(int x, int y, PotionEffect effect, Minecraft mc) {
/* 57 */     if (mc.field_71462_r != null) {
/* 58 */       mc.func_110434_K().func_110577_a(this.iconTexture);
/* 59 */       Gui.func_146110_a(x + 6, y + 7, 0.0F, 0.0F, 18, 18, 18.0F, 18.0F);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderHUDEffect(int x, int y, PotionEffect effect, Minecraft mc, float alpha) {
/* 76 */     mc.func_110434_K().func_110577_a(this.iconTexture);
/* 77 */     Gui.func_146110_a(x + 3, y + 3, 0.0F, 0.0F, 18, 18, 18.0F, 18.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\PotionBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */