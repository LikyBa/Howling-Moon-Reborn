/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.raz.howlingmoon.entities.EntityTameWere;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDoor;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.ai.EntityAIDoorInteract;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ 
/*     */ public class EntityAIWereBreakDoor
/*     */   extends EntityAIDoorInteract {
/*     */   private EntityTameWere theTameable;
/*     */   private int breakingTime;
/*  15 */   private int previousBreakProgress = -1;
/*     */ 
/*     */   
/*     */   public EntityAIWereBreakDoor(EntityTameWere entityIn) {
/*  19 */     super((EntityLiving)entityIn);
/*  20 */     this.theTameable = entityIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  28 */     if (!super.func_75250_a())
/*     */     {
/*  30 */       return false;
/*     */     }
/*  32 */     if (!this.field_75356_a.field_70170_p.func_82736_K().func_82766_b("mobGriefing"))
/*     */     {
/*  34 */       return false;
/*     */     }
/*  36 */     if (!this.theTameable.getBreakDoors())
/*     */     {
/*  38 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  42 */     BlockDoor blockdoor = this.field_151504_e;
/*  43 */     return !BlockDoor.func_176514_f((IBlockAccess)this.field_75356_a.field_70170_p, this.field_179507_b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  52 */     super.func_75249_e();
/*  53 */     this.breakingTime = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  61 */     double d0 = this.field_75356_a.func_174818_b(this.field_179507_b);
/*     */ 
/*     */     
/*  64 */     if (this.breakingTime <= 240) {
/*     */       
/*  66 */       BlockDoor blockdoor = this.field_151504_e;
/*     */       
/*  68 */       if (!BlockDoor.func_176514_f((IBlockAccess)this.field_75356_a.field_70170_p, this.field_179507_b) && d0 < 4.0D) {
/*     */         
/*  70 */         boolean bool = true;
/*  71 */         return bool;
/*     */       } 
/*     */     } 
/*     */     
/*  75 */     boolean flag = false;
/*  76 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/*  84 */     super.func_75251_c();
/*  85 */     this.field_75356_a.field_70170_p.func_175715_c(this.field_75356_a.func_145782_y(), this.field_179507_b, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  93 */     super.func_75246_d();
/*     */     
/*  95 */     if (this.field_75356_a.func_70681_au().nextInt(20) == 0)
/*     */     {
/*  97 */       this.field_75356_a.field_70170_p.func_175718_b(1019, this.field_179507_b, 0);
/*     */     }
/*     */     
/* 100 */     this.breakingTime++;
/* 101 */     int i = (int)(this.breakingTime / 240.0F * 10.0F);
/*     */     
/* 103 */     if (i != this.previousBreakProgress) {
/*     */       
/* 105 */       this.field_75356_a.field_70170_p.func_175715_c(this.field_75356_a.func_145782_y(), this.field_179507_b, i);
/* 106 */       this.previousBreakProgress = i;
/*     */     } 
/*     */     
/* 109 */     if (this.breakingTime == 240 && this.field_75356_a.field_70170_p.func_175659_aa() == EnumDifficulty.HARD) {
/*     */       
/* 111 */       this.field_75356_a.field_70170_p.func_175698_g(this.field_179507_b);
/* 112 */       this.field_75356_a.field_70170_p.func_175718_b(1021, this.field_179507_b, 0);
/* 113 */       this.field_75356_a.field_70170_p.func_175718_b(2001, this.field_179507_b, Block.func_149682_b((Block)this.field_151504_e));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIWereBreakDoor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */