/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.village.Village;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIMoveAroundVillage
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final EntityCreature entity;
/*     */   private final double movementSpeed;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*     */   private final boolean isNocturnal;
/*     */   protected int executionChance;
/*     */   
/*     */   public EntityAIMoveAroundVillage(EntityCreature entityIn, double movementSpeedIn, boolean isNocturnalIn) {
/*  34 */     this(entityIn, movementSpeedIn, isNocturnalIn, 120);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAIMoveAroundVillage(EntityCreature entityIn, double movementSpeedIn, boolean isNocturnalIn, int executionChanceIn) {
/*  39 */     this.entity = entityIn;
/*  40 */     this.movementSpeed = movementSpeedIn;
/*  41 */     this.isNocturnal = isNocturnalIn;
/*  42 */     this.executionChance = executionChanceIn;
/*  43 */     func_75248_a(1);
/*     */     
/*  45 */     if (!(entityIn.func_70661_as() instanceof net.minecraft.pathfinding.PathNavigateGround))
/*     */     {
/*  47 */       throw new IllegalArgumentException("Unsupported mob for MoveAroundVillageGoal");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  57 */     if (this.entity.func_70681_au().nextInt(this.executionChance) != 0)
/*     */     {
/*  59 */       return false;
/*     */     }
/*  61 */     if (this.isNocturnal && this.entity.field_70170_p.func_72935_r())
/*     */     {
/*  63 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  68 */     Village village = this.entity.field_70170_p.func_175714_ae().func_176056_a(new BlockPos((Entity)this.entity), 2);
/*     */     
/*  70 */     if (village == null)
/*     */     {
/*  72 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  76 */     Vec3d vec3d = RandomPositionGenerator.func_75464_a(this.entity, village.func_75568_b(), 8, new Vec3d(village.func_180608_a().func_177958_n() + 0.5D, village.func_180608_a().func_177956_o(), village.func_180608_a().func_177952_p() + 0.5D));
/*     */     
/*  78 */     if (vec3d == null)
/*     */     {
/*  80 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  84 */     this.movePosX = vec3d.field_72450_a;
/*  85 */     this.movePosY = vec3d.field_72448_b;
/*  86 */     this.movePosZ = vec3d.field_72449_c;
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  98 */     return !this.entity.func_70661_as().func_75500_f();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 116 */     this.entity.func_70661_as().func_75492_a(this.movePosX, this.movePosY, this.movePosZ, this.movementSpeed);
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIMoveAroundVillage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */