/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.raz.howlingmoon.entities.EntityHunter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.util.EnumHand;
/*     */ 
/*     */ public class EntityAIHunterRanged
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final EntityHunter entity;
/*     */   private final double moveSpeedAmp;
/*     */   private int attackCooldown;
/*     */   private final float maxAttackDistance;
/*  18 */   private int attackTime = -1;
/*     */   private int seeTime;
/*     */   private boolean strafingClockwise;
/*     */   private boolean strafingBackwards;
/*  22 */   private int strafingTime = -1;
/*     */ 
/*     */   
/*     */   public EntityAIHunterRanged(EntityHunter skeleton, double speedAmplifier, int delay, float maxDistance) {
/*  26 */     this.entity = skeleton;
/*  27 */     this.moveSpeedAmp = speedAmplifier;
/*  28 */     this.attackCooldown = delay;
/*  29 */     this.maxAttackDistance = maxDistance * maxDistance;
/*  30 */     func_75248_a(3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttackCooldown(int p_189428_1_) {
/*  35 */     this.attackCooldown = p_189428_1_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  43 */     return (this.entity.func_70638_az() == null) ? false : isBowInMainhand();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isBowInMainhand() {
/*  48 */     return (this.entity.func_184614_ca() != null && this.entity.func_184614_ca().func_77973_b() == Items.field_151031_f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/*  56 */     return ((func_75250_a() || !this.entity.func_70661_as().func_75500_f()) && isBowInMainhand());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  64 */     super.func_75249_e();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/*  73 */     super.func_75251_c();
/*     */     
/*  75 */     this.seeTime = 0;
/*  76 */     this.attackTime = -1;
/*  77 */     this.entity.func_184602_cy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/*  85 */     EntityLivingBase entitylivingbase = this.entity.func_70638_az();
/*     */     
/*  87 */     if (entitylivingbase != null) {
/*     */       
/*  89 */       double d0 = this.entity.func_70092_e(entitylivingbase.field_70165_t, (entitylivingbase.func_174813_aQ()).field_72338_b, entitylivingbase.field_70161_v);
/*  90 */       boolean flag = this.entity.func_70635_at().func_75522_a((Entity)entitylivingbase);
/*  91 */       boolean flag1 = (this.seeTime > 0);
/*     */       
/*  93 */       if (flag != flag1)
/*     */       {
/*  95 */         this.seeTime = 0;
/*     */       }
/*     */       
/*  98 */       if (flag) {
/*     */         
/* 100 */         this.seeTime++;
/*     */       }
/*     */       else {
/*     */         
/* 104 */         this.seeTime--;
/*     */       } 
/*     */       
/* 107 */       if (d0 <= this.maxAttackDistance && this.seeTime >= 20) {
/*     */         
/* 109 */         this.entity.func_70661_as().func_75499_g();
/* 110 */         this.strafingTime++;
/*     */       }
/*     */       else {
/*     */         
/* 114 */         this.entity.func_70661_as().func_75497_a((Entity)entitylivingbase, this.moveSpeedAmp);
/* 115 */         this.strafingTime = -1;
/*     */       } 
/*     */       
/* 118 */       if (this.strafingTime >= 20) {
/*     */         
/* 120 */         if (this.entity.func_70681_au().nextFloat() < 0.3D)
/*     */         {
/* 122 */           this.strafingClockwise = !this.strafingClockwise;
/*     */         }
/*     */         
/* 125 */         if (this.entity.func_70681_au().nextFloat() < 0.3D)
/*     */         {
/* 127 */           this.strafingBackwards = !this.strafingBackwards;
/*     */         }
/*     */         
/* 130 */         this.strafingTime = 0;
/*     */       } 
/*     */       
/* 133 */       if (this.strafingTime > -1) {
/*     */         
/* 135 */         if (d0 > (this.maxAttackDistance * 0.75F)) {
/*     */           
/* 137 */           this.strafingBackwards = false;
/*     */         }
/* 139 */         else if (d0 < (this.maxAttackDistance * 0.25F)) {
/*     */           
/* 141 */           this.strafingBackwards = true;
/*     */         } 
/*     */         
/* 144 */         this.entity.func_70605_aq().func_188488_a(this.strafingBackwards ? -0.5F : 0.5F, this.strafingClockwise ? 0.5F : -0.5F);
/* 145 */         this.entity.func_70625_a((Entity)entitylivingbase, 30.0F, 30.0F);
/*     */       }
/*     */       else {
/*     */         
/* 149 */         this.entity.func_70671_ap().func_75651_a((Entity)entitylivingbase, 30.0F, 30.0F);
/*     */       } 
/*     */       
/* 152 */       if (this.entity.func_184587_cr()) {
/*     */         
/* 154 */         if (!flag && this.seeTime < -60) {
/*     */           
/* 156 */           this.entity.func_184602_cy();
/*     */         }
/* 158 */         else if (flag) {
/*     */           
/* 160 */           int i = this.entity.func_184612_cw();
/*     */           
/* 162 */           if (i >= 20)
/*     */           {
/* 164 */             this.entity.func_184602_cy();
/* 165 */             this.entity.func_82196_d(entitylivingbase, ItemBow.func_185059_b(i));
/* 166 */             this.attackTime = this.attackCooldown;
/*     */           }
/*     */         
/*     */         } 
/* 170 */       } else if (--this.attackTime <= 0 && this.seeTime >= -60) {
/*     */         
/* 172 */         this.entity.func_184598_c(EnumHand.MAIN_HAND);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIHunterRanged.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */