/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.google.common.base.Function;
/*     */ import com.google.common.base.Predicate;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAITarget;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EntitySelectors;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIAttackWerewolf<T extends EntityLivingBase>
/*     */   extends EntityAITarget
/*     */ {
/*     */   protected final Class<T> targetClass;
/*     */   private final int targetChance;
/*     */   protected final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
/*     */   protected final Predicate<? super T> targetEntitySelector;
/*     */   protected T targetEntity;
/*     */   
/*     */   public EntityAIAttackWerewolf(EntityCreature creature, Class<T> classTarget, boolean checkSight) {
/*  38 */     this(creature, classTarget, checkSight, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAIAttackWerewolf(EntityCreature creature, Class<T> classTarget, boolean checkSight, boolean onlyNearby) {
/*  43 */     this(creature, classTarget, 10, checkSight, onlyNearby, (Predicate<? super T>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAIAttackWerewolf(EntityCreature creature, Class<T> classTarget, int chance, boolean checkSight, boolean onlyNearby, @Nullable final Predicate<? super T> targetSelector) {
/*  48 */     super(creature, checkSight, onlyNearby);
/*  49 */     this.targetClass = classTarget;
/*  50 */     this.targetChance = chance;
/*  51 */     this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter((Entity)creature);
/*  52 */     func_75248_a(1);
/*  53 */     this.targetEntitySelector = new Predicate<T>()
/*     */       {
/*     */         public boolean apply(@Nullable T p_apply_1_)
/*     */         {
/*  57 */           if (p_apply_1_ == null)
/*  58 */             return false; 
/*  59 */           if (targetSelector != null && !targetSelector.apply(p_apply_1_))
/*  60 */             return false; 
/*  61 */           if (p_apply_1_ instanceof EntityPlayer)
/*     */           {
/*  63 */             if (!((IWerewolfCapability)((EntityPlayer)p_apply_1_).getCapability(WereEventHandler.WERE_CAP, null)).isWerewolf())
/*  64 */               return false; 
/*     */           }
/*  66 */           return !EntitySelectors.field_180132_d.apply(p_apply_1_) ? false : EntityAIAttackWerewolf.this.func_75296_a((EntityLivingBase)p_apply_1_, false);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  92 */     EntityLivingBase entitylivingbase = this.field_75299_d.func_70638_az();
/*  93 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/*     */     {
/*  95 */       return false;
/*     */     }
/*  97 */     if (this.targetChance > 0 && this.field_75299_d.func_70681_au().nextInt(this.targetChance) != 0)
/*     */     {
/*  99 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     if (this.targetClass != EntityPlayer.class && this.targetClass != EntityPlayerMP.class) {
/*     */       
/* 124 */       List<T> list = this.field_75299_d.field_70170_p.func_175647_a(this.targetClass, getTargetableArea(func_111175_f()), this.targetEntitySelector);
/*     */       
/* 126 */       if (list.isEmpty())
/*     */       {
/* 128 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 132 */       Collections.sort(list, (Comparator<? super T>)this.theNearestAttackableTargetSorter);
/* 133 */       this.targetEntity = list.get(0);
/* 134 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 139 */     this.targetEntity = (T)this.field_75299_d.field_70170_p.func_184150_a(this.field_75299_d.field_70165_t, this.field_75299_d.field_70163_u + this.field_75299_d.func_70047_e(), this.field_75299_d.field_70161_v, func_111175_f(), func_111175_f(), new Function<EntityPlayer, Double>()
/*     */         {
/*     */           @Nullable
/*     */           public Double apply(@Nullable EntityPlayer p_apply_1_)
/*     */           {
/* 144 */             ItemStack itemstack = p_apply_1_.func_184582_a(EntityEquipmentSlot.HEAD);
/*     */             
/* 146 */             return Double.valueOf(1.0D);
/*     */           }
/*     */         },  this.targetEntitySelector);
/* 149 */     if (this.targetEntity != null) {
/*     */       
/* 151 */       if (((IWerewolfCapability)((EntityPlayer)this.targetEntity).getCapability(WereEventHandler.WERE_CAP, null)).isTransformed()) {
/* 152 */         return true;
/*     */       }
/* 154 */       if (!this.field_75299_d.func_184592_cb().func_190926_b())
/*     */       {
/* 156 */         if (this.field_75299_d.func_184592_cb().func_77973_b() == HMItems.moonstone) {
/*     */           
/* 158 */           List<T> list = this.field_75299_d.field_70170_p.func_175647_a(this.targetClass, getTargetableArea(4.0D), this.targetEntitySelector);
/* 159 */           return !list.isEmpty();
/*     */         } 
/*     */       }
/*     */     } 
/* 163 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 170 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/* 171 */       return false; 
/* 172 */     return super.func_75253_b();
/*     */   }
/*     */ 
/*     */   
/*     */   protected AxisAlignedBB getTargetableArea(double targetDistance) {
/* 177 */     return this.field_75299_d.func_174813_aQ().func_72314_b(targetDistance, 4.0D, targetDistance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 185 */     this.field_75299_d.func_70624_b((EntityLivingBase)this.targetEntity);
/* 186 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public static class Sorter
/*     */     implements Comparator<Entity>
/*     */   {
/*     */     private final Entity theEntity;
/*     */     
/*     */     public Sorter(Entity theEntityIn) {
/* 195 */       this.theEntity = theEntityIn;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(Entity p_compare_1_, Entity p_compare_2_) {
/* 200 */       double d0 = this.theEntity.func_70068_e(p_compare_1_);
/* 201 */       double d1 = this.theEntity.func_70068_e(p_compare_2_);
/* 202 */       return (d0 < d1) ? -1 : ((d0 > d1) ? 1 : 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIAttackWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */