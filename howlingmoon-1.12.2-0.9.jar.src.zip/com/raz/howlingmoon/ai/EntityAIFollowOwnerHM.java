/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.raz.howlingmoon.entities.EntityWolfSpirit;
/*     */ import net.minecraft.block.state.BlockFaceShape;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.pathfinding.PathNodeType;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIFollowOwnerHM
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final EntityWolfSpirit spirit;
/*     */   private EntityLivingBase owner;
/*     */   World world;
/*     */   private final double followSpeed;
/*     */   private final PathNavigate petPathfinder;
/*     */   private int timeToRecalcPath;
/*     */   float maxDist;
/*     */   float minDist;
/*     */   private float oldWaterCost;
/*     */   
/*     */   public EntityAIFollowOwnerHM(EntityWolfSpirit tameableIn, double followSpeedIn, float minDistIn, float maxDistIn) {
/*  34 */     this.spirit = tameableIn;
/*  35 */     this.world = tameableIn.field_70170_p;
/*  36 */     this.followSpeed = followSpeedIn;
/*  37 */     this.petPathfinder = tameableIn.func_70661_as();
/*  38 */     this.minDist = minDistIn;
/*  39 */     this.maxDist = maxDistIn;
/*  40 */     func_75248_a(3);
/*     */     
/*  42 */     if (!(tameableIn.func_70661_as() instanceof net.minecraft.pathfinding.PathNavigateGround) && !(tameableIn.func_70661_as() instanceof net.minecraft.pathfinding.PathNavigateFlying))
/*     */     {
/*  44 */       throw new IllegalArgumentException("Unsupported mob type for FollowOwnerGoal");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  53 */     EntityLivingBase entitylivingbase = this.spirit.getOwner();
/*     */     
/*  55 */     if (entitylivingbase == null)
/*     */     {
/*  57 */       return false;
/*     */     }
/*  59 */     if (entitylivingbase instanceof EntityPlayer && ((EntityPlayer)entitylivingbase).func_175149_v())
/*     */     {
/*  61 */       return false;
/*     */     }
/*  63 */     if (this.spirit.func_70068_e((Entity)entitylivingbase) < (this.minDist * this.minDist))
/*     */     {
/*  65 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  69 */     this.owner = entitylivingbase;
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  79 */     return (!this.petPathfinder.func_75500_f() && this.spirit.func_70068_e((Entity)this.owner) > (this.maxDist * this.maxDist));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/*  87 */     this.timeToRecalcPath = 0;
/*  88 */     this.oldWaterCost = this.spirit.func_184643_a(PathNodeType.WATER);
/*  89 */     this.spirit.func_184644_a(PathNodeType.WATER, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/*  97 */     this.owner = null;
/*  98 */     this.petPathfinder.func_75499_g();
/*  99 */     this.spirit.func_184644_a(PathNodeType.WATER, this.oldWaterCost);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 107 */     this.spirit.func_70671_ap().func_75651_a((Entity)this.owner, 10.0F, this.spirit.func_70646_bf());
/*     */     
/* 109 */     if (--this.timeToRecalcPath <= 0) {
/*     */       
/* 111 */       this.timeToRecalcPath = 10;
/*     */       
/* 113 */       if (!this.petPathfinder.func_75497_a((Entity)this.owner, this.followSpeed))
/*     */       {
/* 115 */         if (!this.spirit.func_110167_bD() && !this.spirit.func_184218_aH())
/*     */         {
/* 117 */           if (this.spirit.func_70068_e((Entity)this.owner) >= 144.0D) {
/*     */             
/* 119 */             int i = MathHelper.func_76128_c(this.owner.field_70165_t) - 2;
/* 120 */             int j = MathHelper.func_76128_c(this.owner.field_70161_v) - 2;
/* 121 */             int k = MathHelper.func_76128_c((this.owner.func_174813_aQ()).field_72338_b);
/*     */             
/* 123 */             for (int l = 0; l <= 4; l++) {
/*     */               
/* 125 */               for (int i1 = 0; i1 <= 4; i1++) {
/*     */                 
/* 127 */                 if ((l < 1 || i1 < 1 || l > 3 || i1 > 3) && isTeleportFriendlyBlock(i, j, k, l, i1)) {
/*     */                   
/* 129 */                   this.spirit.func_70012_b(((i + l) + 0.5F), k, ((j + i1) + 0.5F), this.spirit.field_70177_z, this.spirit.field_70125_A);
/* 130 */                   this.petPathfinder.func_75499_g();
/*     */                   return;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTeleportFriendlyBlock(int x, int p_192381_2_, int y, int p_192381_4_, int p_192381_5_) {
/* 144 */     BlockPos blockpos = new BlockPos(x + p_192381_4_, y - 1, p_192381_2_ + p_192381_5_);
/* 145 */     IBlockState iblockstate = this.world.func_180495_p(blockpos);
/* 146 */     return (iblockstate.func_193401_d((IBlockAccess)this.world, blockpos, EnumFacing.DOWN) == BlockFaceShape.SOLID && iblockstate.func_189884_a((Entity)this.spirit) && this.world.func_175623_d(blockpos.func_177984_a()) && this.world.func_175623_d(blockpos.func_177981_b(2)));
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIFollowOwnerHM.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */