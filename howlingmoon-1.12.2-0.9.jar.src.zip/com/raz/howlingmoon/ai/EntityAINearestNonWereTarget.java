/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.google.common.base.Function;
/*     */ import com.google.common.base.Predicate;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.entities.EntityTameWere;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*     */ import net.minecraft.entity.ai.EntityAITarget;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.util.EntitySelectors;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.EnumDifficulty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAINearestNonWereTarget<T extends EntityLivingBase>
/*     */   extends EntityAITarget
/*     */ {
/*     */   private EntityTameWere theTameable;
/*     */   protected final Class<T> targetClass;
/*     */   private final int targetChance;
/*     */   protected final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
/*     */   protected final Predicate<? super T> targetEntitySelector;
/*     */   protected T targetEntity;
/*     */   
/*     */   public EntityAINearestNonWereTarget(EntityTameWere creature, Class<T> classTarget, boolean checkSight) {
/*  39 */     this(creature, classTarget, checkSight, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAINearestNonWereTarget(EntityTameWere creature, Class<T> classTarget, boolean checkSight, boolean onlyNearby) {
/*  44 */     this(creature, classTarget, 10, checkSight, onlyNearby, (Predicate<? super T>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAINearestNonWereTarget(EntityTameWere creature, Class<T> classTarget, int chance, boolean checkSight, boolean onlyNearby, @Nullable final Predicate<? super T> targetSelector) {
/*  49 */     super((EntityCreature)creature, checkSight, onlyNearby);
/*  50 */     this.theTameable = creature;
/*  51 */     this.targetClass = classTarget;
/*  52 */     this.targetChance = chance;
/*  53 */     this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter((Entity)creature);
/*  54 */     func_75248_a(1);
/*  55 */     this.targetEntitySelector = new Predicate<T>()
/*     */       {
/*     */         public boolean apply(@Nullable T p_apply_1_)
/*     */         {
/*  59 */           if (p_apply_1_ == null)
/*  60 */             return false; 
/*  61 */           if (targetSelector != null && !targetSelector.apply(p_apply_1_))
/*  62 */             return false; 
/*  63 */           if (p_apply_1_ instanceof EntityPlayer)
/*     */           {
/*  65 */             if (((IWerewolfCapability)((EntityPlayer)p_apply_1_).getCapability(WereEventHandler.WERE_CAP, null)).isWerewolf() || !EntityAINearestNonWereTarget.this.theTameable.doesAttackPlayers()) {
/*  66 */               return false;
/*     */             }
/*     */           }
/*  69 */           return !EntitySelectors.field_180132_d.apply(p_apply_1_) ? false : EntityAINearestNonWereTarget.this.func_75296_a((EntityLivingBase)p_apply_1_, false);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  81 */     EntityLivingBase entitylivingbase = this.field_75299_d.func_70638_az();
/*  82 */     if (this.theTameable.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/*  83 */       return false; 
/*  84 */     if (this.targetChance > 0 && this.field_75299_d.func_70681_au().nextInt(this.targetChance) != 0)
/*     */     {
/*  86 */       return false;
/*     */     }
/*  88 */     if (this.theTameable.isTamed() && !(entitylivingbase instanceof net.minecraft.entity.monster.EntitySkeleton) && (
/*  89 */       !this.theTameable.needsToFeed() || (entitylivingbase instanceof EntityPlayer && this.theTameable.getSavageryLevel() != 5))) {
/*     */       
/*  91 */       EntityLivingBase owner = this.theTameable.getOwner();
/*     */       
/*  93 */       if (owner != null) {
/*     */         
/*  95 */         if (owner instanceof EntityPlayer) {
/*     */           
/*  97 */           if (this.theTameable.getHunger() >= 19 || this.theTameable.isSubmissve())
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 102 */             return false;
/*     */           }
/*     */         } else {
/* 105 */           return false;
/*     */         } 
/*     */       } else {
/* 108 */         return false;
/*     */       } 
/* 110 */     }  if ((entitylivingbase instanceof net.minecraft.entity.passive.EntityAnimal && !this.theTameable.doesAttackAnimals()) || (entitylivingbase instanceof net.minecraft.entity.passive.EntityVillager && !this.theTameable.doesAttackVillagers()) || (entitylivingbase instanceof EntityPlayer && 
/* 111 */       !this.theTameable.doesAttackPlayers()) || (entitylivingbase instanceof net.minecraft.entity.monster.EntitySkeleton && !this.theTameable.doesAttackBones()))
/*     */     {
/* 113 */       return false;
/*     */     }
/* 115 */     if (this.targetClass != EntityPlayer.class && this.targetClass != EntityPlayerMP.class) {
/*     */       
/* 117 */       List<T> list = this.field_75299_d.field_70170_p.func_175647_a(this.targetClass, getTargetableArea(func_111175_f()), this.targetEntitySelector);
/*     */       
/* 119 */       if (list.isEmpty())
/*     */       {
/* 121 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 125 */       Collections.sort(list, (Comparator<? super T>)this.theNearestAttackableTargetSorter);
/* 126 */       this.targetEntity = list.get(0);
/* 127 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 132 */     this.targetEntity = (T)this.field_75299_d.field_70170_p.func_184150_a(this.field_75299_d.field_70165_t, this.field_75299_d.field_70163_u + this.field_75299_d.func_70047_e(), this.field_75299_d.field_70161_v, func_111175_f(), func_111175_f(), new Function<EntityPlayer, Double>()
/*     */         {
/*     */           
/*     */           @Nullable
/*     */           public Double apply(@Nullable EntityPlayer p_apply_1_)
/*     */           {
/* 138 */             return Double.valueOf(1.0D);
/*     */           }
/*     */         },  this.targetEntitySelector);
/* 141 */     return (this.targetEntity != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AxisAlignedBB getTargetableArea(double targetDistance) {
/* 147 */     return this.field_75299_d.func_174813_aQ().func_72314_b(targetDistance, 4.0D, targetDistance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 155 */     this.field_75299_d.func_70624_b((EntityLivingBase)this.targetEntity);
/* 156 */     super.func_75249_e();
/*     */   }
/*     */   
/*     */   public static class Sorter
/*     */     implements Comparator<Entity>
/*     */   {
/*     */     private final Entity theEntity;
/*     */     
/*     */     public Sorter(Entity theEntityIn) {
/* 165 */       this.theEntity = theEntityIn;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(Entity p_compare_1_, Entity p_compare_2_) {
/* 170 */       double d0 = this.theEntity.func_70068_e(p_compare_1_);
/* 171 */       double d1 = this.theEntity.func_70068_e(p_compare_2_);
/* 172 */       return (d0 < d1) ? -1 : ((d0 > d1) ? 1 : 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAINearestNonWereTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */