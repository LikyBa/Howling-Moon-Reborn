/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.google.common.base.Predicates;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.pathfinding.Path;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.util.EntitySelectors;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAIAvoidWerewolf<T extends Entity>
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final Predicate<Entity> canBeSeenSelector;
/*     */   protected EntityCreature entity;
/*     */   private final double farSpeed;
/*     */   private final double nearSpeed;
/*     */   protected T closestLivingEntity;
/*     */   private final float avoidDistance;
/*     */   private Path path;
/*     */   private final PathNavigate navigation;
/*     */   private final Class<T> classToAvoid;
/*     */   private final Predicate<? super T> avoidTargetSelector;
/*     */   
/*     */   public EntityAIAvoidWerewolf(EntityCreature theEntityIn, Class<T> classToAvoidIn, float avoidDistanceIn, double farSpeedIn, double nearSpeedIn) {
/*  42 */     this(theEntityIn, classToAvoidIn, Predicates.alwaysTrue(), avoidDistanceIn, farSpeedIn, nearSpeedIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAIAvoidWerewolf(EntityCreature theEntityIn, Class<T> classToAvoidIn, Predicate<? super T> avoidTargetSelectorIn, float avoidDistanceIn, double farSpeedIn, double nearSpeedIn) {
/*  47 */     this.canBeSeenSelector = new Predicate<Entity>()
/*     */       {
/*     */         public boolean apply(@Nullable Entity p_apply_1_)
/*     */         {
/*  51 */           return (p_apply_1_.func_70089_S() && EntityAIAvoidWerewolf.this.entity.func_70635_at().func_75522_a(p_apply_1_) && !EntityAIAvoidWerewolf.this.entity.func_184191_r(p_apply_1_));
/*     */         }
/*     */       };
/*  54 */     this.entity = theEntityIn;
/*  55 */     this.classToAvoid = classToAvoidIn;
/*  56 */     this.avoidTargetSelector = avoidTargetSelectorIn;
/*  57 */     this.avoidDistance = avoidDistanceIn;
/*  58 */     this.farSpeed = farSpeedIn;
/*  59 */     this.nearSpeed = nearSpeedIn;
/*  60 */     this.navigation = theEntityIn.func_70661_as();
/*  61 */     func_75248_a(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  69 */     List<T> list = this.entity.field_70170_p.func_175647_a(this.classToAvoid, this.entity.func_174813_aQ().func_72314_b(this.avoidDistance, 3.0D, this.avoidDistance), Predicates.and(new Predicate[] { EntitySelectors.field_188444_d, this.canBeSeenSelector, this.avoidTargetSelector }));
/*     */     
/*  71 */     if (list.isEmpty()) {
/*     */       
/*  73 */       list = this.entity.field_70170_p.func_175647_a(EntityPlayer.class, this.entity.func_174813_aQ().func_72314_b(this.avoidDistance, 3.0D, this.avoidDistance), Predicates.and(this.canBeSeenSelector, this.avoidTargetSelector));
/*  74 */       if (list.isEmpty())
/*     */       {
/*  76 */         return false;
/*     */       }
/*     */ 
/*     */       
/*  80 */       IWerewolfCapability wolf = (IWerewolfCapability)((EntityPlayer)list.get(0)).getCapability(WereEventHandler.WERE_CAP, null);
/*  81 */       if (!wolf.isTransformed() || (wolf.getInclinationType() == 1 && wolf.getQuestsDone() > 3)) {
/*  82 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  86 */     this.closestLivingEntity = list.get(0);
/*     */     
/*  88 */     Vec3d vec3d = RandomPositionGenerator.func_75461_b(this.entity, 16, 7, new Vec3d(((Entity)this.closestLivingEntity).field_70165_t, ((Entity)this.closestLivingEntity).field_70163_u, ((Entity)this.closestLivingEntity).field_70161_v));
/*     */     
/*  90 */     if (vec3d == null)
/*     */     {
/*  92 */       return false;
/*     */     }
/*  94 */     if (this.closestLivingEntity.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c) < this.closestLivingEntity.func_70068_e((Entity)this.entity))
/*     */     {
/*  96 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 100 */     this.path = this.navigation.func_75488_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
/* 101 */     return (this.path != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueExecuting() {
/* 111 */     return !this.navigation.func_75500_f();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 119 */     this.navigation.func_75484_a(this.path, this.farSpeed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/* 127 */     this.closestLivingEntity = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 135 */     if (this.entity.func_70068_e((Entity)this.closestLivingEntity) < 49.0D) {
/*     */       
/* 137 */       this.entity.func_70661_as().func_75489_a(this.nearSpeed);
/*     */     }
/*     */     else {
/*     */       
/* 141 */       this.entity.func_70661_as().func_75489_a(this.farSpeed);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIAvoidWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */