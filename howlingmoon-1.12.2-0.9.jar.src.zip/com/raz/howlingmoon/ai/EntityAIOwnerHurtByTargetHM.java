/*    */ package com.raz.howlingmoon.ai;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityWolfSpirit;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAITarget;
/*    */ 
/*    */ public class EntityAIOwnerHurtByTargetHM
/*    */   extends EntityAITarget
/*    */ {
/*    */   EntityWolfSpirit tameable;
/*    */   EntityLivingBase attacker;
/*    */   private int timestamp;
/*    */   
/*    */   public EntityAIOwnerHurtByTargetHM(EntityWolfSpirit theDefendingTameableIn) {
/* 16 */     super((EntityCreature)theDefendingTameableIn, false);
/* 17 */     this.tameable = theDefendingTameableIn;
/* 18 */     func_75248_a(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 27 */     EntityLivingBase entitylivingbase = this.tameable.getOwner();
/*    */     
/* 29 */     if (entitylivingbase == null)
/*    */     {
/* 31 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 35 */     this.attacker = entitylivingbase.func_70643_av();
/* 36 */     int i = entitylivingbase.func_142015_aE();
/* 37 */     return (i != this.timestamp && func_75296_a(this.attacker, false));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 47 */     this.field_75299_d.func_70624_b(this.attacker);
/* 48 */     EntityLivingBase entitylivingbase = this.tameable.getOwner();
/*    */     
/* 50 */     if (entitylivingbase != null)
/*    */     {
/* 52 */       this.timestamp = entitylivingbase.func_142015_aE();
/*    */     }
/*    */     
/* 55 */     super.func_75249_e();
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIOwnerHurtByTargetHM.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */