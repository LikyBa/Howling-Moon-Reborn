/*    */ package com.raz.howlingmoon.ai;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityWerewolfGuide;
/*    */ import net.minecraft.entity.ai.EntityAIBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAIMoveToSpawn
/*    */   extends EntityAIBase
/*    */ {
/*    */   private final EntityWerewolfGuide creature;
/*    */   private final double movementSpeed;
/*    */   private final int homeRadius;
/*    */   private final int searchLength;
/*    */   
/*    */   public EntityAIMoveToSpawn(EntityWerewolfGuide creature, int radius, double speedIn, int length) {
/* 24 */     this.creature = creature;
/*    */     
/* 26 */     this.homeRadius = radius;
/* 27 */     this.movementSpeed = speedIn;
/* 28 */     this.searchLength = length;
/* 29 */     func_75248_a(5);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 38 */     if (this.creature.func_174818_b(this.creature.getSpawn()) < (this.homeRadius * this.homeRadius))
/*    */     {
/* 40 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 44 */     if (this.creature.func_174818_b(this.creature.getSpawn()) < this.searchLength)
/*    */     {
/* 46 */       return true;
/*    */     }
/*    */     
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 58 */     return !this.creature.func_70661_as().func_75500_f();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_75249_e() {
/* 66 */     this.creature.func_70661_as().func_75492_a(this.creature.getSpawn().func_177958_n(), (this.creature.getSpawn().func_177956_o() + 1), this.creature.getSpawn().func_177952_p(), this.movementSpeed);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIMoveToSpawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */