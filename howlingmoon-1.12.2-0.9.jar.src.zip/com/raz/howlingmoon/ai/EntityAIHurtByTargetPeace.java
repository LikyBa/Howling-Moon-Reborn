/*    */ package com.raz.howlingmoon.ai;
/*    */ 
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.ai.EntityAIHurtByTarget;
/*    */ import net.minecraft.world.EnumDifficulty;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAIHurtByTargetPeace
/*    */   extends EntityAIHurtByTarget
/*    */ {
/*    */   public EntityAIHurtByTargetPeace(EntityCreature creatureIn, boolean entityCallsForHelpIn, Class<?>... excludedReinforcementTypes) {
/* 13 */     super(creatureIn, entityCallsForHelpIn, excludedReinforcementTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 20 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/* 21 */       return false; 
/* 22 */     return super.func_75250_a();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 28 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/* 29 */       return false; 
/* 30 */     return super.func_75253_b();
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIHurtByTargetPeace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */