/*     */ package com.raz.howlingmoon.ai;
/*     */ 
/*     */ import com.raz.howlingmoon.entities.EntityHunter;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.ai.RandomPositionGenerator;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.village.Village;
/*     */ 
/*     */ public class EntityAIMoveAroundLodge
/*     */   extends EntityAIBase
/*     */ {
/*     */   private final EntityHunter hunter;
/*     */   private double movePosX;
/*     */   private double movePosY;
/*     */   private double movePosZ;
/*     */   private final double movementSpeed;
/*     */   protected int executionChance;
/*     */   private boolean ignoreVillage;
/*     */   
/*     */   public EntityAIMoveAroundLodge(EntityHunter creatureIn, double speedIn, boolean ignore) {
/*  24 */     this(creatureIn, speedIn, 120, ignore);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAIMoveAroundLodge(EntityHunter creatureIn, double speedIn, int chance, boolean ignore) {
/*  29 */     this.hunter = creatureIn;
/*  30 */     this.movementSpeed = speedIn;
/*  31 */     this.executionChance = chance;
/*  32 */     this.ignoreVillage = ignore;
/*  33 */     func_75248_a(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75250_a() {
/*  39 */     if (this.hunter.func_70681_au().nextInt(this.executionChance) != 0)
/*     */     {
/*  41 */       return false;
/*     */     }
/*     */     
/*  44 */     Village village = this.hunter.field_70170_p.func_175714_ae().func_176056_a(new BlockPos((Entity)this.hunter), 0);
/*  45 */     if (!this.ignoreVillage && !this.hunter.field_70170_p.func_72935_r() && village != null) {
/*  46 */       return false;
/*     */     }
/*  48 */     boolean lodge = getIsNearRadius(3);
/*  49 */     if (!lodge)
/*     */     {
/*  51 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  56 */     Vec3d vec3d = RandomPositionGenerator.func_75464_a((EntityCreature)this.hunter, 10, 8, new Vec3d(this.hunter.getSpawn().func_177958_n() + 0.5D, this.hunter.getSpawn().func_177956_o() + 1.0D, this.hunter.getSpawn().func_177952_p() + 0.5D));
/*     */     
/*  58 */     if (vec3d == null)
/*     */     {
/*  60 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  64 */     this.movePosX = vec3d.field_72450_a;
/*  65 */     this.movePosY = vec3d.field_72448_b;
/*  66 */     this.movePosZ = vec3d.field_72449_c;
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/* 106 */     return !this.hunter.func_70661_as().func_75500_f();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75249_e() {
/* 115 */     this.hunter.func_70661_as().func_75492_a(this.movePosX, this.movePosY, this.movePosZ, this.movementSpeed);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getIsNearRadius(int radius) {
/* 120 */     double d1 = this.hunter.distanceFromSpawn();
/*     */     
/* 122 */     float f = (radius + 9);
/*     */     
/* 124 */     if (d1 <= (f * f)) {
/* 125 */       return true;
/*     */     }
/* 127 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAIMoveAroundLodge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */