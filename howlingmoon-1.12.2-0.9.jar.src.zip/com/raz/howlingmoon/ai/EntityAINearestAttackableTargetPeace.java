/*    */ package com.raz.howlingmoon.ai;
/*    */ 
/*    */ import com.google.common.base.Predicate;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
/*    */ import net.minecraft.world.EnumDifficulty;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityAINearestAttackableTargetPeace<T extends EntityLivingBase>
/*    */   extends EntityAINearestAttackableTarget
/*    */ {
/*    */   public EntityAINearestAttackableTargetPeace(EntityCreature creature, Class<T> classTarget, boolean checkSight) {
/* 15 */     super(creature, classTarget, checkSight, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityAINearestAttackableTargetPeace(EntityCreature creature, Class<T> classTarget, boolean checkSight, boolean onlyNearby) {
/* 20 */     super(creature, classTarget, 10, checkSight, onlyNearby, (Predicate)null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityAINearestAttackableTargetPeace(EntityCreature creature, Class classTarget, int chance, boolean checkSight, boolean onlyNearby, Predicate targetSelector) {
/* 26 */     super(creature, classTarget, chance, checkSight, onlyNearby, targetSelector);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75250_a() {
/* 32 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/* 33 */       return false; 
/* 34 */     return super.func_75250_a();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75253_b() {
/* 40 */     if (this.field_75299_d.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL)
/* 41 */       return false; 
/* 42 */     return super.func_75253_b();
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\ai\EntityAINearestAttackableTargetPeace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */