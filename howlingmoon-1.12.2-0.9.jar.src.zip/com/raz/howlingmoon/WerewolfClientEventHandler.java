/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.raz.howlingmoon.client.ItemRendererWerewolf;
/*     */ import com.raz.howlingmoon.client.RenderBeastPlayer;
/*     */ import com.raz.howlingmoon.client.RenderDireWolfPlayer;
/*     */ import com.raz.howlingmoon.client.RenderWerewolfPlayer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*     */ import net.minecraft.client.renderer.EntityRenderer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.RenderHandEvent;
/*     */ import net.minecraftforge.client.event.RenderPlayerEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.util.glu.Project;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WerewolfClientEventHandler
/*     */ {
/*  41 */   private static final ResourceLocation guiBar = new ResourceLocation("howlingmoon:textures/gui/bars.png");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private Minecraft mc = Minecraft.func_71410_x();
/*  54 */   public final ItemRendererWerewolf itemRendererWerewolf = new ItemRendererWerewolf(this.mc);
/*  55 */   private Render renderCustomModel = (Render)new RenderWerewolfPlayer(Minecraft.func_71410_x().func_175598_ae());
/*     */   private boolean createdRender = false;
/*  57 */   private int curModel = 0;
/*  58 */   private float ySize = -1.0F;
/*     */   private EntityRenderer rendererBeast;
/*     */   private EntityRenderer rendererDire;
/*     */   private EntityRenderer prevRenderer;
/*     */   private float eyeHeight;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderPlayerPre(RenderPlayerEvent.Pre pre) {
/*  66 */     EntityPlayer player = pre.getEntityPlayer();
/*  67 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/*  69 */     if (wolf.isTransformed()) {
/*     */       
/*  71 */       pre.setCanceled(true);
/*     */       
/*  73 */       if (!this.createdRender || this.curModel != wolf.getModel()) {
/*     */         
/*  75 */         this.curModel = wolf.getModel();
/*  76 */         if (this.curModel == 0) {
/*     */           
/*  78 */           this.renderCustomModel = (Render)new RenderWerewolfPlayer(Minecraft.func_71410_x().func_175598_ae());
/*     */         }
/*  80 */         else if (this.curModel == 1) {
/*     */           
/*  82 */           this.renderCustomModel = (Render)new RenderDireWolfPlayer(Minecraft.func_71410_x().func_175598_ae());
/*     */         }
/*  84 */         else if (this.curModel == 2) {
/*     */           
/*  86 */           this.renderCustomModel = (Render)new RenderBeastPlayer(Minecraft.func_71410_x().func_175598_ae());
/*     */         } 
/*  88 */         this.createdRender = true;
/*     */       } 
/*  90 */       this.renderCustomModel.func_76986_a(pre.getEntity(), pre.getX(), pre.getY(), pre.getZ(), 0.0F, pre.getPartialRenderTick());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 107 */     else if (this.createdRender) {
/*     */       
/* 109 */       this.createdRender = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderWerewolfPaw(RenderHandEvent event) {
/* 117 */     IWerewolfCapability wolf = (IWerewolfCapability)this.mc.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 118 */     if (wolf.isTransformed()) {
/*     */       
/* 120 */       event.setCanceled(true);
/* 121 */       EntityPlayerSP entityPlayerSP = (Minecraft.func_71410_x()).field_71439_g;
/* 122 */       EntityRenderer playerRender = (Minecraft.func_71410_x()).field_71460_t;
/* 123 */       GlStateManager.func_179086_m(256);
/* 124 */       float partialTicks = event.getPartialTicks();
/* 125 */       int pass = event.getRenderPass();
/*     */       
/* 127 */       GlStateManager.func_179128_n(5889);
/* 128 */       GlStateManager.func_179096_D();
/* 129 */       float f = 0.07F;
/*     */       
/* 131 */       if (this.mc.field_71474_y.field_74337_g)
/*     */       {
/* 133 */         GlStateManager.func_179109_b(-(pass * 2 - 1) * 0.07F, 0.0F, 0.0F);
/*     */       }
/*     */       
/* 136 */       float farPlaneDistance = (this.mc.field_71474_y.field_151451_c * 16);
/* 137 */       Project.gluPerspective(getFOVModifier(partialTicks, false), this.mc.field_71443_c / this.mc.field_71440_d, 0.05F, farPlaneDistance * 2.0F);
/* 138 */       GlStateManager.func_179128_n(5888);
/* 139 */       GlStateManager.func_179096_D();
/*     */       
/* 141 */       if (this.mc.field_71474_y.field_74337_g)
/*     */       {
/* 143 */         GlStateManager.func_179109_b((pass * 2 - 1) * 0.1F, 0.0F, 0.0F);
/*     */       }
/*     */       
/* 146 */       GlStateManager.func_179094_E();
/*     */ 
/*     */       
/* 149 */       if (this.mc.field_71474_y.field_74336_f)
/*     */       {
/* 151 */         setupViewBobbing(partialTicks);
/*     */       }
/*     */       
/* 154 */       boolean flag = (this.mc.func_175606_aa() instanceof EntityLivingBase && ((EntityLivingBase)this.mc.func_175606_aa()).func_70608_bn());
/*     */ 
/*     */       
/* 157 */       if (this.mc.field_71474_y.field_74320_O == 0 && !flag && !this.mc.field_71474_y.field_74319_N && !this.mc.field_71442_b.func_78747_a()) {
/*     */         
/* 159 */         playerRender.func_180436_i();
/* 160 */         this.itemRendererWerewolf.updateEquippedItem();
/*     */         
/* 162 */         this.itemRendererWerewolf.renderItemInFirstPerson(partialTicks);
/* 163 */         playerRender.func_175072_h();
/*     */       } 
/*     */       
/* 166 */       GlStateManager.func_179121_F();
/*     */       
/* 168 */       if (this.mc.field_71474_y.field_74320_O == 0 && !flag)
/*     */       {
/* 170 */         playerRender.field_78516_c.func_78447_b(partialTicks);
/*     */       }
/*     */ 
/*     */       
/* 174 */       if (this.mc.field_71474_y.field_74336_f)
/*     */       {
/* 176 */         setupViewBobbing(partialTicks);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupViewBobbing(float partialTicks) {
/* 371 */     if (this.mc.func_175606_aa() instanceof EntityPlayer) {
/*     */       
/* 373 */       EntityPlayer entityplayer = (EntityPlayer)this.mc.func_175606_aa();
/* 374 */       float f = entityplayer.field_70140_Q - entityplayer.field_70141_P;
/* 375 */       float f1 = -(entityplayer.field_70140_Q + f * partialTicks);
/* 376 */       float f2 = entityplayer.field_71107_bF + (entityplayer.field_71109_bG - entityplayer.field_71107_bF) * partialTicks;
/* 377 */       float f3 = entityplayer.field_70727_aS + (entityplayer.field_70726_aT - entityplayer.field_70727_aS) * partialTicks;
/* 378 */       GlStateManager.func_179109_b(MathHelper.func_76126_a(f1 * 3.1415927F) * f2 * 0.5F, -Math.abs(MathHelper.func_76134_b(f1 * 3.1415927F) * f2), 0.0F);
/* 379 */       GlStateManager.func_179114_b(MathHelper.func_76126_a(f1 * 3.1415927F) * f2 * 3.0F, 0.0F, 0.0F, 1.0F);
/* 380 */       GlStateManager.func_179114_b(Math.abs(MathHelper.func_76134_b(f1 * 3.1415927F - 0.2F) * f2) * 5.0F, 1.0F, 0.0F, 0.0F);
/* 381 */       GlStateManager.func_179114_b(f3, 1.0F, 0.0F, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float getFOVModifier(float partialTicks, boolean useFOVSetting) {
/* 390 */     Entity entity = this.mc.func_175606_aa();
/* 391 */     float f = 70.0F;
/*     */     
/* 393 */     if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).func_110143_aJ() <= 0.0F) {
/*     */       
/* 395 */       float f1 = ((EntityLivingBase)entity).field_70725_aQ + partialTicks;
/* 396 */       f /= (1.0F - 500.0F / (f1 + 500.0F)) * 2.0F + 1.0F;
/*     */     } 
/*     */     
/* 399 */     IBlockState iblockstate = ActiveRenderInfo.func_186703_a((World)this.mc.field_71441_e, entity, partialTicks);
/*     */     
/* 401 */     if (iblockstate.func_185904_a() == Material.field_151586_h)
/*     */     {
/* 403 */       f = f * 60.0F / 70.0F;
/*     */     }
/*     */     
/* 406 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WerewolfClientEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */