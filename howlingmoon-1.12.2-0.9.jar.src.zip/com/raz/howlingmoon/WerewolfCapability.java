/*      */ package com.raz.howlingmoon;
/*      */ import com.google.common.collect.HashMultimap;
/*      */ import com.google.common.collect.Multimap;
/*      */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*      */ import com.raz.howlingmoon.packets.TrackingMessage;
/*      */ import java.util.HashMap;
/*      */ import java.util.Set;
/*      */ import net.minecraft.client.resources.I18n;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityList;
/*      */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.init.MobEffects;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraft.util.ResourceLocation;
/*      */ import net.minecraft.world.WorldServer;
/*      */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*      */ import net.minecraftforge.fml.relauncher.Side;
/*      */ 
/*      */ public class WerewolfCapability implements IWerewolfCapability {
/*      */   private boolean isWerewolf;
/*      */   private boolean isTransformed;
/*      */   private boolean isSprintKey;
/*      */   private int infected;
/*      */   private boolean displayRage;
/*      */   private boolean moonTransformation;
/*      */   private int tick;
/*      */   private int cdExhil;
/*      */   private int cdHowl;
/*      */   private int cdBerserk;
/*      */   private int berserkLevel;
/*      */   private int level;
/*      */   private int exp;
/*      */   private int questsDone;
/*      */   private int inclinationType;
/*      */   private int usedAttributePoints;
/*      */   private int usedAbilityPoints;
/*      */   private HashMap<String, Boolean> basicTree;
/*      */   private HashMap<String, Integer> attributeTree;
/*      */   
/*      */   public WerewolfCapability() {
/*   42 */     this.isWerewolf = false;
/*   43 */     this.isTransformed = false;
/*   44 */     this.isSprintKey = false;
/*   45 */     this.infected = 0;
/*   46 */     this.displayRage = false;
/*   47 */     this.moonTransformation = false;
/*   48 */     this.tick = 0;
/*   49 */     this.cdExhil = 150;
/*   50 */     this.cdHowl = 30;
/*   51 */     this.cdBerserk = 0;
/*   52 */     this.berserkLevel = 0;
/*      */     
/*   54 */     this.level = 0;
/*   55 */     this.exp = 0;
/*   56 */     this.questsDone = 0;
/*   57 */     this.inclinationType = 0;
/*      */ 
/*      */ 
/*      */     
/*   61 */     this.basicTree = new HashMap<String, Boolean>()
/*      */       {
/*      */       
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*   68 */     this.attributeTree = new HashMap<String, Integer>()
/*      */       {
/*      */       
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*   75 */     this.abilityTree = new HashMap<String, Boolean>()
/*      */       {
/*      */       
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   83 */     this.scentColors = new HashMap<Class<? extends Entity>, Integer>()
/*      */       {
/*      */       
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  112 */     this.t2Modifier = new AttributeModifier(UUID.fromString("fc1af77f-2c52-4ba6-b722-7d3097162cf9"), "Tenacity", 1.0D, 0);
/*  113 */     this.attributes = (Multimap<String, AttributeModifier>)HashMultimap.create();
/*      */     
/*  115 */     this.attributes.put(SharedMonsterAttributes.field_111266_c.func_111108_a(), this.t2Modifier);
/*      */ 
/*      */ 
/*      */     
/*  119 */     this.sprintClimb = 0; this.sneakJump = 2; this.sprintJump = 2; this.sprintRam = 1;
/*  120 */     this.leapState = 0; this.pawSlot = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     this.texture = 0;
/*  126 */     this.model = 0;
/*      */   }
/*      */   private HashMap<String, Boolean> abilityTree; private HashMap<Class<? extends Entity>, Integer> scentColors; private AttributeModifier t2Modifier; private Multimap<String, AttributeModifier> attributes; private boolean t2Knockback; private boolean climb; private boolean nightVision; private boolean leap; private boolean scentTracking; private int sprintClimb; private int sneakJump; private int sprintJump; private int sprintRam; private int leapState; private int pawSlot; private WereAbility abilitySlot1; private WereAbility abilitySlot2; private int texture; private int model;
/*      */   
/*      */   public void copy(IWerewolfCapability cap) {
/*  131 */     this.isWerewolf = cap.isWerewolf();
/*  132 */     this.isTransformed = false;
/*  133 */     this.infected = cap.getInfected();
/*  134 */     this.level = cap.getLevel();
/*  135 */     this.exp = cap.getExp();
/*  136 */     this.questsDone = cap.getQuestsDone();
/*  137 */     this.inclinationType = cap.getInclinationType();
/*  138 */     this.texture = cap.getTexture();
/*  139 */     this.model = cap.getModel();
/*  140 */     this.abilitySlot1 = cap.getAbilitySlot1();
/*  141 */     this.abilitySlot2 = cap.getAbilitySlot2();
/*  142 */     this.t2Knockback = cap.getKnockbackResist();
/*      */ 
/*      */     
/*  145 */     this.basicTree = cap.getBasicTree();
/*  146 */     this.attributeTree = cap.getAttributeTree();
/*  147 */     this.abilityTree = cap.getAbilityTree();
/*  148 */     this.scentColors = cap.getScentTree();
/*  149 */     this.usedAttributePoints = cap.getUsedAttributePoints();
/*  150 */     this.usedAbilityPoints = cap.getUsedAbilityPoints();
/*      */     
/*  152 */     this.pawSlot = cap.getPawSlot();
/*  153 */     this.nightVision = cap.getNightVision();
/*  154 */     this.scentTracking = cap.getScentTracking();
/*  155 */     this.leapState = cap.getLeapState();
/*  156 */     this.sprintClimb = cap.getSprintClimb();
/*  157 */     this.sneakJump = cap.getSneakJump();
/*  158 */     this.sprintJump = cap.getSprintJump();
/*  159 */     this.sprintRam = cap.getSprintRam();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWerewolf() {
/*  171 */     return this.isWerewolf;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTransformed() {
/*  177 */     return this.isTransformed;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSprintKey() {
/*  183 */     return this.isSprintKey;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSprintKey(boolean isSprintKey) {
/*  188 */     this.isSprintKey = isSprintKey;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTransformed(boolean isTransformed) {
/*  193 */     this.isTransformed = isTransformed;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWerewolf(boolean state) {
/*  199 */     this.isWerewolf = state;
/*  200 */     this.basicTree.put("WEREWOLF", Boolean.valueOf(state));
/*  201 */     this.basicTree.put("EMPTYPAW", Boolean.valueOf(state));
/*  202 */     if (this.level < 1) {
/*  203 */       setLevel(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWerewolf(boolean state, EntityPlayer player) {
/*  209 */     if (!player.field_70170_p.field_72995_K)
/*      */     {
/*  211 */       if (this.isWerewolf != state) {
/*      */         
/*  213 */         this.isWerewolf = state;
/*  214 */         this.basicTree.put("WEREWOLF", Boolean.valueOf(state));
/*  215 */         this.basicTree.put("EMPTYPAW", Boolean.valueOf(state));
/*  216 */         if (state) {
/*      */           
/*  218 */           if (this.level < 1)
/*  219 */             setLevel(1); 
/*  220 */           this.infected = 2;
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  225 */           setQuestsDone(0);
/*  226 */           setInclinationType(0);
/*  227 */           resetAttributePoints();
/*  228 */           resetAbilityPoints();
/*  229 */           setTransformedServer(false, player);
/*  230 */           this.infected = 0;
/*      */ 
/*      */ 
/*      */           
/*  234 */           this.exp = 0;
/*  235 */           this.level /= 2;
/*      */         } 
/*      */         
/*  238 */         PacketDispatcher.sendTo((IMessage)new SyncWereCapsMessage(player), (EntityPlayerMP)player);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void tryTransform(EntityPlayer player) {
/*  246 */     if (player.field_70170_p.func_72935_r() || (player.field_70170_p.func_130001_d() != 1.0F && (getInclinationType() != -1 || getQuestsDone() <= 7))) {
/*      */       
/*  248 */       if (this.isTransformed) {
/*      */ 
/*      */ 
/*      */         
/*  252 */         int duration = 1200;
/*  253 */         duration -= getAttributeTreeAbility(WereList.CLARITY.getKey()) * 400;
/*  254 */         if (duration > 0) {
/*      */           
/*  256 */           player.func_71020_j((duration / 200));
/*  257 */           player.func_70690_d(new PotionEffect(MobEffects.field_76419_f, duration, 0, false, false));
/*  258 */           player.func_70690_d(new PotionEffect(MobEffects.field_76421_d, duration, 0, false, false));
/*  259 */           player.func_70690_d(new PotionEffect(MobEffects.field_76437_t, duration, 0, false, false));
/*  260 */           player.func_70690_d(new PotionEffect(MobEffects.field_76438_s, duration, 0, false, false));
/*      */         } 
/*      */         
/*  263 */         this.isTransformed = false;
/*  264 */         PacketDispatcher.sendTo((IMessage)new SyncTransformMessage(player), (EntityPlayerMP)player);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  270 */         int duration = 0;
/*  271 */         duration += getAttributeTreeAbility(WereList.EXHILARATING.getKey());
/*  272 */         if (duration > 0 && getCDExhil() < 1) {
/*      */           
/*  274 */           player.func_71024_bL().func_75122_a(1, (duration * 3));
/*      */           
/*  276 */           player.func_70690_d(new PotionEffect(MobEffects.field_76444_x, duration * 400, duration - 1, false, false));
/*  277 */           player.func_70690_d(new PotionEffect(MobEffects.field_76422_e, duration * 400, 0, false, false));
/*  278 */           player.func_70690_d(new PotionEffect(MobEffects.field_76424_c, duration * 400, 0, false, false));
/*  279 */           player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, duration * 400, 0, false, false));
/*  280 */           resetCDExhil();
/*      */         } 
/*  282 */         this.isTransformed = true;
/*  283 */         PacketDispatcher.sendTo((IMessage)new SyncTransformMessage(player), (EntityPlayerMP)player);
/*      */       } 
/*      */ 
/*      */       
/*  287 */       Set<? extends EntityPlayer> players = ((WorldServer)player.field_70170_p).func_73039_n().getTrackingPlayers((Entity)player);
/*  288 */       PacketDispatcher.sendToPlayers((IMessage)new TrackingMessage(player), players);
/*      */     }
/*      */     else {
/*      */       
/*  292 */       player.func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.exitmoon", new Object[0]));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransformed(boolean state, boolean ignoreNegative, Side side, EntityPlayer player) {
/*  301 */     boolean temp = this.isTransformed;
/*  302 */     this.isTransformed = state;
/*  303 */     if (state && ignoreNegative) {
/*  304 */       this.moonTransformation = true;
/*      */     } else {
/*  306 */       this.moonTransformation = false;
/*      */     } 
/*  308 */     if (side.isServer()) {
/*      */       
/*  310 */       PacketDispatcher.sendTo((IMessage)new SyncTransformMessage(player), (EntityPlayerMP)player);
/*      */       
/*  312 */       if (!ignoreNegative && !state && temp) {
/*      */         
/*  314 */         int duration = 1200;
/*  315 */         duration -= getAttributeTreeAbility(WereList.CLARITY.getKey()) * 400;
/*  316 */         if (duration > 0)
/*      */         {
/*  318 */           player.func_71020_j((duration / 200));
/*  319 */           player.func_70690_d(new PotionEffect(MobEffects.field_76419_f, duration, 0, false, false));
/*  320 */           player.func_70690_d(new PotionEffect(MobEffects.field_76421_d, duration, 0, false, false));
/*  321 */           player.func_70690_d(new PotionEffect(MobEffects.field_76437_t, duration, 0, false, false));
/*  322 */           player.func_70690_d(new PotionEffect(MobEffects.field_76438_s, duration, 0, false, false));
/*      */         }
/*      */       
/*  325 */       } else if (state && !temp) {
/*      */         
/*  327 */         int duration = 0;
/*  328 */         duration += getAttributeTreeAbility(WereList.EXHILARATING.getKey());
/*  329 */         if (duration > 0 && getCDExhil() < 1) {
/*      */           
/*  331 */           player.func_71024_bL().func_75122_a(1, (duration * 3));
/*      */           
/*  333 */           player.func_70690_d(new PotionEffect(MobEffects.field_76444_x, duration * 400, duration - 1, false, false));
/*  334 */           player.func_70690_d(new PotionEffect(MobEffects.field_76422_e, duration * 400, 0, false, false));
/*  335 */           player.func_70690_d(new PotionEffect(MobEffects.field_76424_c, duration * 400, 0, false, false));
/*  336 */           player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, duration * 400, 0, false, false));
/*  337 */           resetCDExhil();
/*      */         } 
/*      */       } 
/*  340 */       Set<? extends EntityPlayer> players = ((WorldServer)player.field_70170_p).func_73039_n().getTrackingPlayers((Entity)player);
/*  341 */       PacketDispatcher.sendToPlayers((IMessage)new TrackingMessage(player), players);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransformedServer(boolean state, EntityPlayer player) {
/*  349 */     boolean temp = this.isTransformed;
/*  350 */     this.isTransformed = state;
/*  351 */     PacketDispatcher.sendTo((IMessage)new SyncTransformMessage(player), (EntityPlayerMP)player);
/*      */     
/*  353 */     if (!state && temp) {
/*      */       
/*  355 */       int duration = 1200;
/*  356 */       duration -= getAttributeTreeAbility(WereList.CLARITY.getKey()) * 400;
/*  357 */       if (duration > 0)
/*      */       {
/*  359 */         player.func_71020_j((duration / 200));
/*  360 */         player.func_70690_d(new PotionEffect(MobEffects.field_76419_f, duration, 0, false, false));
/*  361 */         player.func_70690_d(new PotionEffect(MobEffects.field_76421_d, duration, 0, false, false));
/*  362 */         player.func_70690_d(new PotionEffect(MobEffects.field_76437_t, duration, 0, false, false));
/*  363 */         player.func_70690_d(new PotionEffect(MobEffects.field_76438_s, duration, 0, false, false));
/*      */       }
/*      */     
/*  366 */     } else if (state && !temp) {
/*      */       
/*  368 */       int duration = 0;
/*  369 */       duration += getAttributeTreeAbility(WereList.EXHILARATING.getKey());
/*  370 */       if (duration > 0 && getCDExhil() < 1) {
/*      */         
/*  372 */         player.func_71024_bL().func_75122_a(1, (duration * 3));
/*      */         
/*  374 */         player.func_70690_d(new PotionEffect(MobEffects.field_76444_x, duration * 400, duration - 1, false, false));
/*  375 */         player.func_70690_d(new PotionEffect(MobEffects.field_76422_e, duration * 400, 0, false, false));
/*  376 */         player.func_70690_d(new PotionEffect(MobEffects.field_76424_c, duration * 400, 0, false, false));
/*  377 */         player.func_70690_d(new PotionEffect(MobEffects.field_76429_m, duration * 400, 0, false, false));
/*  378 */         resetCDExhil();
/*      */       } 
/*      */     } 
/*  381 */     Set<? extends EntityPlayer> players = ((WorldServer)player.field_70170_p).func_73039_n().getTrackingPlayers((Entity)player);
/*  382 */     PacketDispatcher.sendToPlayers((IMessage)new TrackingMessage(player), players);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<String, Boolean> getBasicTree() {
/*  388 */     return this.basicTree;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBasicTree(HashMap<String, Boolean> array) {
/*  394 */     this.basicTree = array;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBasicTreeAbility(String key) {
/*  400 */     if (this.basicTree.get(key) != null)
/*  401 */       return ((Boolean)this.basicTree.get(key)).booleanValue(); 
/*  402 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBasicTreeAbility(String key, boolean value) {
/*  408 */     this.basicTree.put(key, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<String, Integer> getAttributeTree() {
/*  414 */     return this.attributeTree;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeTree(HashMap<String, Integer> array) {
/*  420 */     this.attributeTree = array;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributeTreeAbility(String key) {
/*  426 */     if (this.attributeTree.get(key) != null)
/*  427 */       return ((Integer)this.attributeTree.get(key)).intValue(); 
/*  428 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeTreeAbility(String key, int value) {
/*  434 */     if (value < 0)
/*  435 */       value = 0; 
/*  436 */     this.attributeTree.put(key, Integer.valueOf(value));
/*      */ 
/*      */     
/*  439 */     if (((Integer)this.attributeTree.get(key)).intValue() > WereList.getAttributeFromKey(key).getCap()) {
/*  440 */       this.attributeTree.put(key, Integer.valueOf(WereList.getAttributeFromKey(key).getCap()));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeTreeAbility(WereAttribute ability) {
/*  446 */     String key = ability.getKey();
/*  447 */     if (!isAttributeCapped(key))
/*      */     {
/*  449 */       if (getUsuableAttributePoints() > 0) {
/*      */         
/*  451 */         this.attributeTree.put(key, Integer.valueOf(((Integer)this.attributeTree.get(key)).intValue() + 1));
/*  452 */         setUsedAttributePoints(getUsedAttributePoints() + 1);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAttributeCapped(String key) {
/*  460 */     return (((Integer)this.attributeTree.get(key)).intValue() >= WereList.getAttributeFromKey(key).getCap());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetAttributeTree() {
/*  466 */     for (String key : this.attributeTree.keySet())
/*      */     {
/*  468 */       this.attributeTree.put(key, Integer.valueOf(0));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<String, Boolean> getAbilityTree() {
/*  475 */     return this.abilityTree;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void seAbilityTree(HashMap<String, Boolean> array) {
/*  481 */     this.abilityTree = array;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAbilityTreeAbility(String key) {
/*  487 */     if (this.abilityTree.get(key) != null)
/*  488 */       return ((Boolean)this.abilityTree.get(key)).booleanValue(); 
/*  489 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbilityTreeAbility(String key, boolean value) {
/*  495 */     this.abilityTree.put(key, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAbilityTreeAbility(WereAbility ability) {
/*  501 */     String key = ability.getKey();
/*  502 */     if (!getAbilityTreeAbility(ability.getKey()))
/*      */     {
/*  504 */       if (getUsuableAbilityPoints() > 0) {
/*      */         
/*  506 */         this.abilityTree.put(key, Boolean.valueOf(true));
/*  507 */         setUsedAbilityPoints(getUsedAbilityPoints() + 1);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAbilityTreeAbilityWithoutAP(WereAbility ability) {
/*  515 */     String key = ability.getKey();
/*  516 */     if (!getAbilityTreeAbility(ability.getKey()))
/*      */     {
/*  518 */       this.abilityTree.put(key, Boolean.valueOf(true));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetAbilityTree() {
/*  525 */     for (String key : this.abilityTree.keySet())
/*      */     {
/*  527 */       this.abilityTree.put(key, Boolean.valueOf(false));
/*      */     }
/*  529 */     resetProgressAbilities();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap<Class<? extends Entity>, Integer> getScentTree() {
/*  535 */     return this.scentColors;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getScentColor(Class<? extends Entity> entityClass) {
/*  541 */     if (this.scentColors.get(entityClass) != null)
/*  542 */       return ((Integer)this.scentColors.get(entityClass)).intValue(); 
/*  543 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScentColor(Class<? extends Entity> entityClass, int color) {
/*  549 */     if (this.scentColors.get(entityClass) != null) {
/*  550 */       this.scentColors.put(entityClass, Integer.valueOf(color));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLevelCap() {
/*  557 */     if (getInclinationType() == -1 && getQuestsDone() > 7)
/*  558 */       return ConfigHandler.setLevelCap + 5; 
/*  559 */     return ConfigHandler.setLevelCap;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLevel() {
/*  564 */     return this.level;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLevel(int level) {
/*  569 */     this.level = level;
/*  570 */     if (this.level > getLevelCap())
/*  571 */       this.level = getLevelCap(); 
/*  572 */     setExp(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getExp() {
/*  577 */     return this.exp;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setExp(int exp) {
/*  582 */     this.exp = exp;
/*  583 */     expLevel();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addExp(int amount) {
/*  589 */     this.exp += amount;
/*  590 */     expLevel();
/*      */   }
/*      */ 
/*      */   
/*      */   private void expLevel() {
/*  595 */     if (!levelCapped()) {
/*      */       
/*  597 */       if (this.exp >= expNeededLevel())
/*      */       {
/*  599 */         setLevel(getLevel() + 1);
/*      */       
/*      */       }
/*      */     }
/*  603 */     else if (this.exp > 0) {
/*  604 */       this.exp = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int expNeededLevel() {
/*  611 */     return getLevel() * 25;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean levelCapped() {
/*  616 */     return (this.level >= getLevelCap());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getQuestsDone() {
/*  621 */     return this.questsDone;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQuestsDone(int questsDone) {
/*  627 */     this.questsDone = questsDone;
/*  628 */     resetProgressAbilities();
/*      */   }
/*      */ 
/*      */   
/*      */   private void resetProgressAbilities() {
/*  633 */     if (getUsuableAttributePoints() < 0)
/*      */     {
/*  635 */       resetAttributePoints();
/*      */     }
/*  637 */     if (getUsuableAbilityPoints() < 0)
/*      */     {
/*  639 */       resetAbilityPoints();
/*      */     }
/*  641 */     switch (this.questsDone) {
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  647 */         addAbilityTreeAbilityWithoutAP(WereList.BITE);
/*      */       case 3:
/*      */       case 4:
/*  650 */         addAbilityTreeAbilityWithoutAP(WereList.NIGHTVISION);
/*      */       case 2:
/*  652 */         addAbilityTreeAbilityWithoutAP(WereList.HOWL); break;
/*      */     } 
/*  654 */     if (this.questsDone < 5) {
/*      */       
/*  656 */       if (getAbilityTreeAbility(WereList.BITE.getKey()))
/*      */       {
/*  658 */         this.abilityTree.put(WereList.BITE.getKey(), Boolean.valueOf(false));
/*      */       }
/*  660 */       if (this.questsDone < 3) {
/*      */         
/*  662 */         if (getAbilityTreeAbility(WereList.NIGHTVISION.getKey()))
/*      */         {
/*  664 */           this.abilityTree.put(WereList.NIGHTVISION.getKey(), Boolean.valueOf(false));
/*      */         }
/*  666 */         if (this.questsDone < 2)
/*      */         {
/*  668 */           if (getAbilityTreeAbility(WereList.HOWL.getKey()))
/*      */           {
/*  670 */             this.abilityTree.put(WereList.HOWL.getKey(), Boolean.valueOf(false));
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInclinationType() {
/*  680 */     return this.inclinationType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInclinationType(int type) {
/*  685 */     if (type < 0) {
/*  686 */       type = -1;
/*  687 */     } else if (type > 0) {
/*  688 */       type = 1;
/*  689 */     }  this.inclinationType = type;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributePoints() {
/*  695 */     int temp = this.level * 2;
/*  696 */     if (getInclinationType() == 0) {
/*      */       
/*  698 */       if (getQuestsDone() > 5)
/*  699 */         temp += 10; 
/*  700 */       if (getQuestsDone() > 7)
/*  701 */         temp += 15; 
/*      */     } 
/*  703 */     return temp;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUsedAttributePoints() {
/*  709 */     return this.usedAttributePoints;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUsedAttributePoints(int usedAttributePoints) {
/*  714 */     this.usedAttributePoints = usedAttributePoints;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUsuableAttributePoints() {
/*  720 */     return getAttributePoints() - this.usedAttributePoints;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetAttributePoints() {
/*  726 */     setUsedAttributePoints(0);
/*  727 */     resetAttributeTree();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAbilityPoints() {
/*  733 */     int temp = 1 + (int)Math.floor((this.level / 3));
/*  734 */     if (getInclinationType() == 0)
/*      */     {
/*  736 */       if (getQuestsDone() > 7)
/*  737 */         temp += 2; 
/*      */     }
/*  739 */     return temp;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUsedAbilityPoints() {
/*  745 */     return this.usedAbilityPoints;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUsedAbilityPoints(int usedAbilityPoints) {
/*  750 */     this.usedAbilityPoints = usedAbilityPoints;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUsuableAbilityPoints() {
/*  756 */     return getAbilityPoints() - this.usedAbilityPoints;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetAbilityPoints() {
/*  762 */     setUsedAbilityPoints(0);
/*  763 */     resetAbilityTree();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTexture() {
/*  768 */     return this.texture;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTextureName() {
/*  773 */     switch (this.texture) {
/*      */       case 0:
/*  775 */         return I18n.func_135052_a("werewolf.menu.texture.white", new Object[0]);
/*  776 */       case 1: return I18n.func_135052_a("werewolf.menu.texture.black", new Object[0]);
/*  777 */       case 2: return I18n.func_135052_a("werewolf.menu.texture.timber", new Object[0]);
/*  778 */       case 3: return "Killerwolf";
/*  779 */     }  return I18n.func_135052_a("werewolf.menu.texture.custom", new Object[0]) + (this.texture - 3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTexture(int i) {
/*  785 */     this.texture = i;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTexture(int i, Side side, EntityPlayer player) {
/*  790 */     this.texture = i;
/*  791 */     if (side.isServer() && this.isTransformed) {
/*      */       
/*  793 */       Set<? extends EntityPlayer> players = ((WorldServer)player.field_70170_p).func_73039_n().getTrackingPlayers((Entity)player);
/*  794 */       PacketDispatcher.sendToPlayers((IMessage)new TrackingMessage(player), players);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getModel() {
/*  800 */     return this.model;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getModelName() {
/*  805 */     if (this.model == 0)
/*  806 */       return I18n.func_135052_a("werewolf.menu.werewolf", new Object[0]); 
/*  807 */     if (this.model == 1)
/*  808 */       return I18n.func_135052_a("werewolf.menu.model.wolf", new Object[0]); 
/*  809 */     if (this.model == 2)
/*  810 */       return I18n.func_135052_a("werewolf.menu.model.beast", new Object[0]); 
/*  811 */     return "Error";
/*      */   }
/*      */ 
/*      */   
/*      */   public void setModel(int i) {
/*  816 */     this.model = i;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setModel(int i, Side side, EntityPlayer player) {
/*  821 */     this.model = i;
/*  822 */     if (side.isServer() && this.isTransformed) {
/*      */       
/*  824 */       Set<? extends EntityPlayer> players = ((WorldServer)player.field_70170_p).func_73039_n().getTrackingPlayers((Entity)player);
/*  825 */       PacketDispatcher.sendToPlayers((IMessage)new TrackingMessage(player), players);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInfected() {
/*  832 */     return this.infected;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInfected(int i) {
/*  838 */     this.infected = i;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTick() {
/*  843 */     return this.tick;
/*      */   }
/*      */ 
/*      */   
/*      */   public void incTick() {
/*  848 */     this.tick++;
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetTick() {
/*  853 */     this.tick = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getCDExhil() {
/*  858 */     return this.cdExhil;
/*      */   }
/*      */ 
/*      */   
/*      */   public void deincCDExhil() {
/*  863 */     if (this.cdExhil > 0) {
/*  864 */       this.cdExhil--;
/*      */     }
/*      */   }
/*      */   
/*      */   public void resetCDExhil() {
/*  869 */     this.cdExhil = 300;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getCDHowl() {
/*  874 */     return this.cdHowl;
/*      */   }
/*      */ 
/*      */   
/*      */   public void deincCDHowl() {
/*  879 */     if (this.cdHowl > 0) {
/*  880 */       this.cdHowl--;
/*      */     }
/*      */   }
/*      */   
/*      */   public void resetCDHowl() {
/*  885 */     this.cdHowl = 60;
/*      */   }
/*      */ 
/*      */   
/*      */   public void deincCDBerserk() {
/*  890 */     if (this.cdBerserk > 0) {
/*  891 */       this.cdBerserk--;
/*      */     }
/*      */   }
/*      */   
/*      */   public void resetCDBerserk() {
/*  896 */     this.cdBerserk = 20;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getDisplayRage() {
/*  901 */     return this.displayRage;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDisplayRage(boolean state) {
/*  906 */     this.displayRage = state;
/*      */   }
/*      */ 
/*      */   
/*      */   public Multimap<String, AttributeModifier> getAttributeKBResist() {
/*  911 */     HashMultimap hashMultimap = HashMultimap.create();
/*  912 */     UUID uuid = UUID.fromString("fc1af77f-2c52-4ba6-b722-7d3097162cf9");
/*  913 */     float amount = getAttributeTreeAbility(WereList.KNOCKRESIST.getKey()) / 2.0F;
/*  914 */     hashMultimap.put(SharedMonsterAttributes.field_111266_c.func_111108_a(), new AttributeModifier(uuid, "Tenacity", amount, 0));
/*  915 */     return (Multimap<String, AttributeModifier>)hashMultimap;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Multimap<String, AttributeModifier> getAttributeMod() {
/*  921 */     return this.attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getKnockbackResist() {
/*  927 */     return this.t2Knockback;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKnockbackResist(boolean state) {
/*  933 */     this.t2Knockback = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getClimb() {
/*  939 */     return this.climb;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClimb(boolean set) {
/*  945 */     this.climb = set;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLeap() {
/*  951 */     return this.leap;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLeap(boolean set) {
/*  957 */     this.leap = set;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNightVision() {
/*  963 */     return this.nightVision;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNightVision(boolean set) {
/*  969 */     this.nightVision = set;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getScentTracking() {
/*  975 */     return this.scentTracking;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScentTracking(boolean set) {
/*  981 */     this.scentTracking = set;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSprintClimb() {
/*  987 */     return this.sprintClimb;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSprintClimb(int state) {
/*  993 */     this.sprintClimb = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLeapState() {
/*  999 */     return this.leapState;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLeapState(int state) {
/* 1005 */     this.leapState = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSneakJump() {
/* 1011 */     return this.sneakJump;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSneakJump(int state) {
/* 1017 */     this.sneakJump = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSprintJump() {
/* 1023 */     return this.sprintJump;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSprintJump(int state) {
/* 1029 */     this.sprintJump = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSprintRam() {
/* 1035 */     return this.sprintRam;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSprintRam(int state) {
/* 1041 */     this.sprintRam = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public WereAbility getAbilitySlot1() {
/* 1047 */     return this.abilitySlot1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public WereAbility getAbilitySlot2() {
/* 1053 */     return this.abilitySlot2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbilitySlot1(WereAbility ability) {
/* 1059 */     this.abilitySlot1 = ability;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbilitySlot2(WereAbility ability) {
/* 1065 */     this.abilitySlot2 = ability;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPawSlot() {
/* 1071 */     return this.pawSlot;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPawSlot(int slot) {
/* 1077 */     this.pawSlot = slot;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getModelHeight() {
/* 1083 */     if (this.isTransformed) {
/*      */       
/* 1085 */       switch (this.model) {
/*      */         case 0:
/* 1087 */           return 1.8F;
/* 1088 */         case 1: return 0.85F;
/* 1089 */         case 2: return 2.8F;
/* 1090 */       }  return 1.8F;
/*      */     } 
/*      */     
/* 1093 */     return 1.8F;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInclinationTitle() {
/* 1099 */     if (this.inclinationType == 1) {
/*      */       
/* 1101 */       if (getQuestsDone() > 7)
/* 1102 */         return I18n.func_135052_a("werewolf.menu.title.calm3", new Object[0]); 
/* 1103 */       if (getQuestsDone() > 5)
/* 1104 */         return I18n.func_135052_a("werewolf.menu.title.calm2", new Object[0]); 
/* 1105 */       if (getQuestsDone() > 3) {
/* 1106 */         return I18n.func_135052_a("werewolf.menu.title.calm1", new Object[0]);
/*      */       }
/* 1108 */     } else if (this.inclinationType == -1) {
/*      */       
/* 1110 */       if (getQuestsDone() > 7)
/* 1111 */         return I18n.func_135052_a("werewolf.menu.title.savage3", new Object[0]); 
/* 1112 */       if (getQuestsDone() > 5)
/* 1113 */         return I18n.func_135052_a("werewolf.menu.title.savage2", new Object[0]); 
/* 1114 */       if (getQuestsDone() > 3)
/* 1115 */         return I18n.func_135052_a("werewolf.menu.title.savage1", new Object[0]); 
/*      */     } 
/* 1117 */     return I18n.func_135052_a("werewolf.menu.title.neutral", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoonTransformation() {
/* 1123 */     return this.moonTransformation;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMoonTransformation(boolean state) {
/* 1129 */     this.moonTransformation = state;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBerserkLevel() {
/* 1135 */     if (this.cdBerserk < 1) {
/*      */       
/* 1137 */       this.berserkLevel = 0;
/* 1138 */       return 0;
/*      */     } 
/* 1140 */     return this.berserkLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBerserkLevel(int level) {
/* 1146 */     this.berserkLevel = level;
/*      */   }
/*      */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WerewolfCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */