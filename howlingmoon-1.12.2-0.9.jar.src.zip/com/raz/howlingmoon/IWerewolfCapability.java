package com.raz.howlingmoon;

import com.google.common.collect.Multimap;
import java.util.HashMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.relauncher.Side;

public interface IWerewolfCapability {
  boolean isWerewolf();
  
  boolean isTransformed();
  
  boolean isSprintKey();
  
  void setWerewolf(boolean paramBoolean);
  
  void setWerewolf(boolean paramBoolean, EntityPlayer paramEntityPlayer);
  
  void setTransformed(boolean paramBoolean);
  
  void setSprintKey(boolean paramBoolean);
  
  void copy(IWerewolfCapability paramIWerewolfCapability);
  
  int getLevel();
  
  int getLevelCap();
  
  int getExp();
  
  int getQuestsDone();
  
  void setLevel(int paramInt);
  
  void setExp(int paramInt);
  
  void setQuestsDone(int paramInt);
  
  void addExp(int paramInt);
  
  int getInfected();
  
  void setInfected(int paramInt);
  
  boolean getDisplayRage();
  
  void setDisplayRage(boolean paramBoolean);
  
  int getTick();
  
  void incTick();
  
  void resetTick();
  
  int getCDExhil();
  
  void deincCDExhil();
  
  void resetCDExhil();
  
  void tryTransform(EntityPlayer paramEntityPlayer);
  
  void setTransformed(boolean paramBoolean1, boolean paramBoolean2, Side paramSide, EntityPlayer paramEntityPlayer);
  
  void setTransformedServer(boolean paramBoolean, EntityPlayer paramEntityPlayer);
  
  int getModel();
  
  int getTexture();
  
  String getModelName();
  
  String getTextureName();
  
  void setModel(int paramInt);
  
  void setModel(int paramInt, Side paramSide, EntityPlayer paramEntityPlayer);
  
  void setTexture(int paramInt);
  
  void setTexture(int paramInt, Side paramSide, EntityPlayer paramEntityPlayer);
  
  Multimap<String, AttributeModifier> getAttributeMod();
  
  boolean getKnockbackResist();
  
  void setKnockbackResist(boolean paramBoolean);
  
  boolean getClimb();
  
  void setClimb(boolean paramBoolean);
  
  int getSprintClimb();
  
  void setSprintClimb(int paramInt);
  
  int getSneakJump();
  
  void setSneakJump(int paramInt);
  
  int getSprintJump();
  
  void setSprintJump(int paramInt);
  
  WereAbility getAbilitySlot1();
  
  WereAbility getAbilitySlot2();
  
  void setAbilitySlot1(WereAbility paramWereAbility);
  
  void setAbilitySlot2(WereAbility paramWereAbility);
  
  float getModelHeight();
  
  int getLeapState();
  
  void setLeapState(int paramInt);
  
  boolean getNightVision();
  
  void setNightVision(boolean paramBoolean);
  
  boolean getLeap();
  
  void setLeap(boolean paramBoolean);
  
  int getPawSlot();
  
  void setPawSlot(int paramInt);
  
  int expNeededLevel();
  
  int getUsedAttributePoints();
  
  void setUsedAttributePoints(int paramInt);
  
  int getUsuableAttributePoints();
  
  void resetAttributePoints();
  
  HashMap<String, Boolean> getBasicTree();
  
  void setBasicTree(HashMap paramHashMap);
  
  boolean getBasicTreeAbility(String paramString);
  
  void setBasicTreeAbility(String paramString, boolean paramBoolean);
  
  HashMap<String, Integer> getAttributeTree();
  
  void setAttributeTree(HashMap paramHashMap);
  
  int getAttributeTreeAbility(String paramString);
  
  void setAttributeTreeAbility(String paramString, int paramInt);
  
  void addAttributeTreeAbility(WereAttribute paramWereAttribute);
  
  boolean isAttributeCapped(String paramString);
  
  void resetAttributeTree();
  
  HashMap<String, Boolean> getAbilityTree();
  
  void seAbilityTree(HashMap paramHashMap);
  
  boolean getAbilityTreeAbility(String paramString);
  
  void setAbilityTreeAbility(String paramString, boolean paramBoolean);
  
  void resetAbilityTree();
  
  int getUsedAbilityPoints();
  
  void setUsedAbilityPoints(int paramInt);
  
  int getUsuableAbilityPoints();
  
  void resetAbilityPoints();
  
  Multimap<String, AttributeModifier> getAttributeKBResist();
  
  void addAbilityTreeAbility(WereAbility paramWereAbility);
  
  int getAbilityPoints();
  
  int getAttributePoints();
  
  boolean getScentTracking();
  
  void setScentTracking(boolean paramBoolean);
  
  HashMap<Class<? extends Entity>, Integer> getScentTree();
  
  int getScentColor(Class<? extends Entity> paramClass);
  
  void setScentColor(Class<? extends Entity> paramClass, int paramInt);
  
  int getSprintRam();
  
  void setSprintRam(int paramInt);
  
  int getInclinationType();
  
  void setInclinationType(int paramInt);
  
  String getInclinationTitle();
  
  void addAbilityTreeAbilityWithoutAP(WereAbility paramWereAbility);
  
  int getCDHowl();
  
  void deincCDHowl();
  
  void resetCDHowl();
  
  boolean getMoonTransformation();
  
  void setMoonTransformation(boolean paramBoolean);
  
  int getBerserkLevel();
  
  void setBerserkLevel(int paramInt);
  
  void deincCDBerserk();
  
  void resetCDBerserk();
}


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\IWerewolfCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */