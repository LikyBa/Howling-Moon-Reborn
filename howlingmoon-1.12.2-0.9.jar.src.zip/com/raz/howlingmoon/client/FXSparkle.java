/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXSparkle
/*     */   extends Particle
/*     */ {
/*  22 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/particles/scent.png");
/*     */   
/*  24 */   private static final Queue<FXSparkle> queuedRenders = new ArrayDeque<>();
/*     */   
/*     */   private float f;
/*     */   
/*     */   private float f1;
/*     */   private float f2;
/*     */   private float f3;
/*     */   private float f4;
/*     */   private float f5;
/*     */   
/*     */   public FXSparkle(World world, double d, double d1, double d2, float size, float red, float green, float blue, int maxAge) {
/*  35 */     super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
/*  36 */     this.field_70552_h = red;
/*  37 */     this.field_70553_i = green;
/*  38 */     this.field_70551_j = blue;
/*  39 */     this.field_82339_as = 0.5F;
/*  40 */     this.field_70545_g = 0.0F;
/*  41 */     this.field_187129_i = this.field_187130_j = this.field_187131_k = 0.0D;
/*  42 */     this.field_70544_f *= size;
/*  43 */     this.field_70547_e = maxAge;
/*     */     
/*  45 */     func_187115_a(0.01F, 0.01F);
/*     */     
/*  47 */     this.field_187123_c = this.field_187126_f;
/*  48 */     this.field_187124_d = this.field_187127_g;
/*  49 */     this.field_187125_e = this.field_187128_h;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void dispatchQueuedRenders(Tessellator tessellator) {
/*  54 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.75F);
/*  55 */     (Minecraft.func_71410_x()).field_71446_o.func_110577_a(texture);
/*     */     
/*  57 */     if (!queuedRenders.isEmpty()) {
/*  58 */       tessellator.func_178180_c().func_181668_a(7, DefaultVertexFormats.field_181711_k);
/*  59 */       for (FXSparkle sparkle : queuedRenders)
/*  60 */         sparkle.renderQueued(tessellator); 
/*  61 */       tessellator.func_78381_a();
/*     */     } 
/*     */     
/*  64 */     queuedRenders.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderQueued(Tessellator tessellator) {
/*  69 */     float f10 = 0.5F * this.field_70544_f;
/*  70 */     float f11 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * this.f - field_70556_an);
/*  71 */     float f12 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * this.f - field_70554_ao);
/*  72 */     float f13 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * this.f - field_70555_ap);
/*  73 */     int combined = 15728880;
/*  74 */     int k3 = combined >> 16 & 0xFFFF;
/*  75 */     int l3 = combined & 0xFFFF;
/*  76 */     tessellator.func_178180_c().func_181662_b((f11 - this.f1 * f10 - this.f4 * f10), (f12 - this.f2 * f10), (f13 - this.f3 * f10 - this.f5 * f10)).func_187315_a(0.0D, 1.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 0.5F).func_181675_d();
/*  77 */     tessellator.func_178180_c().func_181662_b((f11 - this.f1 * f10 + this.f4 * f10), (f12 + this.f2 * f10), (f13 - this.f3 * f10 + this.f5 * f10)).func_187315_a(1.0D, 1.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 0.5F).func_181675_d();
/*  78 */     tessellator.func_178180_c().func_181662_b((f11 + this.f1 * f10 + this.f4 * f10), (f12 + this.f2 * f10), (f13 + this.f3 * f10 + this.f5 * f10)).func_187315_a(1.0D, 0.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 0.5F).func_181675_d();
/*  79 */     tessellator.func_178180_c().func_181662_b((f11 + this.f1 * f10 - this.f4 * f10), (f12 - this.f2 * f10), (f13 + this.f3 * f10 - this.f5 * f10)).func_187315_a(0.0D, 0.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, 0.5F).func_181675_d();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180434_a(BufferBuilder wr, Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/*  84 */     this.f = f;
/*  85 */     this.f1 = f1;
/*  86 */     this.f2 = f2;
/*  87 */     this.f3 = f3;
/*  88 */     this.f4 = f4;
/*  89 */     this.f5 = f5;
/*     */     
/*  91 */     queuedRenders.add(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_189213_a() {
/*  96 */     this.field_187123_c = this.field_187126_f;
/*  97 */     this.field_187124_d = this.field_187127_g;
/*  98 */     this.field_187125_e = this.field_187128_h;
/*     */     
/* 100 */     if (this.field_70546_d++ >= this.field_70547_e) {
/* 101 */       func_187112_i();
/*     */     }
/* 103 */     this.field_187126_f += this.field_187129_i;
/* 104 */     this.field_187127_g += this.field_187130_j;
/* 105 */     this.field_187128_h += this.field_187131_k;
/* 106 */     this.field_187129_i *= 0.9800000190734863D;
/* 107 */     this.field_187130_j *= 0.9800000190734863D;
/* 108 */     this.field_187131_k *= 0.9800000190734863D;
/*     */   }
/*     */   
/*     */   public void setGravity(float value) {
/* 112 */     this.field_70545_g = value;
/*     */   }
/*     */   
/*     */   public void setSpeed(float mx, float my, float mz) {
/* 116 */     this.field_187129_i = mx;
/* 117 */     this.field_187130_j = my;
/* 118 */     this.field_187131_k = mz;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\FXSparkle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */