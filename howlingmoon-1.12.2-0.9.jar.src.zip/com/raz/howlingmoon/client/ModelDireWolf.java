/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelDireWolf
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer wolfHeadMain;
/*     */   public ModelRenderer wolfBody;
/*     */   public ModelRenderer wolfLeg1;
/*     */   public ModelRenderer wolfLeg2;
/*     */   public ModelRenderer wolfLeg3;
/*     */   public ModelRenderer wolfLeg4;
/*     */   ModelRenderer wolfTail;
/*     */   ModelRenderer wolfMane;
/*     */   public int heldItemLeft;
/*     */   public int heldItemRight;
/*     */   public boolean isSneak;
/*     */   
/*     */   public ModelDireWolf() {
/*  40 */     float f = 0.0F;
/*  41 */     float f1 = 13.5F;
/*  42 */     this.wolfHeadMain = new ModelRenderer(this, 0, 65);
/*  43 */     this.wolfHeadMain.func_78790_a(-3.0F, -3.0F, -2.0F, 6, 6, 4, f);
/*  44 */     this.wolfHeadMain.func_78793_a(-1.0F, f1, -7.0F);
/*  45 */     this.wolfBody = new ModelRenderer(this, 18, 79);
/*  46 */     this.wolfBody.func_78790_a(-4.0F, -2.0F, -3.0F, 6, 9, 6, f);
/*  47 */     this.wolfBody.func_78793_a(0.0F, 14.0F, 2.0F);
/*  48 */     this.wolfMane = new ModelRenderer(this, 21, 65);
/*  49 */     this.wolfMane.func_78790_a(-4.0F, -3.0F, -3.0F, 8, 6, 7, f);
/*  50 */     this.wolfMane.func_78793_a(-1.0F, 14.0F, -3.0F);
/*  51 */     this.wolfLeg1 = new ModelRenderer(this, 0, 83);
/*  52 */     this.wolfLeg1.func_78790_a(-1.0F, 0.0F, -1.0F, 2, 8, 2, f);
/*  53 */     this.wolfLeg1.func_78793_a(-2.5F, 16.0F, 7.0F);
/*  54 */     this.wolfLeg2 = new ModelRenderer(this, 0, 83);
/*  55 */     this.wolfLeg2.func_78790_a(-1.0F, 0.0F, -1.0F, 2, 8, 2, f);
/*  56 */     this.wolfLeg2.func_78793_a(0.5F, 16.0F, 7.0F);
/*  57 */     this.wolfLeg3 = new ModelRenderer(this, 0, 83);
/*  58 */     this.wolfLeg3.func_78790_a(-1.0F, 0.0F, -1.0F, 2, 8, 2, f);
/*  59 */     this.wolfLeg3.func_78793_a(-2.5F, 16.0F, -4.0F);
/*  60 */     this.wolfLeg4 = new ModelRenderer(this, 0, 83);
/*  61 */     this.wolfLeg4.func_78790_a(-1.0F, 0.0F, -1.0F, 2, 8, 2, f);
/*  62 */     this.wolfLeg4.func_78793_a(0.5F, 16.0F, -4.0F);
/*  63 */     this.wolfTail = new ModelRenderer(this, 9, 83);
/*  64 */     this.wolfTail.func_78790_a(-1.0F, 0.0F, -1.0F, 2, 8, 2, f);
/*  65 */     this.wolfTail.func_78793_a(-1.0F, 12.0F, 8.0F);
/*  66 */     this.wolfHeadMain.func_78784_a(16, 79).func_78790_a(-3.0F, -5.0F, 0.0F, 2, 2, 1, f);
/*  67 */     this.wolfHeadMain.func_78784_a(16, 79).func_78790_a(1.0F, -5.0F, 0.0F, 2, 2, 1, f);
/*  68 */     this.wolfHeadMain.func_78784_a(0, 75).func_78790_a(-1.5F, 0.0F, -5.0F, 3, 3, 4, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity p_78088_1_, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_, float p_78088_6_, float p_78088_7_) {
/*  76 */     super.func_78088_a(p_78088_1_, p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, p_78088_7_);
/*  77 */     func_78087_a(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, p_78088_7_, p_78088_1_);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.wolfHeadMain.func_78791_b(p_78088_7_);
/*  85 */     this.wolfBody.func_78785_a(p_78088_7_);
/*  86 */     this.wolfLeg1.func_78785_a(p_78088_7_);
/*  87 */     this.wolfLeg2.func_78785_a(p_78088_7_);
/*  88 */     this.wolfLeg3.func_78785_a(p_78088_7_);
/*  89 */     this.wolfLeg4.func_78785_a(p_78088_7_);
/*  90 */     this.wolfTail.func_78785_a(p_78088_7_);
/*     */     
/*  92 */     this.wolfMane.func_78785_a(p_78088_7_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78087_a(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_, float p_78087_5_, float p_78087_6_, Entity p_78087_7_) {
/* 103 */     super.func_78087_a(p_78087_1_, p_78087_2_, p_78087_3_, p_78087_4_, p_78087_5_, p_78087_6_, p_78087_7_);
/* 104 */     this.wolfHeadMain.field_78795_f = p_78087_5_ / 57.295776F;
/* 105 */     this.wolfHeadMain.field_78796_g = p_78087_4_ / 57.295776F;
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.wolfBody.field_78795_f = 1.5707964F;
/*     */     
/* 111 */     this.wolfMane.field_78795_f = this.wolfBody.field_78795_f;
/*     */     
/* 113 */     this.wolfTail.field_78795_f = -5.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.wolfLeg1.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F) * 1.4F * p_78087_2_;
/* 119 */     this.wolfLeg2.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F + 3.1415927F) * 1.4F * p_78087_2_;
/* 120 */     this.wolfLeg3.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F + 3.1415927F) * 1.4F * p_78087_2_;
/* 121 */     this.wolfLeg4.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F) * 1.4F * p_78087_2_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_178686_a(ModelBase model) {
/* 128 */     super.func_178686_a(model);
/*     */     
/* 130 */     if (model instanceof ModelDireWolf) {
/*     */       
/* 132 */       ModelDireWolf modelbiped = (ModelDireWolf)model;
/* 133 */       this.heldItemLeft = modelbiped.heldItemLeft;
/* 134 */       this.heldItemRight = modelbiped.heldItemRight;
/* 135 */       this.isSneak = modelbiped.isSneak;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postRenderArm(float scale, EnumHandSide side) {
/* 142 */     getArmForSide(side).func_78794_c(scale);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ModelRenderer getArmForSide(EnumHandSide side) {
/* 147 */     return (side == EnumHandSide.LEFT) ? this.wolfTail : this.wolfHeadMain;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumHandSide getMainHand(Entity entityIn) {
/* 152 */     return (entityIn instanceof EntityLivingBase) ? ((EntityLivingBase)entityIn).func_184591_cq() : EnumHandSide.RIGHT;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\ModelDireWolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */