/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityWerewolf;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderLiving;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class RenderWerewolf extends RenderLiving {
/*    */   protected ResourceLocation texture;
/*    */   protected ResourceLocation textureBlack;
/*    */   protected ResourceLocation textureRed;
/*    */   protected ResourceLocation textureTimber;
/*    */   protected ResourceLocation textureKillerwolf;
/*    */   
/*    */   public RenderWerewolf(RenderManager renderManager) {
/* 19 */     super(renderManager, (ModelBase)new ModelWerewolf(), 0.5F);
/* 20 */     setEntityTexture();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_77041_b(EntityLivingBase entity, float f) {
/* 26 */     preRenderCallbackWerewolf((EntityWerewolf)entity, f);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void preRenderCallbackWerewolf(EntityWerewolf entity, float f) {}
/*    */ 
/*    */   
/*    */   protected void setEntityTexture() {
/* 35 */     this.texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/* 36 */     this.textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/*    */     
/* 38 */     this.textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/* 39 */     this.textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 45 */     int temp = ((EntityWerewolf)entity).getFurColor();
/* 46 */     switch (temp) {
/*    */       case 0:
/* 48 */         return this.texture;
/* 49 */       case 1: return this.textureBlack;
/* 50 */       case 2: return this.textureTimber;
/* 51 */       case 3: return this.textureKillerwolf;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */