/*     */ package com.raz.howlingmoon.client;
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.RenderItem;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumBlockRenderType;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.storage.MapData;
/*     */ import net.minecraftforge.client.ForgeHooksClient;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ItemRendererWerewolf {
/*  47 */   private static final ResourceLocation wolfTexture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/*  48 */   private static final ResourceLocation textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/*     */   
/*  50 */   private static final ResourceLocation textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/*  51 */   private static final ResourceLocation textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*     */   
/*  53 */   private static final ResourceLocation RES_MAP_BACKGROUND = new ResourceLocation("textures/map/map_background.png");
/*  54 */   private static final ResourceLocation RES_UNDERWATER_OVERLAY = new ResourceLocation("textures/misc/underwater.png");
/*     */   
/*     */   private final Minecraft mc;
/*  57 */   private ItemStack itemStackMainHand = ItemStack.field_190927_a;
/*  58 */   private ItemStack itemStackOffHand = ItemStack.field_190927_a;
/*     */   
/*     */   private float equippedProgressMainHand;
/*     */   private float prevEquippedProgressMainHand;
/*     */   private float equippedProgressOffHand;
/*     */   private float prevEquippedProgressOffHand;
/*     */   private RenderManager renderManager;
/*     */   private RenderItem itemRenderer;
/*     */   private RenderWerewolfPlayer renderHand;
/*     */   
/*     */   public ItemRendererWerewolf(Minecraft mcIn) {
/*  69 */     this.mc = mcIn;
/*  70 */     this.renderManager = mcIn.func_175598_ae();
/*  71 */     this.itemRenderer = mcIn.func_175599_af();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderItem(EntityLivingBase entityIn, ItemStack heldStack, ItemCameraTransforms.TransformType transform) {
/*  76 */     renderItemSide(entityIn, heldStack, transform, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderItemSide(EntityLivingBase entitylivingbaseIn, ItemStack heldStack, ItemCameraTransforms.TransformType transform, boolean p_187462_4_) {
/*  81 */     if (heldStack != null) {
/*     */       
/*  83 */       Item item = heldStack.func_77973_b();
/*  84 */       Block block = Block.func_149634_a(item);
/*  85 */       GlStateManager.func_179094_E();
/*     */       
/*  87 */       if (this.itemRenderer == null) {
/*  88 */         this.itemRenderer = Minecraft.func_71410_x().func_175599_af();
/*     */       }
/*  90 */       boolean flag = (this.itemRenderer.func_175050_a(heldStack) && isBlockTranslucent(block));
/*     */       
/*  92 */       if (flag)
/*     */       {
/*  94 */         GlStateManager.func_179132_a(false);
/*     */       }
/*     */       
/*  97 */       this.itemRenderer.func_184392_a(heldStack, entitylivingbaseIn, transform, p_187462_4_);
/*     */       
/*  99 */       if (flag)
/*     */       {
/* 101 */         GlStateManager.func_179132_a(true);
/*     */       }
/*     */       
/* 104 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isBlockTranslucent(@Nullable Block blockIn) {
/* 113 */     return (blockIn != null && blockIn.func_180664_k() == BlockRenderLayer.TRANSLUCENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rotateArroundXAndY(float angle, float angleY) {
/* 121 */     GlStateManager.func_179094_E();
/* 122 */     GlStateManager.func_179114_b(angle, 1.0F, 0.0F, 0.0F);
/* 123 */     GlStateManager.func_179114_b(angleY, 0.0F, 1.0F, 0.0F);
/* 124 */     RenderHelper.func_74519_b();
/* 125 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */   
/*     */   private void setLightmap() {
/* 130 */     EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/* 131 */     int i = this.mc.field_71441_e.func_175626_b(new BlockPos(((AbstractClientPlayer)entityPlayerSP).field_70165_t, ((AbstractClientPlayer)entityPlayerSP).field_70163_u + entityPlayerSP.func_70047_e(), ((AbstractClientPlayer)entityPlayerSP).field_70161_v), 0);
/* 132 */     float f = (i & 0xFFFF);
/* 133 */     float f1 = (i >> 16);
/* 134 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, f, f1);
/*     */   }
/*     */ 
/*     */   
/*     */   private void rotateArm(float p_187458_1_) {
/* 139 */     EntityPlayerSP entityplayersp = this.mc.field_71439_g;
/* 140 */     float f = entityplayersp.field_71164_i + (entityplayersp.field_71155_g - entityplayersp.field_71164_i) * p_187458_1_;
/* 141 */     float f1 = entityplayersp.field_71163_h + (entityplayersp.field_71154_f - entityplayersp.field_71163_h) * p_187458_1_;
/* 142 */     GlStateManager.func_179114_b((entityplayersp.field_70125_A - f) * 0.1F, 1.0F, 0.0F, 0.0F);
/* 143 */     GlStateManager.func_179114_b((entityplayersp.field_70177_z - f1) * 0.1F, 0.0F, 1.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float getMapAngleFromPitch(float pitch) {
/* 151 */     float f = 1.0F - pitch / 45.0F + 0.1F;
/* 152 */     f = MathHelper.func_76131_a(f, 0.0F, 1.0F);
/* 153 */     f = -MathHelper.func_76134_b(f * 3.1415927F) * 0.5F + 0.5F;
/* 154 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderArms() {
/* 159 */     if (!this.mc.field_71439_g.func_82150_aj()) {
/*     */       
/* 161 */       GlStateManager.func_179129_p();
/* 162 */       GlStateManager.func_179094_E();
/* 163 */       GlStateManager.func_179114_b(90.0F, 0.0F, 1.0F, 0.0F);
/* 164 */       renderArm(EnumHandSide.RIGHT);
/* 165 */       renderArm(EnumHandSide.LEFT);
/* 166 */       GlStateManager.func_179121_F();
/* 167 */       GlStateManager.func_179089_o();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderArm(EnumHandSide p_187455_1_) {
/* 173 */     this.mc.func_110434_K().func_110577_a(this.mc.field_71439_g.func_110306_p());
/* 174 */     Render<AbstractClientPlayer> render = this.renderManager.func_78713_a((Entity)this.mc.field_71439_g);
/* 175 */     RenderPlayer renderplayer = (RenderPlayer)render;
/* 176 */     GlStateManager.func_179094_E();
/* 177 */     float f = (p_187455_1_ == EnumHandSide.RIGHT) ? 1.0F : -1.0F;
/* 178 */     GlStateManager.func_179114_b(92.0F, 0.0F, 1.0F, 0.0F);
/* 179 */     GlStateManager.func_179114_b(45.0F, 1.0F, 0.0F, 0.0F);
/* 180 */     GlStateManager.func_179114_b(f * -41.0F, 0.0F, 0.0F, 1.0F);
/* 181 */     GlStateManager.func_179109_b(f * 0.3F, -1.1F, 0.45F);
/*     */     
/* 183 */     if (p_187455_1_ == EnumHandSide.RIGHT) {
/*     */       
/* 185 */       renderplayer.func_177138_b((AbstractClientPlayer)this.mc.field_71439_g);
/*     */     }
/*     */     else {
/*     */       
/* 189 */       renderplayer.func_177139_c((AbstractClientPlayer)this.mc.field_71439_g);
/*     */     } 
/*     */     
/* 192 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderMapFirstPersonSide(float p_187465_1_, EnumHandSide p_187465_2_, float p_187465_3_, ItemStack p_187465_4_) {
/* 197 */     float f = (p_187465_2_ == EnumHandSide.RIGHT) ? 1.0F : -1.0F;
/* 198 */     GlStateManager.func_179109_b(f * 0.125F, -0.125F, 0.0F);
/*     */     
/* 200 */     if (!this.mc.field_71439_g.func_82150_aj()) {
/*     */       
/* 202 */       GlStateManager.func_179094_E();
/* 203 */       GlStateManager.func_179114_b(f * 10.0F, 0.0F, 0.0F, 1.0F);
/* 204 */       renderArmFirstPerson(p_187465_1_, p_187465_3_, p_187465_2_);
/* 205 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */     
/* 208 */     GlStateManager.func_179094_E();
/* 209 */     GlStateManager.func_179109_b(f * 0.51F, -0.08F + p_187465_1_ * -1.2F, -0.75F);
/* 210 */     float f1 = MathHelper.func_76129_c(p_187465_3_);
/* 211 */     float f2 = MathHelper.func_76126_a(f1 * 3.1415927F);
/* 212 */     float f3 = -0.5F * f2;
/* 213 */     float f4 = 0.4F * MathHelper.func_76126_a(f1 * 6.2831855F);
/* 214 */     float f5 = -0.3F * MathHelper.func_76126_a(p_187465_3_ * 3.1415927F);
/* 215 */     GlStateManager.func_179109_b(f * f3, f4 - 0.3F * f2, f5);
/* 216 */     GlStateManager.func_179114_b(f2 * -45.0F, 1.0F, 0.0F, 0.0F);
/* 217 */     GlStateManager.func_179114_b(f * f2 * -30.0F, 0.0F, 1.0F, 0.0F);
/* 218 */     renderMapFirstPerson(p_187465_4_);
/* 219 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderMapFirstPerson(float p_187463_1_, float p_187463_2_, float p_187463_3_) {
/* 224 */     float f = MathHelper.func_76129_c(p_187463_3_);
/* 225 */     float f1 = -0.2F * MathHelper.func_76126_a(p_187463_3_ * 3.1415927F);
/* 226 */     float f2 = -0.4F * MathHelper.func_76126_a(f * 3.1415927F);
/* 227 */     GlStateManager.func_179109_b(0.0F, -f1 / 2.0F, f2);
/* 228 */     float f3 = getMapAngleFromPitch(p_187463_1_);
/* 229 */     GlStateManager.func_179109_b(0.0F, 0.04F + p_187463_2_ * -1.2F + f3 * -0.5F, -0.72F);
/* 230 */     GlStateManager.func_179114_b(f3 * -85.0F, 1.0F, 0.0F, 0.0F);
/* 231 */     renderArms();
/* 232 */     float f4 = MathHelper.func_76126_a(f * 3.1415927F);
/* 233 */     GlStateManager.func_179114_b(f4 * 20.0F, 1.0F, 0.0F, 0.0F);
/* 234 */     GlStateManager.func_179152_a(2.0F, 2.0F, 2.0F);
/* 235 */     renderMapFirstPerson(this.itemStackMainHand);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderMapFirstPerson(ItemStack stack) {
/* 240 */     GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
/* 241 */     GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
/* 242 */     GlStateManager.func_179152_a(0.38F, 0.38F, 0.38F);
/* 243 */     GlStateManager.func_179140_f();
/* 244 */     this.mc.func_110434_K().func_110577_a(RES_MAP_BACKGROUND);
/* 245 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 246 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/* 247 */     GlStateManager.func_179109_b(-0.5F, -0.5F, 0.0F);
/* 248 */     GlStateManager.func_179152_a(0.0078125F, 0.0078125F, 0.0078125F);
/* 249 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/* 250 */     vertexbuffer.func_181662_b(-7.0D, 135.0D, 0.0D).func_187315_a(0.0D, 1.0D).func_181675_d();
/* 251 */     vertexbuffer.func_181662_b(135.0D, 135.0D, 0.0D).func_187315_a(1.0D, 1.0D).func_181675_d();
/* 252 */     vertexbuffer.func_181662_b(135.0D, -7.0D, 0.0D).func_187315_a(1.0D, 0.0D).func_181675_d();
/* 253 */     vertexbuffer.func_181662_b(-7.0D, -7.0D, 0.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
/* 254 */     tessellator.func_78381_a();
/* 255 */     MapData mapdata = Items.field_151098_aY.func_77873_a(stack, (World)this.mc.field_71441_e);
/*     */     
/* 257 */     if (mapdata != null)
/*     */     {
/* 259 */       this.mc.field_71460_t.func_147701_i().func_148250_a(mapdata, false);
/*     */     }
/*     */     
/* 262 */     GlStateManager.func_179145_e();
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderArmFirstPerson(float p_187456_1_, float p_187456_2_, EnumHandSide p_187456_3_) {
/* 267 */     boolean flag = (p_187456_3_ != EnumHandSide.LEFT);
/* 268 */     float f = flag ? 1.0F : -1.0F;
/* 269 */     float f1 = MathHelper.func_76129_c(p_187456_2_);
/* 270 */     float f2 = -0.3F * MathHelper.func_76126_a(f1 * 3.1415927F);
/* 271 */     float f3 = 0.4F * MathHelper.func_76126_a(f1 * 6.2831855F);
/* 272 */     float f4 = -0.4F * MathHelper.func_76126_a(p_187456_2_ * 3.1415927F);
/* 273 */     GlStateManager.func_179109_b(f * (f2 + 0.64000005F), f3 + -0.6F + p_187456_1_ * -0.6F, f4 + -0.71999997F);
/* 274 */     GlStateManager.func_179114_b(f * 45.0F, 0.0F, 1.0F, 0.0F);
/* 275 */     float f5 = MathHelper.func_76126_a(p_187456_2_ * p_187456_2_ * 3.1415927F);
/* 276 */     float f6 = MathHelper.func_76126_a(f1 * 3.1415927F);
/* 277 */     GlStateManager.func_179114_b(f * f6 * 70.0F, 0.0F, 1.0F, 0.0F);
/* 278 */     GlStateManager.func_179114_b(f * f5 * -20.0F, 0.0F, 0.0F, 1.0F);
/* 279 */     EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/* 280 */     this.mc.func_110434_K().func_110577_a(entityPlayerSP.func_110306_p());
/* 281 */     GlStateManager.func_179109_b(f * -1.0F, 3.6F, 3.5F);
/* 282 */     GlStateManager.func_179114_b(f * 120.0F, 0.0F, 0.0F, 1.0F);
/* 283 */     GlStateManager.func_179114_b(200.0F, 1.0F, 0.0F, 0.0F);
/* 284 */     GlStateManager.func_179114_b(f * -135.0F, 0.0F, 1.0F, 0.0F);
/* 285 */     GlStateManager.func_179109_b(f * 5.6F, 0.0F, 0.0F);
/*     */     
/* 287 */     int temp = ((IWerewolfCapability)entityPlayerSP.getCapability(WereEventHandler.WERE_CAP, null)).getTexture();
/* 288 */     switch (temp) {
/*     */       
/*     */       case 0:
/* 291 */         this.mc.field_71446_o.func_110577_a(wolfTexture);
/*     */         break;
/*     */       case 1:
/* 294 */         this.mc.field_71446_o.func_110577_a(textureBlack);
/*     */         break;
/*     */       case 2:
/* 297 */         this.mc.field_71446_o.func_110577_a(textureTimber);
/*     */         break;
/*     */       case 3:
/* 300 */         this.mc.field_71446_o.func_110577_a(textureKillerwolf);
/*     */         break;
/*     */       default:
/* 303 */         if (CustomWerewolfTextures.textureCount >= temp - 3) {
/*     */           
/* 305 */           this.mc.field_71446_o.func_110577_a(CustomWerewolfTextures.customTextures.get(temp - 4));
/*     */           break;
/*     */         } 
/* 308 */         this.mc.field_71446_o.func_110577_a(wolfTexture); break;
/*     */     } 
/* 310 */     if (this.renderManager == null)
/* 311 */       this.renderManager = this.mc.func_175598_ae(); 
/* 312 */     if (this.renderHand == null)
/* 313 */       this.renderHand = new RenderWerewolfPlayer(Minecraft.func_71410_x().func_175598_ae()); 
/* 314 */     RenderWerewolfPlayer renderplayer = this.renderHand;
/*     */ 
/*     */     
/* 317 */     GlStateManager.func_179129_p();
/*     */     
/* 319 */     if (flag) {
/*     */       
/* 321 */       renderplayer.renderRightArm((AbstractClientPlayer)entityPlayerSP);
/*     */     }
/*     */     else {
/*     */       
/* 325 */       renderplayer.renderLeftArm((AbstractClientPlayer)entityPlayerSP);
/*     */     } 
/*     */     
/* 328 */     GlStateManager.func_179089_o();
/*     */   }
/*     */ 
/*     */   
/*     */   private void transformEatFirstPerson(float p_187454_1_, EnumHandSide p_187454_2_, ItemStack p_187454_3_) {
/* 333 */     float f = this.mc.field_71439_g.func_184605_cv() - p_187454_1_ + 1.0F;
/* 334 */     float f1 = f / p_187454_3_.func_77988_m();
/*     */     
/* 336 */     if (f1 < 0.8F) {
/*     */       
/* 338 */       float f2 = MathHelper.func_76135_e(MathHelper.func_76134_b(f / 4.0F * 3.1415927F) * 0.1F);
/* 339 */       GlStateManager.func_179109_b(0.0F, f2, 0.0F);
/*     */     } 
/*     */     
/* 342 */     float f3 = 1.0F - (float)Math.pow(f1, 27.0D);
/* 343 */     int i = (p_187454_2_ == EnumHandSide.RIGHT) ? 1 : -1;
/* 344 */     GlStateManager.func_179109_b(f3 * 0.6F * i, f3 * -0.5F, f3 * 0.0F);
/* 345 */     GlStateManager.func_179114_b(i * f3 * 90.0F, 0.0F, 1.0F, 0.0F);
/* 346 */     GlStateManager.func_179114_b(f3 * 10.0F, 1.0F, 0.0F, 0.0F);
/* 347 */     GlStateManager.func_179114_b(i * f3 * 30.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   private void transformFirstPerson(EnumHandSide p_187453_1_, float p_187453_2_) {
/* 352 */     int i = (p_187453_1_ == EnumHandSide.RIGHT) ? 1 : -1;
/* 353 */     float f = MathHelper.func_76126_a(p_187453_2_ * p_187453_2_ * 3.1415927F);
/* 354 */     GlStateManager.func_179114_b(i * (45.0F + f * -20.0F), 0.0F, 1.0F, 0.0F);
/* 355 */     float f1 = MathHelper.func_76126_a(MathHelper.func_76129_c(p_187453_2_) * 3.1415927F);
/* 356 */     GlStateManager.func_179114_b(i * f1 * -20.0F, 0.0F, 0.0F, 1.0F);
/* 357 */     GlStateManager.func_179114_b(f1 * -80.0F, 1.0F, 0.0F, 0.0F);
/* 358 */     GlStateManager.func_179114_b(i * -45.0F, 0.0F, 1.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   private void transformSideFirstPerson(EnumHandSide p_187459_1_, float p_187459_2_) {
/* 363 */     int i = (p_187459_1_ == EnumHandSide.RIGHT) ? 1 : -1;
/* 364 */     GlStateManager.func_179109_b(i * 0.56F, -0.52F + p_187459_2_ * -0.6F, -0.72F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderItemInFirstPerson(float partialTicks) {
/* 372 */     EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/* 373 */     float f = entityPlayerSP.func_70678_g(partialTicks);
/* 374 */     EnumHand enumhand = (EnumHand)MoreObjects.firstNonNull(((AbstractClientPlayer)entityPlayerSP).field_184622_au, EnumHand.MAIN_HAND);
/* 375 */     float f1 = ((AbstractClientPlayer)entityPlayerSP).field_70127_C + (((AbstractClientPlayer)entityPlayerSP).field_70125_A - ((AbstractClientPlayer)entityPlayerSP).field_70127_C) * partialTicks;
/* 376 */     float f2 = ((AbstractClientPlayer)entityPlayerSP).field_70126_B + (((AbstractClientPlayer)entityPlayerSP).field_70177_z - ((AbstractClientPlayer)entityPlayerSP).field_70126_B) * partialTicks;
/* 377 */     boolean flag = true;
/* 378 */     boolean flag1 = true;
/*     */     
/* 380 */     if (entityPlayerSP.func_184587_cr()) {
/*     */       
/* 382 */       ItemStack itemstack = entityPlayerSP.func_184607_cu();
/*     */       
/* 384 */       if (itemstack != null && itemstack.func_77973_b() == Items.field_151031_f) {
/*     */         
/* 386 */         EnumHand enumhand1 = entityPlayerSP.func_184600_cs();
/* 387 */         flag = (enumhand1 == EnumHand.MAIN_HAND);
/* 388 */         flag1 = !flag;
/*     */       } 
/*     */     } 
/*     */     
/* 392 */     rotateArroundXAndY(f1, f2);
/* 393 */     setLightmap();
/* 394 */     rotateArm(partialTicks);
/* 395 */     GlStateManager.func_179091_B();
/*     */     
/* 397 */     if (flag) {
/*     */       
/* 399 */       float f3 = (enumhand == EnumHand.MAIN_HAND) ? f : 0.0F;
/* 400 */       float f5 = 1.0F - this.prevEquippedProgressMainHand + (this.equippedProgressMainHand - this.prevEquippedProgressMainHand) * partialTicks;
/* 401 */       renderItemInFirstPerson((AbstractClientPlayer)entityPlayerSP, partialTicks, f1, EnumHand.MAIN_HAND, f3, this.itemStackMainHand, f5);
/*     */     } 
/*     */     
/* 404 */     if (flag1) {
/*     */       
/* 406 */       float f4 = (enumhand == EnumHand.OFF_HAND) ? f : 0.0F;
/* 407 */       float f6 = 1.0F - this.prevEquippedProgressOffHand + (this.equippedProgressOffHand - this.prevEquippedProgressOffHand) * partialTicks;
/* 408 */       renderItemInFirstPerson((AbstractClientPlayer)entityPlayerSP, partialTicks, f1, EnumHand.OFF_HAND, f4, this.itemStackOffHand, f6);
/*     */     } 
/*     */     
/* 411 */     GlStateManager.func_179101_C();
/* 412 */     RenderHelper.func_74518_a();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderItemInFirstPerson(AbstractClientPlayer p_187457_1_, float p_187457_2_, float p_187457_3_, EnumHand p_187457_4_, float p_187457_5_, ItemStack p_187457_6_, float p_187457_7_) {
/* 417 */     boolean flag = (p_187457_4_ == EnumHand.MAIN_HAND);
/* 418 */     EnumHandSide enumhandside = flag ? p_187457_1_.func_184591_cq() : p_187457_1_.func_184591_cq().func_188468_a();
/* 419 */     GlStateManager.func_179094_E();
/*     */     
/* 421 */     if (p_187457_6_.func_190926_b()) {
/*     */       
/* 423 */       if (flag && !p_187457_1_.func_82150_aj())
/*     */       {
/* 425 */         renderArmFirstPerson(p_187457_7_, p_187457_5_, enumhandside);
/*     */       }
/*     */     }
/* 428 */     else if (p_187457_6_.func_77973_b() instanceof net.minecraft.item.ItemMap) {
/*     */       
/* 430 */       if (flag && this.itemStackOffHand.func_190926_b())
/*     */       {
/* 432 */         renderMapFirstPerson(p_187457_3_, p_187457_7_, p_187457_5_);
/*     */       }
/*     */       else
/*     */       {
/* 436 */         renderMapFirstPersonSide(p_187457_7_, enumhandside, p_187457_5_, p_187457_6_);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 441 */       boolean flag1 = (enumhandside == EnumHandSide.RIGHT);
/*     */       
/* 443 */       if (p_187457_1_.func_184587_cr() && p_187457_1_.func_184605_cv() > 0 && p_187457_1_.func_184600_cs() == p_187457_4_) {
/*     */         float f5, f6;
/* 445 */         int j = flag1 ? 1 : -1;
/*     */         
/* 447 */         switch (p_187457_6_.func_77975_n()) {
/*     */           
/*     */           case NONE:
/* 450 */             transformSideFirstPerson(enumhandside, p_187457_7_);
/*     */             break;
/*     */           case EAT:
/*     */           case DRINK:
/* 454 */             transformEatFirstPerson(p_187457_2_, enumhandside, p_187457_6_);
/* 455 */             transformSideFirstPerson(enumhandside, p_187457_7_);
/*     */             break;
/*     */           case BLOCK:
/* 458 */             transformSideFirstPerson(enumhandside, p_187457_7_);
/*     */             break;
/*     */           case BOW:
/* 461 */             transformSideFirstPerson(enumhandside, p_187457_7_);
/* 462 */             GlStateManager.func_179109_b(j * -0.2785682F, 0.18344387F, 0.15731531F);
/* 463 */             GlStateManager.func_179114_b(-13.935F, 1.0F, 0.0F, 0.0F);
/* 464 */             GlStateManager.func_179114_b(j * 35.3F, 0.0F, 1.0F, 0.0F);
/* 465 */             GlStateManager.func_179114_b(j * -9.785F, 0.0F, 0.0F, 1.0F);
/* 466 */             f5 = p_187457_6_.func_77988_m() - this.mc.field_71439_g.func_184605_cv() - p_187457_2_ + 1.0F;
/* 467 */             f6 = f5 / 20.0F;
/* 468 */             f6 = (f6 * f6 + f6 * 2.0F) / 3.0F;
/*     */             
/* 470 */             if (f6 > 1.0F)
/*     */             {
/* 472 */               f6 = 1.0F;
/*     */             }
/*     */             
/* 475 */             if (f6 > 0.1F) {
/*     */               
/* 477 */               float f7 = MathHelper.func_76126_a((f5 - 0.1F) * 1.3F);
/* 478 */               float f3 = f6 - 0.1F;
/* 479 */               float f4 = f7 * f3;
/* 480 */               GlStateManager.func_179109_b(f4 * 0.0F, f4 * 0.004F, f4 * 0.0F);
/*     */             } 
/*     */             
/* 483 */             GlStateManager.func_179109_b(f6 * 0.0F, f6 * 0.0F, f6 * 0.04F);
/* 484 */             GlStateManager.func_179152_a(1.0F, 1.0F, 1.0F + f6 * 0.2F);
/* 485 */             GlStateManager.func_179114_b(j * 45.0F, 0.0F, -1.0F, 0.0F);
/*     */             break;
/*     */         } 
/*     */       
/*     */       } else {
/* 490 */         float f = -0.4F * MathHelper.func_76126_a(MathHelper.func_76129_c(p_187457_5_) * 3.1415927F);
/* 491 */         float f1 = 0.2F * MathHelper.func_76126_a(MathHelper.func_76129_c(p_187457_5_) * 6.2831855F);
/* 492 */         float f2 = -0.2F * MathHelper.func_76126_a(p_187457_5_ * 3.1415927F);
/* 493 */         int i = flag1 ? 1 : -1;
/* 494 */         GlStateManager.func_179109_b(i * f, f1, f2);
/* 495 */         transformSideFirstPerson(enumhandside, p_187457_7_);
/* 496 */         transformFirstPerson(enumhandside, p_187457_5_);
/*     */       } 
/*     */       
/* 499 */       renderItemSide((EntityLivingBase)p_187457_1_, p_187457_6_, flag1 ? ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND : ItemCameraTransforms.TransformType.FIRST_PERSON_LEFT_HAND, !flag1);
/*     */     } 
/*     */     
/* 502 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderOverlays(float partialTicks) {
/* 510 */     GlStateManager.func_179118_c();
/*     */     
/* 512 */     if (this.mc.field_71439_g.func_70094_T()) {
/*     */       
/* 514 */       IBlockState iblockstate = this.mc.field_71441_e.func_180495_p(new BlockPos((Entity)this.mc.field_71439_g));
/* 515 */       BlockPos overlayPos = new BlockPos((Entity)this.mc.field_71439_g);
/* 516 */       EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/*     */       
/* 518 */       for (int i = 0; i < 8; i++) {
/*     */         
/* 520 */         double d0 = ((EntityPlayer)entityPlayerSP).field_70165_t + ((((i >> 0) % 2) - 0.5F) * ((EntityPlayer)entityPlayerSP).field_70130_N * 0.8F);
/* 521 */         double d1 = ((EntityPlayer)entityPlayerSP).field_70163_u + ((((i >> 1) % 2) - 0.5F) * 0.1F);
/* 522 */         double d2 = ((EntityPlayer)entityPlayerSP).field_70161_v + ((((i >> 2) % 2) - 0.5F) * ((EntityPlayer)entityPlayerSP).field_70130_N * 0.8F);
/* 523 */         BlockPos blockpos = new BlockPos(d0, d1 + entityPlayerSP.func_70047_e(), d2);
/* 524 */         IBlockState iblockstate1 = this.mc.field_71441_e.func_180495_p(blockpos);
/*     */         
/* 526 */         if (iblockstate1.func_191058_s()) {
/*     */           
/* 528 */           iblockstate = iblockstate1;
/* 529 */           overlayPos = blockpos;
/*     */         } 
/*     */       } 
/*     */       
/* 533 */       if (iblockstate.func_185901_i() != EnumBlockRenderType.INVISIBLE)
/*     */       {
/* 535 */         if (!ForgeEventFactory.renderBlockOverlay((EntityPlayer)this.mc.field_71439_g, partialTicks, RenderBlockOverlayEvent.OverlayType.BLOCK, iblockstate, overlayPos)) {
/* 536 */           renderBlockInHand(partialTicks, this.mc.func_175602_ab().func_175023_a().func_178122_a(iblockstate));
/*     */         }
/*     */       }
/*     */     } 
/* 540 */     if (!this.mc.field_71439_g.func_175149_v()) {
/*     */       
/* 542 */       if (this.mc.field_71439_g.func_70055_a(Material.field_151586_h))
/*     */       {
/* 544 */         if (!ForgeEventFactory.renderWaterOverlay((EntityPlayer)this.mc.field_71439_g, partialTicks)) {
/* 545 */           renderWaterOverlayTexture(partialTicks);
/*     */         }
/*     */       }
/* 548 */       if (this.mc.field_71439_g.func_70027_ad())
/*     */       {
/* 550 */         if (!ForgeEventFactory.renderFireOverlay((EntityPlayer)this.mc.field_71439_g, partialTicks)) {
/* 551 */           renderFireInFirstPerson(partialTicks);
/*     */         }
/*     */       }
/*     */     } 
/* 555 */     GlStateManager.func_179141_d();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderBlockInHand(float partialTicks, TextureAtlasSprite atlas) {
/* 563 */     this.mc.func_110434_K().func_110577_a(TextureMap.field_110575_b);
/* 564 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 565 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/* 566 */     float f = 0.1F;
/* 567 */     GlStateManager.func_179131_c(0.1F, 0.1F, 0.1F, 0.5F);
/* 568 */     GlStateManager.func_179094_E();
/* 569 */     float f1 = -1.0F;
/* 570 */     float f2 = 1.0F;
/* 571 */     float f3 = -1.0F;
/* 572 */     float f4 = 1.0F;
/* 573 */     float f5 = -0.5F;
/* 574 */     float f6 = atlas.func_94209_e();
/* 575 */     float f7 = atlas.func_94212_f();
/* 576 */     float f8 = atlas.func_94206_g();
/* 577 */     float f9 = atlas.func_94210_h();
/* 578 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/* 579 */     vertexbuffer.func_181662_b(-1.0D, -1.0D, -0.5D).func_187315_a(f7, f9).func_181675_d();
/* 580 */     vertexbuffer.func_181662_b(1.0D, -1.0D, -0.5D).func_187315_a(f6, f9).func_181675_d();
/* 581 */     vertexbuffer.func_181662_b(1.0D, 1.0D, -0.5D).func_187315_a(f6, f8).func_181675_d();
/* 582 */     vertexbuffer.func_181662_b(-1.0D, 1.0D, -0.5D).func_187315_a(f7, f8).func_181675_d();
/* 583 */     tessellator.func_78381_a();
/* 584 */     GlStateManager.func_179121_F();
/* 585 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderWaterOverlayTexture(float partialTicks) {
/* 594 */     this.mc.func_110434_K().func_110577_a(RES_UNDERWATER_OVERLAY);
/* 595 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 596 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/* 597 */     float f = this.mc.field_71439_g.func_70013_c();
/* 598 */     GlStateManager.func_179131_c(f, f, f, 0.5F);
/* 599 */     GlStateManager.func_179147_l();
/* 600 */     GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 601 */     GlStateManager.func_179094_E();
/* 602 */     float f1 = 4.0F;
/* 603 */     float f2 = -1.0F;
/* 604 */     float f3 = 1.0F;
/* 605 */     float f4 = -1.0F;
/* 606 */     float f5 = 1.0F;
/* 607 */     float f6 = -0.5F;
/* 608 */     float f7 = -this.mc.field_71439_g.field_70177_z / 64.0F;
/* 609 */     float f8 = this.mc.field_71439_g.field_70125_A / 64.0F;
/* 610 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/* 611 */     vertexbuffer.func_181662_b(-1.0D, -1.0D, -0.5D).func_187315_a((4.0F + f7), (4.0F + f8)).func_181675_d();
/* 612 */     vertexbuffer.func_181662_b(1.0D, -1.0D, -0.5D).func_187315_a((0.0F + f7), (4.0F + f8)).func_181675_d();
/* 613 */     vertexbuffer.func_181662_b(1.0D, 1.0D, -0.5D).func_187315_a((0.0F + f7), (0.0F + f8)).func_181675_d();
/* 614 */     vertexbuffer.func_181662_b(-1.0D, 1.0D, -0.5D).func_187315_a((4.0F + f7), (0.0F + f8)).func_181675_d();
/* 615 */     tessellator.func_78381_a();
/* 616 */     GlStateManager.func_179121_F();
/* 617 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 618 */     GlStateManager.func_179084_k();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderFireInFirstPerson(float partialTicks) {
/* 626 */     Tessellator tessellator = Tessellator.func_178181_a();
/* 627 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/* 628 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.9F);
/* 629 */     GlStateManager.func_179143_c(519);
/* 630 */     GlStateManager.func_179132_a(false);
/* 631 */     GlStateManager.func_179147_l();
/* 632 */     GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 633 */     float f = 1.0F;
/*     */     
/* 635 */     for (int i = 0; i < 2; i++) {
/*     */       
/* 637 */       GlStateManager.func_179094_E();
/* 638 */       TextureAtlasSprite textureatlassprite = this.mc.func_147117_R().func_110572_b("minecraft:blocks/fire_layer_1");
/* 639 */       this.mc.func_110434_K().func_110577_a(TextureMap.field_110575_b);
/* 640 */       float f1 = textureatlassprite.func_94209_e();
/* 641 */       float f2 = textureatlassprite.func_94212_f();
/* 642 */       float f3 = textureatlassprite.func_94206_g();
/* 643 */       float f4 = textureatlassprite.func_94210_h();
/* 644 */       float f5 = -0.5F;
/* 645 */       float f6 = 0.5F;
/* 646 */       float f7 = -0.5F;
/* 647 */       float f8 = 0.5F;
/* 648 */       float f9 = -0.5F;
/* 649 */       GlStateManager.func_179109_b(-(i * 2 - 1) * 0.24F, -0.3F, 0.0F);
/* 650 */       GlStateManager.func_179114_b((i * 2 - 1) * 10.0F, 0.0F, 1.0F, 0.0F);
/* 651 */       vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/* 652 */       vertexbuffer.func_181662_b(-0.5D, -0.5D, -0.5D).func_187315_a(f2, f4).func_181675_d();
/* 653 */       vertexbuffer.func_181662_b(0.5D, -0.5D, -0.5D).func_187315_a(f1, f4).func_181675_d();
/* 654 */       vertexbuffer.func_181662_b(0.5D, 0.5D, -0.5D).func_187315_a(f1, f3).func_181675_d();
/* 655 */       vertexbuffer.func_181662_b(-0.5D, 0.5D, -0.5D).func_187315_a(f2, f3).func_181675_d();
/* 656 */       tessellator.func_78381_a();
/* 657 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */     
/* 660 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 661 */     GlStateManager.func_179084_k();
/* 662 */     GlStateManager.func_179132_a(true);
/* 663 */     GlStateManager.func_179143_c(515);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateEquippedItem() {
/* 668 */     this.prevEquippedProgressMainHand = this.equippedProgressMainHand;
/* 669 */     this.prevEquippedProgressOffHand = this.equippedProgressOffHand;
/* 670 */     EntityPlayerSP entityplayersp = this.mc.field_71439_g;
/* 671 */     ItemStack itemstack = entityplayersp.func_184614_ca();
/* 672 */     ItemStack itemstack1 = entityplayersp.func_184592_cb();
/*     */     
/* 674 */     if (entityplayersp.func_184838_M()) {
/*     */       
/* 676 */       this.equippedProgressMainHand = MathHelper.func_76131_a(this.equippedProgressMainHand - 0.4F, 0.0F, 1.0F);
/* 677 */       this.equippedProgressOffHand = MathHelper.func_76131_a(this.equippedProgressOffHand - 0.4F, 0.0F, 1.0F);
/*     */     }
/*     */     else {
/*     */       
/* 681 */       float f = entityplayersp.func_184825_o(1.0F);
/* 682 */       this.equippedProgressMainHand += MathHelper.func_76131_a((!ForgeHooksClient.shouldCauseReequipAnimation(this.itemStackMainHand, itemstack, entityplayersp.field_71071_by.field_70461_c) ? (f * f * f) : 0.0F) - this.equippedProgressMainHand, -0.4F, 0.4F);
/* 683 */       this.equippedProgressOffHand += MathHelper.func_76131_a((!ForgeHooksClient.shouldCauseReequipAnimation(this.itemStackOffHand, itemstack1, -1) ? true : false) - this.equippedProgressOffHand, -0.4F, 0.4F);
/*     */     } 
/*     */     
/* 686 */     if (this.equippedProgressMainHand < 0.1F)
/*     */     {
/* 688 */       this.itemStackMainHand = itemstack;
/*     */     }
/*     */     
/* 691 */     if (this.equippedProgressOffHand < 0.1F)
/*     */     {
/* 693 */       this.itemStackOffHand = itemstack1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetEquippedProgress(EnumHand hand) {
/* 699 */     if (hand == EnumHand.MAIN_HAND) {
/*     */       
/* 701 */       this.equippedProgressMainHand = 0.0F;
/*     */     }
/*     */     else {
/*     */       
/* 705 */       this.equippedProgressOffHand = 0.0F;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\ItemRendererWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */