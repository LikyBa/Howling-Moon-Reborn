/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.entities.EntityStun;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class RenderStun
/*     */   extends Render<EntityStun>
/*     */ {
/*  16 */   private static final ResourceLocation stunTexture = new ResourceLocation("howlingmoon:textures/mob/stun.png");
/*     */   public RenderStun(RenderManager renderManager) {
/*  18 */     super(renderManager);
/*     */   }
/*     */ 
/*     */   
/*     */   public void doRender(EntityStun entity, double x, double y, double z, float entityYaw, float partialTicks) {
/*  23 */     GlStateManager.func_179094_E();
/*  24 */     func_110776_a(stunTexture);
/*  25 */     GlStateManager.func_179109_b((float)x, (float)y, (float)z);
/*  26 */     GlStateManager.func_179091_B();
/*  27 */     if (entity.riderHeight > 0.0F) {
/*  28 */       GlStateManager.func_179152_a(0.5F + entity.field_70130_N, entity.field_70131_O + entity.riderHeight, 0.5F + entity.field_70130_N);
/*     */     } else {
/*  30 */       GlStateManager.func_179152_a(0.5F + entity.field_70130_N, 1.0F, 0.5F + entity.field_70130_N);
/*  31 */     }  Tessellator tessellator = Tessellator.func_178181_a();
/*  32 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*  33 */     float f4 = 1.0F;
/*  34 */     float f5 = 0.5F;
/*  35 */     float f6 = 0.25F;
/*     */     
/*  37 */     if (this.field_188301_f) {
/*     */       
/*  39 */       GlStateManager.func_179142_g();
/*  40 */       GlStateManager.func_187431_e(func_188298_c((Entity)entity));
/*     */     } 
/*     */     
/*  43 */     vertexbuffer.func_181668_a(7, DefaultVertexFormats.field_181710_j);
/*     */     
/*  45 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, -0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  46 */     vertexbuffer.func_181662_b(0.5D, 0.0D, -0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  47 */     vertexbuffer.func_181662_b(0.5D, 1.0D, -0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  48 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, -0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  50 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, 0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  51 */     vertexbuffer.func_181662_b(0.5D, 0.0D, 0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  52 */     vertexbuffer.func_181662_b(0.5D, 1.0D, 0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  53 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, 0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  55 */     vertexbuffer.func_181662_b(0.5D, 0.0D, -0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  56 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, -0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  57 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, -0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  58 */     vertexbuffer.func_181662_b(0.5D, 1.0D, -0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  60 */     vertexbuffer.func_181662_b(0.5D, 0.0D, 0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  61 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, 0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  62 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, 0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  63 */     vertexbuffer.func_181662_b(0.5D, 1.0D, 0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  65 */     vertexbuffer.func_181662_b(0.5D, 0.0D, -0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  66 */     vertexbuffer.func_181662_b(0.5D, 0.0D, 0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  67 */     vertexbuffer.func_181662_b(0.5D, 1.0D, 0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  68 */     vertexbuffer.func_181662_b(0.5D, 1.0D, -0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  70 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, -0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  71 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, 0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  72 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, 0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  73 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, -0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  75 */     vertexbuffer.func_181662_b(0.5D, 0.0D, 0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  76 */     vertexbuffer.func_181662_b(0.5D, 0.0D, -0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  77 */     vertexbuffer.func_181662_b(0.5D, 1.0D, -0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  78 */     vertexbuffer.func_181662_b(0.5D, 1.0D, 0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  80 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, 0.5D).func_187315_a(0.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  81 */     vertexbuffer.func_181662_b(-0.5D, 0.0D, -0.5D).func_187315_a(1.0D, 1.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  82 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, -0.5D).func_187315_a(1.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*  83 */     vertexbuffer.func_181662_b(-0.5D, 1.0D, 0.5D).func_187315_a(0.0D, 0.0D).func_181663_c(0.0F, 1.0F, 0.0F).func_181675_d();
/*     */     
/*  85 */     tessellator.func_78381_a();
/*     */     
/*  87 */     if (this.field_188301_f) {
/*     */       
/*  89 */       GlStateManager.func_187417_n();
/*  90 */       GlStateManager.func_179119_h();
/*     */     } 
/*     */     
/*  93 */     GlStateManager.func_179101_C();
/*  94 */     GlStateManager.func_179121_F();
/*  95 */     super.func_76986_a((Entity)entity, x, y, z, entityYaw, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ResourceLocation getEntityTexture(EntityStun entity) {
/* 100 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderStun.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */