/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.scoreboard.Score;
/*     */ import net.minecraft.scoreboard.ScoreObjective;
/*     */ import net.minecraft.scoreboard.Scoreboard;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderDireWolfPlayer
/*     */   extends RenderLivingBase
/*     */ {
/*  31 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/*  32 */   private static final ResourceLocation textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/*     */   
/*  34 */   private static final ResourceLocation textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/*  35 */   private static final ResourceLocation textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*     */   
/*  37 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */ 
/*     */   
/*     */   public RenderDireWolfPlayer(RenderManager renderManagerIn) {
/*  41 */     super(renderManagerIn, new ModelDireWolf(), 0.5F);
/*  42 */     func_177094_a(new LayerDireHeldItem(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation func_110775_a(Entity par1Entity) {
/*  54 */     int temp = ((IWerewolfCapability)((EntityPlayer)par1Entity).getCapability(WereEventHandler.WERE_CAP, null)).getTexture();
/*  55 */     switch (temp) {
/*     */       
/*     */       case 0:
/*  58 */         this; return texture;
/*     */       case 1:
/*  60 */         this; return textureBlack;
/*     */       case 2:
/*  62 */         this; return textureTimber;
/*     */       case 3:
/*  64 */         this; return textureKillerwolf;
/*     */     } 
/*  66 */     if (CustomWerewolfTextures.textureCount >= temp - 3)
/*     */     {
/*  68 */       return CustomWerewolfTextures.customTextures.get(temp - 4);
/*     */     }
/*  70 */     this; return texture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelDireWolf getPlayerModel() {
/*  79 */     return (ModelDireWolf)super.func_177087_b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks) {
/*  91 */     if (!entity.func_175144_cb() || this.field_76990_c.field_78734_h == entity) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       setModelVisibilities(entity);
/* 104 */       super.func_76986_a((EntityLivingBase)entity, x, y, z, entityYaw, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setModelVisibilities(AbstractClientPlayer clientPlayer) {
/* 111 */     ModelDireWolf modelplayer = getPlayerModel();
/*     */     
/* 113 */     if (!clientPlayer.func_175149_v()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       ItemStack itemstack = clientPlayer.field_71071_by.func_70448_g();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       modelplayer.heldItemLeft = 0;
/*     */       
/* 131 */       modelplayer.isSneak = clientPlayer.func_70093_af();
/*     */       
/* 133 */       if (!itemstack.func_190926_b()) {
/*     */         
/* 135 */         modelplayer.heldItemRight = 0;
/*     */       }
/*     */       else {
/*     */         
/* 139 */         modelplayer.heldItemRight = 1;
/*     */         
/* 141 */         if (clientPlayer.func_184605_cv() > 0) {
/*     */           
/* 143 */           EnumAction enumaction = itemstack.func_77975_n();
/*     */           
/* 145 */           if (enumaction == EnumAction.BLOCK)
/*     */           {
/* 147 */             modelplayer.heldItemRight = 3;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77041_b(EntityLivingBase p_77041_1_, float p_77041_2_) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77039_a(EntityLivingBase p_77039_1_, double p_77039_2_, double p_77039_4_, double p_77039_6_) {
/* 189 */     renderLivingAt((AbstractClientPlayer)p_77039_1_, p_77039_2_, p_77039_4_, p_77039_6_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(EntityLivingBase entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 200 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelBase func_177087_b() {
/* 205 */     return getPlayerModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(Entity entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 216 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderEntityName(AbstractClientPlayer entityIn, double x, double y, double z, String name, double p_188296_9_) {
/* 221 */     if (p_188296_9_ < 100.0D) {
/*     */       
/* 223 */       Scoreboard scoreboard = entityIn.func_96123_co();
/* 224 */       ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
/*     */       
/* 226 */       if (scoreobjective != null) {
/*     */         
/* 228 */         Score score = scoreboard.func_96529_a(entityIn.func_70005_c_(), scoreobjective);
/* 229 */         func_147906_a((Entity)entityIn, score.func_96652_c() + " " + scoreobjective.func_96678_d(), x, y, z, 64);
/* 230 */         y += ((func_76983_a()).field_78288_b * 1.15F * 0.025F);
/*     */       } 
/*     */     } 
/*     */     
/* 234 */     func_188296_a((Entity)entityIn, x, y, z, name, p_188296_9_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderLivingAt(AbstractClientPlayer entityLivingBaseIn, double x, double y, double z) {
/* 242 */     if (entityLivingBaseIn.func_70089_S() && entityLivingBaseIn.func_70608_bn()) {
/*     */       
/* 244 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x + entityLivingBaseIn.field_71079_bU, y + entityLivingBaseIn.field_71082_cx, z + entityLivingBaseIn.field_71089_bV);
/*     */     }
/*     */     else {
/*     */       
/* 248 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x, y, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyRotations(AbstractClientPlayer entityLiving, float p_77043_2_, float p_77043_3_, float partialTicks) {
/* 254 */     if (entityLiving.func_70089_S() && entityLiving.func_70608_bn()) {
/*     */       
/* 256 */       GlStateManager.func_179114_b(entityLiving.func_71051_bG(), 0.0F, 1.0F, 0.0F);
/* 257 */       GlStateManager.func_179114_b(func_77037_a((EntityLivingBase)entityLiving), 0.0F, 0.0F, 1.0F);
/* 258 */       GlStateManager.func_179114_b(270.0F, 0.0F, 1.0F, 0.0F);
/*     */     }
/* 260 */     else if (entityLiving.func_184613_cA()) {
/*     */       
/* 262 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/* 263 */       float f = entityLiving.func_184599_cB() + partialTicks;
/* 264 */       float f1 = MathHelper.func_76131_a(f * f / 100.0F, 0.0F, 1.0F);
/* 265 */       GlStateManager.func_179114_b(f1 * (-90.0F - entityLiving.field_70125_A), 1.0F, 0.0F, 0.0F);
/* 266 */       Vec3d vec3d = entityLiving.func_70676_i(partialTicks);
/* 267 */       double d0 = entityLiving.field_70159_w * entityLiving.field_70159_w + entityLiving.field_70179_y * entityLiving.field_70179_y;
/* 268 */       double d1 = vec3d.field_72450_a * vec3d.field_72450_a + vec3d.field_72449_c * vec3d.field_72449_c;
/*     */       
/* 270 */       if (d0 > 0.0D && d1 > 0.0D)
/*     */       {
/* 272 */         double d2 = (entityLiving.field_70159_w * vec3d.field_72450_a + entityLiving.field_70179_y * vec3d.field_72449_c) / Math.sqrt(d0) * Math.sqrt(d1);
/* 273 */         double d3 = entityLiving.field_70159_w * vec3d.field_72449_c - entityLiving.field_70179_y * vec3d.field_72450_a;
/* 274 */         GlStateManager.func_179114_b((float)(Math.signum(d3) * Math.acos(d2)) * 180.0F / 3.1415927F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 279 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderDireWolfPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */