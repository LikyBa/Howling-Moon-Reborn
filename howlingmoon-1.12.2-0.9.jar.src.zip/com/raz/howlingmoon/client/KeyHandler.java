/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereAbility;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.WereList;
/*     */ import com.raz.howlingmoon.packets.BiteEntity;
/*     */ import com.raz.howlingmoon.packets.DismountEntity;
/*     */ import com.raz.howlingmoon.packets.LaunchEntity;
/*     */ import com.raz.howlingmoon.packets.LiftEntity;
/*     */ import com.raz.howlingmoon.packets.MaimEntity;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.PlaySoundPacket;
/*     */ import com.raz.howlingmoon.packets.SummonWolves;
/*     */ import com.raz.howlingmoon.packets.SyncNightVisionMessage;
/*     */ import com.raz.howlingmoon.packets.SyncScentTrackingMessage;
/*     */ import com.raz.howlingmoon.packets.TryTransformServerMessage;
/*     */ import com.raz.howlingmoon.reference.Key;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyHandler
/*     */ {
/*  42 */   private final Minecraft mc = Minecraft.func_71410_x();
/*     */ 
/*     */ 
/*     */   
/*     */   private static Key getPressedKeybinding() {
/*  47 */     if (KeyBindings.menu.func_151468_f())
/*     */     {
/*  49 */       return Key.MENU;
/*     */     }
/*  51 */     if (KeyBindings.transform.func_151468_f())
/*     */     {
/*  53 */       return Key.TRANSFORM;
/*     */     }
/*  55 */     if (KeyBindings.ability1.func_151468_f())
/*     */     {
/*  57 */       return Key.ABILITY1;
/*     */     }
/*  59 */     if (KeyBindings.ability2.func_151468_f())
/*     */     {
/*  61 */       return Key.ABILITY2;
/*     */     }
/*     */     
/*  64 */     return Key.UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void handleKeyInputEvent(InputEvent.KeyInputEvent event) {
/*  70 */     if (this.mc.field_71415_G) {
/*     */       
/*  72 */       EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/*  73 */       IWerewolfCapability wolf = (IWerewolfCapability)entityPlayerSP.getCapability(WereEventHandler.WERE_CAP, null);
/*  74 */       Key temp = getPressedKeybinding();
/*  75 */       if (temp == Key.MENU)
/*     */       {
/*  77 */         entityPlayerSP.openGui(HowlingMoon.instance, 0, ((EntityPlayer)entityPlayerSP).field_70170_p, 0, (int)((EntityPlayer)entityPlayerSP).field_70163_u, (int)((EntityPlayer)entityPlayerSP).field_70161_v);
/*     */       }
/*  79 */       if (wolf.isWerewolf()) {
/*     */ 
/*     */         
/*  82 */         if (temp == Key.TRANSFORM) {
/*     */ 
/*     */ 
/*     */           
/*  86 */           PacketDispatcher.sendToServer((IMessage)new TryTransformServerMessage((EntityPlayer)entityPlayerSP));
/*     */         
/*     */         }
/*  89 */         else if (temp == Key.ABILITY1) {
/*     */           
/*  91 */           abilityActivate(wolf.getAbilitySlot1());
/*     */         }
/*  93 */         else if (temp == Key.ABILITY2) {
/*     */           
/*  95 */           abilityActivate(wolf.getAbilitySlot2());
/*     */         }
/*  97 */         else if (this.mc.field_71474_y.field_74316_C.func_151470_d() && this.mc.field_71439_g.func_184614_ca().func_190926_b()) {
/*     */ 
/*     */ 
/*     */           
/* 101 */           if (!entityPlayerSP.func_184188_bt().isEmpty()) {
/*     */             
/* 103 */             entityPlayerSP.func_184226_ay();
/* 104 */             PacketDispatcher.sendToServer((IMessage)new DismountEntity((EntityPlayer)entityPlayerSP));
/*     */           } 
/*     */         } 
/* 107 */         if (this.mc.field_71474_y.field_74314_A.func_151470_d() && !this.mc.field_71439_g.field_70122_E && wolf.getClimb())
/*     */         {
/* 109 */           if ((entityPlayerSP.func_70093_af() && wolf.getSneakJump() != 0) || (this.mc.field_71474_y.field_151444_V.func_151470_d() && (wolf.getSprintJump() & 0x1) == 1)) {
/*     */             
/* 111 */             wolf.setLeap(true);
/* 112 */             entityPlayerSP.func_70664_aZ();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void abilityActivate(WereAbility ability) {
/* 121 */     EntityPlayerSP entityPlayerSP = this.mc.field_71439_g;
/* 122 */     IWerewolfCapability wolf = (IWerewolfCapability)entityPlayerSP.getCapability(WereEventHandler.WERE_CAP, null);
/* 123 */     if (ability == WereList.HOWL) {
/*     */       
/* 125 */       if (wolf.isTransformed())
/*     */       {
/* 127 */         if (wolf.getCDHowl() < 1) {
/*     */           
/* 129 */           wolf.resetCDHowl();
/* 130 */           PacketDispatcher.sendToServer((IMessage)new PlaySoundPacket((EntityPlayer)entityPlayerSP, 1.0F));
/* 131 */           PacketDispatcher.sendToServer((IMessage)new SummonWolves((EntityPlayer)entityPlayerSP));
/*     */         } else {
/*     */           
/* 134 */           PacketDispatcher.sendToServer((IMessage)new PlaySoundPacket((EntityPlayer)entityPlayerSP, 0.5F));
/*     */         } 
/*     */       }
/* 137 */     } else if (ability == WereList.LEAP) {
/*     */       
/* 139 */       if (wolf.isTransformed())
/*     */       {
/* 141 */         if (this.mc.field_71439_g.field_70122_E || (!this.mc.field_71439_g.field_70122_E && wolf.getClimb()))
/*     */         {
/* 143 */           if (wolf.getAbilityTreeAbility(WereList.LEAP.getKey()))
/*     */           {
/*     */             
/* 146 */             wolf.setLeap(true);
/* 147 */             entityPlayerSP.func_70664_aZ();
/*     */           }
/*     */         
/*     */         }
/*     */       }
/* 152 */     } else if (ability == WereList.NIGHTVISION) {
/*     */       
/* 154 */       if (wolf.isTransformed())
/*     */       {
/* 156 */         if (wolf.getQuestsDone() > 2)
/*     */         {
/* 158 */           wolf.setNightVision(!wolf.getNightVision());
/* 159 */           PacketDispatcher.sendToServer((IMessage)new SyncNightVisionMessage((EntityPlayer)this.mc.field_71439_g));
/*     */         }
/*     */       
/*     */       }
/* 163 */     } else if (ability == WereList.SCENTRACKING) {
/*     */       
/* 165 */       if (wolf.isTransformed())
/*     */       {
/* 167 */         if (wolf.getAbilityTreeAbility(WereList.SCENTRACKING.getKey()))
/*     */         {
/* 169 */           wolf.setScentTracking(!wolf.getScentTracking());
/* 170 */           PacketDispatcher.sendToServer((IMessage)new SyncScentTrackingMessage((EntityPlayer)this.mc.field_71439_g));
/*     */         }
/*     */       
/*     */       }
/* 174 */     } else if (ability == WereList.LIFT) {
/*     */       
/* 176 */       if (wolf.isTransformed() && emptyPaws((EntityPlayer)entityPlayerSP))
/*     */       {
/* 178 */         if (!entityPlayerSP.func_184188_bt().isEmpty())
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 183 */           entityPlayerSP.func_184226_ay();
/* 184 */           PacketDispatcher.sendToServer((IMessage)new LaunchEntity((EntityPlayer)entityPlayerSP));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 191 */         else if ((Minecraft.func_71410_x()).field_71476_x != null)
/*     */         {
/* 193 */           if ((Minecraft.func_71410_x()).field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY)
/*     */           {
/* 195 */             if (wolf.getAbilityTreeAbility(WereList.LIFT.getKey()))
/*     */             {
/* 197 */               PacketDispatcher.sendToServer((IMessage)new LiftEntity((EntityPlayer)this.mc.field_71439_g, (Minecraft.func_71410_x()).field_71476_x.field_72308_g));
/*     */             }
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 203 */     } else if (ability == WereList.BITE) {
/*     */       
/* 205 */       if (wolf.isTransformed())
/*     */       {
/* 207 */         if ((Minecraft.func_71410_x()).field_71476_x != null)
/*     */         {
/* 209 */           if ((Minecraft.func_71410_x()).field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY)
/*     */           {
/* 211 */             if ((Minecraft.func_71410_x()).field_71476_x.field_72308_g instanceof EntityPlayer)
/*     */             {
/* 213 */               if (wolf.getQuestsDone() > 5)
/*     */               {
/* 215 */                 PacketDispatcher.sendToServer((IMessage)new BiteEntity((EntityPlayer)(Minecraft.func_71410_x()).field_71476_x.field_72308_g));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 222 */     else if (ability == WereList.MAIM) {
/*     */       
/* 224 */       if (wolf.isTransformed())
/*     */       {
/* 226 */         if ((Minecraft.func_71410_x()).field_71476_x != null)
/*     */         {
/* 228 */           if ((Minecraft.func_71410_x()).field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY)
/*     */           {
/* 230 */             if ((Minecraft.func_71410_x()).field_71476_x.field_72308_g instanceof EntityLiving)
/*     */             {
/* 232 */               if (wolf.getAbilityTreeAbility(WereList.MAIM.getKey()))
/*     */               {
/* 234 */                 PacketDispatcher.sendToServer((IMessage)new MaimEntity((EntityPlayer)this.mc.field_71439_g, (EntityLiving)(Minecraft.func_71410_x()).field_71476_x.field_72308_g));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean emptyPaws(EntityPlayer player) {
/* 245 */     if (player.func_184614_ca().func_190926_b())
/* 246 */       return true; 
/* 247 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\KeyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */