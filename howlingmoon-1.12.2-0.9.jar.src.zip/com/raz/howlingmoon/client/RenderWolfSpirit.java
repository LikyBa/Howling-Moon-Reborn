/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityWolfSpirit;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.entity.RenderLiving;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class RenderWolfSpirit extends RenderLiving {
/*    */   protected ResourceLocation texture;
/*    */   protected ResourceLocation textureBlack;
/*    */   protected ResourceLocation textureRed;
/*    */   protected ResourceLocation textureTimber;
/*    */   protected ResourceLocation textureKillerwolf;
/*    */   
/*    */   public RenderWolfSpirit(RenderManager renderManager) {
/* 20 */     super(renderManager, new ModelDireWolf(), 0.5F);
/* 21 */     setEntityTexture();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_76986_a(EntityLiving entity, double x, double y, double z, float f, float partialTicks) {
/* 27 */     GlStateManager.func_179094_E();
/*    */     
/* 29 */     GlStateManager.func_179141_d();
/* 30 */     GlStateManager.func_179147_l();
/*    */     
/* 32 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.5F);
/*    */     
/* 34 */     super.func_76986_a(entity, x, y, z, f, partialTicks);
/*    */     
/* 36 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*    */     
/* 38 */     GlStateManager.func_179118_c();
/* 39 */     GlStateManager.func_179084_k();
/*    */     
/* 41 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_77041_b(EntityLivingBase entity, float f) {
/* 47 */     preRenderCallbackWerewolf((EntityWolfSpirit)entity, f);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void preRenderCallbackWerewolf(EntityWolfSpirit entity, float f) {}
/*    */ 
/*    */   
/*    */   protected void setEntityTexture() {
/* 56 */     this.texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/* 57 */     this.textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/* 58 */     this.textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/* 59 */     this.textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 65 */     int temp = ((EntityWolfSpirit)entity).getFurColor();
/* 66 */     switch (temp) {
/*    */       case 0:
/* 68 */         return this.texture;
/* 69 */       case 1: return this.textureBlack;
/* 70 */       case 2: return this.textureTimber;
/* 71 */       case 3: return this.textureKillerwolf;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 77 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderWolfSpirit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */