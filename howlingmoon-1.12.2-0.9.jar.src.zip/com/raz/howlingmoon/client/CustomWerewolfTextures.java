/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomWerewolfTextures
/*    */ {
/*    */   private static File cacheFile;
/*    */   public static int textureCount;
/* 14 */   public static List<ResourceLocation> customTextures = new ArrayList<>();
/*    */   
/*    */   public static void setCacheFile(File f) {
/* 17 */     cacheFile = f;
/* 18 */     boolean create = true;
/* 19 */     if (!cacheFile.exists()) {
/*    */       
/* 21 */       create = cacheFile.mkdir();
/* 22 */       if (create) {
/* 23 */         System.out.println("HowlingMoon Directory successfully created");
/*    */       } else {
/* 25 */         System.out.println("Failed to create HowlingMoon directory");
/*    */       } 
/* 27 */     }  if (create) {
/* 28 */       checkImages();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static void checkImages() {
/* 34 */     textureCount = 0;
/* 35 */     for (File file : cacheFile.listFiles()) {
/* 36 */       if (file.isFile() && file.getName().endsWith(".png")) {
/* 37 */         textureCount++;
/* 38 */         customTextures.add(new ResourceLocation("howlingmoon:" + file.getName()));
/*    */       } 
/*    */     } 
/*    */     
/* 42 */     System.out.println("Number of custom werewolf textures: " + textureCount);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\CustomWerewolfTextures.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */