/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerRenderer;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayerDireHeldItem
/*     */   implements LayerRenderer<EntityLivingBase>
/*     */ {
/*     */   private final RenderLivingBase<?> livingEntityRenderer;
/*     */   
/*     */   public LayerDireHeldItem(RenderLivingBase<?> livingEntityRendererIn) {
/*  24 */     this.livingEntityRenderer = livingEntityRendererIn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_177141_a(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/*  29 */     boolean flag = (entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT);
/*  30 */     ItemStack itemstack = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
/*  31 */     ItemStack itemstack1 = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();
/*     */     
/*  33 */     if (!itemstack.func_190926_b() || !itemstack1.func_190926_b()) {
/*     */       
/*  35 */       GlStateManager.func_179094_E();
/*     */       
/*  37 */       if ((this.livingEntityRenderer.func_177087_b()).field_78091_s) {
/*     */         
/*  39 */         float f = 0.5F;
/*  40 */         GlStateManager.func_179109_b(0.0F, 0.625F, 0.0F);
/*  41 */         GlStateManager.func_179114_b(-20.0F, -1.0F, 0.0F, 0.0F);
/*  42 */         GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/*     */       } 
/*     */       
/*  45 */       renderHeldItem(entitylivingbaseIn, itemstack1, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT);
/*  46 */       renderHeldItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT);
/*  47 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderHeldItem(EntityLivingBase p_188358_1_, ItemStack p_188358_2_, ItemCameraTransforms.TransformType p_188358_3_, EnumHandSide handSide) {
/*  53 */     if (!p_188358_2_.func_190926_b()) {
/*     */       
/*  55 */       GlStateManager.func_179094_E();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  62 */       ((ModelDireWolf)this.livingEntityRenderer.func_177087_b()).postRenderArm(0.0625F, handSide);
/*  63 */       GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/*  64 */       GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
/*  65 */       boolean flag = (handSide == EnumHandSide.LEFT);
/*  66 */       if (flag) {
/*     */         
/*  68 */         GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/*  69 */         GlStateManager.func_179109_b(0.0F, 0.5F, 0.0F);
/*     */       } else {
/*     */         
/*  72 */         GlStateManager.func_179109_b(0.0F, 0.375F, -0.16F);
/*  73 */       }  Minecraft.func_71410_x().func_175597_ag().func_187462_a(p_188358_1_, p_188358_2_, p_188358_3_, flag);
/*  74 */       GlStateManager.func_179121_F();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_177142_b() {
/* 127 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\LayerDireHeldItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */