/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import com.google.common.collect.ImmutableSet;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Set;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.resources.IResourcePack;
/*    */ import net.minecraft.client.resources.data.MetadataSerializer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomWerewolfResourcePack
/*    */   implements IResourcePack
/*    */ {
/*    */   public InputStream func_110590_a(ResourceLocation p_110590_1_) throws IOException {
/* 25 */     return new FileInputStream((Minecraft.func_71410_x()).field_71412_D + "/config/HowlingMoonTextures/" + p_110590_1_.func_110623_a());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private InputStream getResourceStream(ResourceLocation p_110605_1_) {
/*    */     try {
/* 32 */       return new FileInputStream((Minecraft.func_71410_x()).field_71412_D + "/config/HowlingMoonTextures/" + p_110605_1_.func_110623_a());
/* 33 */     } catch (FileNotFoundException e) {
/*    */       
/* 35 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_110589_b(ResourceLocation p_110589_1_) {
/* 41 */     return (getResourceStream(p_110589_1_) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set func_110587_b() {
/* 48 */     return (Set)ImmutableSet.of("howlingmoon");
/*    */   }
/*    */ 
/*    */   
/*    */   public BufferedImage func_110586_a() throws IOException {
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_130077_b() {
/* 58 */     return "CustomWerewolfResourcePack";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends net.minecraft.client.resources.data.IMetadataSection> T func_135058_a(MetadataSerializer metadataSerializer, String metadataSectionName) throws IOException {
/* 65 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\CustomWerewolfResourcePack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */