/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.scoreboard.Score;
/*     */ import net.minecraft.scoreboard.ScoreObjective;
/*     */ import net.minecraft.scoreboard.Scoreboard;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderBeastPlayer
/*     */   extends RenderLivingBase
/*     */ {
/*  32 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/*  33 */   private static final ResourceLocation textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/*  34 */   private static final ResourceLocation textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/*  35 */   private static final ResourceLocation textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*     */   
/*  37 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */ 
/*     */   
/*     */   public RenderBeastPlayer(RenderManager renderManagerIn) {
/*  41 */     super(renderManagerIn, new ModelBeast(), 0.5F);
/*  42 */     func_177094_a(new LayerBeastHeldItem(this));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation func_110775_a(Entity par1Entity) {
/*  48 */     int temp = ((IWerewolfCapability)((EntityPlayer)par1Entity).getCapability(WereEventHandler.WERE_CAP, null)).getTexture();
/*  49 */     switch (temp) {
/*     */       
/*     */       case 0:
/*  52 */         this; return texture;
/*     */       case 1:
/*  54 */         this; return textureBlack;
/*     */       case 2:
/*  56 */         this; return textureTimber;
/*     */       case 3:
/*  58 */         this; return textureKillerwolf;
/*     */     } 
/*  60 */     if (CustomWerewolfTextures.textureCount >= temp - 3)
/*     */     {
/*  62 */       return CustomWerewolfTextures.customTextures.get(temp - 4);
/*     */     }
/*  64 */     this; return texture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelBeast getPlayerModel() {
/*  73 */     return (ModelBeast)super.func_177087_b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks) {
/*  85 */     if (!entity.func_175144_cb() || this.field_76990_c.field_78734_h == entity) {
/*     */ 
/*     */ 
/*     */       
/*  89 */       double d0 = y + 1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  96 */       setModelVisibilities(entity);
/*  97 */       super.func_76986_a((EntityLivingBase)entity, x, d0, z, entityYaw, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setModelVisibilities(AbstractClientPlayer clientPlayer) {
/* 104 */     ModelBeast modelplayer = getPlayerModel();
/*     */     
/* 106 */     if (!clientPlayer.func_175149_v()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       ItemStack itemstack = clientPlayer.field_71071_by.func_70448_g();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 122 */       modelplayer.heldItemLeft = 0;
/*     */       
/* 124 */       modelplayer.isSneak = clientPlayer.func_70093_af();
/* 125 */       modelplayer.isSprinting = clientPlayer.func_70051_ag();
/*     */       
/* 127 */       if (!itemstack.func_190926_b()) {
/*     */         
/* 129 */         modelplayer.heldItemRight = 0;
/*     */       }
/*     */       else {
/*     */         
/* 133 */         modelplayer.heldItemRight = 1;
/*     */         
/* 135 */         if (clientPlayer.func_184605_cv() > 0) {
/*     */           
/* 137 */           EnumAction enumaction = itemstack.func_77975_n();
/*     */           
/* 139 */           if (enumaction == EnumAction.BLOCK)
/*     */           {
/* 141 */             modelplayer.heldItemRight = 3;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderEntityName(AbstractClientPlayer entityIn, double x, double y, double z, String name, double p_188296_9_) {
/* 150 */     if (p_188296_9_ < 100.0D) {
/*     */       
/* 152 */       Scoreboard scoreboard = entityIn.func_96123_co();
/* 153 */       ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
/*     */       
/* 155 */       if (scoreobjective != null) {
/*     */         
/* 157 */         Score score = scoreboard.func_96529_a(entityIn.func_70005_c_(), scoreobjective);
/* 158 */         func_147906_a((Entity)entityIn, score.func_96652_c() + " " + scoreobjective.func_96678_d(), x, y, z, 64);
/* 159 */         y += ((func_76983_a()).field_78288_b * 1.15F * 0.025F);
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     func_188296_a((Entity)entityIn, x, y, z, name, p_188296_9_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77041_b(EntityLivingBase p_77041_1_, float p_77041_2_) {
/* 173 */     GL11.glTranslatef(0.0F, 1.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77039_a(EntityLivingBase p_77039_1_, double p_77039_2_, double p_77039_4_, double p_77039_6_) {
/* 186 */     renderLivingAt((AbstractClientPlayer)p_77039_1_, p_77039_2_, p_77039_4_, p_77039_6_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(EntityLivingBase entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 197 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelBase func_177087_b() {
/* 202 */     return getPlayerModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(Entity entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 213 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderLivingAt(AbstractClientPlayer entityLivingBaseIn, double x, double y, double z) {
/* 223 */     if (entityLivingBaseIn.func_70089_S() && entityLivingBaseIn.func_70608_bn()) {
/*     */       
/* 225 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x + entityLivingBaseIn.field_71079_bU, y + entityLivingBaseIn.field_71082_cx, z + entityLivingBaseIn.field_71089_bV);
/*     */     }
/*     */     else {
/*     */       
/* 229 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x, y, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyRotations(AbstractClientPlayer entityLiving, float p_77043_2_, float p_77043_3_, float partialTicks) {
/* 235 */     if (entityLiving.func_70089_S() && entityLiving.func_70608_bn()) {
/*     */       
/* 237 */       GlStateManager.func_179114_b(entityLiving.func_71051_bG(), 0.0F, 1.0F, 0.0F);
/* 238 */       GlStateManager.func_179114_b(func_77037_a((EntityLivingBase)entityLiving), 0.0F, 0.0F, 1.0F);
/* 239 */       GlStateManager.func_179114_b(270.0F, 0.0F, 1.0F, 0.0F);
/*     */     }
/* 241 */     else if (entityLiving.func_184613_cA()) {
/*     */       
/* 243 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/* 244 */       float f = entityLiving.func_184599_cB() + partialTicks;
/* 245 */       float f1 = MathHelper.func_76131_a(f * f / 100.0F, 0.0F, 1.0F);
/* 246 */       GlStateManager.func_179114_b(f1 * (-90.0F - entityLiving.field_70125_A), 1.0F, 0.0F, 0.0F);
/* 247 */       Vec3d vec3d = entityLiving.func_70676_i(partialTicks);
/* 248 */       double d0 = entityLiving.field_70159_w * entityLiving.field_70159_w + entityLiving.field_70179_y * entityLiving.field_70179_y;
/* 249 */       double d1 = vec3d.field_72450_a * vec3d.field_72450_a + vec3d.field_72449_c * vec3d.field_72449_c;
/*     */       
/* 251 */       if (d0 > 0.0D && d1 > 0.0D)
/*     */       {
/* 253 */         double d2 = (entityLiving.field_70159_w * vec3d.field_72450_a + entityLiving.field_70179_y * vec3d.field_72449_c) / Math.sqrt(d0) * Math.sqrt(d1);
/* 254 */         double d3 = entityLiving.field_70159_w * vec3d.field_72449_c - entityLiving.field_70179_y * vec3d.field_72450_a;
/* 255 */         GlStateManager.func_179114_b((float)(Math.signum(d3) * Math.acos(d2)) * 180.0F / 3.1415927F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 260 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderBeastPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */