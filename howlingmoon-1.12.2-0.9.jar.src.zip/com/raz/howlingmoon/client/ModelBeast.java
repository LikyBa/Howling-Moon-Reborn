/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelBeast
/*     */   extends ModelBase
/*     */ {
/*     */   ModelRenderer head;
/*     */   ModelRenderer neck;
/*     */   ModelRenderer rightFoot;
/*     */   ModelRenderer leftFoot;
/*     */   ModelRenderer rightLeg;
/*     */   ModelRenderer rightAnkle;
/*     */   ModelRenderer rightThigh;
/*     */   ModelRenderer upperBody;
/*     */   ModelRenderer lowerBody;
/*     */   ModelRenderer middleBody;
/*     */   ModelRenderer leftLeg;
/*     */   ModelRenderer leftAnkle;
/*     */   ModelRenderer leftThigh;
/*     */   ModelRenderer nose;
/*     */   ModelRenderer rightEar;
/*     */   ModelRenderer leftEar;
/*     */   ModelRenderer tail;
/*     */   ModelRenderer tail2;
/*     */   ModelRenderer tail3;
/*     */   ModelRenderer tail4;
/*     */   ModelRenderer rightArm;
/*     */   ModelRenderer rightForearm;
/*     */   ModelRenderer rightHand;
/*     */   ModelRenderer leftArm;
/*     */   ModelRenderer leftForearm;
/*     */   ModelRenderer leftHand;
/*  43 */   private float xhead = 0.0698132F;
/*  44 */   private float xArm = 0.2443461F;
/*  45 */   private float xForeArm = -0.2617994F;
/*  46 */   private float xleg = 0.418879F;
/*  47 */   private float xThigh = -0.1047198F;
/*  48 */   private float xAnkle = -0.3490659F;
/*  49 */   private float xUpperBody = 0.2094395F;
/*  50 */   private float xMiddleBody = 0.1047198F;
/*  51 */   private float xNeck = 0.4712389F;
/*     */   
/*  53 */   private float sneakX = 1.570796F;
/*     */   
/*     */   public int heldItemLeft;
/*     */   
/*     */   public int heldItemRight;
/*     */   
/*     */   public boolean isSneak;
/*     */   
/*     */   public boolean isSprinting;
/*     */ 
/*     */   
/*     */   public ModelBeast() {
/*  65 */     this.field_78090_t = 128;
/*  66 */     this.field_78089_u = 128;
/*     */     
/*  68 */     this.head = new ModelRenderer(this, 65, 0);
/*  69 */     this.head.func_78789_a(-4.0F, -4.0F, -9.0F, 8, 8, 9);
/*  70 */     this.head.func_78793_a(0.0F, -17.0F, 1.0F);
/*  71 */     this.head.func_78787_b(this.field_78090_t, this.field_78089_u);
/*  72 */     this.head.field_78809_i = true;
/*  73 */     setRotation(this.head, 0.0698132F, 0.0F, 0.0F);
/*  74 */     this.neck = new ModelRenderer(this, 0, 97);
/*  75 */     this.neck.func_78789_a(-4.5F, -20.0F, 3.0F, 9, 5, 9);
/*  76 */     this.neck.func_78793_a(0.0F, 6.0F, 1.0F);
/*  77 */     this.neck.func_78787_b(this.field_78090_t, this.field_78089_u);
/*  78 */     this.neck.field_78809_i = true;
/*  79 */     setRotation(this.neck, 0.4712389F, 0.0F, 0.0F);
/*     */     
/*  81 */     this.rightFoot = new ModelRenderer(this, 95, 123);
/*  82 */     this.rightFoot.func_78789_a(-2.0F, 17.0F, -1.5F, 4, 2, 3);
/*  83 */     this.rightFoot.func_78793_a(-4.0F, 5.0F, 0.0F);
/*  84 */     this.rightFoot.func_78787_b(this.field_78090_t, this.field_78089_u);
/*  85 */     this.rightFoot.field_78809_i = true;
/*  86 */     setRotation(this.rightFoot, 0.0F, 0.0F, 0.0F);
/*  87 */     this.leftFoot = new ModelRenderer(this, 112, 123);
/*  88 */     this.leftFoot.func_78789_a(-2.0F, 17.0F, -1.5F, 4, 2, 3);
/*  89 */     this.leftFoot.func_78793_a(4.0F, 5.0F, 0.0F);
/*  90 */     this.leftFoot.func_78787_b(this.field_78090_t, this.field_78089_u);
/*  91 */     this.leftFoot.field_78809_i = true;
/*  92 */     setRotation(this.leftFoot, 0.0F, 0.0F, 0.0F);
/*  93 */     this.rightLeg = new ModelRenderer(this, 95, 100);
/*  94 */     this.rightLeg.func_78789_a(-2.0F, 5.1F, -5.2F, 4, 8, 4);
/*  95 */     this.rightLeg.func_78793_a(-4.0F, 5.0F, 0.0F);
/*  96 */     this.rightLeg.func_78787_b(this.field_78090_t, this.field_78089_u);
/*  97 */     this.rightLeg.field_78809_i = true;
/*  98 */     setRotation(this.rightLeg, 0.418879F, 0.0F, 0.0F);
/*  99 */     this.rightAnkle = new ModelRenderer(this, 95, 113);
/* 100 */     this.rightAnkle.func_78789_a(-1.5F, 10.3F, 5.433333F, 3, 6, 3);
/* 101 */     this.rightAnkle.func_78793_a(-4.0F, 5.0F, 0.0F);
/* 102 */     this.rightAnkle.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 103 */     this.rightAnkle.field_78809_i = true;
/* 104 */     setRotation(this.rightAnkle, -0.3490659F, 0.0F, 0.0F);
/* 105 */     this.rightThigh = new ModelRenderer(this, 95, 88);
/* 106 */     this.rightThigh.func_78789_a(-2.0F, 0.0F, -2.0F, 4, 7, 4);
/* 107 */     this.rightThigh.func_78793_a(-4.0F, 5.0F, 0.0F);
/* 108 */     this.rightThigh.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 109 */     this.rightThigh.field_78809_i = true;
/* 110 */     setRotation(this.rightThigh, -0.1047198F, 0.0F, 0.0F);
/* 111 */     this.upperBody = new ModelRenderer(this, 65, 18);
/* 112 */     this.upperBody.func_78789_a(-7.0F, -18.0F, -5.0F, 14, 9, 14);
/* 113 */     this.upperBody.func_78793_a(0.0F, 6.0F, 1.0F);
/* 114 */     this.upperBody.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 115 */     this.upperBody.field_78809_i = true;
/* 116 */     setRotation(this.upperBody, 0.2094395F, 0.0F, 0.0F);
/* 117 */     this.lowerBody = new ModelRenderer(this, 50, 111);
/* 118 */     this.lowerBody.func_78789_a(-5.0F, -6.0F, -5.0F, 10, 7, 10);
/* 119 */     this.lowerBody.func_78793_a(0.0F, 6.0F, 1.0F);
/* 120 */     this.lowerBody.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 121 */     this.lowerBody.field_78809_i = true;
/* 122 */     setRotation(this.lowerBody, 0.0F, 0.0F, 0.0F);
/* 123 */     this.middleBody = new ModelRenderer(this, 0, 112);
/* 124 */     this.middleBody.func_78789_a(-6.0F, -10.0F, -4.5F, 12, 4, 12);
/* 125 */     this.middleBody.func_78793_a(0.0F, 6.0F, 1.0F);
/* 126 */     this.middleBody.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 127 */     this.middleBody.field_78809_i = true;
/* 128 */     setRotation(this.middleBody, 0.1047198F, 0.0F, 0.0F);
/* 129 */     this.leftLeg = new ModelRenderer(this, 112, 100);
/* 130 */     this.leftLeg.func_78789_a(-2.0F, 5.1F, -5.2F, 4, 8, 4);
/* 131 */     this.leftLeg.func_78793_a(4.0F, 5.0F, 0.0F);
/* 132 */     this.leftLeg.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 133 */     this.leftLeg.field_78809_i = true;
/* 134 */     setRotation(this.leftLeg, 0.418879F, 0.0F, 0.0F);
/* 135 */     this.leftAnkle = new ModelRenderer(this, 112, 113);
/* 136 */     this.leftAnkle.func_78789_a(-1.5F, 10.3F, 5.4F, 3, 6, 3);
/* 137 */     this.leftAnkle.func_78793_a(4.0F, 5.0F, 0.0F);
/* 138 */     this.leftAnkle.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 139 */     this.leftAnkle.field_78809_i = true;
/* 140 */     setRotation(this.leftAnkle, -0.3490659F, 0.0F, 0.0F);
/* 141 */     this.leftThigh = new ModelRenderer(this, 112, 88);
/* 142 */     this.leftThigh.func_78789_a(-2.0F, 0.0F, -2.0F, 4, 7, 4);
/* 143 */     this.leftThigh.func_78793_a(4.0F, 5.0F, 0.0F);
/* 144 */     this.leftThigh.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 145 */     this.leftThigh.field_78809_i = true;
/* 146 */     setRotation(this.leftThigh, -0.1047198F, 0.0F, 0.0F);
/* 147 */     this.nose = new ModelRenderer(this, 112, 5);
/* 148 */     this.nose.func_78789_a(-2.0F, 0.5F, -13.0F, 4, 3, 4);
/* 149 */     this.nose.func_78793_a(0.0F, -17.0F, 1.0F);
/* 150 */     this.nose.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 151 */     this.nose.field_78809_i = true;
/* 152 */     setRotation(this.nose, 0.0698132F, 0.0F, 0.0F);
/* 153 */     this.rightEar = new ModelRenderer(this, 115, 0);
/* 154 */     this.rightEar.func_78789_a(-3.5F, -7.0F, -3.0F, 2, 3, 1);
/* 155 */     this.rightEar.func_78793_a(0.0F, -17.0F, 1.0F);
/* 156 */     this.rightEar.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 157 */     this.rightEar.field_78809_i = true;
/* 158 */     setRotation(this.rightEar, 0.0F, 0.0F, -0.0698132F);
/* 159 */     this.leftEar = new ModelRenderer(this, 122, 0);
/* 160 */     this.leftEar.func_78789_a(1.5F, -7.0F, -3.0F, 2, 3, 1);
/* 161 */     this.leftEar.func_78793_a(0.0F, -17.0F, 1.0F);
/* 162 */     this.leftEar.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 163 */     this.leftEar.field_78809_i = true;
/* 164 */     setRotation(this.leftEar, 0.0F, 0.0F, 0.0698132F);
/* 165 */     this.tail = new ModelRenderer(this, 70, 68);
/* 166 */     this.tail.func_78789_a(-1.5F, 0.0F, -1.5F, 3, 6, 3);
/* 167 */     this.tail.func_78793_a(0.0F, 4.0F, 5.0F);
/* 168 */     this.tail.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 169 */     this.tail.field_78809_i = true;
/* 170 */     setRotation(this.tail, 0.3490659F, 0.0F, 0.0F);
/* 171 */     this.tail2 = new ModelRenderer(this, 70, 78);
/* 172 */     this.tail2.func_78789_a(-2.0F, 0.0F, -2.0F, 4, 4, 4);
/* 173 */     this.tail2.func_78793_a(0.0F, 8.0F, 6.0F);
/* 174 */     this.tail2.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 175 */     this.tail2.field_78809_i = true;
/* 176 */     setRotation(this.tail2, 0.6632251F, 0.0F, 0.0F);
/* 177 */     this.tail3 = new ModelRenderer(this, 70, 87);
/* 178 */     this.tail3.func_78789_a(-3.0F, 0.0F, -3.0F, 6, 10, 6);
/* 179 */     this.tail3.func_78793_a(0.0F, 10.0F, 8.0F);
/* 180 */     this.tail3.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 181 */     this.tail3.field_78809_i = true;
/* 182 */     setRotation(this.tail3, 1.117011F, 0.0F, 0.0F);
/* 183 */     this.tail4 = new ModelRenderer(this, 70, 104);
/* 184 */     this.tail4.func_78789_a(-1.5F, 0.0F, -1.5F, 3, 3, 3);
/* 185 */     this.tail4.func_78793_a(0.0F, 14.0F, 16.0F);
/* 186 */     this.tail4.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 187 */     this.tail4.field_78809_i = true;
/* 188 */     setRotation(this.tail4, 1.117011F, 0.0F, 0.0F);
/* 189 */     this.rightArm = new ModelRenderer(this, 95, 54);
/* 190 */     this.rightArm.func_78789_a(-4.0F, -1.0F, -2.0F, 4, 8, 4);
/* 191 */     this.rightArm.func_78793_a(-7.0F, -10.0F, 0.0F);
/* 192 */     this.rightArm.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 193 */     this.rightArm.field_78809_i = true;
/* 194 */     setRotation(this.rightArm, 0.2443461F, 0.0F, 0.0F);
/* 195 */     this.rightForearm = new ModelRenderer(this, 95, 67);
/* 196 */     this.rightForearm.func_78789_a(-4.0F, 5.2F, 1.1F, 4, 9, 4);
/* 197 */     this.rightForearm.func_78793_a(-7.0F, -10.0F, 0.0F);
/* 198 */     this.rightForearm.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 199 */     this.rightForearm.field_78809_i = true;
/* 200 */     setRotation(this.rightForearm, -0.2617994F, 0.0F, 0.0F);
/* 201 */     this.rightHand = new ModelRenderer(this, 95, 81);
/* 202 */     this.rightHand.func_78789_a(-4.0F, 14.0F, -3.0F, 4, 2, 4);
/* 203 */     this.rightHand.func_78793_a(-7.0F, -10.0F, 0.0F);
/* 204 */     this.rightHand.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 205 */     this.rightHand.field_78809_i = true;
/* 206 */     setRotation(this.rightHand, 0.0F, 0.0F, 0.0F);
/* 207 */     this.leftArm = new ModelRenderer(this, 112, 54);
/* 208 */     this.leftArm.func_78789_a(0.0F, -1.0F, -2.0F, 4, 8, 4);
/* 209 */     this.leftArm.func_78793_a(7.0F, -10.0F, 0.0F);
/* 210 */     this.leftArm.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 211 */     this.leftArm.field_78809_i = true;
/* 212 */     setRotation(this.leftArm, 0.2443461F, 0.0F, 0.0F);
/* 213 */     this.leftForearm = new ModelRenderer(this, 112, 67);
/* 214 */     this.leftForearm.func_78789_a(0.0F, 5.2F, 1.1F, 4, 9, 4);
/* 215 */     this.leftForearm.func_78793_a(7.0F, -10.0F, 0.0F);
/* 216 */     this.leftForearm.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 217 */     this.leftForearm.field_78809_i = true;
/* 218 */     setRotation(this.leftForearm, -0.2617994F, 0.0F, 0.0F);
/* 219 */     this.leftHand = new ModelRenderer(this, 112, 81);
/* 220 */     this.leftHand.func_78789_a(0.0F, 14.0F, -3.0F, 4, 2, 4);
/* 221 */     this.leftHand.func_78793_a(7.0F, -10.0F, 0.0F);
/* 222 */     this.leftHand.func_78787_b(this.field_78090_t, this.field_78089_u);
/* 223 */     this.leftHand.field_78809_i = true;
/* 224 */     setRotation(this.leftHand, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 229 */     super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
/* 230 */     func_78087_a(f, f1, f2, f3, f4, f5, entity);
/* 231 */     this.head.func_78785_a(f5);
/* 232 */     this.rightFoot.func_78785_a(f5);
/* 233 */     this.leftFoot.func_78785_a(f5);
/* 234 */     this.rightLeg.func_78785_a(f5);
/* 235 */     this.rightAnkle.func_78785_a(f5);
/* 236 */     this.rightThigh.func_78785_a(f5);
/* 237 */     this.upperBody.func_78785_a(f5);
/* 238 */     this.lowerBody.func_78785_a(f5);
/* 239 */     this.middleBody.func_78785_a(f5);
/* 240 */     this.neck.func_78785_a(f5);
/* 241 */     this.leftLeg.func_78785_a(f5);
/* 242 */     this.leftAnkle.func_78785_a(f5);
/* 243 */     this.leftThigh.func_78785_a(f5);
/* 244 */     this.nose.func_78785_a(f5);
/* 245 */     this.rightEar.func_78785_a(f5);
/* 246 */     this.leftEar.func_78785_a(f5);
/* 247 */     this.tail.func_78785_a(f5);
/* 248 */     this.tail2.func_78785_a(f5);
/* 249 */     this.tail3.func_78785_a(f5);
/* 250 */     this.tail4.func_78785_a(f5);
/* 251 */     this.rightArm.func_78785_a(f5);
/* 252 */     this.rightForearm.func_78785_a(f5);
/* 253 */     this.rightHand.func_78785_a(f5);
/* 254 */     this.leftArm.func_78785_a(f5);
/* 255 */     this.leftForearm.func_78785_a(f5);
/* 256 */     this.leftHand.func_78785_a(f5);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 261 */     model.field_78795_f = x;
/* 262 */     model.field_78796_g = y;
/* 263 */     model.field_78808_h = z;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_78087_a(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
/* 268 */     this.head.field_78796_g = f3 / 57.295776F;
/* 269 */     this.head.field_78795_f = f4 / 57.295776F;
/*     */     
/* 271 */     this.nose.field_78796_g = this.head.field_78796_g;
/* 272 */     this.nose.field_78795_f = this.head.field_78795_f;
/* 273 */     this.nose.field_78797_d = this.head.field_78797_d;
/* 274 */     this.leftEar.field_78796_g = this.head.field_78796_g;
/* 275 */     this.leftEar.field_78795_f = this.head.field_78795_f;
/* 276 */     this.leftEar.field_78797_d = this.head.field_78797_d;
/* 277 */     this.rightEar.field_78796_g = this.head.field_78796_g;
/* 278 */     this.rightEar.field_78795_f = this.head.field_78795_f;
/* 279 */     this.rightEar.field_78797_d = this.head.field_78797_d;
/*     */     
/* 281 */     float rightAngleArmsX = MathHelper.func_76134_b(f * 0.6662F + 3.1415927F) * 2.0F * f1 * 0.5F;
/* 282 */     float leftAngleArmsX = MathHelper.func_76134_b(f * 0.6662F) * 2.0F * f1 * 0.5F;
/* 283 */     if (this.isSneak || this.isSprinting) {
/*     */       
/* 285 */       rightAngleArmsX = MathHelper.func_76134_b(f * 0.6662F + 3.1415927F) * 1.4F * f1;
/* 286 */       leftAngleArmsX = MathHelper.func_76134_b(f * 0.6662F) * 1.4F * f1;
/*     */     } 
/* 288 */     this.rightArm.field_78795_f = this.xArm + rightAngleArmsX;
/* 289 */     this.rightForearm.field_78795_f = this.xForeArm + rightAngleArmsX;
/* 290 */     this.rightHand.field_78795_f = rightAngleArmsX;
/*     */     
/* 292 */     this.leftArm.field_78795_f = this.xArm + leftAngleArmsX;
/* 293 */     this.leftForearm.field_78795_f = this.xForeArm + leftAngleArmsX;
/* 294 */     this.leftHand.field_78795_f = leftAngleArmsX;
/*     */     
/* 296 */     this.rightArm.field_78808_h = 0.0F;
/* 297 */     this.rightForearm.field_78808_h = 0.0F;
/* 298 */     this.rightHand.field_78808_h = 0.0F;
/* 299 */     this.leftArm.field_78808_h = 0.0F;
/* 300 */     this.leftForearm.field_78808_h = 0.0F;
/* 301 */     this.leftHand.field_78808_h = 0.0F;
/*     */     
/* 303 */     this.rightArm.field_78796_g = 0.0F;
/* 304 */     this.rightForearm.field_78796_g = 0.0F;
/* 305 */     this.rightHand.field_78796_g = 0.0F;
/* 306 */     this.leftArm.field_78796_g = 0.0F;
/* 307 */     this.leftForearm.field_78796_g = 0.0F;
/* 308 */     this.leftHand.field_78796_g = 0.0F;
/*     */ 
/*     */     
/* 311 */     float rightAngleX = MathHelper.func_76134_b(f * 0.6662F) * 1.4F * f1;
/* 312 */     this.rightThigh.field_78795_f = this.xThigh + rightAngleX;
/* 313 */     this.rightLeg.field_78795_f = this.xleg + rightAngleX;
/* 314 */     this.rightAnkle.field_78795_f = this.xAnkle + rightAngleX;
/* 315 */     this.rightFoot.field_78795_f = rightAngleX;
/* 316 */     float leftAngleX = MathHelper.func_76134_b(f * 0.6662F + 3.1415927F) * 1.4F * f1;
/* 317 */     this.leftThigh.field_78795_f = this.xThigh + leftAngleX;
/* 318 */     this.leftLeg.field_78795_f = this.xleg + leftAngleX;
/* 319 */     this.leftAnkle.field_78795_f = this.xAnkle + leftAngleX;
/* 320 */     this.leftFoot.field_78795_f = leftAngleX;
/*     */     
/* 322 */     if (this.field_78095_p > -9990.0F) {
/*     */       
/* 324 */       float s = this.field_78095_p;
/* 325 */       this.upperBody.field_78796_g = MathHelper.func_76126_a(MathHelper.func_76129_c(s) * 3.1415927F * 2.0F) * 0.2F;
/* 326 */       this.rightArm.field_78798_e = MathHelper.func_76126_a(this.upperBody.field_78796_g) * 5.0F;
/* 327 */       this.rightArm.field_78800_c = -MathHelper.func_76134_b(this.upperBody.field_78796_g) * 5.0F;
/* 328 */       this.leftArm.field_78798_e = -MathHelper.func_76126_a(this.upperBody.field_78796_g) * 5.0F;
/* 329 */       this.leftArm.field_78800_c = MathHelper.func_76134_b(this.upperBody.field_78796_g) * 5.0F;
/* 330 */       this.rightArm.field_78796_g += this.upperBody.field_78796_g;
/* 331 */       this.leftArm.field_78796_g += this.upperBody.field_78796_g;
/* 332 */       this.leftArm.field_78795_f += this.upperBody.field_78796_g;
/*     */       
/* 334 */       this.rightForearm.field_78798_e = this.rightArm.field_78798_e;
/* 335 */       this.rightForearm.field_78800_c = this.rightArm.field_78800_c;
/* 336 */       this.leftForearm.field_78798_e = this.leftArm.field_78798_e;
/* 337 */       this.leftForearm.field_78800_c = this.leftArm.field_78800_c;
/* 338 */       this.rightForearm.field_78796_g += this.upperBody.field_78796_g;
/* 339 */       this.leftForearm.field_78796_g += this.upperBody.field_78796_g;
/* 340 */       this.leftForearm.field_78795_f += this.upperBody.field_78796_g;
/*     */       
/* 342 */       this.rightHand.field_78798_e = this.rightArm.field_78798_e;
/* 343 */       this.rightHand.field_78800_c = this.rightArm.field_78800_c;
/* 344 */       this.leftHand.field_78798_e = this.leftArm.field_78798_e;
/* 345 */       this.leftHand.field_78800_c = this.leftArm.field_78800_c;
/* 346 */       this.rightHand.field_78796_g += this.upperBody.field_78796_g;
/* 347 */       this.leftHand.field_78796_g += this.upperBody.field_78796_g;
/* 348 */       this.leftHand.field_78795_f += this.upperBody.field_78796_g;
/*     */       
/* 350 */       s = 1.0F - this.field_78095_p;
/* 351 */       s *= s;
/* 352 */       s *= s;
/* 353 */       s = 1.0F - s;
/* 354 */       float s1 = MathHelper.func_76126_a(s * 3.1415927F);
/* 355 */       float s2 = MathHelper.func_76126_a(this.field_78095_p * 3.1415927F) * -(this.head.field_78795_f - 0.7F) * 0.75F;
/* 356 */       this.rightArm.field_78795_f = (float)(this.rightArm.field_78795_f - s1 * 1.2D + s2);
/* 357 */       this.rightArm.field_78796_g += this.upperBody.field_78796_g * 2.0F;
/* 358 */       this.rightArm.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * 3.1415927F) * -0.4F;
/*     */       
/* 360 */       this.rightForearm.field_78795_f = (float)(this.rightForearm.field_78795_f - s1 * 1.2D + s2);
/* 361 */       this.rightForearm.field_78796_g += this.upperBody.field_78796_g * 2.0F;
/* 362 */       this.rightForearm.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * 3.1415927F) * -0.4F;
/*     */       
/* 364 */       this.rightHand.field_78795_f = (float)(this.rightHand.field_78795_f - s1 * 1.2D + s2);
/* 365 */       this.rightHand.field_78796_g += this.upperBody.field_78796_g * 2.0F;
/* 366 */       this.rightHand.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * 3.1415927F) * -0.4F;
/*     */     } 
/*     */     
/* 369 */     if (this.isSneak || this.isSprinting) {
/*     */       
/* 371 */       this.neck.field_78795_f = this.xNeck + this.sneakX;
/* 372 */       this.upperBody.field_78795_f = this.xUpperBody + this.sneakX;
/* 373 */       this.middleBody.field_78795_f = this.xMiddleBody + this.sneakX;
/* 374 */       this.lowerBody.field_78795_f = this.sneakX;
/*     */       
/* 376 */       this.head.func_78793_a(0.0F, 8.0F, -20.0F);
/*     */ 
/*     */       
/* 379 */       this.nose.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/* 380 */       this.leftEar.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/* 381 */       this.rightEar.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/*     */       
/* 383 */       this.rightArm.func_78793_a(-7.0F, 8.0F, -13.0F);
/* 384 */       this.rightForearm.func_78793_a(-7.0F, 8.0F, -13.0F);
/* 385 */       this.rightHand.func_78793_a(-7.0F, 8.0F, -13.0F);
/*     */       
/* 387 */       this.leftArm.func_78793_a(7.0F, 8.0F, -13.0F);
/* 388 */       this.leftForearm.func_78793_a(7.0F, 8.0F, -13.0F);
/* 389 */       this.leftHand.func_78793_a(7.0F, 8.0F, -13.0F);
/*     */       
/* 391 */       this.tail.func_78793_a(0.0F, 4.0F, 1.0F);
/* 392 */       this.tail2.func_78793_a(0.0F, 6.0F, 5.0F);
/* 393 */       this.tail3.func_78793_a(0.0F, 8.0F, 8.0F);
/* 394 */       this.tail4.func_78793_a(0.0F, 11.5F, 17.0F);
/*     */       
/* 396 */       this.tail.field_78795_f = 1.092638F;
/* 397 */       this.tail2.field_78795_f = 1.183726F;
/* 398 */       this.tail3.field_78795_f = 1.228547F;
/* 399 */       this.tail4.field_78795_f = 1.265725F;
/*     */     }
/*     */     else {
/*     */       
/* 403 */       this.neck.field_78795_f = this.xNeck;
/* 404 */       this.upperBody.field_78795_f = this.xUpperBody;
/* 405 */       this.middleBody.field_78795_f = this.xMiddleBody;
/* 406 */       this.lowerBody.field_78795_f = 0.0F;
/*     */       
/* 408 */       this.head.func_78793_a(0.0F, -17.0F, 1.0F);
/* 409 */       this.nose.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/* 410 */       this.leftEar.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/* 411 */       this.rightEar.func_78793_a(this.head.field_78800_c, this.head.field_78797_d, this.head.field_78798_e);
/*     */       
/* 413 */       this.rightArm.func_78793_a(-7.0F, -10.0F, 0.0F);
/* 414 */       this.rightForearm.func_78793_a(-7.0F, -10.0F, 0.0F);
/* 415 */       this.rightHand.func_78793_a(-7.0F, -10.0F, 0.0F);
/*     */       
/* 417 */       this.leftArm.func_78793_a(7.0F, -10.0F, 0.0F);
/* 418 */       this.leftForearm.func_78793_a(7.0F, -10.0F, 0.0F);
/* 419 */       this.leftHand.func_78793_a(7.0F, -10.0F, 0.0F);
/*     */       
/* 421 */       this.tail.func_78793_a(0.0F, 4.0F, 5.0F);
/* 422 */       this.tail2.func_78793_a(0.0F, 8.0F, 6.0F);
/* 423 */       this.tail3.func_78793_a(0.0F, 10.0F, 8.0F);
/* 424 */       this.tail4.func_78793_a(0.0F, 14.0F, 16.0F);
/*     */       
/* 426 */       this.tail.field_78795_f = 0.3490659F;
/* 427 */       this.tail2.field_78795_f = 0.6632251F;
/* 428 */       this.tail3.field_78795_f = 1.117011F;
/* 429 */       this.tail4.field_78795_f = 1.117011F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_178686_a(ModelBase model) {
/* 436 */     super.func_178686_a(model);
/*     */     
/* 438 */     if (model instanceof ModelBeast) {
/*     */       
/* 440 */       ModelBeast modelbiped = (ModelBeast)model;
/* 441 */       this.heldItemLeft = modelbiped.heldItemLeft;
/* 442 */       this.heldItemRight = modelbiped.heldItemRight;
/* 443 */       this.isSneak = modelbiped.isSneak;
/* 444 */       this.isSprinting = modelbiped.isSprinting;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInvisible(boolean invisible) {
/* 451 */     this.head.field_78806_j = invisible;
/* 452 */     this.neck.field_78806_j = invisible;
/* 453 */     this.rightFoot.field_78806_j = invisible;
/* 454 */     this.leftFoot.field_78806_j = invisible;
/* 455 */     this.rightLeg.field_78806_j = invisible;
/* 456 */     this.rightAnkle.field_78806_j = invisible;
/* 457 */     this.rightThigh.field_78806_j = invisible;
/* 458 */     this.upperBody.field_78806_j = invisible;
/* 459 */     this.lowerBody.field_78806_j = invisible;
/* 460 */     this.middleBody.field_78806_j = invisible;
/* 461 */     this.leftLeg.field_78806_j = invisible;
/* 462 */     this.leftAnkle.field_78806_j = invisible;
/* 463 */     this.leftThigh.field_78806_j = invisible;
/* 464 */     this.nose.field_78806_j = invisible;
/* 465 */     this.rightEar.field_78806_j = invisible;
/* 466 */     this.leftEar.field_78806_j = invisible;
/* 467 */     this.tail.field_78806_j = invisible;
/* 468 */     this.tail2.field_78806_j = invisible;
/* 469 */     this.tail3.field_78806_j = invisible;
/* 470 */     this.tail4.field_78806_j = invisible;
/* 471 */     this.rightArm.field_78806_j = invisible;
/* 472 */     this.rightForearm.field_78806_j = invisible;
/* 473 */     this.rightHand.field_78806_j = invisible;
/* 474 */     this.leftArm.field_78806_j = invisible;
/* 475 */     this.leftForearm.field_78806_j = invisible;
/* 476 */     this.leftHand.field_78806_j = invisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postRenderArm(float scale, EnumHandSide side) {
/* 486 */     getArmForSide(side).func_78794_c(scale);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ModelRenderer getArmForSide(EnumHandSide side) {
/* 491 */     return (side == EnumHandSide.LEFT) ? this.leftHand : this.rightHand;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EnumHandSide getMainHand(Entity entityIn) {
/* 496 */     return (entityIn instanceof EntityLivingBase) ? ((EntityLivingBase)entityIn).func_184591_cq() : EnumHandSide.RIGHT;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\ModelBeast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */