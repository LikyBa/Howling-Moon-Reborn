/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.AbstractClientPlayer;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerArrow;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
/*     */ import net.minecraft.client.renderer.entity.layers.LayerRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EnumPlayerModelParts;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.scoreboard.Score;
/*     */ import net.minecraft.scoreboard.ScoreObjective;
/*     */ import net.minecraft.scoreboard.Scoreboard;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderWerewolfPlayer
/*     */   extends RenderLivingBase
/*     */ {
/*  40 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/*  41 */   private static final ResourceLocation textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/*  42 */   private static final ResourceLocation textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/*  43 */   private static final ResourceLocation textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*     */   
/*     */   public ModelBiped tutModel;
/*     */   private boolean textureSwitch;
/*  47 */   private static Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   private boolean smallArms;
/*     */   
/*     */   public RenderWerewolfPlayer(RenderManager renderManager) {
/*  52 */     this(renderManager, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public RenderWerewolfPlayer(RenderManager renderManager, boolean useSmallArms) {
/*  57 */     super(renderManager, (ModelBase)new ModelWerewolf(), 0.5F);
/*  58 */     this.smallArms = useSmallArms;
/*  59 */     func_177094_a((LayerRenderer)new LayerBipedArmor(this));
/*  60 */     func_177094_a((LayerRenderer)new LayerHeldItem(this));
/*  61 */     func_177094_a((LayerRenderer)new LayerArrow(this));
/*     */ 
/*     */     
/*  64 */     func_177094_a((LayerRenderer)new LayerCustomHead((getPlayerModel()).field_78116_c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation func_110775_a(Entity par1Entity) {
/*  73 */     int temp = ((IWerewolfCapability)((EntityPlayer)par1Entity).getCapability(WereEventHandler.WERE_CAP, null)).getTexture();
/*  74 */     switch (temp) {
/*     */       
/*     */       case 0:
/*  77 */         this; return texture;
/*     */       case 1:
/*  79 */         this; return textureBlack;
/*     */       case 2:
/*  81 */         this; return textureTimber;
/*     */       case 3:
/*  83 */         this; return textureKillerwolf;
/*     */     } 
/*  85 */     if (CustomWerewolfTextures.textureCount >= temp - 3)
/*     */     {
/*  87 */       return CustomWerewolfTextures.customTextures.get(temp - 4);
/*     */     }
/*  89 */     this; return texture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelWerewolf getPlayerModel() {
/*  99 */     return (ModelWerewolf)super.func_177087_b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doRender(AbstractClientPlayer entity, double x, double y, double z, float entityYaw, float partialTicks) {
/* 126 */     if (!entity.func_175144_cb() || this.field_76990_c.field_78734_h == entity) {
/*     */       
/* 128 */       double d0 = y;
/*     */       
/* 130 */       if (entity.func_70093_af() && !(entity instanceof net.minecraft.client.entity.EntityPlayerSP))
/*     */       {
/* 132 */         d0 = y - 0.125D;
/*     */       }
/*     */       
/* 135 */       setModelVisibilities(entity);
/* 136 */       GlStateManager.func_187408_a(GlStateManager.Profile.PLAYER_SKIN);
/* 137 */       super.func_76986_a((EntityLivingBase)entity, x, d0, z, entityYaw, partialTicks);
/* 138 */       GlStateManager.func_187440_b(GlStateManager.Profile.PLAYER_SKIN);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setModelVisibilities(AbstractClientPlayer clientPlayer) {
/* 145 */     ModelWerewolf modelplayer = getPlayerModel();
/*     */     
/* 147 */     if (clientPlayer.func_175149_v()) {
/*     */       
/* 149 */       modelplayer.func_178719_a(false);
/* 150 */       modelplayer.field_78116_c.field_78806_j = true;
/* 151 */       modelplayer.field_178720_f.field_78806_j = true;
/*     */     }
/*     */     else {
/*     */       
/* 155 */       ItemStack itemstack = clientPlayer.func_184614_ca();
/* 156 */       ItemStack itemstack1 = clientPlayer.func_184592_cb();
/* 157 */       modelplayer.func_178719_a(true);
/* 158 */       modelplayer.field_178720_f.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.HAT);
/* 159 */       modelplayer.bipedBodyWear.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.JACKET);
/* 160 */       modelplayer.bipedLeftLegwear.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.LEFT_PANTS_LEG);
/* 161 */       modelplayer.bipedRightLegwear.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.RIGHT_PANTS_LEG);
/* 162 */       modelplayer.bipedLeftArmwear.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.LEFT_SLEEVE);
/* 163 */       modelplayer.bipedRightArmwear.field_78806_j = clientPlayer.func_175148_a(EnumPlayerModelParts.RIGHT_SLEEVE);
/* 164 */       modelplayer.field_78117_n = clientPlayer.func_70093_af();
/* 165 */       ModelBiped.ArmPose modelbiped$armpose = ModelBiped.ArmPose.EMPTY;
/* 166 */       ModelBiped.ArmPose modelbiped$armpose1 = ModelBiped.ArmPose.EMPTY;
/*     */       
/* 168 */       if (!itemstack.func_190926_b()) {
/*     */         
/* 170 */         modelbiped$armpose = ModelBiped.ArmPose.ITEM;
/*     */         
/* 172 */         if (clientPlayer.func_184605_cv() > 0) {
/*     */           
/* 174 */           EnumAction enumaction = itemstack.func_77975_n();
/*     */           
/* 176 */           if (enumaction == EnumAction.BLOCK) {
/*     */             
/* 178 */             modelbiped$armpose = ModelBiped.ArmPose.BLOCK;
/*     */           }
/* 180 */           else if (enumaction == EnumAction.BOW) {
/*     */             
/* 182 */             modelbiped$armpose = ModelBiped.ArmPose.BOW_AND_ARROW;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 187 */       if (!itemstack1.func_190926_b()) {
/*     */         
/* 189 */         modelbiped$armpose1 = ModelBiped.ArmPose.ITEM;
/*     */         
/* 191 */         if (clientPlayer.func_184605_cv() > 0) {
/*     */           
/* 193 */           EnumAction enumaction1 = itemstack1.func_77975_n();
/*     */           
/* 195 */           if (enumaction1 == EnumAction.BLOCK) {
/*     */             
/* 197 */             modelbiped$armpose1 = ModelBiped.ArmPose.BLOCK;
/*     */           }
/* 199 */           else if (enumaction1 == EnumAction.BOW) {
/*     */             
/* 201 */             modelbiped$armpose1 = ModelBiped.ArmPose.BOW_AND_ARROW;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 206 */       if (clientPlayer.func_184591_cq() == EnumHandSide.RIGHT) {
/*     */         
/* 208 */         modelplayer.field_187076_m = modelbiped$armpose;
/* 209 */         modelplayer.field_187075_l = modelbiped$armpose1;
/*     */       }
/*     */       else {
/*     */         
/* 213 */         modelplayer.field_187076_m = modelbiped$armpose1;
/* 214 */         modelplayer.field_187075_l = modelbiped$armpose;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceLocation getEntityTexture(AbstractClientPlayer entity) {
/* 271 */     return entity.func_110306_p();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_82422_c() {
/* 276 */     GlStateManager.func_179109_b(0.0F, 0.1875F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void preRenderCallback(AbstractClientPlayer entitylivingbaseIn, float partialTickTime) {
/* 285 */     float f1 = 0.9375F;
/* 286 */     GlStateManager.func_179152_a(f1, f1, f1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderEntityName(AbstractClientPlayer entityIn, double x, double y, double z, String name, double distanceSq) {
/* 291 */     if (distanceSq < 100.0D) {
/*     */       
/* 293 */       Scoreboard scoreboard = entityIn.func_96123_co();
/* 294 */       ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
/*     */       
/* 296 */       if (scoreobjective != null) {
/*     */         
/* 298 */         Score score = scoreboard.func_96529_a(entityIn.func_70005_c_(), scoreobjective);
/* 299 */         func_147906_a((Entity)entityIn, score.func_96652_c() + " " + scoreobjective.func_96678_d(), x, y, z, 64);
/* 300 */         y += ((func_76983_a()).field_78288_b * 1.15F * 0.025F);
/*     */       } 
/*     */     } 
/*     */     
/* 304 */     func_188296_a((Entity)entityIn, x, y, z, name, distanceSq);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderRightArm(AbstractClientPlayer clientPlayer) {
/* 309 */     float f = 1.0F;
/* 310 */     GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
/* 311 */     float f1 = 0.0625F;
/* 312 */     ModelWerewolf modelplayer = getPlayerModel();
/* 313 */     setModelVisibilities(clientPlayer);
/* 314 */     GlStateManager.func_179147_l();
/* 315 */     modelplayer.field_78095_p = 0.0F;
/* 316 */     modelplayer.field_78117_n = false;
/* 317 */     modelplayer.func_78087_a(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F, (Entity)clientPlayer);
/* 318 */     modelplayer.field_178723_h.field_78795_f = 0.0F;
/* 319 */     modelplayer.field_178723_h.func_78785_a(0.0625F);
/* 320 */     modelplayer.bipedRightArmwear.field_78795_f = 0.0F;
/* 321 */     modelplayer.bipedRightArmwear.func_78785_a(0.0625F);
/* 322 */     GlStateManager.func_179084_k();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderLeftArm(AbstractClientPlayer clientPlayer) {
/* 327 */     float f = 1.0F;
/* 328 */     GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
/* 329 */     float f1 = 0.0625F;
/* 330 */     ModelWerewolf modelplayer = getPlayerModel();
/* 331 */     setModelVisibilities(clientPlayer);
/* 332 */     GlStateManager.func_179147_l();
/* 333 */     modelplayer.field_78117_n = false;
/* 334 */     modelplayer.field_78095_p = 0.0F;
/* 335 */     modelplayer.func_78087_a(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0625F, (Entity)clientPlayer);
/* 336 */     modelplayer.field_178724_i.field_78795_f = 0.0F;
/* 337 */     modelplayer.field_178724_i.func_78785_a(0.0625F);
/* 338 */     modelplayer.bipedLeftArmwear.field_78795_f = 0.0F;
/* 339 */     modelplayer.bipedLeftArmwear.func_78785_a(0.0625F);
/* 340 */     GlStateManager.func_179084_k();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderLivingAt(AbstractClientPlayer entityLivingBaseIn, double x, double y, double z) {
/* 348 */     if (entityLivingBaseIn.func_70089_S() && entityLivingBaseIn.func_70608_bn()) {
/*     */       
/* 350 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x + entityLivingBaseIn.field_71079_bU, y + entityLivingBaseIn.field_71082_cx, z + entityLivingBaseIn.field_71089_bV);
/*     */     }
/*     */     else {
/*     */       
/* 354 */       super.func_77039_a((EntityLivingBase)entityLivingBaseIn, x, y, z);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void applyRotations(AbstractClientPlayer entityLiving, float p_77043_2_, float p_77043_3_, float partialTicks) {
/* 360 */     if (entityLiving.func_70089_S() && entityLiving.func_70608_bn()) {
/*     */       
/* 362 */       GlStateManager.func_179114_b(entityLiving.func_71051_bG(), 0.0F, 1.0F, 0.0F);
/* 363 */       GlStateManager.func_179114_b(func_77037_a((EntityLivingBase)entityLiving), 0.0F, 0.0F, 1.0F);
/* 364 */       GlStateManager.func_179114_b(270.0F, 0.0F, 1.0F, 0.0F);
/*     */     }
/* 366 */     else if (entityLiving.func_184613_cA()) {
/*     */       
/* 368 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/* 369 */       float f = entityLiving.func_184599_cB() + partialTicks;
/* 370 */       float f1 = MathHelper.func_76131_a(f * f / 100.0F, 0.0F, 1.0F);
/* 371 */       GlStateManager.func_179114_b(f1 * (-90.0F - entityLiving.field_70125_A), 1.0F, 0.0F, 0.0F);
/* 372 */       Vec3d vec3d = entityLiving.func_70676_i(partialTicks);
/* 373 */       double d0 = entityLiving.field_70159_w * entityLiving.field_70159_w + entityLiving.field_70179_y * entityLiving.field_70179_y;
/* 374 */       double d1 = vec3d.field_72450_a * vec3d.field_72450_a + vec3d.field_72449_c * vec3d.field_72449_c;
/*     */       
/* 376 */       if (d0 > 0.0D && d1 > 0.0D)
/*     */       {
/* 378 */         double d2 = (entityLiving.field_70159_w * vec3d.field_72450_a + entityLiving.field_70179_y * vec3d.field_72449_c) / Math.sqrt(d0) * Math.sqrt(d1);
/* 379 */         double d3 = entityLiving.field_70159_w * vec3d.field_72449_c - entityLiving.field_70179_y * vec3d.field_72450_a;
/* 380 */         GlStateManager.func_179114_b((float)(Math.signum(d3) * Math.acos(d2)) * 180.0F / 3.1415927F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 385 */       func_77043_a((EntityLivingBase)entityLiving, p_77043_2_, p_77043_3_, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77041_b(EntityLivingBase p_77041_1_, float p_77041_2_) {
/* 395 */     preRenderCallback((AbstractClientPlayer)p_77041_1_, p_77041_2_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_77039_a(EntityLivingBase p_77039_1_, double p_77039_2_, double p_77039_4_, double p_77039_6_) {
/* 403 */     renderLivingAt((AbstractClientPlayer)p_77039_1_, p_77039_2_, p_77039_4_, p_77039_6_);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(EntityLivingBase entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 414 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelBase func_177087_b() {
/* 419 */     return (ModelBase)getPlayerModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_76986_a(Entity entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 430 */     doRender((AbstractClientPlayer)entity, x, y, z, p_76986_8_, partialTicks);
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderWerewolfPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */