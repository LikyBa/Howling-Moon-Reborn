/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityHunter;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderLiving;
/*    */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class RenderHunter
/*    */   extends RenderLiving
/*    */ {
/*    */   protected ResourceLocation texture;
/*    */   
/*    */   public RenderHunter(RenderManager renderManager) {
/* 21 */     super(renderManager, (ModelBase)new ModelHunter(), 0.5F);
/* 22 */     func_177094_a((LayerRenderer)new LayerHeldItem((RenderLivingBase)this));
/* 23 */     func_177094_a((LayerRenderer)new LayerBipedArmor((RenderLivingBase)this)
/*    */         {
/*    */           protected void func_177177_a()
/*    */           {
/* 27 */             this.field_177189_c = (ModelBase)new ModelHunter(0.5F);
/* 28 */             this.field_177186_d = (ModelBase)new ModelHunter(1.0F);
/*    */           }
/*    */         });
/* 31 */     setEntityTexture();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_77041_b(EntityLivingBase entity, float f) {
/* 37 */     preRenderCallbackHunter((EntityHunter)entity, f);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void preRenderCallbackHunter(EntityHunter entity, float f) {}
/*    */ 
/*    */   
/*    */   protected void setEntityTexture() {
/* 46 */     this.texture = new ResourceLocation("howlingmoon:textures/mob/hunter.png");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity p_110775_1_) {
/* 52 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderHunter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */