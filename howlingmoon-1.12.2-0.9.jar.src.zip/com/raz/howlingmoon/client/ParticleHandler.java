/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void onRenderWorldLast(RenderWorldLastEvent event) {
/* 17 */     Tessellator tessellator = Tessellator.func_178181_a();
/*    */ 
/*    */     
/* 20 */     GlStateManager.func_179094_E();
/*    */     
/* 22 */     GlStateManager.func_179132_a(false);
/* 23 */     GlStateManager.func_179147_l();
/* 24 */     GlStateManager.func_179112_b(770, 771);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 30 */     FXScent.dispatchQueuedRenders(tessellator);
/* 31 */     FXSparkle.dispatchQueuedRenders(tessellator);
/*    */ 
/*    */ 
/*    */     
/* 35 */     GlStateManager.func_179084_k();
/* 36 */     GlStateManager.func_179132_a(true);
/*    */     
/* 38 */     GlStateManager.func_179121_F();
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\ParticleHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */