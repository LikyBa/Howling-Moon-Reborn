/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.Particle;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class EntityParticleFXInfrared
/*    */   extends Particle
/*    */ {
/* 13 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:particles/scent");
/*    */ 
/*    */   
/*    */   public EntityParticleFXInfrared(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn, float red, float green, float blue) {
/* 17 */     super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
/*    */     
/* 19 */     this.field_70552_h = red;
/* 20 */     this.field_70553_i = green;
/* 21 */     this.field_70551_j = blue;
/* 22 */     this.field_82339_as = 0.1F;
/* 23 */     func_187115_a(0.02F, 0.02F);
/* 24 */     this.field_187129_i *= 0.0D;
/* 25 */     this.field_187130_j *= 0.0D;
/* 26 */     this.field_187131_k *= 0.0D;
/* 27 */     this.field_70547_e = 10;
/*    */     
/* 29 */     TextureAtlasSprite sprite = Minecraft.func_71410_x().func_147117_R().func_110572_b(texture.toString());
/* 30 */     func_187117_a(sprite);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_187111_c() {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_70537_b() {
/* 41 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\EntityParticleFXInfrared.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */