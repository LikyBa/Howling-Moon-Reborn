/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelBiped;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHandSide;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ModelWerewolf
/*     */   extends ModelBiped
/*     */ {
/*     */   public ModelRenderer bipedLeftArmwear;
/*     */   public ModelRenderer bipedRightArmwear;
/*     */   public ModelRenderer bipedLeftLegwear;
/*     */   public ModelRenderer bipedRightLegwear;
/*     */   public ModelRenderer bipedBodyWear;
/*     */   private ModelRenderer bipedCape;
/*     */   private ModelRenderer bipedDeadmau5Head;
/*     */   private boolean smallArms;
/*     */   ModelRenderer leftEar;
/*     */   ModelRenderer rightEar;
/*     */   ModelRenderer tail;
/*     */   ModelRenderer nose;
/*     */   
/*     */   public ModelWerewolf() {
/*  36 */     this(0.0F);
/*     */   }
/*     */   
/*     */   public ModelWerewolf(float modelSize) {
/*  40 */     this(modelSize, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelWerewolf(float modelSize, boolean smallArmsIn) {
/*  45 */     super(modelSize, 0.0F, 128, 128);
/*  46 */     this.smallArms = smallArmsIn;
/*  47 */     this.bipedDeadmau5Head = new ModelRenderer((ModelBase)this, 24, 0);
/*  48 */     this.bipedDeadmau5Head.func_78790_a(-3.0F, -6.0F, -1.0F, 6, 6, 1, modelSize);
/*  49 */     this.bipedCape = new ModelRenderer((ModelBase)this, 0, 0);
/*  50 */     this.bipedCape.func_78787_b(64, 32);
/*  51 */     this.bipedCape.func_78790_a(-5.0F, 0.0F, -1.0F, 10, 16, 1, modelSize);
/*     */     
/*  53 */     if (smallArmsIn) {
/*     */       
/*  55 */       this.field_178724_i = new ModelRenderer((ModelBase)this, 32, 48);
/*  56 */       this.field_178724_i.func_78790_a(-1.0F, -2.0F, -2.0F, 3, 12, 4, modelSize);
/*  57 */       this.field_178724_i.func_78793_a(5.0F, 2.5F, 0.0F);
/*  58 */       this.field_178723_h = new ModelRenderer((ModelBase)this, 40, 16);
/*  59 */       this.field_178723_h.func_78790_a(-2.0F, -2.0F, -2.0F, 3, 12, 4, modelSize);
/*  60 */       this.field_178723_h.func_78793_a(-5.0F, 2.5F, 0.0F);
/*  61 */       this.bipedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48);
/*  62 */       this.bipedLeftArmwear.func_78790_a(-1.0F, -2.0F, -2.0F, 3, 12, 4, modelSize + 0.25F);
/*  63 */       this.bipedLeftArmwear.func_78793_a(5.0F, 2.5F, 0.0F);
/*  64 */       this.bipedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32);
/*  65 */       this.bipedRightArmwear.func_78790_a(-2.0F, -2.0F, -2.0F, 3, 12, 4, modelSize + 0.25F);
/*  66 */       this.bipedRightArmwear.func_78793_a(-5.0F, 2.5F, 10.0F);
/*     */     }
/*     */     else {
/*     */       
/*  70 */       this.field_178724_i = new ModelRenderer((ModelBase)this, 32, 48);
/*  71 */       this.field_178724_i.func_78790_a(-1.0F, -2.0F, -2.0F, 4, 12, 4, modelSize);
/*  72 */       this.field_178724_i.func_78793_a(5.0F, 2.0F, 0.0F);
/*  73 */       this.bipedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48);
/*  74 */       this.bipedLeftArmwear.func_78790_a(-1.0F, -2.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
/*  75 */       this.bipedLeftArmwear.func_78793_a(5.0F, 2.0F, 0.0F);
/*  76 */       this.bipedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32);
/*  77 */       this.bipedRightArmwear.func_78790_a(-3.0F, -2.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
/*  78 */       this.bipedRightArmwear.func_78793_a(-5.0F, 2.0F, 10.0F);
/*     */     } 
/*     */     
/*  81 */     this.field_178722_k = new ModelRenderer((ModelBase)this, 16, 48);
/*  82 */     this.field_178722_k.func_78790_a(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize);
/*  83 */     this.field_178722_k.func_78793_a(1.9F, 12.0F, 0.0F);
/*  84 */     this.bipedLeftLegwear = new ModelRenderer((ModelBase)this, 0, 48);
/*  85 */     this.bipedLeftLegwear.func_78790_a(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
/*  86 */     this.bipedLeftLegwear.func_78793_a(1.9F, 12.0F, 0.0F);
/*  87 */     this.bipedRightLegwear = new ModelRenderer((ModelBase)this, 0, 32);
/*  88 */     this.bipedRightLegwear.func_78790_a(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
/*  89 */     this.bipedRightLegwear.func_78793_a(-1.9F, 12.0F, 0.0F);
/*  90 */     this.bipedBodyWear = new ModelRenderer((ModelBase)this, 16, 32);
/*  91 */     this.bipedBodyWear.func_78790_a(-4.0F, 0.0F, -2.0F, 8, 12, 4, modelSize + 0.25F);
/*  92 */     this.bipedBodyWear.func_78793_a(0.0F, 0.0F, 0.0F);
/*     */ 
/*     */     
/*  95 */     this.leftEar = new ModelRenderer((ModelBase)this, 0, 0);
/*  96 */     this.leftEar.func_78789_a(2.0F, -10.0F, 0.0F, 2, 2, 1);
/*  97 */     this.leftEar.func_78793_a(0.0F, 0.0F, 0.0F);
/*  98 */     this.leftEar.func_78787_b(64, 64);
/*  99 */     this.leftEar.field_78809_i = true;
/* 100 */     setRotation(this.leftEar, 0.0F, 0.0F, 0.0F);
/*     */     
/* 102 */     this.rightEar = new ModelRenderer((ModelBase)this, 0, 0);
/* 103 */     this.rightEar.func_78789_a(-4.0F, -10.0F, 0.0F, 2, 2, 1);
/* 104 */     this.rightEar.func_78793_a(0.0F, 0.0F, 0.0F);
/* 105 */     this.rightEar.func_78787_b(64, 64);
/* 106 */     this.rightEar.field_78809_i = true;
/* 107 */     setRotation(this.rightEar, 0.0F, 0.0F, 0.0F);
/* 108 */     this.rightEar.field_78809_i = false;
/*     */     
/* 110 */     this.tail = new ModelRenderer((ModelBase)this, 56, 16);
/* 111 */     this.tail.func_78789_a(0.0F, 0.0F, 0.0F, 2, 10, 2);
/* 112 */     this.tail.func_78793_a(-1.0F, 10.0F, 0.0F);
/* 113 */     this.tail.func_78787_b(64, 64);
/* 114 */     this.tail.field_78809_i = true;
/* 115 */     setRotation(this.tail, 0.8F, 0.0F, 0.0F);
/*     */     
/* 117 */     this.nose = new ModelRenderer((ModelBase)this, 25, 0);
/* 118 */     this.nose.func_78789_a(-2.0F, -4.0F, -7.0F, 4, 3, 3);
/* 119 */     this.nose.func_78793_a(0.0F, 0.0F, 0.0F);
/* 120 */     this.nose.func_78787_b(64, 64);
/* 121 */     this.nose.field_78809_i = true;
/* 122 */     setRotation(this.nose, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_78088_a(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 127 */     func_78087_a(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entityIn);
/* 128 */     setRotationAnglesExtras(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entityIn);
/*     */     
/* 130 */     if (entityIn instanceof EntityPlayer) {
/*     */       
/* 132 */       if (((IWerewolfCapability)((EntityPlayer)entityIn).getCapability(WereEventHandler.WERE_CAP, null)).isTransformed()) {
/*     */         
/* 134 */         this.leftEar.func_78785_a(scale);
/* 135 */         this.rightEar.func_78785_a(scale);
/* 136 */         this.tail.func_78785_a(scale);
/* 137 */         this.nose.func_78785_a(scale);
/*     */       } 
/* 139 */       if (((EntityPlayer)entityIn).func_184207_aI())
/*     */       {
/* 141 */         this.field_178723_h.field_78795_f = -3.0F;
/* 142 */         this.field_178724_i.field_78795_f = -3.0F;
/* 143 */         this.bipedRightArmwear.field_78795_f = -3.0F;
/* 144 */         this.bipedLeftArmwear.field_78795_f = -3.0F;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 149 */       this.leftEar.func_78785_a(scale);
/* 150 */       this.rightEar.func_78785_a(scale);
/* 151 */       this.tail.func_78785_a(scale);
/* 152 */       this.nose.func_78785_a(scale);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     GlStateManager.func_179094_E();
/*     */     
/* 192 */     if (this.field_78091_s) {
/*     */       
/* 194 */       float f = 2.0F;
/* 195 */       GlStateManager.func_179152_a(0.75F, 0.75F, 0.75F);
/* 196 */       GlStateManager.func_179109_b(0.0F, 16.0F * scale, 0.0F);
/* 197 */       this.field_78116_c.func_78785_a(scale);
/* 198 */       GlStateManager.func_179121_F();
/* 199 */       GlStateManager.func_179094_E();
/* 200 */       GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/* 201 */       GlStateManager.func_179109_b(0.0F, 24.0F * scale, 0.0F);
/* 202 */       this.field_78115_e.func_78785_a(scale);
/* 203 */       this.field_178723_h.func_78785_a(scale);
/* 204 */       this.field_178724_i.func_78785_a(scale);
/* 205 */       this.field_178721_j.func_78785_a(scale);
/* 206 */       this.field_178722_k.func_78785_a(scale);
/* 207 */       this.field_178720_f.func_78785_a(scale);
/*     */     }
/*     */     else {
/*     */       
/* 211 */       if (entityIn.func_70093_af())
/*     */       {
/* 213 */         GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
/*     */       }
/*     */       
/* 216 */       this.field_78116_c.func_78785_a(scale);
/* 217 */       this.field_78115_e.func_78785_a(scale);
/* 218 */       this.field_178723_h.func_78785_a(scale);
/* 219 */       this.field_178724_i.func_78785_a(scale);
/* 220 */       this.field_178721_j.func_78785_a(scale);
/* 221 */       this.field_178722_k.func_78785_a(scale);
/* 222 */       this.field_178720_f.func_78785_a(scale);
/*     */     } 
/*     */     
/* 225 */     GlStateManager.func_179121_F();
/* 226 */     GlStateManager.func_179094_E();
/*     */     
/* 228 */     if (this.field_78091_s) {
/*     */       
/* 230 */       float f = 2.0F;
/* 231 */       GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/* 232 */       GlStateManager.func_179109_b(0.0F, 24.0F * scale, 0.0F);
/* 233 */       this.bipedLeftLegwear.func_78785_a(scale);
/* 234 */       this.bipedRightLegwear.func_78785_a(scale);
/* 235 */       this.bipedLeftArmwear.func_78785_a(scale);
/* 236 */       this.bipedRightArmwear.func_78785_a(scale);
/* 237 */       this.bipedBodyWear.func_78785_a(scale);
/*     */     }
/*     */     else {
/*     */       
/* 241 */       if (entityIn.func_70093_af())
/*     */       {
/* 243 */         GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
/*     */       }
/*     */       
/* 246 */       this.bipedLeftLegwear.func_78785_a(scale);
/* 247 */       this.bipedRightLegwear.func_78785_a(scale);
/* 248 */       this.bipedLeftArmwear.func_78785_a(scale);
/* 249 */       this.bipedRightArmwear.func_78785_a(scale);
/* 250 */       this.bipedBodyWear.func_78785_a(scale);
/*     */     } 
/*     */     
/* 253 */     GlStateManager.func_179121_F();
/*     */   }
/*     */ 
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 258 */     model.field_78795_f = x;
/* 259 */     model.field_78796_g = y;
/* 260 */     model.field_78808_h = z;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_78087_a(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
/* 266 */     super.func_78087_a(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
/* 267 */     func_178685_a(this.field_178722_k, this.bipedLeftLegwear);
/* 268 */     func_178685_a(this.field_178721_j, this.bipedRightLegwear);
/* 269 */     func_178685_a(this.field_178724_i, this.bipedLeftArmwear);
/* 270 */     func_178685_a(this.field_178723_h, this.bipedRightArmwear);
/* 271 */     func_178685_a(this.field_78115_e, this.bipedBodyWear);
/*     */     
/* 273 */     if (entityIn.func_70093_af()) {
/*     */       
/* 275 */       this.bipedCape.field_78797_d = 2.0F;
/*     */     }
/*     */     else {
/*     */       
/* 279 */       this.bipedCape.field_78797_d = 0.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotationAnglesExtras(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
/* 290 */     this.nose.field_78796_g = this.field_78116_c.field_78796_g;
/* 291 */     this.nose.field_78795_f = this.field_78116_c.field_78795_f;
/* 292 */     this.nose.field_78797_d = this.field_78116_c.field_78797_d;
/* 293 */     this.leftEar.field_78796_g = this.field_78116_c.field_78796_g;
/* 294 */     this.leftEar.field_78795_f = this.field_78116_c.field_78795_f;
/* 295 */     this.leftEar.field_78797_d = this.field_78116_c.field_78797_d;
/* 296 */     this.rightEar.field_78796_g = this.field_78116_c.field_78796_g;
/* 297 */     this.rightEar.field_78795_f = this.field_78116_c.field_78795_f;
/* 298 */     this.rightEar.field_78797_d = this.field_78116_c.field_78797_d;
/*     */     
/* 300 */     if (this.field_78117_n) {
/*     */       
/* 302 */       this.field_78116_c.field_78797_d += 3.0F;
/* 303 */       this.field_78116_c.field_78797_d += 3.0F;
/* 304 */       this.field_78116_c.field_78797_d += 3.0F;
/* 305 */       this.tail.field_78797_d = 13.0F;
/* 306 */       this.tail.field_78798_e = 5.5F;
/* 307 */       this.tail.field_78795_f = 1.2F;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 312 */       this.tail.field_78797_d = 10.0F;
/* 313 */       this.tail.field_78798_e = 0.0F;
/* 314 */       this.tail.field_78795_f = 0.8F;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderDeadmau5Head(float scale) {
/* 320 */     func_178685_a(this.field_78116_c, this.bipedDeadmau5Head);
/* 321 */     this.bipedDeadmau5Head.field_78800_c = 0.0F;
/* 322 */     this.bipedDeadmau5Head.field_78797_d = 0.0F;
/* 323 */     this.bipedDeadmau5Head.func_78785_a(scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderCape(float scale) {
/* 328 */     this.bipedCape.func_78785_a(scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_178719_a(boolean visible) {
/* 333 */     super.func_178719_a(visible);
/* 334 */     this.bipedLeftArmwear.field_78806_j = visible;
/* 335 */     this.bipedRightArmwear.field_78806_j = visible;
/* 336 */     this.bipedLeftLegwear.field_78806_j = visible;
/* 337 */     this.bipedRightLegwear.field_78806_j = visible;
/* 338 */     this.bipedBodyWear.field_78806_j = visible;
/* 339 */     this.bipedCape.field_78806_j = visible;
/* 340 */     this.bipedDeadmau5Head.field_78806_j = visible;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_187073_a(float scale, EnumHandSide side) {
/* 345 */     ModelRenderer modelrenderer = func_187074_a(side);
/*     */     
/* 347 */     if (this.smallArms) {
/*     */       
/* 349 */       float f = 0.5F * ((side == EnumHandSide.RIGHT) ? true : -1);
/* 350 */       modelrenderer.field_78800_c += f;
/* 351 */       modelrenderer.func_78794_c(scale);
/* 352 */       modelrenderer.field_78800_c -= f;
/*     */     }
/*     */     else {
/*     */       
/* 356 */       modelrenderer.func_78794_c(scale);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\ModelWerewolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */