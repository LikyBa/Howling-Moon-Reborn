/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
/*    */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerRenderer;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class LayerBeastHeldItem
/*    */   implements LayerRenderer<EntityLivingBase>
/*    */ {
/*    */   protected final RenderLivingBase<?> livingEntityRenderer;
/*    */   
/*    */   public LayerBeastHeldItem(RenderLivingBase<?> livingEntityRendererIn) {
/* 27 */     this.livingEntityRenderer = livingEntityRendererIn;
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_177141_a(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
/* 32 */     boolean flag = (entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT);
/* 33 */     ItemStack itemstack = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
/* 34 */     ItemStack itemstack1 = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();
/*    */     
/* 36 */     if (!itemstack.func_190926_b() || !itemstack1.func_190926_b()) {
/*    */       
/* 38 */       GlStateManager.func_179094_E();
/*    */       
/* 40 */       if ((this.livingEntityRenderer.func_177087_b()).field_78091_s) {
/*    */         
/* 42 */         float f = 0.5F;
/* 43 */         GlStateManager.func_179109_b(0.0F, 0.625F, 0.0F);
/* 44 */         GlStateManager.func_179114_b(-20.0F, -1.0F, 0.0F, 0.0F);
/* 45 */         GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/*    */       } 
/*    */       
/* 48 */       renderHeldItem(entitylivingbaseIn, itemstack1, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT);
/* 49 */       renderHeldItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT);
/* 50 */       GlStateManager.func_179121_F();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void renderHeldItem(EntityLivingBase p_188358_1_, ItemStack p_188358_2_, ItemCameraTransforms.TransformType p_188358_3_, EnumHandSide handSide) {
/* 56 */     if (!p_188358_2_.func_190926_b()) {
/*    */       
/* 58 */       GlStateManager.func_179094_E();
/*    */       
/* 60 */       if (p_188358_1_.func_70093_af())
/*    */       {
/* 62 */         GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
/*    */       }
/*    */       
/* 65 */       ((ModelBeast)this.livingEntityRenderer.func_177087_b()).postRenderArm(0.0625F, handSide);
/* 66 */       GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/* 67 */       GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
/* 68 */       boolean flag = (handSide == EnumHandSide.LEFT);
/* 69 */       GlStateManager.func_179109_b((flag ? -1 : true) / 8.0F, 0.125F, -1.0F);
/*    */       
/* 71 */       Minecraft.func_71410_x().func_175597_ag().func_187462_a(p_188358_1_, p_188358_2_, p_188358_3_, flag);
/* 72 */       GlStateManager.func_179121_F();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_177142_b() {
/* 78 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\LayerBeastHeldItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */