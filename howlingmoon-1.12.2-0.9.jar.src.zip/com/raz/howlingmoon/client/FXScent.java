/*     */ package com.raz.howlingmoon.client;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXScent
/*     */   extends Particle
/*     */ {
/*  22 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/particles/scent.png");
/*     */ 
/*     */   
/*  25 */   private static final Queue<FXScent> queuedDepthIgnoringRenders = new ArrayDeque<>();
/*     */   
/*     */   private float f;
/*     */   
/*     */   private float f1;
/*     */   
/*     */   private float f2;
/*     */   
/*     */   private float f3;
/*     */   private float f4;
/*     */   private float f5;
/*     */   
/*     */   public FXScent(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, float red, float green, float blue, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
/*  38 */     super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
/*     */     
/*  40 */     this.field_70552_h = red;
/*  41 */     this.field_70553_i = green;
/*  42 */     this.field_70551_j = blue;
/*  43 */     this.field_82339_as = 0.35F;
/*  44 */     func_187115_a(0.02F, 0.02F);
/*  45 */     this.field_70544_f *= this.field_187136_p.nextFloat() * 0.8F + 0.5F;
/*  46 */     this.field_187129_i *= 0.019999999552965164D;
/*  47 */     this.field_187130_j *= 0.019999999552965164D;
/*  48 */     this.field_187131_k *= 0.019999999552965164D;
/*  49 */     this.field_70547_e = (int)(20.0D / (Math.random() * 0.8D + 0.2D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dispatchQueuedRenders(Tessellator tessellator) {
/*  59 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.75F);
/*  60 */     (Minecraft.func_71410_x()).field_71446_o.func_110577_a(texture);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     if (!queuedDepthIgnoringRenders.isEmpty()) {
/*  70 */       GlStateManager.func_179097_i();
/*  71 */       tessellator.func_178180_c().func_181668_a(7, DefaultVertexFormats.field_181711_k);
/*  72 */       for (FXScent wisp : queuedDepthIgnoringRenders)
/*  73 */         wisp.renderQueued(tessellator, false); 
/*  74 */       tessellator.func_78381_a();
/*  75 */       GlStateManager.func_179126_j();
/*     */     } 
/*     */ 
/*     */     
/*  79 */     queuedDepthIgnoringRenders.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderQueued(Tessellator tessellator, boolean depthEnabled) {
/*  93 */     float f10 = 0.5F * this.field_70544_f;
/*  94 */     float f11 = (float)(this.field_187123_c + (this.field_187126_f - this.field_187123_c) * this.f - field_70556_an);
/*  95 */     float f12 = (float)(this.field_187124_d + (this.field_187127_g - this.field_187124_d) * this.f - field_70554_ao);
/*  96 */     float f13 = (float)(this.field_187125_e + (this.field_187128_h - this.field_187125_e) * this.f - field_70555_ap);
/*  97 */     int combined = 15728880;
/*  98 */     int k3 = combined >> 16 & 0xFFFF;
/*  99 */     int l3 = combined & 0xFFFF;
/* 100 */     tessellator.func_178180_c().func_181662_b((f11 - this.f1 * f10 - this.f4 * f10), (f12 - this.f2 * f10), (f13 - this.f3 * f10 - this.f5 * f10)).func_187315_a(0.0D, 1.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 101 */     tessellator.func_178180_c().func_181662_b((f11 - this.f1 * f10 + this.f4 * f10), (f12 + this.f2 * f10), (f13 - this.f3 * f10 + this.f5 * f10)).func_187315_a(1.0D, 1.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 102 */     tessellator.func_178180_c().func_181662_b((f11 + this.f1 * f10 + this.f4 * f10), (f12 + this.f2 * f10), (f13 + this.f3 * f10 + this.f5 * f10)).func_187315_a(1.0D, 0.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/* 103 */     tessellator.func_178180_c().func_181662_b((f11 + this.f1 * f10 - this.f4 * f10), (f12 - this.f2 * f10), (f13 + this.f3 * f10 - this.f5 * f10)).func_187315_a(0.0D, 0.0D).func_187314_a(k3, l3).func_181666_a(this.field_70552_h, this.field_70553_i, this.field_70551_j, this.field_82339_as).func_181675_d();
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180434_a(BufferBuilder wr, Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
/* 108 */     this.f = f;
/* 109 */     this.f1 = f1;
/* 110 */     this.f2 = f2;
/* 111 */     this.f3 = f3;
/* 112 */     this.f4 = f4;
/* 113 */     this.f5 = f5;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     queuedDepthIgnoringRenders.add(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_189213_a() {
/* 123 */     this.field_187123_c = this.field_187126_f;
/* 124 */     this.field_187124_d = this.field_187127_g;
/* 125 */     this.field_187125_e = this.field_187128_h;
/*     */     
/* 127 */     if (this.field_70546_d++ >= this.field_70547_e) {
/* 128 */       func_187112_i();
/*     */     }
/* 130 */     this.field_187130_j -= 0.04D * this.field_70545_g;
/* 131 */     this.field_187126_f += this.field_187129_i;
/* 132 */     this.field_187127_g += this.field_187130_j;
/* 133 */     this.field_187128_h += this.field_187131_k;
/* 134 */     this.field_187129_i *= 0.9800000190734863D;
/* 135 */     this.field_187130_j *= 0.9800000190734863D;
/* 136 */     this.field_187131_k *= 0.9800000190734863D;
/*     */   }
/*     */   
/*     */   public void setGravity(float value) {
/* 140 */     this.field_70545_g = value;
/*     */   }
/*     */   
/*     */   public void setSpeed(float mx, float my, float mz) {
/* 144 */     this.field_187129_i = mx;
/* 145 */     this.field_187130_j = my;
/* 146 */     this.field_187131_k = mz;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\FXScent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */