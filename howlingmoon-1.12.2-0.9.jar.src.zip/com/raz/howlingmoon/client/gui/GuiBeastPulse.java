/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import com.raz.howlingmoon.WereEventHandler;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiBeastPulse
/*    */   extends Gui
/*    */ {
/*    */   private Minecraft mc;
/* 22 */   private static final ResourceLocation texture = new ResourceLocation("howlingmoon:textures/gui/werewolf_rage.png");
/*    */ 
/*    */   
/*    */   public GuiBeastPulse(Minecraft mc) {
/* 26 */     this.mc = mc;
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderExperienceBar(RenderGameOverlayEvent event) {
/* 32 */     if (event.isCancelable() || event.getType() != RenderGameOverlayEvent.ElementType.EXPERIENCE) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 37 */     IWerewolfCapability wolf = (IWerewolfCapability)this.mc.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*    */     
/* 39 */     if (wolf.getDisplayRage()) {
/*    */       float alpha;
/*    */       
/* 42 */       if (wolf.getTick() - 2400 < 51) {
/* 43 */         alpha = (wolf.getTick() - 2400) / 50.0F;
/*    */       } else {
/* 45 */         alpha = 1.0F - (wolf.getTick() - 2450) / 50.0F;
/* 46 */       }  GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, alpha);
/*    */ 
/*    */       
/* 49 */       this.mc.func_110434_K().func_110577_a(texture);
/*    */       
/* 51 */       func_73729_b(0, 0, 0, 0, this.mc.field_71443_c, this.mc.field_71440_d);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiBeastPulse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */