/*     */ package com.raz.howlingmoon.client.gui;
/*     */ 
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.WereScent;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncWereCapsMessage;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.client.config.GuiSlider;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiScentColors
/*     */   extends GuiScreen
/*     */ {
/*  39 */   public static final ResourceLocation background = new ResourceLocation("howlingmoon:textures/particles/scent.png");
/*     */   
/*  41 */   private static final ResourceLocation CREATIVE_INVENTORY_TABS = new ResourceLocation("textures/gui/container/creative_inventory/tabs.png");
/*     */   
/*     */   private int currentPage;
/*     */   
/*     */   private float currentScroll;
/*     */   
/*     */   private boolean isScrolling;
/*     */   
/*     */   private boolean wasClicking;
/*     */   
/*     */   protected int guiLeft;
/*     */   
/*     */   protected int guiRight;
/*     */   
/*     */   protected int guiTop;
/*     */   
/*     */   protected int guiBottom;
/*     */   
/*     */   private int listSize;
/*     */   
/*     */   private int currentIndex;
/*     */   
/*     */   private int newColor;
/*     */   private boolean scentPopup;
/*  65 */   private ArrayList<WereScent> mobs = new ArrayList<>(); private GuiButton buttonMobs; private GuiButton buttonAnimals; private GuiButton buttonCreatures; private GuiButton buttonOthers; private GuiButton buttonEdit; private GuiButton buttonClear; private GuiButton buttonIgnore; private GuiButton buttonCancel; private GuiSlider sliderRedColor; private GuiSlider sliderGreenColor; private GuiSlider sliderBlueColor; private WereScent selected;
/*  66 */   private ArrayList<WereScent> animals = new ArrayList<>();
/*  67 */   private ArrayList<WereScent> creatures = new ArrayList<>();
/*  68 */   private ArrayList<WereScent> others = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public void func_73866_w_() {
/*  72 */     this.field_146292_n.clear();
/*  73 */     this.mobs.clear();
/*  74 */     this.animals.clear();
/*  75 */     this.creatures.clear();
/*  76 */     this.others.clear();
/*  77 */     this.currentPage = 0;
/*  78 */     this.currentIndex = 0;
/*  79 */     this.guiLeft = 20;
/*  80 */     this.guiRight = this.field_146294_l - 20;
/*  81 */     this.guiTop = 40;
/*  82 */     this.guiBottom = this.field_146295_m - 40;
/*  83 */     this.listSize = (this.field_146295_m - 110) / 20;
/*  84 */     this.newColor = -16777216;
/*  85 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*  86 */     for (Map.Entry<Class<? extends Entity>, Integer> entry : (Iterable<Map.Entry<Class<? extends Entity>, Integer>>)wolf.getScentTree().entrySet()) {
/*     */ 
/*     */       
/*  89 */       if (EntityMob.class.isAssignableFrom(entry.getKey())) {
/*     */         
/*  91 */         if (((Class)entry.getKey()).equals(EntityMob.class)) {
/*  92 */           this.mobs.add(0, new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */         } 
/*  94 */         this.mobs.add(new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */       } 
/*  96 */       if (EntityAnimal.class.isAssignableFrom(entry.getKey())) {
/*     */         
/*  98 */         if (((Class)entry.getKey()).equals(EntityAnimal.class)) {
/*  99 */           this.animals.add(0, new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */         } 
/* 101 */         this.animals.add(new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */       } 
/* 103 */       if (EntityCreature.class.isAssignableFrom(entry.getKey())) {
/*     */         
/* 105 */         if (((Class)entry.getKey()).equals(EntityCreature.class)) {
/* 106 */           this.creatures.add(0, new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */         } 
/* 108 */         this.creatures.add(new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue()));
/*     */         
/*     */         continue;
/*     */       } 
/* 112 */       if (((Class)entry.getKey()).equals(EntityLiving.class)) {
/* 113 */         this.others.add(0, new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue())); continue;
/*     */       } 
/* 115 */       this.others.add(new WereScent(entry.getKey(), ((Integer)entry.getValue()).intValue()));
/*     */     } 
/*     */ 
/*     */     
/* 119 */     this.buttonMobs = new GuiButton(0, this.field_146294_l / 5 - 30, 15, 60, 20, I18n.func_135052_a("werewolf.scent.mobs", new Object[0]));
/* 120 */     this.field_146292_n.add(this.buttonMobs);
/* 121 */     this.buttonAnimals = new GuiButton(1, 2 * this.field_146294_l / 5 - 30, 15, 60, 20, I18n.func_135052_a("werewolf.scent.animals", new Object[0]));
/* 122 */     this.field_146292_n.add(this.buttonAnimals);
/* 123 */     this.buttonCreatures = new GuiButton(2, 3 * this.field_146294_l / 5 - 30, 15, 60, 20, I18n.func_135052_a("werewolf.scent.creatures", new Object[0]));
/* 124 */     this.field_146292_n.add(this.buttonCreatures);
/* 125 */     this.buttonOthers = new GuiButton(3, this.field_146294_l - this.field_146294_l / 5 - 30, 15, 60, 20, I18n.func_135052_a("werewolf.scent.others", new Object[0]));
/* 126 */     this.field_146292_n.add(this.buttonOthers);
/*     */     
/* 128 */     this.buttonEdit = new GuiButton(4, this.field_146294_l / 4 - 25, 20, 50, 20, I18n.func_135052_a("werewolf.scent.edit", new Object[0]));
/* 129 */     this.field_146292_n.add(this.buttonEdit);
/* 130 */     this.buttonClear = new GuiButton(5, this.field_146294_l / 2 - 25, 20, 50, 20, I18n.func_135052_a("werewolf.scent.clear", new Object[0]));
/* 131 */     this.field_146292_n.add(this.buttonClear);
/* 132 */     this.buttonIgnore = new GuiButton(6, this.field_146294_l - this.field_146294_l / 4 - 25, 20, 50, 20, I18n.func_135052_a("werewolf.scent.ignore", new Object[0]));
/* 133 */     this.field_146292_n.add(this.buttonIgnore);
/* 134 */     this.buttonCancel = new GuiButton(7, this.field_146294_l / 2 - 25, this.guiBottom, 50, 20, I18n.func_135052_a("werewolf.scent.cancel", new Object[0]));
/* 135 */     this.field_146292_n.add(this.buttonCancel);
/* 136 */     this.sliderRedColor = new GuiSlider(8, this.field_146294_l / 2 - 128, this.field_146295_m / 2 - 30, 256, 20, "Red: ", "", 0.0D, 255.0D, 0.0D, false, true);
/* 137 */     this.field_146292_n.add(this.sliderRedColor);
/* 138 */     this.sliderGreenColor = new GuiSlider(9, this.field_146294_l / 2 - 128, this.field_146295_m / 2, 256, 20, "Green: ", "", 0.0D, 255.0D, 0.0D, false, true);
/* 139 */     this.field_146292_n.add(this.sliderGreenColor);
/* 140 */     this.sliderBlueColor = new GuiSlider(10, this.field_146294_l / 2 - 128, this.field_146295_m / 2 + 30, 256, 20, "Blue: ", "", 0.0D, 255.0D, 0.0D, false, true);
/* 141 */     this.field_146292_n.add(this.sliderBlueColor);
/*     */     
/* 143 */     this.buttonEdit.field_146125_m = false;
/* 144 */     this.buttonClear.field_146125_m = false;
/* 145 */     this.buttonIgnore.field_146125_m = false;
/* 146 */     this.buttonCancel.field_146125_m = false;
/* 147 */     this.sliderRedColor.field_146125_m = false;
/* 148 */     this.sliderGreenColor.field_146125_m = false;
/* 149 */     this.sliderBlueColor.field_146125_m = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73876_c() {
/* 158 */     this.buttonMobs.field_146125_m = !this.scentPopup;
/* 159 */     this.buttonAnimals.field_146125_m = !this.scentPopup;
/* 160 */     this.buttonCreatures.field_146125_m = !this.scentPopup;
/* 161 */     this.buttonOthers.field_146125_m = !this.scentPopup;
/*     */     
/* 163 */     this.buttonEdit.field_146125_m = this.scentPopup;
/* 164 */     this.buttonClear.field_146125_m = this.scentPopup;
/* 165 */     this.buttonIgnore.field_146125_m = this.scentPopup;
/* 166 */     this.buttonCancel.field_146125_m = this.scentPopup;
/* 167 */     this.sliderRedColor.field_146125_m = this.scentPopup;
/* 168 */     this.sliderGreenColor.field_146125_m = this.scentPopup;
/* 169 */     this.sliderBlueColor.field_146125_m = this.scentPopup;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_146284_a(GuiButton b) throws IOException {
/* 175 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 176 */     switch (b.field_146127_k) {
/*     */       case 0:
/* 178 */         this.currentPage = 0; break;
/*     */       case 1:
/* 180 */         this.currentPage = 1; break;
/*     */       case 2:
/* 182 */         this.currentPage = 2; break;
/*     */       case 3:
/* 184 */         this.currentPage = 3;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 189 */         wolf.setScentColor(this.selected.entity, this.newColor);
/* 190 */         PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/* 191 */         this.selected.color = this.newColor;
/* 192 */         if (this.currentPage == 0) {
/* 193 */           this.mobs.set(this.currentIndex, this.selected);
/* 194 */         } else if (this.currentPage == 1) {
/* 195 */           this.animals.set(this.currentIndex, this.selected);
/* 196 */         } else if (this.currentPage == 2) {
/* 197 */           this.creatures.set(this.currentIndex, this.selected);
/*     */         } else {
/* 199 */           this.others.set(this.currentIndex, this.selected);
/* 200 */         }  this.selected = null;
/* 201 */         this.scentPopup = false;
/*     */         break;
/*     */       case 5:
/* 204 */         wolf.setScentColor(this.selected.entity, 0);
/* 205 */         PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/* 206 */         this.selected.color = 0;
/* 207 */         if (this.currentPage == 0) {
/* 208 */           this.mobs.set(this.currentIndex, this.selected);
/* 209 */         } else if (this.currentPage == 1) {
/* 210 */           this.animals.set(this.currentIndex, this.selected);
/* 211 */         } else if (this.currentPage == 2) {
/* 212 */           this.creatures.set(this.currentIndex, this.selected);
/*     */         } else {
/* 214 */           this.others.set(this.currentIndex, this.selected);
/* 215 */         }  this.selected = null;
/* 216 */         this.scentPopup = false;
/*     */         break;
/*     */       case 6:
/* 219 */         wolf.setScentColor(this.selected.entity, 1);
/* 220 */         PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/* 221 */         this.selected.color = 1;
/* 222 */         if (this.currentPage == 0) {
/* 223 */           this.mobs.set(this.currentIndex, this.selected);
/* 224 */         } else if (this.currentPage == 1) {
/* 225 */           this.animals.set(this.currentIndex, this.selected);
/* 226 */         } else if (this.currentPage == 2) {
/* 227 */           this.creatures.set(this.currentIndex, this.selected);
/*     */         } else {
/* 229 */           this.others.set(this.currentIndex, this.selected);
/* 230 */         }  this.selected = null;
/* 231 */         this.scentPopup = false;
/*     */         break;
/*     */       case 7:
/* 234 */         this.selected = null;
/* 235 */         this.scentPopup = false;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_146274_d() throws IOException {
/* 245 */     super.func_146274_d();
/* 246 */     int i = Mouse.getEventDWheel();
/*     */     
/* 248 */     if (i != 0 && needsScrollBars()) {
/*     */       
/* 250 */       int j = 5;
/*     */       
/* 252 */       if (i > 0)
/*     */       {
/* 254 */         i = 1;
/*     */       }
/*     */       
/* 257 */       if (i < 0)
/*     */       {
/* 259 */         i = -1;
/*     */       }
/*     */       
/* 262 */       this.currentScroll = (float)(this.currentScroll - i / j);
/* 263 */       this.currentScroll = MathHelper.func_76131_a(this.currentScroll, 0.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 273 */     func_146276_q_();
/*     */     
/* 275 */     if (!this.scentPopup) {
/*     */       
/* 277 */       drawScrollBar(mouseX, mouseY, partialTicks);
/*     */ 
/*     */       
/* 280 */       boolean flag = Mouse.isButtonDown(0);
/* 281 */       int i = this.guiRight;
/* 282 */       int j = this.guiTop;
/*     */       
/* 284 */       int l = j + 18;
/* 285 */       int i1 = i + 14;
/* 286 */       int j1 = this.guiBottom;
/*     */       
/* 288 */       if (!this.wasClicking && flag && mouseX >= i && mouseY >= l && mouseX < i1 && mouseY < j1)
/*     */       {
/* 290 */         this.isScrolling = needsScrollBars();
/*     */       }
/*     */       
/* 293 */       if (!flag)
/*     */       {
/* 295 */         this.isScrolling = false;
/*     */       }
/*     */       
/* 298 */       this.wasClicking = flag;
/*     */       
/* 300 */       if (this.isScrolling) {
/*     */         
/* 302 */         this.currentScroll = ((mouseY - l) - 7.5F) / ((j1 - l) - 15.0F);
/* 303 */         this.currentScroll = MathHelper.func_76131_a(this.currentScroll, 0.0F, 1.0F);
/*     */       } 
/*     */ 
/*     */       
/* 307 */       switch (this.currentPage) {
/*     */         case 0:
/* 309 */           drawMobLayer(mouseX, mouseY, partialTicks); break;
/*     */         case 1:
/* 311 */           drawAnimalLayer(mouseX, mouseY, partialTicks); break;
/*     */         case 2:
/* 313 */           drawCreatureLayer(mouseX, mouseY, partialTicks); break;
/*     */         case 3:
/* 315 */           drawOtherLayer(mouseX, mouseY, partialTicks);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } else {
/* 321 */       this; func_73734_a(this.field_146294_l / 2 - 10, this.guiTop + 10, this.field_146294_l / 2 + 10, this.guiTop + 20, this.selected.color);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 328 */       this.newColor = 255;
/* 329 */       this.newColor = (this.newColor << 8) + this.sliderRedColor.getValueInt();
/* 330 */       this.newColor = (this.newColor << 8) + this.sliderGreenColor.getValueInt();
/* 331 */       this.newColor = (this.newColor << 8) + this.sliderBlueColor.getValueInt();
/* 332 */       this; func_73734_a(this.field_146294_l / 2 - 10, this.guiTop + 30, this.field_146294_l / 2 + 10, this.guiTop + 40, this.newColor);
/*     */     } 
/*     */     
/* 335 */     super.func_73863_a(mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawMobLayer(int mouseX, int mouseY, float partialTicks) {
/* 340 */     drawScrollList(mouseX, mouseY, partialTicks, this.mobs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawAnimalLayer(int mouseX, int mouseY, float partialTicks) {
/* 365 */     drawScrollList(mouseX, mouseY, partialTicks, this.animals);
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawCreatureLayer(int mouseX, int mouseY, float partialTicks) {
/* 370 */     drawScrollList(mouseX, mouseY, partialTicks, this.creatures);
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawOtherLayer(int mouseX, int mouseY, float partialTicks) {
/* 375 */     drawScrollList(mouseX, mouseY, partialTicks, this.others);
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawScrollList(int mouseX, int mouseY, float partialTicks, ArrayList<WereScent> list) {
/* 380 */     int y = this.guiTop + 30;
/* 381 */     int start = 1;
/* 382 */     int end = list.size();
/* 383 */     WereScent highlight = null;
/* 384 */     WereScent current = list.get(0);
/*     */     
/* 386 */     if (((WereScent)list.get(0)).color == 0) {
/* 387 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.scent.specific", new Object[0]), this.field_146294_l / 2 - this.field_146289_q.func_78256_a(I18n.func_135052_a("werewolf.scent.specific", new Object[0])) / 2, this.guiTop + 10, 16777215);
/* 388 */     } else if (((WereScent)list.get(0)).color == 1) {
/* 389 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.scent.disabled", new Object[0]), this.field_146294_l / 2 - this.field_146289_q.func_78256_a(I18n.func_135052_a("werewolf.scent.disabled", new Object[0])) / 2, this.guiTop + 10, 16777215);
/*     */     } else {
/* 391 */       this; func_73734_a(this.field_146294_l / 2 - 10, this.guiTop + 10, this.field_146294_l / 2 + 10, this.guiTop + 20, ((WereScent)list.get(0)).color);
/* 392 */     }  if (mouseX >= this.field_146294_l / 2.0F - 50.0F && mouseX <= (this.field_146294_l / 2 + 50) && mouseY >= this.guiTop + 7.0F && mouseY <= (this.guiTop + 23)) {
/*     */       
/* 394 */       this.currentIndex = 0;
/* 395 */       highlight = current;
/* 396 */       func_73730_a(this.field_146294_l / 2 - 50, this.field_146294_l / 2 + 50, this.guiTop + 7, -256);
/* 397 */       func_73730_a(this.field_146294_l / 2 - 50, this.field_146294_l / 2 + 50, this.guiTop + 22, -256);
/* 398 */       func_73728_b(this.field_146294_l / 2 - 50, this.guiTop + 7, this.guiTop + 22, -256);
/* 399 */       func_73728_b(this.field_146294_l / 2 + 50, this.guiTop + 7, this.guiTop + 22, -256);
/*     */     } 
/*     */     
/* 402 */     if (end > this.listSize) {
/*     */       
/* 404 */       start = (int)((list.size() - 1 - this.listSize) * this.currentScroll) + 1;
/* 405 */       if (end - start > this.listSize) {
/* 406 */         end = Math.min(start + this.listSize, list.size());
/*     */       }
/*     */     } 
/* 409 */     for (int i = start; i < end; i++) {
/*     */       
/* 411 */       current = list.get(i);
/* 412 */       String temp = EntityList.func_191302_a(EntityList.func_191306_a(((WereScent)list.get(i)).entity));
/* 413 */       this.field_146289_q.func_78276_b(temp, this.field_146294_l / 4, y, 16777215);
/* 414 */       if (((WereScent)list.get(i)).color != 1) {
/* 415 */         this; func_73734_a(this.field_146294_l / 4 + this.field_146289_q.func_78256_a(temp) + 5, y, this.field_146294_l / 4 + this.field_146289_q.func_78256_a(temp) + 25, y + 10, ((WereScent)list.get(i)).color);
/*     */       } else {
/* 417 */         this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.scent.disabled", new Object[0]), this.field_146294_l / 4 + this.field_146289_q.func_78256_a(temp) + 5, y, 16777215);
/*     */       } 
/* 419 */       int x2 = this.field_146294_l / 4;
/* 420 */       int y2 = y;
/* 421 */       y += 20;
/* 422 */       if (mouseX >= x2 && mouseX <= (x2 + 100) && mouseY >= y2 - 2.0F && mouseY <= (y2 + 12)) {
/*     */         
/* 424 */         this.currentIndex = i;
/* 425 */         highlight = current;
/* 426 */         func_73730_a(x2 - 3, x2 + 202, y2 - 3, -256);
/* 427 */         func_73730_a(x2 - 3, x2 + 202, y2 + 12, -256);
/* 428 */         func_73728_b(x2 - 3, y2 - 3, y2 + 12, -256);
/* 429 */         func_73728_b(x2 + 202, y2 - 3, y2 + 12, -256);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 434 */     if (!this.scentPopup) {
/* 435 */       this.selected = highlight;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawScrollBar(int mouseX, int mouseY, float partialTicks) {
/* 443 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 444 */     int i = this.guiRight;
/* 445 */     int j = this.guiTop + 18;
/* 446 */     int k = this.guiBottom;
/* 447 */     this.field_146297_k.func_110434_K().func_110577_a(CREATIVE_INVENTORY_TABS);
/*     */ 
/*     */ 
/*     */     
/* 451 */     func_73729_b(i, j + (int)((k - j - 17) * this.currentScroll), 232 + (needsScrollBars() ? 0 : 12), 0, 12, 15);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char typedChar, int keyCode) throws IOException {
/* 461 */     if (this.field_146297_k.field_71474_y.field_151445_Q.isActiveAndMatches(keyCode)) {
/*     */       
/* 463 */       this.field_146297_k.field_71439_g.openGui(HowlingMoon.instance, 0, this.field_146297_k.field_71439_g.field_70170_p, 1, 0, 0);
/*     */     }
/*     */     else {
/*     */       
/* 467 */       super.func_73869_a(typedChar, keyCode);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
/* 473 */     super.func_73864_a(mouseX, mouseY, mouseButton);
/* 474 */     if (!this.scentPopup)
/*     */     {
/* 476 */       if (this.selected != null) {
/* 477 */         this.scentPopup = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean needsScrollBars() {
/* 486 */     return canScroll(mapFromPage());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canScroll(ArrayList map) {
/* 493 */     return (map.size() - 1 > this.listSize);
/*     */   }
/*     */ 
/*     */   
/*     */   private ArrayList mapFromPage() {
/* 498 */     switch (this.currentPage) {
/*     */       case 0:
/* 500 */         return this.mobs;
/* 501 */       case 1: return this.animals;
/* 502 */       case 2: return this.creatures;
/* 503 */       case 3: return this.others;
/* 504 */     }  return this.others;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiScentColors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */