/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import com.raz.howlingmoon.WereAbility;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiButtonSetAbilities
/*    */   extends GuiButton
/*    */ {
/*    */   public ResourceLocation buttonTexture;
/*    */   public ResourceLocation abilityTexture;
/*    */   public WereAbility ability;
/*    */   int slot;
/*    */   
/*    */   public GuiButtonSetAbilities(int id, int xPos, int yPos, WereAbility ability) {
/* 22 */     this(id, xPos, yPos, ability, 0);
/*    */   }
/*    */   
/*    */   public GuiButtonSetAbilities(int id, int xPos, int yPos, WereAbility ability, int slot) {
/* 26 */     super(id, xPos, yPos, 24, 24, "");
/*    */     
/* 28 */     this.buttonTexture = new ResourceLocation("howlingmoon:textures/gui/skills.png");
/* 29 */     this.ability = ability;
/* 30 */     if (ability != null) {
/* 31 */       this.abilityTexture = ability.getTexture();
/*    */     } else {
/* 33 */       this.abilityTexture = null;
/* 34 */     }  this.slot = slot;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 43 */     if (this.field_146125_m) {
/*    */ 
/*    */       
/* 46 */       mc.func_110434_K().func_110577_a(this.buttonTexture);
/* 47 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 48 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/*    */       
/* 50 */       int active = func_146114_a(this.field_146123_n);
/* 51 */       GlStateManager.func_179147_l();
/* 52 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 53 */       GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       if (active == 1) {
/* 60 */         func_73729_b(this.field_146128_h, this.field_146129_i, 30, 2, this.field_146120_f, this.field_146121_g);
/*    */       } else {
/* 62 */         func_73729_b(this.field_146128_h, this.field_146129_i, 114, 2, this.field_146120_f, this.field_146121_g);
/* 63 */       }  if (this.ability != null)
/*    */       {
/* 65 */         if (this.abilityTexture != this.ability.getTexture())
/*    */         {
/* 67 */           this.abilityTexture = this.ability.getTexture();
/*    */         }
/*    */       }
/* 70 */       if (this.abilityTexture != null && this.ability != null) {
/*    */         
/* 72 */         mc.func_110434_K().func_110577_a(this.abilityTexture);
/*    */         
/* 74 */         this; func_146110_a(this.field_146128_h + 2, this.field_146129_i + 2, 0.0F, 0.0F, 20, 20, 20.0F, 20.0F);
/*    */       } 
/*    */       
/* 77 */       func_146119_b(mc, mouseX, mouseY);
/*    */     }
/* 79 */     else if (this.field_146123_n) {
/*    */       
/* 81 */       this.field_146123_n = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] text() {
/* 87 */     if (this.ability != null)
/*    */     {
/* 89 */       return new String[] { I18n.func_135052_a("werewolf.menu.ability", new Object[0]), this.ability.getName() };
/*    */     }
/* 91 */     if (this.slot == 0)
/* 92 */       return new String[] { I18n.func_135052_a("werewolf.menu.toggle.none", new Object[0]) }; 
/* 93 */     if (this.slot == 1)
/* 94 */       return new String[] { I18n.func_135052_a("keys.howlingmoon.ability1", new Object[0]), I18n.func_135052_a("werewolf.menu.toggle.click", new Object[0]) }; 
/* 95 */     return new String[] { I18n.func_135052_a("keys.howlingmoon.ability2", new Object[0]), I18n.func_135052_a("werewolf.menu.toggle.click", new Object[0]) };
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiButtonSetAbilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */