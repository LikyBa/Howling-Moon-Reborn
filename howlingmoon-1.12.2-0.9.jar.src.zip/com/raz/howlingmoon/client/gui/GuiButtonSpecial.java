/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiButtonSpecial
/*    */   extends GuiButton
/*    */ {
/* 15 */   protected static final ResourceLocation BUTTON_TEXTURES = new ResourceLocation("howlingmoon:textures/gui/skill_box.png");
/*    */ 
/*    */   
/*    */   public GuiButtonSpecial(int buttonId, int x, int y, int widthIn, int heightIn) {
/* 19 */     super(buttonId, x, y, widthIn, heightIn, "");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 25 */     if (this.field_146125_m) {
/*    */       
/* 27 */       mc.func_110434_K().func_110577_a(BUTTON_TEXTURES);
/* 28 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 29 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/*    */       
/* 31 */       int i = func_146114_a(this.field_146123_n);
/* 32 */       GlStateManager.func_179147_l();
/* 33 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 34 */       GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*    */       
/* 36 */       if (this.field_146123_n) {
/* 37 */         func_73729_b(this.field_146128_h, this.field_146129_i, 200, 31, this.field_146120_f, this.field_146121_g);
/*    */       } else {
/* 39 */         func_73729_b(this.field_146128_h, this.field_146129_i, 200, 17, this.field_146120_f, this.field_146121_g);
/*    */       } 
/*    */       
/* 42 */       func_146119_b(mc, mouseX, mouseY);
/*    */     }
/* 44 */     else if (this.field_146123_n) {
/*    */       
/* 46 */       this.field_146123_n = false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiButtonSpecial.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */