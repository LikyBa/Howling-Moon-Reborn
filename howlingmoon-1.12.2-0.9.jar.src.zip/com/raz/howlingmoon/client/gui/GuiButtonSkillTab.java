/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public class GuiButtonSkillTab
/*    */   extends GuiButton
/*    */ {
/*    */   public ResourceLocation buttonTexture;
/*    */   public int number;
/*    */   public int active;
/*    */   
/*    */   public GuiButtonSkillTab(int id, int xPos, int yPos, int number) {
/* 17 */     super(id, xPos, yPos, 29, 28, "");
/* 18 */     this.buttonTexture = new ResourceLocation("howlingmoon:textures/gui/skill_box.png");
/* 19 */     this.number = number;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft p_146112_1_, int p_146112_2_, int p_146112_3_, float partialTicks) {
/* 28 */     if (this.field_146125_m) {
/*    */ 
/*    */       
/* 31 */       p_146112_1_.func_110434_K().func_110577_a(this.buttonTexture);
/* 32 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 38 */       GlStateManager.func_179147_l();
/* 39 */       GlStateManager.func_179120_a(770, 771, 1, 0);
/* 40 */       GlStateManager.func_179112_b(770, 771);
/* 41 */       func_73729_b(this.field_146128_h, this.field_146129_i, 16, 16 + this.active * 28, this.field_146120_f, this.field_146121_g);
/* 42 */       func_73729_b(this.field_146128_h + 4, this.field_146129_i + 5, 16 + this.number * 18, 72, 18, 18);
/* 43 */       func_146119_b(p_146112_1_, p_146112_2_, p_146112_3_);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void hoverState(boolean state) {
/* 49 */     if (state);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiButtonSkillTab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */