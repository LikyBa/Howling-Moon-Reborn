/*     */ package com.raz.howlingmoon.client.gui;
/*     */ 
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.WereList;
/*     */ import com.raz.howlingmoon.client.CustomWerewolfTextures;
/*     */ import com.raz.howlingmoon.client.KeyBindings;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.PawSlot;
/*     */ import com.raz.howlingmoon.packets.RestoreEyeHeight;
/*     */ import com.raz.howlingmoon.packets.SetEquippedAbilities;
/*     */ import com.raz.howlingmoon.packets.SneakJumpToggle;
/*     */ import com.raz.howlingmoon.packets.SprintClimbToggle;
/*     */ import com.raz.howlingmoon.packets.SprintJumpToggle;
/*     */ import com.raz.howlingmoon.packets.SyncLeapMessage;
/*     */ import com.raz.howlingmoon.packets.SyncNightVisionMessage;
/*     */ import com.raz.howlingmoon.packets.SyncRamStateMessage;
/*     */ import com.raz.howlingmoon.packets.SyncScentTrackingMessage;
/*     */ import com.raz.howlingmoon.packets.SyncWerewolfModelMessage;
/*     */ import com.raz.howlingmoon.packets.SyncWerewolfTextureMessage;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiTextField;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ public class GuiWerewolfMenu
/*     */   extends GuiScreen
/*     */ {
/*  43 */   public static final ResourceLocation background = new ResourceLocation("howlingmoon", "textures/gui/werewolf_menu.png");
/*     */   
/*  45 */   public static final ResourceLocation background2 = new ResourceLocation("howlingmoon", "textures/gui/werewolf_menu2.png");
/*     */   
/*  47 */   public static final ResourceLocation bars = new ResourceLocation("howlingmoon", "textures/gui/bars.png");
/*     */ 
/*     */   
/*     */   private float oldMouseX;
/*     */   
/*     */   private float oldMouseY;
/*     */   
/*  54 */   protected int xSize = 176;
/*     */   
/*  56 */   protected int ySize = 166; private int guiLeft; private int guiTop; private GuiButton buttonTexture; private GuiButton buttonTexture2; private GuiButton buttonModel;
/*     */   private GuiButton buttonModelWolf;
/*     */   private GuiButton buttonModelBeast;
/*     */   private GuiButton buttonSkillTree;
/*     */   private GuiButton buttonPawConfirm;
/*     */   private GuiButton buttonPawCancel;
/*     */   private GuiTextField text;
/*     */   private GuiButtonAbility buttonPaw;
/*     */   private GuiButtonAbility buttonLeap;
/*     */   private GuiButtonAbility buttonNV;
/*     */   private GuiButtonAbility buttonST;
/*     */   private GuiButtonAbility buttonSTC;
/*     */   private GuiButtonAbility sprintRam;
/*     */   private GuiButtonTab buttonGeneral;
/*     */   private GuiButtonTab buttonTextureMenu;
/*     */   private GuiButtonTab buttonAbility;
/*     */   private GuiButtonSetAbilities buttonToggle;
/*     */   private GuiButtonSetAbilities buttonToggle2;
/*     */   private GuiButtonSetAbilities setHowl;
/*     */   
/*     */   public GuiWerewolfMenu(int screen) {
/*  77 */     if (screen == 1) {
/*  78 */       this.state = 1;
/*     */     } else {
/*  80 */       this.state = 0;
/*     */     } 
/*     */   }
/*     */   private GuiButtonSetAbilities setLeap;
/*     */   private GuiButtonSetAbilities setNV;
/*     */   private GuiButtonSetAbilities setST;
/*     */   private GuiButtonSetAbilities setLT;
/*     */   
/*     */   public void func_73866_w_() {
/*  89 */     this.field_146292_n.clear();
/*  90 */     this.guiLeft = (this.field_146294_l - this.xSize) / 2;
/*  91 */     this.guiTop = (this.field_146295_m - this.ySize) / 2;
/*     */     
/*  93 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/*  95 */     this.text = new GuiTextField(0, this.field_146289_q, this.guiLeft + 73, this.guiTop + 90, 30, 20);
/*  96 */     this.text.func_146203_f(2);
/*  97 */     this.text.func_146195_b(false);
/*  98 */     this.text.func_146189_e(false);
/*  99 */     this.textState = 0;
/*     */     
/* 101 */     this.buttonGeneral = new GuiButtonTab(0, this.guiLeft, this.guiTop - 28, 0);
/* 102 */     this.field_146292_n.add(this.buttonGeneral);
/* 103 */     this.buttonAbility = new GuiButtonTab(1, this.guiLeft + 28, this.guiTop - 28, 1);
/* 104 */     this.field_146292_n.add(this.buttonAbility);
/* 105 */     this.buttonTextureMenu = new GuiButtonTab(2, this.guiLeft + 56, this.guiTop - 28, 2);
/* 106 */     this.field_146292_n.add(this.buttonTextureMenu);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     this.buttonTexture = new GuiButton(5, this.guiLeft + 140, this.guiTop + 89, 20, 20, ">");
/* 113 */     this.field_146292_n.add(this.buttonTexture);
/* 114 */     this.buttonTexture2 = new GuiButton(6, this.guiLeft + 60, this.guiTop + 89, 20, 20, "<");
/* 115 */     this.field_146292_n.add(this.buttonTexture2);
/* 116 */     this.buttonModel = new GuiButton(7, this.guiLeft + 65, this.guiTop + 114, 50, 20, I18n.func_135052_a("werewolf.menu.werewolf", new Object[0]));
/* 117 */     this.field_146292_n.add(this.buttonModel);
/* 118 */     this.buttonModelWolf = new GuiButton(8, this.guiLeft + 10, this.guiTop + 114, 50, 20, I18n.func_135052_a("werewolf.menu.model.wolf", new Object[0]));
/* 119 */     this.field_146292_n.add(this.buttonModelWolf);
/* 120 */     this.buttonModelBeast = new GuiButton(9, this.guiLeft + 120, this.guiTop + 114, 50, 20, I18n.func_135052_a("werewolf.menu.model.beast", new Object[0]));
/* 121 */     this.field_146292_n.add(this.buttonModelBeast);
/*     */     
/* 123 */     this.buttonSkillTree = new GuiButton(10, this.guiLeft + 48, this.guiTop + 20, 80, 20, I18n.func_135052_a("werewolf.menu.skills", new Object[0]));
/* 124 */     this.field_146292_n.add(this.buttonSkillTree);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.buttonToggle = new GuiButtonSetAbilities(11, this.guiLeft + 32, this.guiTop + 122, null, 1);
/* 131 */     this.field_146292_n.add(this.buttonToggle);
/* 132 */     this.buttonToggle2 = new GuiButtonSetAbilities(12, this.guiLeft + 118, this.guiTop + 122, null, 2);
/* 133 */     this.field_146292_n.add(this.buttonToggle2);
/*     */     
/* 135 */     this.buttonPaw = new GuiButtonAbility(13, this.guiLeft + 53, this.guiTop + 50, 0, 0, true);
/* 136 */     this.field_146292_n.add(this.buttonPaw);
/* 137 */     this.buttonLeap = new GuiButtonAbility(14, this.guiLeft + 53, this.guiTop + 75, 2, 2, true);
/* 138 */     this.field_146292_n.add(this.buttonLeap);
/* 139 */     this.buttonNV = new GuiButtonAbility(15, this.guiLeft + 103, this.guiTop + 50, 4, 4, true);
/* 140 */     this.field_146292_n.add(this.buttonNV);
/* 141 */     this.buttonST = new GuiButtonAbility(16, this.guiLeft + 103, this.guiTop + 100, 5, 5, true);
/* 142 */     this.field_146292_n.add(this.buttonST);
/* 143 */     this.buttonSTC = new GuiButtonAbility(17, this.guiLeft + 133, this.guiTop + 100, 6, 5, true);
/* 144 */     this.field_146292_n.add(this.buttonSTC);
/* 145 */     this.sprintRam = new GuiButtonAbility(18, this.guiLeft + 53, this.guiTop + 100, 7, 6, true);
/* 146 */     this.field_146292_n.add(this.sprintRam);
/*     */     
/* 148 */     this.sneakLeap = new GuiButtonToggleKeys(19, this.guiLeft + 38, this.guiTop + 80, 0);
/* 149 */     this.field_146292_n.add(this.sneakLeap);
/* 150 */     this.sprintLeap = new GuiButtonToggleKeys(20, this.guiLeft + 23, this.guiTop + 80, 1);
/* 151 */     this.field_146292_n.add(this.sprintLeap);
/* 152 */     this.sprintClimb = new GuiButtonToggleKeys(21, this.guiLeft + 133, this.guiTop + 80, 2);
/* 153 */     this.field_146292_n.add(this.sprintClimb);
/*     */     
/* 155 */     this.clearAbility = new GuiButtonSetAbilities(22, this.guiLeft + 76, this.guiTop + 131, null, 0);
/* 156 */     this.field_146292_n.add(this.clearAbility);
/* 157 */     this.setHowl = new GuiButtonSetAbilities(23, this.guiLeft + 31, this.guiTop + 11, WereList.HOWL);
/* 158 */     this.field_146292_n.add(this.setHowl);
/* 159 */     this.setLeap = new GuiButtonSetAbilities(24, this.guiLeft + 61, this.guiTop + 11, WereList.LEAP);
/* 160 */     this.field_146292_n.add(this.setLeap);
/* 161 */     this.setNV = new GuiButtonSetAbilities(25, this.guiLeft + 91, this.guiTop + 11, WereList.NIGHTVISION);
/* 162 */     this.field_146292_n.add(this.setNV);
/* 163 */     this.setST = new GuiButtonSetAbilities(26, this.guiLeft + 121, this.guiTop + 11, WereList.SCENTRACKING);
/* 164 */     this.field_146292_n.add(this.setST);
/* 165 */     this.setLT = new GuiButtonSetAbilities(27, this.guiLeft + 31, this.guiTop + 41, WereList.LIFT);
/* 166 */     this.field_146292_n.add(this.setLT);
/* 167 */     this.setBite = new GuiButtonSetAbilities(28, this.guiLeft + 61, this.guiTop + 41, WereList.BITE);
/* 168 */     this.field_146292_n.add(this.setBite);
/* 169 */     this.setMaim = new GuiButtonSetAbilities(29, this.guiLeft + 91, this.guiTop + 41, WereList.MAIM);
/* 170 */     this.field_146292_n.add(this.setMaim);
/*     */     
/* 172 */     this.buttonPawConfirm = new GuiButton(30, this.guiLeft + 20, this.guiTop + 126, 50, 20, I18n.func_135052_a("skills.confirm", new Object[0]));
/* 173 */     this.field_146292_n.add(this.buttonPawConfirm);
/* 174 */     this.buttonPawCancel = new GuiButton(31, this.guiLeft + 106, this.guiTop + 126, 50, 20, I18n.func_135052_a("skills.close", new Object[0]));
/* 175 */     this.field_146292_n.add(this.buttonPawCancel);
/*     */ 
/*     */     
/* 178 */     if (this.state == 1) {
/* 179 */       this.buttonAbility.active = 1;
/*     */     } else {
/* 181 */       this.buttonGeneral.active = 1;
/*     */     } 
/* 183 */     this.buttonSkillTree.field_146125_m = false;
/* 184 */     this.buttonToggle.field_146125_m = false;
/* 185 */     this.buttonToggle2.field_146125_m = false;
/* 186 */     this.buttonPaw.field_146125_m = false;
/* 187 */     this.buttonLeap.field_146125_m = false;
/* 188 */     this.buttonNV.field_146125_m = false;
/* 189 */     this.buttonST.field_146125_m = false;
/* 190 */     this.buttonSTC.field_146125_m = false;
/* 191 */     this.buttonSTC.active = 2;
/* 192 */     this.sprintRam.field_146125_m = false;
/*     */     
/* 194 */     this.buttonPawConfirm.field_146125_m = false;
/* 195 */     this.buttonPawCancel.field_146125_m = false;
/*     */     
/* 197 */     this.sneakLeap.field_146125_m = false;
/* 198 */     this.sprintLeap.field_146125_m = false;
/* 199 */     this.sprintClimb.field_146125_m = false;
/*     */     
/* 201 */     this.clearAbility.field_146125_m = false;
/* 202 */     this.setHowl.field_146125_m = false;
/* 203 */     this.setLeap.field_146125_m = false;
/* 204 */     this.setNV.field_146125_m = false;
/* 205 */     this.setST.field_146125_m = false;
/* 206 */     this.setLT.field_146125_m = false;
/* 207 */     this.setBite.field_146125_m = false;
/* 208 */     this.setMaim.field_146125_m = false;
/*     */     
/* 210 */     this.abilityState = 0;
/*     */     
/* 212 */     this.buttonTexture.field_146125_m = false;
/* 213 */     this.buttonTexture2.field_146125_m = false;
/* 214 */     this.buttonModel.field_146125_m = false;
/* 215 */     this.buttonModelWolf.field_146125_m = false;
/* 216 */     this.buttonModelBeast.field_146125_m = false;
/*     */     
/* 218 */     if (!wolf.isWerewolf()) {
/*     */       
/* 220 */       this.buttonAbility.field_146125_m = false;
/* 221 */       this.buttonTextureMenu.field_146125_m = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 226 */     checkAbilitySlots(wolf);
/*     */   }
/*     */   private GuiButtonSetAbilities setBite; private GuiButtonSetAbilities setMaim; private GuiButtonSetAbilities clearAbility; private GuiButtonToggleKeys sneakLeap; private GuiButtonToggleKeys sprintLeap;
/*     */   private GuiButtonToggleKeys sprintClimb;
/*     */   private int state;
/*     */   private int abilityState;
/*     */   private int textState;
/*     */   
/*     */   public void func_73876_c() {
/* 235 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 237 */     this.buttonGeneral.active = (this.state == 0) ? 1 : 0;
/* 238 */     this.buttonAbility.active = (this.state == 1) ? 1 : 0;
/* 239 */     this.buttonTextureMenu.active = (this.state == 2) ? 1 : 0;
/*     */ 
/*     */ 
/*     */     
/* 243 */     this.buttonSkillTree.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 0);
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (wolf.getAbilitySlot1() != null)
/*     */     {
/* 249 */       this.buttonToggle.ability = wolf.getAbilitySlot1();
/*     */     }
/* 251 */     this.buttonToggle.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 0);
/*     */     
/* 253 */     if (wolf.getAbilitySlot2() != null)
/*     */     {
/* 255 */       this.buttonToggle2.ability = wolf.getAbilitySlot2();
/*     */     }
/* 257 */     this.buttonToggle2.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 0);
/*     */     
/* 259 */     this.sneakLeap.field_146125_m = (wolf.getAbilityTreeAbility(WereList.LEAP.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 260 */     this.sneakLeap.active = wolf.getSneakJump();
/* 261 */     this.sprintLeap.field_146125_m = (wolf.getAbilityTreeAbility(WereList.LEAP.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 262 */     this.sprintLeap.active = wolf.getSprintJump();
/* 263 */     this.sprintClimb.field_146125_m = (wolf.getAbilityTreeAbility(WereList.CLIMB.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 264 */     this.sprintClimb.active = wolf.getSprintClimb();
/*     */     
/* 266 */     this.buttonPaw.active = (wolf.getPawSlot() != -1) ? 1 : 0;
/* 267 */     this.buttonPaw.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 268 */     this.buttonLeap.active = wolf.getLeapState();
/* 269 */     this.buttonLeap.field_146125_m = (wolf.getAbilityTreeAbility(WereList.LEAP.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 270 */     this.buttonNV.active = wolf.getNightVision() ? 1 : 0;
/* 271 */     this.buttonNV.field_146125_m = (wolf.getQuestsDone() > 2 && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 272 */     this.buttonST.active = wolf.getScentTracking() ? 1 : 0;
/* 273 */     this.buttonST.field_146125_m = (wolf.getAbilityTreeAbility(WereList.SCENTRACKING.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 274 */     this.buttonSTC.field_146125_m = (wolf.getAbilityTreeAbility(WereList.SCENTRACKING.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/* 275 */     this.sprintRam.active = wolf.getSprintRam();
/* 276 */     this.sprintRam.field_146125_m = (wolf.getAbilityTreeAbility(WereList.RAM.getKey()) && this.state == 1 && this.abilityState == 0 && this.textState == 0);
/*     */     
/* 278 */     this.clearAbility.field_146125_m = (this.state == 1 && this.abilityState != 0);
/* 279 */     this.setHowl.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.HOWL.getKey()));
/* 280 */     this.setLeap.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.LEAP.getKey()));
/* 281 */     this.setNV.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.NIGHTVISION.getKey()));
/* 282 */     this.setST.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.SCENTRACKING.getKey()));
/* 283 */     this.setLT.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.LIFT.getKey()));
/* 284 */     this.setBite.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.BITE.getKey()));
/* 285 */     this.setMaim.field_146125_m = (this.state == 1 && this.abilityState != 0 && wolf.getAbilityTreeAbility(WereList.MAIM.getKey()));
/*     */     
/* 287 */     this.buttonPawConfirm.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 1);
/* 288 */     this.buttonPawCancel.field_146125_m = (this.state == 1 && this.abilityState == 0 && this.textState == 1);
/*     */     
/* 290 */     this.text.func_146189_e((this.state == 1 && this.textState > 0));
/* 291 */     this.text.func_146178_a();
/*     */     
/* 293 */     this.buttonTexture.field_146125_m = (this.state == 2);
/* 294 */     this.buttonTexture2.field_146125_m = (this.state == 2);
/* 295 */     this.buttonModel.field_146125_m = (this.state == 2);
/* 296 */     this.buttonModelBeast.field_146125_m = (this.state == 2 && wolf.getQuestsDone() > 4);
/* 297 */     this.buttonModelWolf.field_146125_m = (this.state == 2 && wolf.getQuestsDone() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_73868_f() {
/* 303 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char c, int keyCode) throws IOException {
/* 308 */     super.func_73869_a(c, keyCode);
/* 309 */     if (!this.text.func_146206_l()) {
/*     */       
/* 311 */       if (keyCode == KeyBindings.menu.func_151463_i())
/*     */       {
/* 313 */         this.field_146297_k.func_147108_a((GuiScreen)null);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 318 */       this.text.func_146201_a(c, keyCode);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_146284_a(GuiButton b) {
/*     */     int textureTemp, textureTemp2, slot;
/* 325 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 327 */     switch (b.field_146127_k) {
/*     */       case 0:
/* 329 */         this.state = 0;
/* 330 */         this.textState = 0;
/* 331 */         this.abilityState = 0; break;
/*     */       case 1:
/* 333 */         this.state = 1;
/* 334 */         this.textState = 0;
/* 335 */         this.abilityState = 0; break;
/*     */       case 2:
/* 337 */         this.state = 2;
/* 338 */         this.textState = 0;
/* 339 */         this.abilityState = 0; break;
/*     */       case 3:
/* 341 */         this.state = 3;
/* 342 */         this.textState = 0;
/* 343 */         this.abilityState = 0; break;
/*     */       case 4:
/* 345 */         this.state = 4;
/*     */         break;
/*     */       
/*     */       case 5:
/* 349 */         textureTemp = wolf.getTexture();
/* 350 */         if (textureTemp > 2 + CustomWerewolfTextures.textureCount) {
/* 351 */           wolf.setTexture(0);
/*     */         } else {
/* 353 */           wolf.setTexture(textureTemp + 1);
/* 354 */         }  PacketDispatcher.sendToServer((IMessage)new SyncWerewolfTextureMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 6:
/* 357 */         textureTemp2 = wolf.getTexture();
/* 358 */         if (textureTemp2 < 1) {
/* 359 */           wolf.setTexture(3 + CustomWerewolfTextures.textureCount);
/*     */         } else {
/* 361 */           wolf.setTexture(textureTemp2 - 1);
/* 362 */         }  PacketDispatcher.sendToServer((IMessage)new SyncWerewolfTextureMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 7:
/* 365 */         if (wolf.getModel() != 0) {
/*     */           
/* 367 */           wolf.setModel(0);
/* 368 */           if (wolf.isTransformed()) {
/* 369 */             PacketDispatcher.sendToServer((IMessage)new RestoreEyeHeight((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */           }
/* 371 */           PacketDispatcher.sendToServer((IMessage)new SyncWerewolfModelMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         } 
/*     */         break;
/*     */       case 8:
/* 375 */         if (wolf.getModel() != 1 && wolf.getQuestsDone() > 0) {
/*     */           
/* 377 */           wolf.setModel(1);
/*     */ 
/*     */           
/* 380 */           PacketDispatcher.sendToServer((IMessage)new SyncWerewolfModelMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         } 
/*     */         break;
/*     */       case 9:
/* 384 */         if (wolf.getModel() != 2 && wolf.getQuestsDone() > 4) {
/*     */           
/* 386 */           wolf.setModel(2);
/*     */ 
/*     */           
/* 389 */           PacketDispatcher.sendToServer((IMessage)new SyncWerewolfModelMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         } 
/*     */         break;
/*     */       case 10:
/* 393 */         this.field_146297_k.field_71439_g.openGui(HowlingMoon.instance, 1, this.field_146297_k.field_71439_g.field_70170_p, (int)this.field_146297_k.field_71439_g.field_70165_t, (int)this.field_146297_k.field_71439_g.field_70163_u, (int)this.field_146297_k.field_71439_g.field_70161_v);
/*     */         break;
/*     */       
/*     */       case 11:
/* 397 */         this.abilityState = 1;
/*     */         break;
/*     */       
/*     */       case 12:
/* 401 */         this.abilityState = 2;
/*     */         break;
/*     */       case 13:
/* 404 */         this.textState = 1;
/* 405 */         this.text.func_146180_a("");
/*     */         break;
/*     */       case 14:
/* 408 */         if (wolf.getLeapState() == 0) {
/* 409 */           wolf.setLeapState(1);
/*     */         } else {
/* 411 */           wolf.setLeapState(0);
/* 412 */         }  PacketDispatcher.sendToServer((IMessage)new SyncLeapMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 15:
/* 415 */         wolf.setNightVision(!wolf.getNightVision());
/* 416 */         PacketDispatcher.sendToServer((IMessage)new SyncNightVisionMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 16:
/* 419 */         wolf.setScentTracking(!wolf.getScentTracking());
/* 420 */         PacketDispatcher.sendToServer((IMessage)new SyncScentTrackingMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 17:
/* 423 */         this.field_146297_k.field_71439_g.openGui(HowlingMoon.instance, 2, this.field_146297_k.field_71439_g.field_70170_p, (int)this.field_146297_k.field_71439_g.field_70165_t, (int)this.field_146297_k.field_71439_g.field_70163_u, (int)this.field_146297_k.field_71439_g.field_70161_v);
/*     */         break;
/*     */       case 18:
/* 426 */         if (wolf.getSprintRam() == 0) {
/* 427 */           wolf.setSprintRam(1);
/* 428 */         } else if (wolf.getSprintRam() == 1) {
/* 429 */           wolf.setSprintRam(2);
/*     */         } else {
/* 431 */           wolf.setSprintRam(0);
/* 432 */         }  PacketDispatcher.sendToServer((IMessage)new SyncRamStateMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 19:
/* 435 */         if (wolf.getSneakJump() == 0) {
/* 436 */           wolf.setSneakJump(1);
/* 437 */         } else if (wolf.getSneakJump() == 1) {
/* 438 */           wolf.setSneakJump(2);
/*     */         } else {
/* 440 */           wolf.setSneakJump(0);
/* 441 */         }  PacketDispatcher.sendToServer((IMessage)new SneakJumpToggle((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 20:
/* 444 */         if (wolf.getSprintJump() == 0) {
/* 445 */           wolf.setSprintJump(1);
/* 446 */         } else if (wolf.getSprintJump() == 1) {
/* 447 */           wolf.setSprintJump(2);
/* 448 */         } else if (wolf.getSprintJump() == 2) {
/* 449 */           wolf.setSprintJump(3);
/*     */         } else {
/* 451 */           wolf.setSprintJump(0);
/* 452 */         }  PacketDispatcher.sendToServer((IMessage)new SprintJumpToggle((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 21:
/* 455 */         if (wolf.getSprintClimb() == 0) {
/* 456 */           wolf.setSprintClimb(1);
/* 457 */         } else if (wolf.getSprintClimb() == 1) {
/* 458 */           wolf.setSprintClimb(2);
/* 459 */         } else if (wolf.getSprintClimb() == 2) {
/* 460 */           wolf.setSprintClimb(3);
/* 461 */         } else if (wolf.getSprintClimb() == 3) {
/* 462 */           wolf.setSprintClimb(4);
/* 463 */         } else if (wolf.getSprintClimb() == 4) {
/* 464 */           wolf.setSprintClimb(5);
/*     */         } else {
/* 466 */           wolf.setSprintClimb(0);
/* 467 */         }  PacketDispatcher.sendToServer((IMessage)new SprintClimbToggle((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         break;
/*     */       case 22:
/* 470 */         if (this.abilityState == 1) {
/*     */           
/* 472 */           wolf.setAbilitySlot1(null);
/* 473 */           this.buttonToggle.ability = null;
/* 474 */           this.buttonToggle.slot = 1;
/*     */         }
/*     */         else {
/*     */           
/* 478 */           wolf.setAbilitySlot2(null);
/* 479 */           this.buttonToggle2.ability = null;
/* 480 */           this.buttonToggle2.slot = 2;
/*     */         } 
/* 482 */         PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 483 */         this.abilityState = 0;
/*     */         break;
/*     */       case 23:
/* 486 */         if (this.abilityState == 1) {
/* 487 */           wolf.setAbilitySlot1(WereList.HOWL);
/*     */         } else {
/* 489 */           wolf.setAbilitySlot2(WereList.HOWL);
/* 490 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 491 */         this.abilityState = 0;
/*     */         break;
/*     */       case 24:
/* 494 */         if (this.abilityState == 1) {
/* 495 */           wolf.setAbilitySlot1(WereList.LEAP);
/*     */         } else {
/* 497 */           wolf.setAbilitySlot2(WereList.LEAP);
/* 498 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 499 */         this.abilityState = 0;
/*     */         break;
/*     */       case 25:
/* 502 */         if (this.abilityState == 1) {
/* 503 */           wolf.setAbilitySlot1(WereList.NIGHTVISION);
/*     */         } else {
/* 505 */           wolf.setAbilitySlot2(WereList.NIGHTVISION);
/* 506 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 507 */         this.abilityState = 0;
/*     */         break;
/*     */       case 26:
/* 510 */         if (this.abilityState == 1) {
/* 511 */           wolf.setAbilitySlot1(WereList.SCENTRACKING);
/*     */         } else {
/* 513 */           wolf.setAbilitySlot2(WereList.SCENTRACKING);
/* 514 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 515 */         this.abilityState = 0;
/*     */         break;
/*     */       case 27:
/* 518 */         if (this.abilityState == 1) {
/* 519 */           wolf.setAbilitySlot1(WereList.LIFT);
/*     */         } else {
/* 521 */           wolf.setAbilitySlot2(WereList.LIFT);
/* 522 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 523 */         this.abilityState = 0;
/*     */         break;
/*     */       case 28:
/* 526 */         if (this.abilityState == 1) {
/* 527 */           wolf.setAbilitySlot1(WereList.BITE);
/*     */         } else {
/* 529 */           wolf.setAbilitySlot2(WereList.BITE);
/* 530 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 531 */         this.abilityState = 0;
/*     */         break;
/*     */       case 29:
/* 534 */         if (this.abilityState == 1) {
/* 535 */           wolf.setAbilitySlot1(WereList.MAIM);
/*     */         } else {
/* 537 */           wolf.setAbilitySlot2(WereList.MAIM);
/* 538 */         }  PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/* 539 */         this.abilityState = 0;
/*     */         break;
/*     */       
/*     */       case 30:
/*     */         try {
/* 544 */           slot = Integer.parseInt(this.text.func_146179_b());
/* 545 */         } catch (NumberFormatException e) {
/* 546 */           slot = -1;
/*     */         } 
/* 548 */         if (slot < 0 || slot > 8)
/* 549 */           slot = -1; 
/* 550 */         wolf.setPawSlot(slot);
/* 551 */         PacketDispatcher.sendToServer((IMessage)new PawSlot((EntityPlayer)this.field_146297_k.field_71439_g));
/* 552 */         this.textState = 0;
/*     */         break;
/*     */       case 31:
/* 555 */         this.textState = 0;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int x, int y, int btn) throws IOException {
/* 563 */     super.func_73864_a(x, y, btn);
/* 564 */     this.text.func_146192_a(x, y, btn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int par1, int par2, float par3) {
/* 582 */     this.oldMouseX = par1;
/* 583 */     this.oldMouseY = par2;
/* 584 */     if (this.state == 0) {
/* 585 */       drawGuiContainerBackgroundLayer();
/* 586 */     } else if (this.state == 1) {
/* 587 */       drawGuiAbilityLayer();
/* 588 */     } else if (this.state == 2) {
/* 589 */       drawGuiModelTextureLayer();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 594 */     super.func_73863_a(par1, par2, par3);
/* 595 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 596 */     for (int i = 0; i < this.field_146292_n.size(); i++) {
/* 597 */       if (this.field_146292_n.get(i) instanceof GuiButtonAbility) {
/* 598 */         GuiButtonAbility btn = this.field_146292_n.get(i);
/* 599 */         if (btn.func_146115_a())
/*     */         {
/* 601 */           List<String> temp = Arrays.asList(btn.text(wolf));
/* 602 */           drawHoveringText(temp, par1, par2, this.field_146289_q);
/*     */         }
/*     */       
/* 605 */       } else if (this.field_146292_n.get(i) instanceof GuiButtonSetAbilities) {
/*     */         
/* 607 */         GuiButtonSetAbilities btn = this.field_146292_n.get(i);
/* 608 */         if (btn.func_146115_a())
/*     */         {
/* 610 */           List<String> temp = Arrays.asList(btn.text());
/* 611 */           drawHoveringText(temp, par1, par2, this.field_146289_q);
/*     */         }
/*     */       
/* 614 */       } else if (this.field_146292_n.get(i) instanceof GuiButtonToggleKeys) {
/*     */         
/* 616 */         GuiButtonToggleKeys btn = this.field_146292_n.get(i);
/* 617 */         if (btn.func_146115_a()) {
/*     */           
/* 619 */           List<String> temp = Arrays.asList(btn.text());
/* 620 */           drawHoveringText(temp, par1, par2, this.field_146289_q);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer() {
/* 672 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 673 */     this.field_146297_k.func_110434_K().func_110577_a(background);
/* 674 */     int k = this.guiLeft;
/* 675 */     int l = this.guiTop;
/* 676 */     func_73729_b(k, l, 0, 0, this.xSize, this.ySize);
/*     */     
/* 678 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 679 */     int scale = (wolf.isTransformed() && wolf.getModel() == 2) ? 20 : 30;
/*     */     
/* 681 */     drawEntityOnScreen(k + 51, l + 72, scale, (k + 51) - this.oldMouseX, (l + 75 - 50) - this.oldMouseY, (EntityLivingBase)this.field_146297_k.field_71439_g);
/* 682 */     drawWerewolfInfo(k, l, (EntityPlayer)this.field_146297_k.field_71439_g);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawGuiAbilityLayer() {
/* 687 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 688 */     this.field_146297_k.func_110434_K().func_110577_a(background2);
/* 689 */     int k = this.guiLeft;
/* 690 */     int l = this.guiTop;
/* 691 */     func_73729_b(k, l, 0, 0, this.xSize, this.ySize);
/*     */     
/* 693 */     drawAbilityInfo(k, l, (EntityPlayer)this.field_146297_k.field_71439_g);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawGuiModelTextureLayer() {
/* 698 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 699 */     this.field_146297_k.func_110434_K().func_110577_a(background);
/* 700 */     int k = this.guiLeft;
/* 701 */     int l = this.guiTop;
/* 702 */     func_73729_b(k, l, 0, 0, this.xSize, this.ySize);
/*     */     
/* 704 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 705 */     int scale = (wolf.isTransformed() && wolf.getModel() == 2) ? 20 : 30;
/*     */     
/* 707 */     drawEntityOnScreen(k + 51, l + 72, scale, (k + 51) - this.oldMouseX, (l + 75 - 50) - this.oldMouseY, (EntityLivingBase)this.field_146297_k.field_71439_g);
/* 708 */     drawTextureInfo(k, l, (EntityPlayer)this.field_146297_k.field_71439_g);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawGuiPackLayer() {
/* 713 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 714 */     this.field_146297_k.func_110434_K().func_110577_a(background2);
/* 715 */     int k = this.guiLeft;
/* 716 */     int l = this.guiTop;
/* 717 */     func_73729_b(k, l, 0, 0, this.xSize, this.ySize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawGuiPackAddLayer() {
/* 724 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 725 */     this.field_146297_k.func_110434_K().func_110577_a(background2);
/* 726 */     int k = this.guiLeft;
/* 727 */     int l = this.guiTop;
/* 728 */     func_73729_b(k, l, 0, 0, this.xSize, this.ySize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawWerewolfInfo(int x, int y, EntityPlayer player) {
/* 735 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 736 */     if (wolf.isWerewolf()) {
/*     */       
/* 738 */       if (wolf.getLevel() != 0) {
/*     */         
/* 740 */         float percent = wolf.getExp() / (wolf.getLevel() * 25);
/* 741 */         percent *= 79.0F;
/* 742 */         int widthP = (int)percent;
/* 743 */         this.field_146297_k.func_110434_K().func_110577_a(bars);
/* 744 */         func_73729_b(x + 86, y + 60, 0, 42, 81, 9);
/* 745 */         func_73729_b(x + 87, y + 61, 1, 53, widthP, 7);
/* 746 */         String exp = wolf.getExp() + "/" + wolf.expNeededLevel();
/* 747 */         this.field_146289_q.func_78276_b(exp, x + 126 - this.field_146289_q
/* 748 */             .func_78256_a(exp) / 2, y + 71, 0);
/* 749 */         this.field_146289_q.func_78276_b("" + wolf.getLevel(), x + 126 - this.field_146289_q
/* 750 */             .func_78256_a("" + wolf.getLevel()) / 2, y + 40, 0);
/*     */       } 
/* 752 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.menu.werewolf", new Object[0]), x + 126 - this.field_146289_q
/* 753 */           .func_78256_a(I18n.func_135052_a("werewolf.menu.werewolf", new Object[0])) / 2, y + 10, 0);
/*     */       
/* 755 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.menu.title", new Object[0]) + ": " + wolf.getInclinationTitle(), x + 80 - this.field_146289_q
/* 756 */           .func_78256_a(I18n.func_135052_a("werewolf.menu.title", new Object[0]) + ": " + wolf.getInclinationTitle()) / 2, y + 100, 0);
/*     */     }
/*     */     else {
/*     */       
/* 760 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.menu.status", new Object[0]) + ": " + getInfectionName(wolf), x + 10, y + 90, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawAbilityInfo(int x, int y, EntityPlayer player) {
/* 767 */     if (this.abilityState == 0)
/*     */     {
/* 769 */       this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.menu.abilities", new Object[0]), x + (this.xSize - this.field_146289_q
/* 770 */           .func_78256_a(I18n.func_135052_a("werewolf.menu.abilities", new Object[0]))) / 2, y + 10, 0);
/*     */     }
/*     */     
/* 773 */     if (this.textState > 0) {
/*     */       
/* 775 */       this.text.func_146194_f();
/* 776 */       this.field_146289_q.func_78279_b(I18n.func_135052_a("werewolf.menu.pawSlot", new Object[0]), x + 13, y + 30, 150, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawTextureInfo(int x, int y, EntityPlayer player) {
/* 787 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 788 */     this.field_146289_q.func_78276_b(I18n.func_135052_a("werewolf.menu.texture", new Object[0]), x + 10, y + 95, 0);
/* 789 */     this.field_146289_q.func_78276_b(wolf.getTextureName(), x + 110 - this.field_146289_q
/* 790 */         .func_78256_a(I18n.func_135052_a(wolf.getTextureName(), new Object[0])) / 2, y + 95, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent) {
/* 799 */     GlStateManager.func_179142_g();
/* 800 */     GlStateManager.func_179094_E();
/* 801 */     GlStateManager.func_179109_b(posX, posY, 50.0F);
/* 802 */     GlStateManager.func_179152_a(-scale, scale, scale);
/* 803 */     GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
/* 804 */     float f = ent.field_70761_aq;
/* 805 */     float f1 = ent.field_70177_z;
/* 806 */     float f2 = ent.field_70125_A;
/* 807 */     float f3 = ent.field_70758_at;
/* 808 */     float f4 = ent.field_70759_as;
/* 809 */     GlStateManager.func_179114_b(135.0F, 0.0F, 1.0F, 0.0F);
/* 810 */     RenderHelper.func_74519_b();
/* 811 */     GlStateManager.func_179114_b(-135.0F, 0.0F, 1.0F, 0.0F);
/* 812 */     GlStateManager.func_179114_b(-((float)Math.atan((mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
/* 813 */     ent.field_70761_aq = (float)Math.atan((mouseX / 40.0F)) * 20.0F;
/* 814 */     ent.field_70177_z = (float)Math.atan((mouseX / 40.0F)) * 40.0F;
/* 815 */     ent.field_70125_A = -((float)Math.atan((mouseY / 40.0F))) * 20.0F;
/* 816 */     ent.field_70759_as = ent.field_70177_z;
/* 817 */     ent.field_70758_at = ent.field_70177_z;
/* 818 */     GlStateManager.func_179109_b(0.0F, 0.0F, 0.0F);
/* 819 */     RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
/* 820 */     rendermanager.func_178631_a(180.0F);
/* 821 */     rendermanager.func_178633_a(false);
/* 822 */     rendermanager.func_188391_a((Entity)ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
/* 823 */     rendermanager.func_178633_a(true);
/* 824 */     ent.field_70761_aq = f;
/* 825 */     ent.field_70177_z = f1;
/* 826 */     ent.field_70125_A = f2;
/* 827 */     ent.field_70758_at = f3;
/* 828 */     ent.field_70759_as = f4;
/* 829 */     GlStateManager.func_179121_F();
/* 830 */     RenderHelper.func_74518_a();
/* 831 */     GlStateManager.func_179101_C();
/* 832 */     GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
/* 833 */     GlStateManager.func_179090_x();
/* 834 */     GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getInfectionName(IWerewolfCapability wolf) {
/* 839 */     if (wolf.getInfected() == 0)
/* 840 */       return I18n.func_135052_a("werewolf.menu.infection0", new Object[0]); 
/* 841 */     if (!wolf.isWerewolf() && wolf.getInfected() > 0)
/* 842 */       return I18n.func_135052_a("werewolf.menu.infection1", new Object[0]); 
/* 843 */     if (wolf.getInfected() == -1)
/* 844 */       return I18n.func_135052_a("werewolf.menu.infectionN", new Object[0]); 
/* 845 */     return I18n.func_135052_a("werewolf.menu.werewolf", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkAbilitySlots(IWerewolfCapability wolf) {
/* 850 */     if (wolf.getAbilitySlot1() != null)
/*     */     {
/* 852 */       if (!wolf.getAbilityTreeAbility(wolf.getAbilitySlot1().getKey())) {
/*     */         
/* 854 */         wolf.setAbilitySlot1(null);
/* 855 */         this.buttonToggle.ability = null;
/* 856 */         this.buttonToggle.slot = 1;
/*     */       } 
/*     */     }
/* 859 */     if (wolf.getAbilitySlot2() != null)
/*     */     {
/* 861 */       if (!wolf.getAbilityTreeAbility(wolf.getAbilitySlot2().getKey())) {
/*     */         
/* 863 */         wolf.setAbilitySlot2(null);
/* 864 */         this.buttonToggle2.ability = null;
/* 865 */         this.buttonToggle2.slot = 2;
/*     */       } 
/*     */     }
/*     */     
/* 869 */     PacketDispatcher.sendToServer((IMessage)new SetEquippedAbilities((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiWerewolfMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */