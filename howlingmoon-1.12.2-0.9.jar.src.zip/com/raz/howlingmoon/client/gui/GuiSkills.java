/*     */ package com.raz.howlingmoon.client.gui;
/*     */ 
/*     */ import com.raz.howlingmoon.HowlingMoon;
/*     */ import com.raz.howlingmoon.IWerewolfCapability;
/*     */ import com.raz.howlingmoon.WereAbility;
/*     */ import com.raz.howlingmoon.WereAttribute;
/*     */ import com.raz.howlingmoon.WereBasic;
/*     */ import com.raz.howlingmoon.WereEventHandler;
/*     */ import com.raz.howlingmoon.WereInclination;
/*     */ import com.raz.howlingmoon.WereList;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncWereCapsMessage;
/*     */ import com.raz.howlingmoon.packets.UpdateExpServer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ public class GuiSkills
/*     */   extends GuiScreen
/*     */ {
/*  30 */   public static final ResourceLocation background = new ResourceLocation("howlingmoon:textures/gui/skilltree_background.png");
/*     */   
/*  32 */   public static final ResourceLocation backgroundBox = new ResourceLocation("howlingmoon:textures/gui/skill_box.png");
/*     */   
/*  34 */   public static final ResourceLocation BUTTON_TEXTURES = new ResourceLocation("howlingmoon:textures/gui/skills.png");
/*     */   
/*     */   private int currentPage;
/*     */   
/*     */   private GuiButtonSkillTab buttonGeneral;
/*     */   
/*     */   private GuiButtonSkillTab buttonAttribute;
/*     */   
/*     */   private GuiButtonSkillTab buttonAbility;
/*     */   
/*     */   private GuiButtonSkillTab buttonInclination;
/*     */   
/*     */   private GuiButton buttonAssign;
/*     */   private GuiButton buttonClose;
/*     */   
/*     */   public void func_73866_w_() {
/*  50 */     int centerX = this.field_146294_l / 2 - 14;
/*  51 */     int centerY = this.field_146295_m / 2 - 14;
/*  52 */     int popX = (this.field_146294_l - 176) / 2;
/*  53 */     int popY = (this.field_146295_m - 126) / 2;
/*  54 */     int id = 4;
/*  55 */     this.resetActive = false;
/*  56 */     this.currentPage = 0;
/*  57 */     this.field_146292_n.clear();
/*     */     
/*  59 */     this.buttonGeneral = new GuiButtonSkillTab(0, 15, 16, 0);
/*  60 */     this.field_146292_n.add(this.buttonGeneral);
/*  61 */     this.buttonAttribute = new GuiButtonSkillTab(1, 15, 44, 1);
/*  62 */     this.field_146292_n.add(this.buttonAttribute);
/*  63 */     this.buttonAbility = new GuiButtonSkillTab(2, 15, 72, 2);
/*  64 */     this.field_146292_n.add(this.buttonAbility);
/*  65 */     this.buttonInclination = new GuiButtonSkillTab(3, 15, 100, 3);
/*  66 */     this.field_146292_n.add(this.buttonInclination);
/*     */     
/*  68 */     this.buttonAssign = new GuiButton(4, popX + 5, popY + 101, 70, 20, I18n.func_135052_a("skills.assign", new Object[0]));
/*  69 */     this.field_146292_n.add(this.buttonAssign);
/*  70 */     this.buttonClose = new GuiButton(5, popX + 101, popY + 101, 70, 20, I18n.func_135052_a("skills.close", new Object[0]));
/*  71 */     this.field_146292_n.add(this.buttonClose);
/*  72 */     this.buttonReset = new GuiButtonSpecial(6, this.field_146294_l - 16, 3, 13, 13);
/*  73 */     this.field_146292_n.add(this.buttonReset);
/*  74 */     this.buttonResetConfirm = new GuiButton(7, popX + 5, popY + 101, 70, 20, I18n.func_135052_a("skills.confirm", new Object[0]));
/*  75 */     this.field_146292_n.add(this.buttonResetConfirm);
/*     */     
/*  77 */     this.buttonGeneral.active = 1;
/*     */     
/*  79 */     this.buttonAssign.field_146125_m = false;
/*  80 */     this.buttonClose.field_146125_m = false;
/*  81 */     this.buttonReset.field_146125_m = false;
/*  82 */     this.buttonResetConfirm.field_146125_m = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private GuiButton buttonResetConfirm;
/*     */   
/*     */   private GuiButtonSpecial buttonReset;
/*     */   private WereBasic selectedBasic;
/*     */   private WereAbility selectedAbility;
/*     */   private WereAttribute selectedAttribute;
/*     */   private WereInclination selectedInclination;
/*     */   private boolean abilityPopup;
/*     */   private boolean resetActive;
/*     */   
/*     */   protected void func_146284_a(GuiButton b) throws IOException {
/*  97 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*  98 */     switch (b.field_146127_k) {
/*     */       case 0:
/* 100 */         this.currentPage = 0; break;
/*     */       case 1:
/* 102 */         this.currentPage = 1; break;
/*     */       case 2:
/* 104 */         this.currentPage = 2; break;
/*     */       case 3:
/* 106 */         this.currentPage = 3; break;
/*     */       case 4:
/* 108 */         if (this.abilityPopup) {
/*     */           
/* 110 */           if (this.currentPage == 1 && this.selectedAttribute != null) {
/*     */             
/* 112 */             if (this.selectedAttribute.havePointsFor(wolf)) {
/*     */               
/* 114 */               wolf.addAttributeTreeAbility(this.selectedAttribute);
/* 115 */               PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */             }  break;
/*     */           } 
/* 118 */           if (this.currentPage == 2 && this.selectedAbility != null)
/*     */           {
/* 120 */             if (this.selectedAbility.canUnlock(wolf) && this.selectedAbility.havePointsFor(wolf)) {
/*     */               
/* 122 */               wolf.addAbilityTreeAbility(this.selectedAbility);
/* 123 */               PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */             }  } 
/*     */         } 
/*     */         break;
/*     */       case 5:
/* 128 */         this.selectedAbility = null;
/* 129 */         this.selectedAttribute = null;
/* 130 */         this.selectedBasic = null;
/* 131 */         this.selectedInclination = null;
/* 132 */         this.abilityPopup = false;
/* 133 */         this.resetActive = false; break;
/*     */       case 6:
/* 135 */         this.resetActive = true;
/*     */         break;
/*     */       case 7:
/* 138 */         if (this.field_146297_k.field_71439_g.field_71068_ca > 9 || this.field_146297_k.field_71439_g.func_184812_l_()) {
/*     */           
/* 140 */           if (!this.field_146297_k.field_71439_g.func_184812_l_())
/* 141 */             this.field_146297_k.field_71439_g.func_82242_a(-10); 
/* 142 */           PacketDispatcher.sendToServer((IMessage)new UpdateExpServer((EntityPlayer)this.field_146297_k.field_71439_g));
/* 143 */           if (this.currentPage == 1) {
/*     */             
/* 145 */             wolf.resetAttributePoints();
/*     */           }
/* 147 */           else if (this.currentPage == 2) {
/*     */             
/* 149 */             wolf.resetAbilityPoints();
/*     */           }
/* 151 */           else if (this.currentPage == 3) {
/*     */             
/* 153 */             wolf.setInclinationType(0);
/* 154 */             wolf.setQuestsDone(0);
/*     */           } 
/* 156 */           this.resetActive = false;
/* 157 */           PacketDispatcher.sendToServer((IMessage)new SyncWereCapsMessage((EntityPlayer)this.field_146297_k.field_71439_g));
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_73869_a(char typedChar, int keyCode) throws IOException {
/* 170 */     if (this.field_146297_k.field_71474_y.field_151445_Q.isActiveAndMatches(keyCode)) {
/*     */ 
/*     */ 
/*     */       
/* 174 */       this.field_146297_k.field_71439_g.openGui(HowlingMoon.instance, 0, this.field_146297_k.field_71439_g.field_70170_p, 1, 0, 0);
/*     */     }
/*     */     else {
/*     */       
/* 178 */       super.func_73869_a(typedChar, keyCode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/* 187 */     func_146276_q_();
/* 188 */     this.field_146297_k.func_110434_K().func_110577_a(background);
/* 189 */     func_73729_b(0, 0, 0, 0, this.field_146294_l, this.field_146295_m);
/*     */     
/* 191 */     switch (this.currentPage) {
/*     */       case 0:
/* 193 */         drawBasicLayer(mouseX, mouseY, partialTicks); break;
/*     */       case 1:
/* 195 */         drawAttributeLayer(mouseX, mouseY, partialTicks); break;
/*     */       case 2:
/* 197 */         drawAbilityLayer(mouseX, mouseY, partialTicks); break;
/*     */       case 3:
/* 199 */         drawInclinationLayer(mouseX, mouseY, partialTicks);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     drawGuiForgroundLayer();
/*     */     
/* 206 */     drawSkillPoints();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (this.abilityPopup || this.resetActive)
/* 238 */       drawSkillBoxDesc(); 
/* 239 */     for (int i = 0; i < 8; i++)
/*     */     {
/* 241 */       ((GuiButton)this.field_146292_n.get(i)).func_191745_a(this.field_146297_k, mouseX, mouseY, partialTicks);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawBasicLayer(int mouseX, int mouseY, float partialTicks) {
/* 247 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 249 */     GlStateManager.func_179143_c(518);
/* 250 */     GlStateManager.func_179094_E();
/* 251 */     GlStateManager.func_179098_w();
/* 252 */     GlStateManager.func_179140_f();
/* 253 */     GlStateManager.func_179091_B();
/* 254 */     GlStateManager.func_179142_g();
/* 255 */     GlStateManager.func_179126_j();
/* 256 */     GlStateManager.func_179143_c(515);
/* 257 */     List<WereBasic> basicList = WereList.BASIC;
/* 258 */     WereBasic achievement = null;
/* 259 */     float f3 = mouseX;
/* 260 */     float f4 = mouseY;
/*     */ 
/*     */     
/* 263 */     RenderHelper.func_74520_c();
/* 264 */     GlStateManager.func_179140_f();
/* 265 */     GlStateManager.func_179091_B();
/* 266 */     GlStateManager.func_179142_g();
/*     */     
/* 268 */     for (int i6 = 0; i6 < basicList.size(); i6++) {
/*     */       
/* 270 */       WereBasic achievement2 = basicList.get(i6);
/*     */ 
/*     */       
/* 273 */       int x = this.field_146294_l / 2 - 14;
/* 274 */       int y = 48;
/* 275 */       if (i6 == 1) {
/*     */         
/* 277 */         y = 96;
/*     */       }
/* 279 */       else if (i6 == 2) {
/*     */         
/* 281 */         if (wolf.getQuestsDone() < 1)
/*     */           break; 
/* 283 */         x = this.field_146294_l / 2 - 62;
/* 284 */         y = 144;
/*     */       }
/* 286 */       else if (i6 == 3) {
/*     */         
/* 288 */         if (wolf.getQuestsDone() < 5)
/*     */           break; 
/* 290 */         x = this.field_146294_l / 2 + 34;
/* 291 */         y = 144;
/*     */       } 
/*     */       
/* 294 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/* 296 */       this.field_146297_k.func_110434_K().func_110577_a(BUTTON_TEXTURES);
/*     */       
/* 298 */       GlStateManager.func_179147_l();
/*     */ 
/*     */       
/* 301 */       int xPosition = x - 2;
/* 302 */       int yPosition = y - 2;
/*     */ 
/*     */       
/* 305 */       func_73729_b(xPosition, yPosition, 0, 0, 28, 28);
/* 306 */       this.field_146297_k.func_110434_K().func_110577_a(achievement2.getTexture());
/* 307 */       this; func_146110_a(xPosition + 4, yPosition + 4, 0.0F, 0.0F, 20, 20, 20.0F, 20.0F);
/*     */       
/* 309 */       GlStateManager.func_179084_k();
/*     */       
/* 311 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/* 313 */       if (f3 >= x && f3 <= (x + 22) && f4 >= y && f4 <= (y + 22))
/*     */       {
/* 315 */         achievement = achievement2;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 320 */     GlStateManager.func_179097_i();
/* 321 */     GlStateManager.func_179147_l();
/* 322 */     GlStateManager.func_179121_F();
/* 323 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/*     */ 
/*     */     
/* 327 */     GlStateManager.func_179143_c(515);
/* 328 */     GlStateManager.func_179097_i();
/* 329 */     GlStateManager.func_179098_w();
/*     */     
/* 331 */     if (!this.abilityPopup && !this.resetActive) {
/*     */       
/* 333 */       this.selectedBasic = achievement;
/* 334 */       if (achievement != null) {
/*     */         
/* 336 */         String s = achievement.getName();
/*     */         
/* 338 */         List<String> temp = Arrays.asList(new String[] { s });
/* 339 */         drawHoveringText(temp, mouseX, mouseY, this.field_146289_q);
/*     */       } 
/*     */     } 
/*     */     
/* 343 */     GlStateManager.func_179126_j();
/* 344 */     GlStateManager.func_179145_e();
/* 345 */     RenderHelper.func_74518_a();
/*     */   }
/*     */   
/*     */   private void drawAttributeLayer(int mouseX, int mouseY, float partialTicks) {
/* 349 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 351 */     GlStateManager.func_179143_c(518);
/* 352 */     GlStateManager.func_179094_E();
/* 353 */     GlStateManager.func_179098_w();
/* 354 */     GlStateManager.func_179140_f();
/* 355 */     GlStateManager.func_179091_B();
/* 356 */     GlStateManager.func_179142_g();
/* 357 */     GlStateManager.func_179126_j();
/* 358 */     GlStateManager.func_179143_c(515);
/*     */     
/* 360 */     List<WereAttribute> attList = WereList.ATTRIBUTES;
/* 361 */     WereAttribute achievement = null;
/* 362 */     float f3 = mouseX;
/* 363 */     float f4 = mouseY;
/*     */ 
/*     */ 
/*     */     
/* 367 */     RenderHelper.func_74520_c();
/* 368 */     GlStateManager.func_179140_f();
/* 369 */     GlStateManager.func_179091_B();
/* 370 */     GlStateManager.func_179142_g();
/*     */     
/* 372 */     for (int i6 = 0; i6 < attList.size(); i6++) {
/*     */       
/* 374 */       WereAttribute achievement2 = attList.get(i6);
/*     */       
/* 376 */       int x = this.field_146294_l / 5;
/* 377 */       int y = 24 + i6 * 14;
/* 378 */       int x2 = this.field_146294_l - x * 2;
/*     */       
/* 380 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 381 */       GlStateManager.func_179147_l();
/*     */       
/* 383 */       this.field_146289_q.func_78276_b(achievement2.getName(), x, y + 3, 0);
/* 384 */       this.field_146297_k.func_110434_K().func_110577_a(backgroundBox);
/* 385 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 386 */       func_73729_b(x2, y + 3, 160, 20, 3 * achievement2.getCap(), 7);
/* 387 */       func_73729_b(x2, y + 3, 160, 30, 3 * wolf.getAttributeTreeAbility(achievement2.getKey()), 7);
/*     */       
/* 389 */       GlStateManager.func_179084_k();
/*     */       
/* 391 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/* 393 */       if (f3 >= x && f3 <= (x2 + 30) && f4 >= y && f4 <= (y + 12)) {
/*     */         
/* 395 */         achievement = achievement2;
/* 396 */         func_73730_a(x - 3, x2 + 30, y, -256);
/* 397 */         func_73730_a(x - 3, x2 + 30, y + 12, -256);
/* 398 */         func_73728_b(x - 3, y, y + 12, -256);
/* 399 */         func_73728_b(x2 + 30, y, y + 12, -256);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 404 */     GlStateManager.func_179097_i();
/* 405 */     GlStateManager.func_179147_l();
/* 406 */     GlStateManager.func_179121_F();
/* 407 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 408 */     GlStateManager.func_179143_c(515);
/* 409 */     GlStateManager.func_179097_i();
/* 410 */     GlStateManager.func_179098_w();
/*     */     
/* 412 */     if (!this.abilityPopup && !this.resetActive) {
/*     */       
/* 414 */       this.selectedAttribute = achievement;
/* 415 */       if (achievement != null) {
/*     */         
/* 417 */         String s = achievement.getName();
/*     */         
/* 419 */         List<String> temp = Arrays.asList(new String[] { s });
/* 420 */         drawHoveringText(temp, mouseX, mouseY, this.field_146289_q);
/*     */       } 
/*     */     } 
/*     */     
/* 424 */     GlStateManager.func_179126_j();
/* 425 */     GlStateManager.func_179145_e();
/* 426 */     RenderHelper.func_74518_a();
/*     */   }
/*     */   
/*     */   private void drawAbilityLayer(int mouseX, int mouseY, float partialTicks) {
/* 430 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 432 */     GlStateManager.func_179143_c(518);
/* 433 */     GlStateManager.func_179094_E();
/* 434 */     GlStateManager.func_179098_w();
/* 435 */     GlStateManager.func_179140_f();
/* 436 */     GlStateManager.func_179091_B();
/* 437 */     GlStateManager.func_179142_g();
/* 438 */     GlStateManager.func_179126_j();
/* 439 */     GlStateManager.func_179143_c(515);
/* 440 */     List<WereAbility> questList = WereList.QUESTABILITIES;
/* 441 */     List<WereAbility> unlockableList = WereList.UNLOCKABILITIES;
/* 442 */     WereAbility achievement = null;
/* 443 */     float f3 = mouseX;
/* 444 */     float f4 = mouseY;
/*     */ 
/*     */     
/* 447 */     RenderHelper.func_74520_c();
/* 448 */     GlStateManager.func_179140_f();
/* 449 */     GlStateManager.func_179091_B();
/* 450 */     GlStateManager.func_179142_g();
/*     */     int i6;
/* 452 */     for (i6 = 0; i6 < questList.size(); i6++) {
/*     */       
/* 454 */       WereAbility achievement2 = questList.get(i6);
/* 455 */       if (i6 < wolf.getQuestsDone() / 2) {
/*     */         
/* 457 */         int x = this.field_146294_l / 2 - 14 - questList.size() * 14 + i6 * 42;
/* 458 */         int y = 32;
/*     */         
/* 460 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */         
/* 462 */         this.field_146297_k.func_110434_K().func_110577_a(BUTTON_TEXTURES);
/*     */         
/* 464 */         GlStateManager.func_179147_l();
/*     */ 
/*     */         
/* 467 */         int xPosition = x - 2;
/* 468 */         int yPosition = y - 2;
/*     */ 
/*     */         
/* 471 */         func_73729_b(xPosition, yPosition, 0, 0, 28, 28);
/* 472 */         this.field_146297_k.func_110434_K().func_110577_a(achievement2.getTexture());
/* 473 */         this; func_146110_a(xPosition + 4, yPosition + 4, 0.0F, 0.0F, 20, 20, 20.0F, 20.0F);
/*     */         
/* 475 */         GlStateManager.func_179084_k();
/*     */         
/* 477 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */         
/* 479 */         if (f3 >= x && f3 <= (x + 22) && f4 >= y && f4 <= (y + 22))
/*     */         {
/* 481 */           achievement = achievement2;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 486 */     for (i6 = 0; i6 < unlockableList.size(); i6++) {
/*     */       
/* 488 */       WereAbility achievement2 = unlockableList.get(i6);
/* 489 */       int x = this.field_146294_l / 2 - 98 + i6 % 5 * 42;
/*     */ 
/*     */       
/* 492 */       int y = this.field_146295_m / 2 - 28 + i6 / 5 * 42;
/*     */       
/* 494 */       if (wolf.getAbilityTreeAbility(achievement2.getKey())) {
/*     */         
/* 496 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       }
/* 498 */       else if (achievement2.canUnlock(wolf)) {
/*     */         
/* 500 */         GlStateManager.func_179131_c(0.5F, 0.5F, 0.5F, 1.0F);
/*     */       }
/*     */       else {
/*     */         
/* 504 */         GlStateManager.func_179131_c(0.1F, 0.1F, 0.1F, 1.0F);
/*     */       } 
/*     */       
/* 507 */       this.field_146297_k.func_110434_K().func_110577_a(BUTTON_TEXTURES);
/*     */       
/* 509 */       GlStateManager.func_179147_l();
/*     */ 
/*     */       
/* 512 */       int xPosition = x - 2;
/* 513 */       int yPosition = y - 2;
/*     */ 
/*     */       
/* 516 */       func_73729_b(xPosition, yPosition, 0, 0, 28, 28);
/* 517 */       this.field_146297_k.func_110434_K().func_110577_a(achievement2.getTexture());
/* 518 */       this; func_146110_a(xPosition + 4, yPosition + 4, 0.0F, 0.0F, 20, 20, 20.0F, 20.0F);
/*     */       
/* 520 */       GlStateManager.func_179084_k();
/*     */       
/* 522 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       
/* 524 */       if (f3 >= x && f3 <= (x + 22) && f4 >= y && f4 <= (y + 22))
/*     */       {
/* 526 */         achievement = achievement2;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 531 */     GlStateManager.func_179097_i();
/* 532 */     GlStateManager.func_179147_l();
/* 533 */     GlStateManager.func_179121_F();
/* 534 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */ 
/*     */ 
/*     */     
/* 538 */     GlStateManager.func_179143_c(515);
/* 539 */     GlStateManager.func_179097_i();
/* 540 */     GlStateManager.func_179098_w();
/*     */     
/* 542 */     if (!this.abilityPopup && !this.resetActive) {
/*     */       
/* 544 */       this.selectedAbility = achievement;
/* 545 */       if (achievement != null) {
/*     */         
/* 547 */         String s = achievement.getName();
/*     */         
/* 549 */         List<String> temp = Arrays.asList(new String[] { s });
/* 550 */         drawHoveringText(temp, mouseX, mouseY, this.field_146289_q);
/*     */       } 
/*     */     } 
/*     */     
/* 554 */     GlStateManager.func_179126_j();
/* 555 */     GlStateManager.func_179145_e();
/* 556 */     RenderHelper.func_74518_a();
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawInclinationLayer(int mouseX, int mouseY, float partialTicks) {
/* 561 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 563 */     GlStateManager.func_179143_c(518);
/* 564 */     GlStateManager.func_179094_E();
/* 565 */     GlStateManager.func_179098_w();
/* 566 */     GlStateManager.func_179140_f();
/* 567 */     GlStateManager.func_179091_B();
/* 568 */     GlStateManager.func_179142_g();
/* 569 */     GlStateManager.func_179126_j();
/* 570 */     GlStateManager.func_179143_c(515);
/* 571 */     List<WereInclination> inclinationList = WereList.INCLINATION;
/* 572 */     WereInclination achievement = null;
/* 573 */     float f3 = mouseX;
/* 574 */     float f4 = mouseY;
/*     */ 
/*     */     
/* 577 */     RenderHelper.func_74520_c();
/* 578 */     GlStateManager.func_179140_f();
/* 579 */     GlStateManager.func_179091_B();
/* 580 */     GlStateManager.func_179142_g();
/*     */     
/* 582 */     for (int i6 = 0; i6 < inclinationList.size(); i6++) {
/*     */       
/* 584 */       WereInclination achievement2 = inclinationList.get(i6);
/* 585 */       if ((wolf.getInclinationType() == 1 && achievement2.getInclinationType() == WereList.Inclination.CALM) || (wolf
/* 586 */         .getInclinationType() == 0 && achievement2.getInclinationType() == WereList.Inclination.NEUTRAL) || (wolf
/* 587 */         .getInclinationType() == -1 && achievement2.getInclinationType() == WereList.Inclination.SAVAGE)) {
/*     */         
/* 589 */         int x = this.field_146294_l / 2 - 14;
/* 590 */         int y = 48;
/* 591 */         if (achievement2.getNumber() == 1) {
/*     */           
/* 593 */           if (wolf.getQuestsDone() < 4)
/*     */             break; 
/* 595 */           y = 96;
/*     */         }
/* 597 */         else if (achievement2.getNumber() == 2) {
/*     */           
/* 599 */           if (wolf.getQuestsDone() < 6)
/*     */             break; 
/* 601 */           x = this.field_146294_l / 2 - 62;
/* 602 */           y = 144;
/*     */         }
/* 604 */         else if (achievement2.getNumber() == 3) {
/*     */           
/* 606 */           if (wolf.getQuestsDone() < 8)
/*     */             break; 
/* 608 */           x = this.field_146294_l / 2 + 34;
/* 609 */           y = 144;
/*     */         } 
/*     */         
/* 612 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */         
/* 614 */         this.field_146297_k.func_110434_K().func_110577_a(BUTTON_TEXTURES);
/*     */         
/* 616 */         GlStateManager.func_179147_l();
/*     */ 
/*     */         
/* 619 */         int xPosition = x - 2;
/* 620 */         int yPosition = y - 2;
/*     */ 
/*     */         
/* 623 */         func_73729_b(xPosition, yPosition, 0, 0, 28, 28);
/* 624 */         this.field_146297_k.func_110434_K().func_110577_a(achievement2.getTexture());
/* 625 */         this; func_146110_a(xPosition + 4, yPosition + 4, 0.0F, 0.0F, 20, 20, 20.0F, 20.0F);
/*     */         
/* 627 */         GlStateManager.func_179084_k();
/*     */         
/* 629 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */         
/* 631 */         if (f3 >= x && f3 <= (x + 22) && f4 >= y && f4 <= (y + 22))
/*     */         {
/* 633 */           achievement = achievement2;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 638 */     GlStateManager.func_179097_i();
/* 639 */     GlStateManager.func_179147_l();
/* 640 */     GlStateManager.func_179121_F();
/* 641 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 642 */     GlStateManager.func_179143_c(515);
/* 643 */     GlStateManager.func_179097_i();
/* 644 */     GlStateManager.func_179098_w();
/*     */     
/* 646 */     if (!this.abilityPopup && !this.resetActive) {
/*     */       
/* 648 */       this.selectedInclination = achievement;
/* 649 */       if (achievement != null) {
/*     */         
/* 651 */         String s = achievement.getName();
/*     */         
/* 653 */         List<String> temp = Arrays.asList(new String[] { s });
/* 654 */         drawHoveringText(temp, mouseX, mouseY, this.field_146289_q);
/*     */       } 
/*     */     } 
/*     */     
/* 658 */     GlStateManager.func_179126_j();
/* 659 */     GlStateManager.func_179145_e();
/* 660 */     RenderHelper.func_74518_a();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_73876_c() {
/* 668 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/*     */     
/* 670 */     this.buttonGeneral.active = (this.currentPage == 0) ? 1 : 0;
/* 671 */     this.buttonAttribute.active = (this.currentPage == 1) ? 1 : 0;
/* 672 */     this.buttonAbility.active = (this.currentPage == 2) ? 1 : 0;
/* 673 */     this.buttonInclination.active = (this.currentPage == 3) ? 1 : 0;
/*     */     
/* 675 */     this.buttonInclination.number = (wolf.getInclinationType() == 0) ? 3 : ((wolf.getInclinationType() == 1) ? 4 : 5);
/*     */     
/* 677 */     this.buttonGeneral.field_146124_l = (!this.resetActive && !this.abilityPopup);
/* 678 */     this.buttonAttribute.field_146124_l = (!this.resetActive && !this.abilityPopup);
/* 679 */     this.buttonAbility.field_146124_l = (!this.resetActive && !this.abilityPopup);
/* 680 */     this.buttonInclination.field_146124_l = (!this.resetActive && !this.abilityPopup);
/*     */ 
/*     */ 
/*     */     
/* 684 */     this.buttonAssign
/*     */       
/* 686 */       .field_146125_m = (this.abilityPopup && ((this.selectedAbility != null && this.selectedAbility.canUnlock(wolf) && this.selectedAbility.havePointsFor(wolf)) || (this.selectedAttribute != null && this.selectedAttribute.canUnlock(wolf))));
/*     */     
/* 688 */     this.buttonClose.field_146125_m = (this.resetActive || this.abilityPopup);
/* 689 */     this.buttonReset.field_146125_m = (!this.resetActive && !this.abilityPopup && this.currentPage > 0 && (wolf.getQuestsDone() > 3 || this.currentPage != 3));
/* 690 */     this.buttonResetConfirm.field_146125_m = this.resetActive;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
/* 695 */     super.func_73864_a(mouseX, mouseY, mouseButton);
/* 696 */     if (!this.abilityPopup && !this.resetActive)
/*     */     {
/* 698 */       if (this.selectedBasic != null || this.selectedAttribute != null || this.selectedAbility != null || this.selectedInclination != null) {
/* 699 */         this.abilityPopup = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void drawGuiForgroundLayer() {
/* 705 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 706 */     int k = this.field_146294_l;
/* 707 */     int l = this.field_146295_m;
/* 708 */     int x = k - 32;
/* 709 */     int y = l - 49;
/* 710 */     this.field_146297_k.func_110434_K().func_110577_a(backgroundBox);
/*     */     
/* 712 */     func_73729_b(0, 0, 0, 0, 16, 16);
/* 713 */     func_73729_b(k - 16, 0, 240, 0, 16, 16);
/* 714 */     func_73729_b(0, l - 16, 0, 240, 16, 16);
/* 715 */     func_73729_b(k - 16, l - 16, 240, 240, 16, 16);
/* 716 */     k -= 32;
/* 717 */     x = 16;
/* 718 */     while (k > 0) {
/*     */       
/* 720 */       if (k > 224) {
/*     */         
/* 722 */         func_73729_b(x, 0, 16, 0, 224, 16);
/* 723 */         func_73729_b(x, l - 16, 16, 240, 224, 16);
/* 724 */         x += 224;
/* 725 */         k -= 224;
/*     */         
/*     */         continue;
/*     */       } 
/* 729 */       func_73729_b(x, 0, 16, 0, k, 16);
/* 730 */       func_73729_b(x, l - 16, 16, 240, k, 16);
/* 731 */       k = 0;
/*     */     } 
/*     */     
/* 734 */     k = this.field_146294_l;
/* 735 */     l -= 32;
/* 736 */     y = 16;
/* 737 */     while (l > 0) {
/*     */       
/* 739 */       if (l > 224) {
/*     */         
/* 741 */         func_73729_b(0, y, 0, 16, 16, 224);
/* 742 */         func_73729_b(k - 16, y, 240, 16, 16, 224);
/* 743 */         y += 224;
/* 744 */         l -= 224;
/*     */         
/*     */         continue;
/*     */       } 
/* 748 */       func_73729_b(0, y, 0, 16, 16, l);
/* 749 */       func_73729_b(k - 16, y, 240, 16, 16, l);
/* 750 */       l = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawSkillPoints() {
/* 757 */     func_73729_b(this.field_146294_l - 41, 16, 214, 17, 25, 37);
/* 758 */     IWerewolfCapability wolf = (IWerewolfCapability)this.field_146297_k.field_71439_g.getCapability(WereEventHandler.WERE_CAP, null);
/* 759 */     boolean unicode = this.field_146289_q.func_82883_a();
/* 760 */     this.field_146289_q.func_78264_a(true);
/* 761 */     if (this.currentPage == 0) {
/*     */       
/* 763 */       String temp = wolf.getUsedAttributePoints() + "/" + wolf.getAttributePoints();
/* 764 */       this.field_146289_q.func_78276_b(temp, this.field_146294_l - 28 - this.field_146289_q.func_78256_a(temp) / 2, 20, 16777215);
/* 765 */       temp = wolf.getUsedAbilityPoints() + "/" + wolf.getAbilityPoints();
/* 766 */       this.field_146289_q.func_78276_b(temp, this.field_146294_l - 28 - this.field_146289_q.func_78256_a(temp) / 2, 30, -16711936);
/*     */     }
/* 768 */     else if (this.currentPage == 1) {
/*     */       
/* 770 */       String temp = wolf.getUsedAttributePoints() + "/" + wolf.getAttributePoints();
/* 771 */       this.field_146289_q.func_78276_b(temp, this.field_146294_l - 28 - this.field_146289_q.func_78256_a(temp) / 2, 20, 16777215);
/*     */     }
/* 773 */     else if (this.currentPage == 2) {
/*     */       
/* 775 */       String temp = wolf.getUsedAbilityPoints() + "/" + wolf.getAbilityPoints();
/* 776 */       this.field_146289_q.func_78276_b(temp, this.field_146294_l - 28 - this.field_146289_q.func_78256_a(temp) / 2, 20, -16711936);
/*     */     } 
/* 778 */     this.field_146289_q.func_78264_a(unicode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawSkillBoxDesc() {
/* 786 */     int centerX = (this.field_146294_l - 176) / 2;
/* 787 */     int centerY = (this.field_146295_m - 126) / 2;
/* 788 */     GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 789 */     this.field_146297_k.func_110434_K().func_110577_a(backgroundBox);
/* 790 */     func_73729_b(centerX, centerY, 40, 110, 176, 126);
/* 791 */     if (this.currentPage == 0 && this.selectedBasic != null) {
/*     */       
/* 793 */       this.field_146289_q.func_78276_b(this.selectedBasic.getName(), centerX + 5, centerY + 5, 0);
/* 794 */       this.field_146289_q.func_78279_b(this.selectedBasic.getDescription(), centerX + 5, centerY + 20, 166, 0);
/*     */     } 
/* 796 */     if (this.currentPage == 1 && this.selectedAttribute != null) {
/*     */       
/* 798 */       this.field_146289_q.func_78276_b(this.selectedAttribute.getName(), centerX + 5, centerY + 5, 0);
/* 799 */       this.field_146289_q.func_78279_b(this.selectedAttribute.getDescription(), centerX + 5, centerY + 20, 166, 0);
/*     */     } 
/* 801 */     if (this.currentPage == 2 && this.selectedAbility != null) {
/*     */       
/* 803 */       this.field_146289_q.func_78276_b(this.selectedAbility.getName(), centerX + 5, centerY + 5, 0);
/* 804 */       this.field_146289_q.func_78279_b(this.selectedAbility.getDescription(), centerX + 5, centerY + 20, 166, 0);
/*     */     } 
/* 806 */     if (this.currentPage == 3 && this.selectedInclination != null) {
/*     */       
/* 808 */       this.field_146289_q.func_78276_b(this.selectedInclination.getName(), centerX + 5, centerY + 5, 0);
/* 809 */       this.field_146289_q.func_78279_b(this.selectedInclination.getDescription(), centerX + 5, centerY + 20, 166, 0);
/*     */     }
/* 811 */     else if (this.resetActive) {
/*     */       
/* 813 */       if (this.currentPage == 1) {
/* 814 */         this.field_146289_q.func_78276_b(I18n.func_135052_a("skills.reset.attribute", new Object[0]), centerX + 5, centerY + 5, 0);
/* 815 */       } else if (this.currentPage == 2) {
/* 816 */         this.field_146289_q.func_78276_b(I18n.func_135052_a("skills.reset.ability", new Object[0]), centerX + 5, centerY + 5, 0);
/* 817 */       } else if (this.currentPage == 3) {
/*     */         
/* 819 */         this.field_146289_q.func_78276_b(I18n.func_135052_a("skills.reset.inclination", new Object[0]), centerX + 5, centerY + 5, 0);
/* 820 */         this.field_146289_q.func_78279_b(I18n.func_135052_a("skills.reset.inclination2", new Object[0]), centerX + 5, centerY + 50, 166, 0);
/*     */       } else {
/*     */         
/* 823 */         this.field_146289_q.func_78276_b(I18n.func_135052_a("skills.broke", new Object[0]), centerX + 5, centerY + 5, 0);
/* 824 */       }  this.field_146289_q.func_78279_b(I18n.func_135052_a("skills.reset.desc", new Object[0]), centerX + 5, centerY + 20, 166, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiSkills.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */