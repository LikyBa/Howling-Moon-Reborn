/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiButtonToggleKeys
/*    */   extends GuiButton
/*    */ {
/*    */   public ResourceLocation buttonTexture;
/*    */   public int number;
/*    */   public int active;
/*    */   
/*    */   public GuiButtonToggleKeys(int id, int xPos, int yPos, int number) {
/* 22 */     super(id, xPos, yPos, 10, 10, "");
/* 23 */     this.buttonTexture = new ResourceLocation("howlingmoon:textures/gui/werewolf_menu2.png");
/* 24 */     this.number = number;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 34 */     if (this.field_146125_m) {
/*    */ 
/*    */       
/* 37 */       mc.func_110434_K().func_110577_a(this.buttonTexture);
/* 38 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 39 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/*    */       
/* 41 */       GlStateManager.func_179147_l();
/* 42 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 43 */       GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*    */       
/* 45 */       func_73729_b(this.field_146128_h, this.field_146129_i, this.active * 10, 246, this.field_146120_f, this.field_146121_g);
/* 46 */       func_146119_b(mc, mouseX, mouseY);
/*    */     }
/* 48 */     else if (this.field_146123_n) {
/*    */       
/* 50 */       this.field_146123_n = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] text() {
/* 56 */     switch (this.number) {
/*    */       
/*    */       case 0:
/* 59 */         if (this.active == 1)
/* 60 */           return new String[] { I18n.func_135052_a("werewolf.menu.sneakJump", new Object[0]), I18n.func_135052_a("werewolf.menu.leap.climb", new Object[0]) }; 
/* 61 */         if (this.active == 2)
/* 62 */           return new String[] { I18n.func_135052_a("werewolf.menu.sneakJump", new Object[0]), I18n.func_135052_a("werewolf.menu.on", new Object[0]) }; 
/* 63 */         return new String[] { I18n.func_135052_a("werewolf.menu.sneakJump", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */       case 1:
/* 65 */         if (this.active == 1)
/* 66 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintJump", new Object[0]), I18n.func_135052_a("werewolf.menu.leap.climb", new Object[0]) }; 
/* 67 */         if (this.active == 2)
/* 68 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintJump", new Object[0]), I18n.func_135052_a("werewolf.menu.leap.leap", new Object[0]) }; 
/* 69 */         if (this.active == 3)
/* 70 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintJump", new Object[0]), I18n.func_135052_a("werewolf.menu.on", new Object[0]) }; 
/* 71 */         return new String[] { I18n.func_135052_a("werewolf.menu.sprintJump", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */       case 2:
/* 73 */         if (this.active == 1)
/* 74 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.climb", new Object[0]) }; 
/* 75 */         if (this.active == 2)
/* 76 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.no", new Object[0]) }; 
/* 77 */         if (this.active == 3)
/* 78 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.stop", new Object[0]) }; 
/* 79 */         if (this.active == 4)
/* 80 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.clamp", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.clamp2", new Object[0]) }; 
/* 81 */         if (this.active == 5)
/* 82 */           return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.clampClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.sprintClimb.clamp2", new Object[0]) }; 
/* 83 */         return new String[] { I18n.func_135052_a("werewolf.menu.sprintClimb", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */     } 
/* 85 */     return new String[] { "", "" };
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiButtonToggleKeys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */