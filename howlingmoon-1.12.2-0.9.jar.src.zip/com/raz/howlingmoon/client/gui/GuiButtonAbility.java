/*    */ package com.raz.howlingmoon.client.gui;
/*    */ 
/*    */ import com.raz.howlingmoon.IWerewolfCapability;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public class GuiButtonAbility
/*    */   extends GuiButton
/*    */ {
/*    */   public ResourceLocation buttonTexture;
/*    */   public int number;
/*    */   public int active;
/*    */   public int row;
/*    */   public boolean ability;
/*    */   
/*    */   public GuiButtonAbility(int id, int xPos, int yPos, int number, int row, boolean ability) {
/* 21 */     super(id, xPos, yPos, 20, 20, "");
/* 22 */     this.buttonTexture = new ResourceLocation("howlingmoon:textures/gui/werewolf_menu2.png");
/* 23 */     this.number = number;
/* 24 */     this.row = row;
/* 25 */     this.ability = ability;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
/* 34 */     if (this.field_146125_m) {
/*    */ 
/*    */       
/* 37 */       mc.func_110434_K().func_110577_a(this.buttonTexture);
/* 38 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 39 */       this.field_146123_n = (mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 45 */       GlStateManager.func_179147_l();
/* 46 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 47 */       GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*    */       
/* 49 */       if (this.ability) {
/* 50 */         func_73729_b(this.field_146128_h, this.field_146129_i, 176 + this.active * 20, this.row * 20, this.field_146120_f, this.field_146121_g);
/*    */       } else {
/* 52 */         func_73729_b(this.field_146128_h, this.field_146129_i, this.active * 20, 176 + this.row * 20, this.field_146120_f, this.field_146121_g);
/* 53 */       }  func_146119_b(mc, mouseX, mouseY);
/*    */     }
/* 55 */     else if (this.field_146123_n) {
/*    */       
/* 57 */       this.field_146123_n = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] text(IWerewolfCapability wolf) {
/* 63 */     switch (this.number) {
/*    */       
/*    */       case 0:
/* 66 */         if (this.active == 0)
/* 67 */           return new String[] { I18n.func_135052_a("ability.Paw", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) }; 
/* 68 */         return new String[] { I18n.func_135052_a("ability.Paw", new Object[0]), I18n.func_135052_a("werewolf.menu.slot", new Object[0]) + ": " + String.valueOf(wolf.getPawSlot()) };
/*    */       case 2:
/* 70 */         if (this.active == 0)
/* 71 */           return new String[] { I18n.func_135052_a("ability.Leap", new Object[0]), I18n.func_135052_a("werewolf.menu.leap.forward", new Object[0]) }; 
/* 72 */         if (this.active == 1)
/* 73 */           return new String[] { I18n.func_135052_a("ability.Leap", new Object[0]), I18n.func_135052_a("werewolf.menu.leap.aim", new Object[0]) }; 
/* 74 */         return new String[] { I18n.func_135052_a("ability.Leap", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */       case 4:
/* 76 */         if (this.active == 1)
/* 77 */           return new String[] { I18n.func_135052_a("ability.NightVision", new Object[0]), I18n.func_135052_a("werewolf.menu.on", new Object[0]) }; 
/* 78 */         return new String[] { I18n.func_135052_a("ability.NightVision", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */       case 5:
/* 80 */         if (this.active == 1)
/* 81 */           return new String[] { I18n.func_135052_a("ability.ScentTracking", new Object[0]), I18n.func_135052_a("werewolf.menu.on", new Object[0]) }; 
/* 82 */         return new String[] { I18n.func_135052_a("ability.ScentTracking", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) };
/*    */       case 6:
/* 84 */         return new String[] { I18n.func_135052_a("werewolf.scent.Color", new Object[0]), I18n.func_135052_a("werewolf.scent.settings", new Object[0]) };
/*    */       case 7:
/* 86 */         if (this.active == 0)
/* 87 */           return new String[] { I18n.func_135052_a("ability.Ram", new Object[0]), I18n.func_135052_a("werewolf.menu.off", new Object[0]) }; 
/* 88 */         if (this.active == 1)
/* 89 */           return new String[] { I18n.func_135052_a("ability.Ram", new Object[0]), I18n.func_135052_a("werewolf.menu.ram.key", new Object[0]) }; 
/* 90 */         return new String[] { I18n.func_135052_a("ability.Ram", new Object[0]), I18n.func_135052_a("werewolf.menu.on", new Object[0]) };
/* 91 */     }  return new String[] { "", "" };
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\gui\GuiButtonAbility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */