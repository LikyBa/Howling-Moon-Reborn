/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import com.raz.howlingmoon.entities.EntityWerewolfGuide;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderLiving;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class RenderWerewolfGuide extends RenderLiving {
/*    */   protected ResourceLocation texture;
/*    */   protected ResourceLocation textureBlack;
/*    */   protected ResourceLocation textureRed;
/*    */   protected ResourceLocation textureTimber;
/*    */   protected ResourceLocation textureKillerwolf;
/*    */   
/*    */   public RenderWerewolfGuide(RenderManager renderManager) {
/* 19 */     super(renderManager, (ModelBase)new ModelWerewolf(), 0.5F);
/* 20 */     setEntityTexture();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void func_77041_b(EntityLivingBase entity, float f) {
/* 26 */     preRenderCallbackWerewolf((EntityWerewolfGuide)entity, f);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void preRenderCallbackWerewolf(EntityWerewolfGuide entity, float f) {}
/*    */ 
/*    */   
/*    */   protected void setEntityTexture() {
/* 35 */     this.texture = new ResourceLocation("howlingmoon:textures/mob/werewolf_white.png");
/* 36 */     this.textureBlack = new ResourceLocation("howlingmoon:textures/mob/werewolf_black.png");
/* 37 */     this.textureTimber = new ResourceLocation("howlingmoon:textures/mob/werewolf_timber.png");
/* 38 */     this.textureKillerwolf = new ResourceLocation("howlingmoon:textures/mob/werewolf_killerwolf.png");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 44 */     int temp = ((EntityWerewolfGuide)entity).getFurColor();
/* 45 */     switch (temp) {
/*    */       case 0:
/* 47 */         return this.texture;
/* 48 */       case 1: return this.textureBlack;
/* 49 */       case 2: return this.textureTimber;
/* 50 */       case 3: return this.textureKillerwolf;
/*    */     } 
/* 52 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\RenderWerewolfGuide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */