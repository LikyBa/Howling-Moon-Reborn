/*    */ package com.raz.howlingmoon.client;
/*    */ 
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyBindings
/*    */ {
/* 11 */   public static KeyBinding menu = new KeyBinding("keys.howlingmoon.menu", 37, "keys.howlingmoon.category");
/* 12 */   public static KeyBinding transform = new KeyBinding("keys.howlingmoon.transform", 36, "keys.howlingmoon.category");
/* 13 */   public static KeyBinding ability1 = new KeyBinding("keys.howlingmoon.ability1", 19, "keys.howlingmoon.category");
/* 14 */   public static KeyBinding ability2 = new KeyBinding("keys.howlingmoon.ability2", 34, "keys.howlingmoon.category");
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\client\KeyBindings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */