/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import net.minecraft.client.resources.I18n;
/*    */ 
/*    */ 
/*    */ public class WereBase
/*    */ {
/*    */   private final String name;
/*    */   private final String description;
/*    */   
/*    */   public WereBase(String unlocalizedName) {
/* 12 */     this.name = unlocalizedName;
/* 13 */     this.description = unlocalizedName + ".desc";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 18 */     return I18n.func_135052_a(this.name, new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 23 */     return I18n.func_135052_a(this.description, new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */