/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ 
/*     */ 
/*     */ public class WerewolfCommand
/*     */   implements ICommand
/*     */ {
/*     */   private List aliases;
/*     */   
/*     */   public WerewolfCommand() {
/*  22 */     this.aliases = new ArrayList();
/*  23 */     this.aliases.add("werewolf");
/*  24 */     this.aliases.add("were");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ICommand arg0) {
/*  30 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/*  54 */     if (args.length <= 0) {
/*     */       
/*  56 */       sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werewolf.usage", new Object[0]));
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  61 */     else if (sender instanceof EntityPlayer) {
/*     */       
/*  63 */       String s = args[0];
/*  64 */       boolean i = CommandBase.func_180527_d(s);
/*  65 */       EntityPlayer entityplayer = (EntityPlayer)sender;
/*  66 */       IWerewolfCapability wolf = (IWerewolfCapability)entityplayer.getCapability(WereEventHandler.WERE_CAP, null);
/*  67 */       boolean temp = wolf.isWerewolf();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       wolf.setWerewolf(i, entityplayer);
/*  73 */       if (temp != wolf.isWerewolf())
/*     */       {
/*  75 */         if (!temp) {
/*  76 */           sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werewolf.success", new Object[] { entityplayer.func_70005_c_() }));
/*     */         } else {
/*  78 */           sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.werewolf.success.false", new Object[] { entityplayer.func_70005_c_() }));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184882_a(MinecraftServer server, ICommandSender sender) {
/*  88 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71517_b() {
/* 101 */     return "werewolf";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/* 107 */     return "commands.werewolf.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_71514_a() {
/* 113 */     return this.aliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args, BlockPos targetPos) {
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WerewolfCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */