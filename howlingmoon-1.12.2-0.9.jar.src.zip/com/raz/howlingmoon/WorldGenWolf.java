/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.raz.howlingmoon.blocks.HMBlocks;
/*     */ import com.raz.howlingmoon.handler.ConfigHandler;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockBush;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.Mirror;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Rotation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.ChunkPos;
/*     */ import net.minecraft.village.Village;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraft.world.gen.IChunkGenerator;
/*     */ import net.minecraft.world.gen.feature.WorldGenBush;
/*     */ import net.minecraft.world.gen.feature.WorldGenMinable;
/*     */ import net.minecraft.world.gen.feature.WorldGenerator;
/*     */ import net.minecraft.world.gen.structure.StructureBoundingBox;
/*     */ import net.minecraft.world.gen.structure.template.PlacementSettings;
/*     */ import net.minecraft.world.gen.structure.template.Template;
/*     */ import net.minecraft.world.gen.structure.template.TemplateManager;
/*     */ import net.minecraftforge.fml.common.IWorldGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldGenWolf
/*     */   implements IWorldGenerator
/*     */ {
/*  53 */   private final WorldGenBush gen_wolfsbane = new WorldGenBush((BlockBush)HMBlocks.wolfsbane);
/*  54 */   private final WorldGenMinable gen_silverOre = new WorldGenMinable(HMBlocks.silverOre.func_176223_P(), 4);
/*  55 */   private List<Village> villageLodge = Lists.newArrayList();
/*     */   
/*     */   protected StructureBoundingBox boundingBox;
/*     */ 
/*     */   
/*     */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
/*  61 */     switch (world.field_73011_w.getDimension()) {
/*     */       case 0:
/*  63 */         runGenerator((WorldGenerator)this.gen_wolfsbane, world, random, chunkX, chunkZ, 1, 1, 255);
/*  64 */         if (ConfigHandler.spawnSilverOre) {
/*  65 */           runGeneratorOre((WorldGenerator)this.gen_silverOre, world, random, chunkX, chunkZ, 6, 0, 40);
/*     */         }
/*  67 */         runGeneratorLodge(world, random, chunkX, chunkZ, 1);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runGenerator(WorldGenerator generator, World world, Random rand, int chunk_X, int chunk_Z, int chancesToSpawn, int minHeight, int maxHeight) {
/*  78 */     if (minHeight < 0 || maxHeight > 256 || minHeight > maxHeight) {
/*  79 */       throw new IllegalArgumentException("Illegal Height Arguments for WorldGenerator");
/*     */     }
/*  81 */     int heightDiff = maxHeight - minHeight + 1;
/*  82 */     for (int i = 0; i < chancesToSpawn; i++) {
/*  83 */       int x = chunk_X * 16 + rand.nextInt(16) + 8;
/*  84 */       int z = chunk_Z * 16 + rand.nextInt(16) + 8;
/*  85 */       int y = minHeight + rand.nextInt(heightDiff);
/*  86 */       BlockPos blockPos = new BlockPos(x, y, z);
/*  87 */       generator.func_180709_b(world, rand, blockPos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runGeneratorOre(WorldGenerator generator, World world, Random rand, int chunk_X, int chunk_Z, int chancesToSpawn, int minHeight, int maxHeight) {
/*  92 */     if (minHeight < 0 || maxHeight > 256 || minHeight > maxHeight) {
/*  93 */       throw new IllegalArgumentException("Illegal Height Arguments for WorldGenerator");
/*     */     }
/*  95 */     int heightDiff = maxHeight - minHeight + 1;
/*  96 */     for (int i = 0; i < chancesToSpawn; i++) {
/*  97 */       int x = chunk_X * 16 + rand.nextInt(16);
/*  98 */       int z = chunk_Z * 16 + rand.nextInt(16);
/*  99 */       int y = minHeight + rand.nextInt(heightDiff);
/* 100 */       BlockPos blockPos = new BlockPos(x, y, z);
/* 101 */       generator.func_180709_b(world, rand, blockPos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runGeneratorLodge(World world, Random rand, int chunk_X, int chunk_Z, int chancesToSpawn) {
/* 111 */     int x = chunk_X * 16 + 2;
/* 112 */     int z = chunk_Z * 16 + 2;
/* 113 */     int y = 64;
/* 114 */     BlockPos blockPos = new BlockPos(x, y, z);
/*     */     
/* 116 */     y = world.func_175672_r(blockPos).func_177956_o();
/* 117 */     blockPos = new BlockPos(x, y, z);
/* 118 */     if (!world.func_180495_p(blockPos).func_177230_c().equals(Blocks.field_150355_j)) {
/*     */       
/* 120 */       BlockPos blockPos2 = new BlockPos(x, y - 1, z);
/* 121 */       if (world.func_180495_p(blockPos2).func_177230_c().equals(Blocks.field_150349_c) || world.func_180495_p(blockPos2).func_177230_c().equals(Blocks.field_150354_m)) {
/*     */         
/* 123 */         Village village = world.func_175714_ae().func_176056_a(blockPos, 20);
/* 124 */         if (village != null && !this.villageLodge.contains(village)) {
/*     */ 
/*     */ 
/*     */           
/* 128 */           blockPos2 = new BlockPos(x + 11, y, z + 8);
/*     */ 
/*     */           
/* 131 */           this.boundingBox = new StructureBoundingBox(new int[] { x, y - 5, z, x + 22, y + 5, z + 17 });
/* 132 */           y = getAverageGroundLevel(world, this.boundingBox);
/* 133 */           if (y > 0) {
/*     */             
/* 135 */             blockPos = new BlockPos(x, y, z);
/*     */ 
/*     */ 
/*     */             
/* 139 */             this.villageLodge.add(village);
/* 140 */             spawnHunterLodge(world, blockPos);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void spawnHunterLodge(World world, BlockPos pos) {
/* 182 */     if (!world.field_72995_K) {
/* 183 */       WorldServer worldserver = (WorldServer)world;
/* 184 */       MinecraftServer minecraftserver = world.func_73046_m();
/* 185 */       TemplateManager templatemanager = worldserver.func_184163_y();
/* 186 */       ResourceLocation loc = new ResourceLocation("howlingmoon", "hunter_lodge");
/*     */       
/* 188 */       Template template = templatemanager.func_186237_a(minecraftserver, loc);
/*     */       
/* 190 */       if (template != null) {
/* 191 */         IBlockState iblockstate = world.func_180495_p(pos);
/* 192 */         world.func_184138_a(pos, iblockstate, iblockstate, 3);
/*     */ 
/*     */         
/* 195 */         PlacementSettings placementsettings = (new PlacementSettings()).func_186214_a(Mirror.NONE).func_186220_a(Rotation.NONE).func_186222_a(false).func_186218_a((ChunkPos)null).func_186225_a((Block)null).func_186226_b(false);
/*     */ 
/*     */ 
/*     */         
/* 199 */         template.func_186253_b(world, pos, placementsettings);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getAverageGroundLevel(World world, StructureBoundingBox box) {
/* 218 */     int i = 0;
/* 219 */     int j = 0;
/*     */     
/* 221 */     for (int k = box.field_78896_c; k <= box.field_78892_f; k++) {
/*     */       
/* 223 */       for (int l = box.field_78897_a; l <= box.field_78893_d; l++) {
/*     */         
/* 225 */         BlockPos blockpos = new BlockPos(l, 64, k);
/* 226 */         blockpos = world.func_175672_r(blockpos);
/*     */         
/* 228 */         while (blockpos.func_177956_o() > world.field_73011_w.func_76557_i() - 1) {
/*     */ 
/*     */           
/* 231 */           if (world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockAir || world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockLeaves || world
/* 232 */             .func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockLog || world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockFlower) {
/*     */             
/* 234 */             blockpos = new BlockPos(blockpos.func_177958_n(), blockpos.func_177956_o() - 1, blockpos.func_177952_p()); continue;
/*     */           } 
/* 236 */           if (world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockPlanks || world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockStairs || world
/* 237 */             .func_180495_p(blockpos).func_177230_c().equals(Blocks.field_150347_e)) {
/* 238 */             return -1;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 243 */         i += Math.max(blockpos.func_177956_o() + 1, world.field_73011_w.func_76557_i() - 1);
/* 244 */         j++;
/*     */       } 
/*     */     } 
/*     */     
/* 248 */     if (j == 0)
/*     */     {
/* 250 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 254 */     return i / j;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WorldGenWolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */