/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.raz.howlingmoon.ai.EntityAIAvoidWerewolf;
/*     */ import com.raz.howlingmoon.dimension.HMTeleporter;
/*     */ import com.raz.howlingmoon.entities.EntityWere;
/*     */ import com.raz.howlingmoon.handler.ConfigHandler;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncExpLevelClient;
/*     */ import com.raz.howlingmoon.packets.SyncWereCapsMessage;
/*     */ import com.raz.howlingmoon.packets.TrackingMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityCreature;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.entity.monster.AbstractSkeleton;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.entity.monster.EntityMob;
/*     */ import net.minecraft.entity.passive.EntityAnimal;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.passive.EntityVillager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.ItemFood;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.CombatRules;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraftforge.common.ISpecialArmor;
/*     */ import net.minecraftforge.common.capabilities.Capability;
/*     */ import net.minecraftforge.common.capabilities.CapabilityInject;
/*     */ import net.minecraftforge.common.capabilities.ICapabilityProvider;
/*     */ import net.minecraftforge.common.capabilities.ICapabilitySerializable;
/*     */ import net.minecraftforge.event.AttachCapabilitiesEvent;
/*     */ import net.minecraftforge.event.entity.EntityJoinWorldEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingFallEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingHurtEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
/*     */ import net.minecraftforge.event.entity.living.LootingLevelEvent;
/*     */ import net.minecraftforge.event.entity.player.AttackEntityEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerPickupXpEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WereEventHandler
/*     */ {
/*  82 */   public static List<String> transformedPlayers = new ArrayList<>();
/*     */   
/*     */   @CapabilityInject(IWerewolfCapability.class)
/*  85 */   public static final Capability<IWerewolfCapability> WERE_CAP = null;
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityConstruct(AttachCapabilitiesEvent<Entity> evt) {
/*  90 */     if (evt.getObject() instanceof EntityPlayer)
/*     */     {
/*  92 */       evt.addCapability(new ResourceLocation("howlingmoon", "IWerewolfCapability"), (ICapabilityProvider)new ICapabilitySerializable<NBTBase>()
/*     */           {
/*  94 */             IWerewolfCapability inst = (IWerewolfCapability)WereEventHandler.WERE_CAP.getDefaultInstance();
/*     */             
/*     */             public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
/*  97 */               return (capability == WereEventHandler.WERE_CAP);
/*     */             }
/*     */ 
/*     */             
/*     */             public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
/* 102 */               return (capability == WereEventHandler.WERE_CAP) ? (T)WereEventHandler.WERE_CAP.cast(this.inst) : null;
/*     */             }
/*     */ 
/*     */             
/*     */             public NBTBase serializeNBT() {
/* 107 */               return WereEventHandler.WERE_CAP.getStorage().writeNBT(WereEventHandler.WERE_CAP, this.inst, null);
/*     */             }
/*     */ 
/*     */             
/*     */             public void deserializeNBT(NBTBase nbt) {
/* 112 */               WereEventHandler.WERE_CAP.getStorage().readNBT(WereEventHandler.WERE_CAP, this.inst, null, nbt);
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityJoinWorld(EntityJoinWorldEvent event) {
/* 121 */     if (event.getEntity() instanceof EntityPlayer && !(event.getEntity()).field_70170_p.field_72995_K) {
/*     */       
/* 123 */       PacketDispatcher.sendTo((IMessage)new SyncWereCapsMessage((EntityPlayer)event.getEntity()), (EntityPlayerMP)event.getEntity());
/*     */     }
/* 125 */     else if (event.getEntity() instanceof EntityAnimal) {
/*     */       
/* 127 */       if (!(event.getEntity() instanceof net.minecraft.entity.passive.EntityWolf))
/*     */       {
/* 129 */         ((EntityAnimal)event.getEntity()).field_70714_bg.func_75776_a(3, (EntityAIBase)new EntityAIAvoidWerewolf((EntityCreature)event.getEntity(), EntityWere.class, 6.0F, 1.3D, 1.5D));
/*     */       }
/*     */     }
/* 132 */     else if (event.getEntity() instanceof EntityVillager) {
/* 133 */       ((EntityVillager)event.getEntity()).field_70714_bg.func_75776_a(1, (EntityAIBase)new EntityAIAvoidWerewolf((EntityCreature)event.getEntity(), EntityWere.class, 8.0F, 0.6D, 0.6D));
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onClonePlayer(PlayerEvent.Clone event) {
/* 139 */     ((IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null)).copy((IWerewolfCapability)event.getOriginal().getCapability(WERE_CAP, null));
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void TrackHandler(PlayerEvent.StartTracking event) {
/* 145 */     if (event.getTarget() instanceof EntityPlayer && 
/* 146 */       !(event.getEntityPlayer()).field_70170_p.field_72995_K && (
/* 147 */       (IWerewolfCapability)((EntityPlayer)event.getTarget()).getCapability(WERE_CAP, null)).isWerewolf()) {
/* 148 */       PacketDispatcher.sendTo((IMessage)new TrackingMessage((EntityPlayer)event.getTarget()), (EntityPlayerMP)event.getEntityPlayer());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void jumpHeight(LivingEvent.LivingJumpEvent event) {
/* 156 */     if (event.getEntityLiving() instanceof EntityPlayer) {
/*     */       
/* 158 */       EntityPlayer player = (EntityPlayer)event.getEntityLiving();
/* 159 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/*     */       
/* 161 */       if (wolf.isTransformed()) {
/*     */         
/* 163 */         double i = wolf.getAttributeTreeAbility(WereList.JUMP.getKey()) / 10.0D;
/* 164 */         i += 0.2D;
/* 165 */         if (wolf.getModel() == 2)
/* 166 */           i *= 1.5D; 
/* 167 */         if (wearingArmor(player) && !getCalmInclination((EntityPlayer)event.getEntityLiving(), 3))
/*     */         {
/* 169 */           i *= 0.5D;
/*     */         }
/* 171 */         (event.getEntityLiving()).field_70181_x += i;
/*     */         
/* 173 */         if (player.field_70170_p.field_72995_K) {
/*     */           
/* 175 */           if (canLeap(player)) {
/*     */             
/* 177 */             float speed = 1.5F + 0.1F * wolf.getLevel() + 0.1F * wolf.getAttributeTreeAbility(WereList.MOVEMENT.getKey());
/* 178 */             if (!player.field_70122_E)
/*     */             {
/* 180 */               speed -= 0.3F;
/*     */             }
/* 182 */             if (wearingArmor(player) && !getCalmInclination((EntityPlayer)event.getEntityLiving(), 3))
/*     */             {
/* 184 */               speed *= 0.5F;
/*     */             }
/* 186 */             if (wolf.getLeapState() == 0) {
/*     */               
/* 188 */               player.field_70159_w = (-MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * speed);
/* 189 */               player.field_70179_y = (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * speed);
/*     */             }
/*     */             else {
/*     */               
/* 193 */               if (player.field_70127_C < 0.0F)
/* 194 */                 player.field_70181_x += (-MathHelper.func_76126_a(player.field_70125_A / 180.0F * 3.1415927F) * speed / 5.0F); 
/* 195 */               player.field_70159_w = (-MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F) * speed);
/* 196 */               player.field_70179_y = (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(player.field_70125_A / 180.0F * 3.1415927F) * speed);
/*     */             } 
/*     */           } 
/* 199 */           wolf.setLeap(false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingFallEvent(LivingFallEvent event) {
/* 208 */     if (event.getEntityLiving() instanceof EntityPlayer) {
/*     */       
/* 210 */       EntityPlayer player = (EntityPlayer)event.getEntityLiving();
/* 211 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/*     */       
/* 213 */       if (wolf.isTransformed()) {
/*     */         
/* 215 */         float reduceby = 2.0F * (float)Math.pow(2.0D, wolf.getAttributeTreeAbility(WereList.FALL.getKey()));
/*     */         
/* 217 */         if (wolf.getModel() == 2)
/* 218 */           reduceby *= 2.0F; 
/* 219 */         event.setDistance(event.getDistance() - reduceby);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void updateStep(LivingEvent.LivingUpdateEvent event) {
/* 227 */     float wolfsbaneMod = 1.0F;
/*     */     
/* 229 */     if (event.getEntityLiving().func_70644_a(HMPotions.BLEEDING))
/*     */     {
/* 231 */       if (event.getEntityLiving().func_70660_b(HMPotions.BLEEDING).func_76459_b() % 40 == 0)
/* 232 */         event.getEntityLiving().func_70097_a(DamageSource.field_76376_m.func_151518_m(), 1.0F); 
/*     */     }
/* 234 */     if (event.getEntityLiving().func_70644_a(HMPotions.WOLFSBANE))
/*     */     {
/* 236 */       if (event.getEntityLiving() instanceof EntityPlayer) {
/*     */         
/* 238 */         IWerewolfCapability wolfP = (IWerewolfCapability)((EntityPlayer)event.getEntityLiving()).getCapability(WERE_CAP, null);
/* 239 */         if (wolfP.isWerewolf()) {
/*     */           
/* 241 */           if (getCalmInclination((EntityPlayer)event.getEntityLiving(), 2)) {
/*     */             
/* 243 */             wolfsbaneMod = 0.8F;
/* 244 */             if (event.getEntityLiving().func_70660_b(HMPotions.WOLFSBANE).func_76459_b() % 40 == 0) {
/* 245 */               event.getEntityLiving().func_70097_a(DamageSource.field_76376_m.func_151518_m(), 1.0F);
/*     */             }
/* 247 */           } else if (getSavageInclination((EntityPlayer)event.getEntityLiving(), 3)) {
/*     */             
/* 249 */             wolfsbaneMod = 0.4F;
/* 250 */             if (event.getEntityLiving().func_70660_b(HMPotions.WOLFSBANE).func_76459_b() % 15 == 0) {
/* 251 */               event.getEntityLiving().func_70097_a(DamageSource.field_76376_m.func_151518_m(), 1.0F);
/*     */             }
/*     */           } else {
/*     */             
/* 255 */             wolfsbaneMod = 0.6F;
/* 256 */             if (event.getEntityLiving().func_70660_b(HMPotions.WOLFSBANE).func_76459_b() % 20 == 0) {
/* 257 */               event.getEntityLiving().func_70097_a(DamageSource.field_76376_m.func_151518_m(), 1.0F);
/*     */             }
/*     */           } 
/*     */         } else {
/* 261 */           event.getEntityLiving().func_184596_c(HMPotions.WOLFSBANE);
/*     */         } 
/* 263 */       } else if (event.getEntityLiving() instanceof com.raz.howlingmoon.entities.EntityWerewolf) {
/*     */         
/* 265 */         if (event.getEntityLiving().func_70660_b(HMPotions.WOLFSBANE).func_76459_b() % 20 == 0) {
/* 266 */           event.getEntityLiving().func_70097_a(DamageSource.field_76376_m.func_151518_m(), 1.0F);
/*     */         }
/*     */       } else {
/* 269 */         event.getEntityLiving().func_184596_c(HMPotions.WOLFSBANE);
/*     */       } 
/*     */     }
/* 272 */     if (event.getEntityLiving() instanceof EntityPlayer) {
/*     */       
/* 274 */       EntityPlayer player = (EntityPlayer)event.getEntityLiving();
/* 275 */       String s = player.func_146103_bH().getName() + ":" + player.field_70170_p.field_72995_K;
/* 276 */       IWerewolfCapability wolf = (IWerewolfCapability)((EntityPlayer)event.getEntityLiving()).getCapability(WERE_CAP, null);
/*     */       
/* 278 */       if (transformedPlayers.contains(s)) {
/* 279 */         if (wolf.isTransformed()) {
/*     */ 
/*     */           
/* 282 */           if ((player.field_70122_E || player.field_71075_bZ.field_75100_b) && (player.field_191988_bg != 0.0F || player.field_70702_br != 0.0F) && !player.func_70055_a(Material.field_151586_h)) {
/*     */             
/* 284 */             float additional = 0.004F * wolf.getLevel();
/* 285 */             additional += 0.01F * wolf.getAttributeTreeAbility(WereList.MOVEMENT.getKey());
/* 286 */             if (player.func_70051_ag())
/*     */             {
/* 288 */               if (wolf.getModel() == 0) {
/* 289 */                 additional *= 1.5F;
/*     */               } else {
/* 291 */                 additional *= 2.0F;
/*     */               }  } 
/* 293 */             if (wolf.getModel() == 1)
/* 294 */               additional *= 1.5F; 
/* 295 */             if (wearingArmor(player) && !getCalmInclination(player, 3))
/*     */             {
/* 297 */               additional *= 0.25F;
/*     */             }
/* 299 */             additional *= wolfsbaneMod;
/*     */             
/* 301 */             if (player.field_191988_bg < 0.0F) {
/* 302 */               player.func_191958_b(player.field_70702_br * 0.75F, 0.0F, player.field_191988_bg * 0.5F, additional);
/*     */             } else {
/* 304 */               player.func_191958_b(player.field_70702_br * 0.5F, 0.0F, player.field_191988_bg, additional);
/*     */             } 
/* 306 */           }  if (player.func_70093_af())
/* 307 */           { player.field_70138_W = 0.60001F; }
/* 308 */           else { player.field_70138_W = 1.1F; }
/* 309 */            if (wolf.getAttributeTreeAbility(WereList.KNOCKRESIST.getKey()) == 0) {
/*     */             
/* 311 */             if (wolf.getKnockbackResist())
/*     */             {
/* 313 */               player.func_110140_aT().func_111148_a(wolf.getAttributeKBResist());
/* 314 */               wolf.setKnockbackResist(false);
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 319 */           else if (!wolf.getKnockbackResist()) {
/*     */             
/* 321 */             player.func_110140_aT().func_111147_b(wolf.getAttributeKBResist());
/* 322 */             wolf.setKnockbackResist(true);
/*     */           } 
/*     */           
/* 325 */           if (wolf.getAbilityTreeAbility(WereList.NIGHTVISION.getKey()))
/*     */           {
/* 327 */             if (wolf.getNightVision()) {
/* 328 */               player.func_70690_d(new PotionEffect(MobEffects.field_76439_r, 310, 0, false, false));
/* 329 */             } else if (player.func_70644_a(MobEffects.field_76439_r) && player.func_70660_b(MobEffects.field_76439_r).func_76459_b() < 311) {
/* 330 */               player.func_184589_d(MobEffects.field_76439_r);
/*     */             }
/*     */           
/*     */           }
/*     */         } else {
/*     */           
/* 336 */           player.field_70138_W = 0.6F;
/* 337 */           transformedPlayers.remove(s);
/* 338 */           player.func_110140_aT().func_111148_a(wolf.getAttributeKBResist());
/* 339 */           wolf.setKnockbackResist(false);
/*     */         } 
/* 341 */       } else if (wolf.isTransformed()) {
/* 342 */         transformedPlayers.add(s);
/* 343 */         player.field_70138_W = 1.1F;
/*     */         
/* 345 */         if (wolf.getAttributeTreeAbility(WereList.KNOCKRESIST.getKey()) > 0)
/*     */         {
/* 347 */           player.func_110140_aT().func_111147_b(wolf.getAttributeKBResist());
/* 348 */           wolf.setKnockbackResist(true);
/*     */         }
/*     */       
/* 351 */       } else if (wolf.isWerewolf() && wolf.getInclinationType() == -1 && wolf.getQuestsDone() > 7) {
/*     */         
/* 353 */         if ((player.field_70122_E || player.field_71075_bZ.field_75100_b) && (player.field_191988_bg != 0.0F || player.field_70702_br != 0.0F) && !player.func_70055_a(Material.field_151586_h)) {
/*     */           
/* 355 */           float additional = 0.004F * wolf.getLevel();
/* 356 */           additional += 0.01F * wolf.getAttributeTreeAbility(WereList.MOVEMENT.getKey());
/* 357 */           if (player.func_70051_ag())
/*     */           {
/* 359 */             additional *= 1.5F;
/*     */           }
/* 361 */           if (wearingArmor(player))
/*     */           {
/* 363 */             additional *= 0.25F;
/*     */           }
/* 365 */           additional *= wolfsbaneMod;
/* 366 */           additional *= 0.25F;
/* 367 */           if (player.field_191988_bg < 0.0F) {
/* 368 */             player.func_191958_b(player.field_70702_br * 0.75F, 0.0F, player.field_191988_bg * 0.5F, additional);
/*     */           } else {
/* 370 */             player.func_191958_b(player.field_70702_br * 0.5F, 0.0F, player.field_191988_bg, additional);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void mercilessAttack(AttackEntityEvent event) {
/* 379 */     IWerewolfCapability wolf = (IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null);
/* 380 */     if (wolf.isTransformed() && wolf.getInclinationType() < 0 && wolf.getQuestsDone() > 7) {
/*     */       
/* 382 */       float damage = 4.0F + (float)Math.floor(wolf.getLevel() / 5.0D);
/* 383 */       damage *= 1.0F + 0.15F * wolf.getAttributeTreeAbility(WereList.STRENGTH.getKey());
/* 384 */       double range = 1.5D;
/* 385 */       if (wolf.getModel() == 2) {
/*     */         
/* 387 */         damage *= 1.25F;
/* 388 */         range = 3.0D;
/*     */       } 
/*     */       
/* 391 */       for (EntityLivingBase entitylivingbase : (event.getEntityPlayer()).field_70170_p.func_72872_a(EntityLivingBase.class, new AxisAlignedBB(
/* 392 */             (event.getEntityPlayer()).field_70165_t - range, (event.getEntityPlayer()).field_70163_u - range, (event.getEntityPlayer()).field_70161_v - range, 
/* 393 */             (event.getEntityPlayer()).field_70165_t + range, (event.getEntityPlayer()).field_70163_u + range, (event.getEntityPlayer()).field_70161_v + range))) {
/*     */         
/* 395 */         if (entitylivingbase instanceof EntityTameable)
/*     */         {
/* 397 */           if (((EntityTameable)entitylivingbase).func_152114_e((EntityLivingBase)event.getEntityPlayer())) {
/*     */             continue;
/*     */           }
/*     */         }
/*     */         
/* 402 */         if (entitylivingbase != event.getEntityPlayer() && entitylivingbase != event.getTarget() && !event.getEntityPlayer().func_184191_r((Entity)entitylivingbase) && event.getEntityPlayer().func_70068_e((Entity)entitylivingbase) < 9.0D) {
/*     */           
/* 404 */           entitylivingbase.func_70653_a((Entity)event.getEntityPlayer(), 0.4F, MathHelper.func_76126_a((event.getEntityPlayer()).field_70177_z * 0.017453292F), -MathHelper.func_76134_b((event.getEntityPlayer()).field_70177_z * 0.017453292F));
/* 405 */           entitylivingbase.func_70097_a(DamageSource.func_76365_a(event.getEntityPlayer()), damage);
/* 406 */           if (wolf.getAbilityTreeAbility(WereList.SHRED.getKey()))
/*     */           {
/* 408 */             entitylivingbase.func_70690_d(new PotionEffect(HMPotions.BLEEDING, 300, 0, false, true));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 413 */       (event.getEntityPlayer()).field_70170_p.func_184148_a((EntityPlayer)null, (event.getEntityPlayer()).field_70165_t, (event.getEntityPlayer()).field_70163_u, (event.getEntityPlayer()).field_70161_v, SoundEvents.field_187730_dW, event.getEntityPlayer().func_184176_by(), 1.0F, 1.0F);
/* 414 */       event.getEntityPlayer().func_184810_cG();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void clawAttack(LivingHurtEvent event) {
/* 421 */     if (event.getEntityLiving() != null) {
/*     */       
/* 423 */       boolean isSilver = false;
/* 424 */       if (event.getSource().func_76346_g() instanceof EntityLivingBase)
/*     */       {
/* 426 */         if (!((EntityLivingBase)event.getSource().func_76346_g()).func_184614_ca().func_190926_b())
/*     */         {
/*     */           
/* 429 */           if (HowlingMoon.silverTools.contains(((EntityLivingBase)event.getSource().func_76346_g()).func_184614_ca().func_77973_b())) {
/*     */ 
/*     */             
/* 432 */             isSilver = true;
/* 433 */             if (event.getEntityLiving() instanceof EntityPlayer) {
/*     */               
/* 435 */               EntityPlayer player = (EntityPlayer)event.getEntityLiving();
/* 436 */               IWerewolfCapability wolf1 = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/*     */               
/* 438 */               if (wolf1.isWerewolf())
/*     */               {
/* 440 */                 if (getCalmInclination(player, 2))
/*     */                 {
/* 442 */                   event.setAmount(event.getAmount() * 1.2F);
/* 443 */                   player.func_70690_d(new PotionEffect(HMPotions.SILVERPOISON, 150, 0, false, true));
/*     */                 }
/* 445 */                 else if (getSavageInclination(player, 3))
/*     */                 {
/* 447 */                   event.setAmount(event.getAmount() * 2.5F);
/* 448 */                   player.func_70690_d(new PotionEffect(HMPotions.SILVERPOISON, 400, 0, false, true));
/*     */                 }
/*     */                 else
/*     */                 {
/* 452 */                   event.setAmount(event.getAmount() * 1.75F);
/* 453 */                   player.func_70690_d(new PotionEffect(HMPotions.SILVERPOISON, 300, 0, false, true));
/*     */                 }
/*     */               
/*     */               }
/* 457 */             } else if (event.getEntityLiving() instanceof com.raz.howlingmoon.entities.EntityWerewolf) {
/*     */               
/* 459 */               event.setAmount(event.getAmount() * 2.5F);
/* 460 */               event.getEntityLiving().func_70690_d(new PotionEffect(HMPotions.SILVERPOISON, 300, 0, false, true));
/*     */             }
/* 462 */             else if (event.getEntityLiving().func_70662_br()) {
/*     */               
/* 464 */               event.setAmount(event.getAmount() * 2.0F);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       }
/* 469 */       if (event.getSource().func_76346_g() instanceof EntityPlayer) {
/*     */         
/* 471 */         EntityPlayer player = (EntityPlayer)event.getSource().func_76346_g();
/* 472 */         IWerewolfCapability wolf2 = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 473 */         if (wolf2.isTransformed()) {
/*     */           
/* 475 */           boolean feral = (wolf2.getInclinationType() < 0 && wolf2.getQuestsDone() > 7);
/* 476 */           if (player.func_184614_ca().func_190926_b()) {
/*     */             
/* 478 */             if (wolf2.getAbilityTreeAbility(WereList.SHRED.getKey()))
/*     */             {
/* 480 */               event.getEntityLiving().func_70690_d(new PotionEffect(HMPotions.BLEEDING, 300, 0, false, true));
/*     */             }
/* 482 */             float damage = 4.0F + (float)Math.floor(wolf2.getLevel() / 5.0D);
/* 483 */             damage *= 1.0F + 0.15F * wolf2.getAttributeTreeAbility(WereList.STRENGTH.getKey());
/* 484 */             if (wolf2.getModel() == 2)
/* 485 */               damage *= 1.25F; 
/* 486 */             if (feral)
/*     */             {
/* 488 */               damage *= 1.25F;
/*     */             }
/* 490 */             if (wolf2.getInclinationType() < 0 && wolf2.getQuestsDone() > 5)
/*     */             {
/* 492 */               damage += (wolf2.getBerserkLevel() / 3);
/*     */             }
/*     */             
/* 495 */             int armorIgnore = wolf2.getAttributeTreeAbility(WereList.REND.getKey()) * 2;
/* 496 */             int armor = event.getEntityLiving().func_70658_aO();
/* 497 */             if (armor > 0 && (armorIgnore > 0 || feral)) {
/*     */               
/* 499 */               if (feral && wolf2.getAbilityTreeAbility(WereList.ARMOR.getKey()))
/* 500 */                 armor /= 2; 
/* 501 */               armor -= armorIgnore;
/* 502 */               if (armor < 0)
/* 503 */                 armor = 0; 
/* 504 */               event.getSource().func_76348_h();
/* 505 */               damage = CombatRules.func_189427_a(damage, armor, (float)event.getEntityLiving().func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/*     */             } 
/* 507 */             event.setAmount(damage);
/*     */             
/* 509 */             int kbAmount = wolf2.getAttributeTreeAbility(WereList.KNOCKBACK.getKey());
/* 510 */             if (kbAmount > 0)
/*     */             {
/* 512 */               event.getEntityLiving().func_70653_a((Entity)event.getEntityLiving(), 2.0F * kbAmount, (event.getSource().func_76364_f()).field_70165_t - (event.getEntityLiving()).field_70165_t, 
/* 513 */                   (event.getSource().func_76364_f()).field_70161_v - (event.getEntityLiving()).field_70161_v);
/*     */             }
/*     */           }
/* 516 */           else if (!getCalmInclination(player, 3)) {
/*     */             
/* 518 */             if (feral) {
/* 519 */               event.setAmount(event.getAmount() * 0.25F);
/*     */             } else {
/* 521 */               event.setAmount(event.getAmount() * 0.6F);
/*     */             } 
/*     */           } 
/*     */         } 
/* 525 */       }  if (event.getEntity() instanceof EntityPlayer) {
/*     */         
/* 527 */         EntityPlayer player = (EntityPlayer)event.getEntity();
/* 528 */         IWerewolfCapability wolf3 = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 529 */         if (wolf3.isTransformed()) {
/*     */           
/* 531 */           if (wearingArmor(player)) {
/*     */             
/* 533 */             if (!getCalmInclination(player, 3)) {
/*     */               
/* 535 */               Iterator<ItemStack> armor = player.func_184193_aE().iterator();
/* 536 */               int slot = 0;
/* 537 */               while (armor.hasNext())
/*     */               {
/* 539 */                 ItemStack piece = armor.next();
/* 540 */                 if (piece != null)
/*     */                 {
/* 542 */                   if (piece.func_77973_b() instanceof ISpecialArmor) {
/*     */                     
/* 544 */                     ((ISpecialArmor)piece.func_77973_b()).damageArmor((EntityLivingBase)player, piece, event.getSource(), 2, slot);
/*     */                   }
/*     */                   else {
/*     */                     
/* 548 */                     piece.func_77972_a(2, (EntityLivingBase)player);
/*     */                   } 
/*     */                 }
/* 551 */                 slot++;
/*     */               }
/*     */             
/*     */             } 
/* 555 */           } else if (!event.getSource().func_76347_k() && !event.getSource().func_151517_h()) {
/*     */             float damage;
/*     */             
/* 558 */             if (isSilver) {
/* 559 */               damage = 1.0F - wolf3.getLevel() * 0.01F + wolf3.getAttributeTreeAbility(WereList.PROTECTION.getKey()) * 0.04F;
/*     */             } else {
/* 561 */               damage = 1.0F - wolf3.getLevel() * 0.02F + wolf3.getAttributeTreeAbility(WereList.PROTECTION.getKey()) * 0.08F;
/* 562 */             }  if (damage < 0.1F)
/* 563 */               damage = 0.1F; 
/* 564 */             event.setAmount(event.getAmount() * damage);
/*     */           }
/*     */         
/* 567 */         } else if (wolf3.isWerewolf() && wolf3.getInclinationType() < 0 && wolf3.getQuestsDone() > 7) {
/*     */           
/* 569 */           if (!event.getSource().func_151517_h() && !event.getSource().func_82725_o() && !event.getSource().func_76347_k()) {
/*     */             float damage;
/*     */ 
/*     */             
/* 573 */             if (isSilver) {
/* 574 */               damage = 1.0F - (wolf3.getLevel() * 0.01F + wolf3.getAttributeTreeAbility(WereList.PROTECTION.getKey()) * 0.04F) / 2.0F;
/*     */             } else {
/* 576 */               damage = 1.0F - (wolf3.getLevel() * 0.02F + wolf3.getAttributeTreeAbility(WereList.PROTECTION.getKey()) * 0.08F) / 2.0F;
/* 577 */             }  if (damage < 0.2F)
/* 578 */               damage = 0.2F; 
/* 579 */             event.setAmount(event.getAmount() * damage);
/*     */             
/* 581 */             if (wearingArmor(player))
/*     */             {
/* 583 */               int armor = event.getEntityLiving().func_70658_aO();
/* 584 */               armor /= 2;
/* 585 */               event.getSource().func_76348_h();
/* 586 */               event.setAmount(CombatRules.func_189427_a(event.getAmount(), armor, (float)event.getEntityLiving().func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/* 591 */       } else if (event.getEntity() instanceof EntityWere) {
/*     */         
/* 593 */         EntityWere wolf = (EntityWere)event.getEntity();
/* 594 */         if (!event.getSource().func_76347_k() && !event.getSource().func_151517_h()) {
/*     */           float damage;
/*     */           
/* 597 */           if (isSilver) {
/* 598 */             damage = 1.0F - wolf.getSavageryLevel() * 0.08F;
/*     */           } else {
/* 600 */             damage = 1.0F - wolf.getSavageryLevel() * 0.16F;
/* 601 */           }  if (damage < 0.2F)
/* 602 */             damage = 0.2F; 
/* 603 */           event.setAmount(event.getAmount() * damage);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWerewolfKill(LivingDeathEvent event) {
/* 612 */     if (event.getSource().func_76364_f() instanceof EntityPlayer) {
/*     */       
/* 614 */       EntityPlayer player = (EntityPlayer)event.getSource().func_76364_f();
/* 615 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 616 */       if (wolf.isWerewolf())
/*     */       {
/* 618 */         if (wolf.isTransformed()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 634 */           player.func_71024_bL().func_75122_a(1, 2.0F);
/* 635 */           if (event.getEntityLiving().func_110138_aP() > 2.0F) {
/*     */             
/* 637 */             wolf.addExp(Math.max(1, (int)event.getEntityLiving().func_110138_aP() / 10));
/* 638 */             PacketDispatcher.sendTo((IMessage)new SyncExpLevelClient(player), (EntityPlayerMP)player);
/*     */           } 
/* 640 */           if (wolf.getInclinationType() < 0 && wolf.getQuestsDone() > 5) {
/*     */             
/* 642 */             wolf.resetCDBerserk();
/* 643 */             wolf.setBerserkLevel(wolf.getBerserkLevel() + 1);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWerewolfLoot(LootingLevelEvent event) {
/* 653 */     if (event.getDamageSource().func_76364_f() instanceof EntityPlayer) {
/*     */       
/* 655 */       EntityPlayer player = (EntityPlayer)event.getDamageSource().func_76364_f();
/* 656 */       IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 657 */       if (wolf.isWerewolf())
/*     */       {
/* 659 */         if (wolf.isTransformed())
/*     */         {
/* 661 */           if (player.func_184614_ca().func_190926_b()) {
/*     */             
/* 663 */             int wereLoot = (int)Math.ceil(wolf.getAttributeTreeAbility(WereList.DEXTERITY.getKey()) / 2.0D);
/* 664 */             if (event.getLootingLevel() < wereLoot) {
/* 665 */               event.setLootingLevel(wereLoot);
/*     */             }
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWerewolfStartEat(LivingEntityUseItemEvent.Start event) {
/* 675 */     if (event.getEntityLiving() instanceof EntityPlayer)
/*     */     {
/* 677 */       if (event.getItem().func_77973_b() instanceof ItemFood) {
/*     */         
/* 679 */         IWerewolfCapability wolf = (IWerewolfCapability)((EntityPlayer)event.getEntityLiving()).getCapability(WERE_CAP, null);
/* 680 */         if (wolf.getAttributeTreeAbility(WereList.HUNGER.getKey()) < 4) {
/*     */           
/* 682 */           ItemFood itemfood = (ItemFood)event.getItem().func_77973_b();
/* 683 */           if (wolf.isWerewolf() && wolf.isTransformed())
/*     */           {
/* 685 */             if (!itemfood.func_77845_h())
/*     */             {
/* 687 */               event.setCanceled(true);
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void werewolfBreakBlock(PlayerEvent.BreakSpeed event) {
/* 698 */     if ((event.getEntityPlayer()).field_71093_bK == ConfigHandler.dimID && !event.getEntityPlayer().func_184812_l_()) {
/*     */       
/* 700 */       event.setCanceled(true);
/*     */     }
/*     */     else {
/*     */       
/* 704 */       IWerewolfCapability wolf = (IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null);
/* 705 */       if (wolf.isTransformed())
/*     */       {
/* 707 */         if (!event.getEntityPlayer().func_184614_ca().func_190926_b()) {
/*     */           
/* 709 */           if (!getCalmInclination(event.getEntityPlayer(), 3)) {
/* 710 */             event.setNewSpeed(event.getNewSpeed() * 0.4F);
/*     */           }
/* 712 */         } else if (event.getEntityPlayer().func_184614_ca().func_190926_b()) {
/*     */           
/* 714 */           event.setNewSpeed(event.getNewSpeed() + event.getNewSpeed() * wolf.getAttributeTreeAbility(WereList.DEXTERITY.getKey()) / 2.0F);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void fearTargetEvent(LivingSetAttackTargetEvent event) {
/* 723 */     if (event.getTarget() != null && event.getTarget() instanceof EntityPlayer) {
/*     */       
/* 725 */       IWerewolfCapability wolf = (IWerewolfCapability)((EntityPlayer)event.getTarget()).getCapability(WERE_CAP, null);
/* 726 */       if (wolf.isTransformed() && wolf.getInclinationType() < 0)
/*     */       {
/* 728 */         if (event.getEntityLiving().func_110144_aD() != event.getTarget())
/*     */         {
/* 730 */           if (event.getEntityLiving().func_110144_aD() == null && event.getTarget().func_110144_aD() == event.getEntity()) {
/* 731 */             event.getEntityLiving().func_130011_c((Entity)event.getTarget());
/* 732 */           } else if (event.getEntityLiving() instanceof AbstractSkeleton) {
/* 733 */             ((AbstractSkeleton)event.getEntityLiving()).func_70624_b(null);
/* 734 */           } else if (event.getEntityLiving() instanceof EntityCreeper && wolf.getQuestsDone() > 5) {
/* 735 */             ((EntityCreeper)event.getEntityLiving()).func_70624_b(null);
/* 736 */           } else if ((event.getEntityLiving() instanceof net.minecraft.entity.monster.EntityZombie || event.getEntityLiving() instanceof net.minecraft.entity.monster.EntitySpider) && wolf.getQuestsDone() > 7) {
/* 737 */             ((EntityMob)event.getEntityLiving()).func_70624_b(null);
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWereXPPickup(PlayerPickupXpEvent event) {
/* 746 */     IWerewolfCapability wolf = (IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null);
/* 747 */     if (wolf.isWerewolf() && wolf.getInclinationType() == 0 && wolf.getQuestsDone() > 3) {
/* 748 */       event.getEntityPlayer().func_71023_q(event.getOrb().func_70526_d() / 3);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void werewolfSleepEvent(PlayerSleepInBedEvent event) {
/* 754 */     if (!(event.getEntityPlayer()).field_70170_p.field_72995_K) {
/*     */       
/* 756 */       IWerewolfCapability wolf = (IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null);
/* 757 */       if (wolf.isTransformed() && !ConfigHandler.wolfSleep) {
/*     */         
/* 759 */         event.setResult(EntityPlayer.SleepResult.OTHER_PROBLEM);
/* 760 */         event.getEntityPlayer().func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.sleep", new Object[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void werewolfWakeup(PlayerWakeUpEvent event) {
/* 768 */     if (!(event.getEntityPlayer()).field_70170_p.field_72995_K) {
/*     */       
/* 770 */       IWerewolfCapability wolf = (IWerewolfCapability)event.getEntityPlayer().getCapability(WERE_CAP, null);
/* 771 */       if (wolf.isWerewolf() && (event.getEntityPlayer()).field_71071_by.func_70431_c(new ItemStack(HMItems.moonstone)))
/*     */       {
/*     */         
/* 774 */         if (event.getEntityPlayer().func_71026_bH())
/*     */         {
/* 776 */           if (wolf.getQuestsDone() < wolf.getLevel() / 5 * 2) {
/*     */             
/* 778 */             event.getEntityPlayer().func_180473_a((event.getEntityPlayer()).field_71081_bT, false);
/* 779 */             if (event.getEntityPlayer() instanceof EntityPlayerMP)
/*     */             {
/* 781 */               EntityPlayerMP player1 = (EntityPlayerMP)event.getEntityPlayer();
/* 782 */               HMTeleporter.teleportToHMDimension(event.getEntityPlayer(), wolf.getQuestsDone() / 2);
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 787 */             Random rand = new Random();
/* 788 */             if (rand.nextBoolean()) {
/* 789 */               event.getEntityPlayer().func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.wake", new Object[0]));
/*     */             } else {
/* 791 */               event.getEntityPlayer().func_145747_a((ITextComponent)new TextComponentTranslation("werewolf.message.wake2", new Object[0]));
/*     */             } 
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerInteractBlock(PlayerInteractEvent.RightClickBlock event) {
/* 803 */     if ((event.getEntityPlayer()).field_71093_bK == ConfigHandler.dimID && !event.getEntityPlayer().func_184812_l_())
/*     */     {
/* 805 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void playerInteractItem(PlayerInteractEvent.RightClickItem event) {
/* 812 */     if ((event.getEntityPlayer()).field_71093_bK == ConfigHandler.dimID && !event.getEntityPlayer().func_184812_l_())
/*     */     {
/* 814 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canLeap(EntityPlayer player) {
/* 820 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 821 */     if (wolf.getAbilityTreeAbility(WereList.LEAP.getKey())) {
/*     */       
/* 823 */       if ((Minecraft.func_71410_x()).field_71474_y.field_151444_V.func_151470_d() && wolf.getSprintJump() > 1)
/* 824 */         return true; 
/* 825 */       if (player.func_70093_af() && wolf.getSneakJump() > 1)
/* 826 */         return true; 
/* 827 */       return wolf.getLeap();
/*     */     } 
/* 829 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean wearingArmor(EntityPlayer player) {
/* 834 */     Iterator<ItemStack> armor = player.func_184193_aE().iterator();
/* 835 */     while (armor.hasNext()) {
/*     */       
/* 837 */       if (!((ItemStack)armor.next()).func_190926_b()) {
/* 838 */         return true;
/*     */       }
/*     */     } 
/* 841 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getCalmInclination(EntityPlayer player, int stage) {
/* 846 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 847 */     if (wolf.getInclinationType() == 1)
/*     */     {
/* 849 */       if (stage == 1) {
/*     */         
/* 851 */         if (wolf.getQuestsDone() > 3) {
/* 852 */           return true;
/*     */         }
/* 854 */       } else if (stage == 2) {
/*     */         
/* 856 */         if (wolf.getQuestsDone() > 5) {
/* 857 */           return true;
/*     */         }
/* 859 */       } else if (stage == 3) {
/*     */         
/* 861 */         if (wolf.getQuestsDone() > 7)
/* 862 */           return true; 
/*     */       } 
/*     */     }
/* 865 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getSavageInclination(EntityPlayer player, int stage) {
/* 870 */     IWerewolfCapability wolf = (IWerewolfCapability)player.getCapability(WERE_CAP, null);
/* 871 */     if (wolf.getInclinationType() == -1)
/*     */     {
/* 873 */       if (stage == 1) {
/*     */         
/* 875 */         if (wolf.getQuestsDone() > 3) {
/* 876 */           return true;
/*     */         }
/* 878 */       } else if (stage == 2) {
/*     */         
/* 880 */         if (wolf.getQuestsDone() > 5) {
/* 881 */           return true;
/*     */         }
/* 883 */       } else if (stage == 3) {
/*     */         
/* 885 */         if (wolf.getQuestsDone() > 7)
/* 886 */           return true; 
/*     */       } 
/*     */     }
/* 889 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */