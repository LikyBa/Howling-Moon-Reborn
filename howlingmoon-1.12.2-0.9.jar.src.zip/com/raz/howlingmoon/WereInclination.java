/*    */ package com.raz.howlingmoon;
/*    */ 
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WereInclination
/*    */   extends WereBase
/*    */ {
/*    */   private final String key;
/*    */   private final ResourceLocation texture;
/*    */   private final WereList.Inclination type;
/*    */   private final int number;
/*    */   
/*    */   public WereInclination(String key, String unlocalizedName, int number, WereList.Inclination type, ResourceLocation texture) {
/* 16 */     super(unlocalizedName);
/* 17 */     this.key = key;
/* 18 */     this.texture = texture;
/* 19 */     this.number = number;
/* 20 */     this.type = type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WereInclination registerStat() {
/* 29 */     WereList.INCLINATION.add(this);
/* 30 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 35 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceLocation getTexture() {
/* 40 */     return this.texture;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNumber() {
/* 45 */     return this.number;
/*    */   }
/*    */ 
/*    */   
/*    */   public WereList.Inclination getInclinationType() {
/* 50 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereInclination.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */