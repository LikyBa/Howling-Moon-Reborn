/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import com.raz.howlingmoon.packets.SyncWereCapsMessage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentTranslation;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*     */ 
/*     */ 
/*     */ public class WereProgressCommand
/*     */   implements ICommand
/*     */ {
/*     */   private List aliases;
/*     */   
/*     */   public WereProgressCommand() {
/*  26 */     this.aliases = new ArrayList();
/*  27 */     this.aliases.add("wereprogress");
/*  28 */     this.aliases.add("werequests");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ICommand o) {
/*  34 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
/*  54 */     if (args.length <= 0) {
/*     */       
/*  56 */       sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.wereprogress.usage", new Object[0]));
/*     */ 
/*     */     
/*     */     }
/*  60 */     else if (sender instanceof EntityPlayer) {
/*     */       
/*  62 */       String s = args[0];
/*  63 */       String s2 = args[1];
/*  64 */       int i = CommandBase.func_175755_a(s);
/*  65 */       int t = CommandBase.func_175755_a(s2);
/*  66 */       if (i >= 0) {
/*     */         
/*  68 */         EntityPlayer entityplayer = (EntityPlayer)sender;
/*  69 */         IWerewolfCapability wolf = (IWerewolfCapability)entityplayer.getCapability(WereEventHandler.WERE_CAP, null);
/*  70 */         if (wolf.isWerewolf())
/*     */         {
/*  72 */           int currentLevel = wolf.getLevel();
/*  73 */           i = Math.min(i, currentLevel / 5 * 2);
/*  74 */           wolf.setQuestsDone(i);
/*  75 */           wolf.setInclinationType(t);
/*  76 */           PacketDispatcher.sendTo((IMessage)new SyncWereCapsMessage(entityplayer), (EntityPlayerMP)entityplayer);
/*     */           
/*  78 */           sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.wereprogress.success", new Object[] { Integer.valueOf(wolf.getQuestsDone()), Integer.valueOf(wolf.getInclinationType()), entityplayer.func_70005_c_() }));
/*     */         }
/*     */         else
/*     */         {
/*  82 */           sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.wereprogress.failure.non", new Object[0]));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  87 */         sender.func_145747_a((ITextComponent)new TextComponentTranslation("commands.wereprogress.failure", new Object[0]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_184882_a(MinecraftServer server, ICommandSender sender) {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71517_b() {
/* 114 */     return "wereprogress";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/* 120 */     return "commands.wereprogress.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_71514_a() {
/* 126 */     return this.aliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args, BlockPos targetPos) {
/* 133 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\WereProgressCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */