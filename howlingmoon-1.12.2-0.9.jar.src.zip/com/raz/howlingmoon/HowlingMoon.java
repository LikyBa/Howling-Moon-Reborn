/*     */ package com.raz.howlingmoon;
/*     */ 
/*     */ import com.google.common.collect.Sets;
/*     */ import com.raz.howlingmoon.blocks.HMBlocks;
/*     */ import com.raz.howlingmoon.client.CustomWerewolfResourcePack;
/*     */ import com.raz.howlingmoon.client.CustomWerewolfTextures;
/*     */ import com.raz.howlingmoon.client.FXScent;
/*     */ import com.raz.howlingmoon.client.FXSparkle;
/*     */ import com.raz.howlingmoon.client.KeyBindings;
/*     */ import com.raz.howlingmoon.client.KeyHandler;
/*     */ import com.raz.howlingmoon.client.ParticleHandler;
/*     */ import com.raz.howlingmoon.client.RenderHunter;
/*     */ import com.raz.howlingmoon.client.RenderStun;
/*     */ import com.raz.howlingmoon.client.RenderWerewolf;
/*     */ import com.raz.howlingmoon.client.RenderWerewolfGuide;
/*     */ import com.raz.howlingmoon.client.RenderWolfGuide;
/*     */ import com.raz.howlingmoon.client.RenderWolfSpirit;
/*     */ import com.raz.howlingmoon.client.gui.GuiBeastPulse;
/*     */ import com.raz.howlingmoon.dimension.HMDimension;
/*     */ import com.raz.howlingmoon.entities.EntityCarry;
/*     */ import com.raz.howlingmoon.entities.EntityHunter;
/*     */ import com.raz.howlingmoon.entities.EntityStun;
/*     */ import com.raz.howlingmoon.entities.EntityWerewolf;
/*     */ import com.raz.howlingmoon.entities.EntityWerewolfGuide;
/*     */ import com.raz.howlingmoon.entities.EntityWolfGuide;
/*     */ import com.raz.howlingmoon.entities.EntityWolfSpirit;
/*     */ import com.raz.howlingmoon.entities.TileEntityHunterBanner;
/*     */ import com.raz.howlingmoon.handler.ConfigHandler;
/*     */ import com.raz.howlingmoon.handler.GuiHandler;
/*     */ import com.raz.howlingmoon.handler.WerewolfTick;
/*     */ import com.raz.howlingmoon.items.HMItems;
/*     */ import com.raz.howlingmoon.packets.PacketDispatcher;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.renderer.block.model.ModelResourceLocation;
/*     */ import net.minecraft.client.renderer.entity.Render;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.resources.IResourcePack;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.PotionTypes;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.CraftingManager;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.item.crafting.Ingredient;
/*     */ import net.minecraft.potion.PotionUtils;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.Biome;
/*     */ import net.minecraftforge.client.model.ModelLoader;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
/*     */ import net.minecraftforge.common.capabilities.CapabilityManager;
/*     */ import net.minecraftforge.fml.client.FMLClientHandler;
/*     */ import net.minecraftforge.fml.client.registry.ClientRegistry;
/*     */ import net.minecraftforge.fml.client.registry.IRenderFactory;
/*     */ import net.minecraftforge.fml.client.registry.RenderingRegistry;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.Mod.Instance;
/*     */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*     */ import net.minecraftforge.fml.common.SidedProxy;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/*     */ import net.minecraftforge.fml.common.network.IGuiHandler;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*     */ import net.minecraftforge.fml.common.registry.EntityRegistry;
/*     */ import net.minecraftforge.fml.common.registry.ForgeRegistries;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mod(modid = "howlingmoon", name = "Howling Moon", version = "0.9", acceptedMinecraftVersions = "[1.12.2]")
/*     */ public class HowlingMoon
/*     */ {
/*     */   @Instance("howlingmoon")
/*     */   public static HowlingMoon instance;
/*     */   @SidedProxy
/*     */   public static CommonProxy proxy;
/*     */   public static final int GUI = 0;
/*     */   public static final int GUISKILL = 1;
/*     */   public static final int GUISCENT = 2;
/*     */   public static final int GUIBOOK = 3;
/*     */   public static final int GUITAME = 4;
/*     */   public static final int GUIWMERCHANT = 5;
/* 108 */   public static Set<Item> silverTools = Sets.newHashSet((Object[])new Item[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event) {
/* 117 */     proxy.preInit(event);
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/* 123 */     GameRegistry.registerWorldGenerator(new WorldGenWolf(), 5);
/* 124 */     this; NetworkRegistry.INSTANCE.registerGuiHandler(instance, (IGuiHandler)new GuiHandler());
/*     */     
/* 126 */     OreDictionary.registerOre("oreSilver", new ItemStack((Block)HMBlocks.silverOre));
/* 127 */     OreDictionary.registerOre("ingotSilver", new ItemStack(HMItems.silverIngot));
/*     */ 
/*     */     
/* 130 */     BrewingRecipeRegistry.addRecipe(PotionUtils.func_185188_a(new ItemStack((Item)Items.field_151068_bn, 1), PotionTypes.field_185233_e), new ItemStack((Block)HMBlocks.wolfsbane, 1), new ItemStack(HMItems.potionWolfsbane));
/* 131 */     GameRegistry.addSmelting((Block)HMBlocks.silverOre, new ItemStack(HMItems.silverIngot), 1.0F);
/* 132 */     proxy.init(event);
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 138 */     proxy.postInit(event);
/*     */ 
/*     */     
/* 141 */     for (IRecipe irecipe : CraftingManager.field_193380_a) {
/*     */       
/* 143 */       if (irecipe instanceof net.minecraftforge.oredict.ShapelessOreRecipe || irecipe instanceof net.minecraftforge.oredict.ShapedOreRecipe)
/*     */       {
/* 145 */         if (proxy.hasSilver(irecipe))
/*     */         {
/* 147 */           silverTools.add(irecipe.func_77571_b().func_77973_b());
/*     */         }
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 154 */     Collection<Biome> biomes = ForgeRegistries.BIOMES.getValuesCollection();
/* 155 */     List<Biome> forest = new ArrayList<>();
/* 156 */     for (Biome b : biomes) {
/*     */       
/* 158 */       if (BiomeDictionary.hasType(b, BiomeDictionary.Type.FOREST)) {
/* 159 */         forest.add(b);
/*     */       }
/*     */     } 
/* 162 */     Biome.SpawnListEntry werewolfSpawn = new Biome.SpawnListEntry(EntityWerewolf.class, 25, 1, 2);
/* 163 */     Biome.SpawnListEntry hunterSpawn = new Biome.SpawnListEntry(EntityHunter.class, 10, 1, 2);
/* 164 */     Biome.SpawnListEntry hunterSpawnDay = new Biome.SpawnListEntry(EntityHunter.class, 1, 1, 3);
/*     */     
/* 166 */     for (Biome b : forest) {
/*     */       
/* 168 */       b.func_76747_a(EnumCreatureType.MONSTER).add(werewolfSpawn);
/* 169 */       b.func_76747_a(EnumCreatureType.MONSTER).add(hunterSpawn);
/* 170 */       b.func_76747_a(EnumCreatureType.CREATURE).add(hunterSpawnDay);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void serverLoad(FMLServerStartingEvent event) {
/* 177 */     event.registerServerCommand(new WerewolfCommand());
/* 178 */     event.registerServerCommand(new WereLevelCommand());
/* 179 */     event.registerServerCommand(new WereProgressCommand());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CommonProxy
/*     */   {
/*     */     public void registerRenderers() {}
/*     */ 
/*     */     
/*     */     public EntityPlayer getPlayerEntity(MessageContext ctx) {
/* 190 */       return (EntityPlayer)(ctx.getServerHandler()).field_147369_b;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void preInit(FMLPreInitializationEvent event) {
/* 196 */       MinecraftForge.EVENT_BUS.register(new WereEventHandler());
/* 197 */       MinecraftForge.EVENT_BUS.register(new WerewolfTick());
/*     */ 
/*     */       
/* 200 */       MinecraftForge.EVENT_BUS.register(new ConfigHandler());
/* 201 */       registerEntities();
/* 202 */       HMDimension.init();
/*     */       
/* 204 */       PacketDispatcher.registerPackets();
/*     */     }
/*     */ 
/*     */     
/*     */     public void init(FMLInitializationEvent event) {
/* 209 */       CapabilityManager.INSTANCE.register(IWerewolfCapability.class, new WerewolfStorage(), WerewolfCapability::new);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void postInit(FMLPostInitializationEvent event) {}
/*     */ 
/*     */     
/*     */     public void registerItemRenderer(Item item, int meta, String id) {}
/*     */ 
/*     */     
/*     */     public boolean hasSilver(IRecipe irecipe) {
/* 221 */       for (Ingredient stack : irecipe.func_192400_c()) {
/*     */         
/* 223 */         if (stack != null)
/* 224 */           for (ItemStack item : stack.func_193365_a()) {
/*     */             
/* 226 */             if (OreDictionary.getOres("ingotSilver").contains(item))
/* 227 */               return true; 
/*     */           }  
/*     */       } 
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerEntities() {
/* 235 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityWerewolf"), EntityWerewolf.class, "Werewolf", 0, HowlingMoon.instance, 80, 3, true, 14869218, 10420283);
/*     */       
/* 237 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityHunter"), EntityHunter.class, "Hunter", 1, HowlingMoon.instance, 80, 3, true, 14869218, 10420283);
/*     */       
/* 239 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityCarry"), EntityCarry.class, "carry", 3, HowlingMoon.instance, 80, 3, true);
/* 240 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityStun"), EntityStun.class, "stun", 4, HowlingMoon.instance, 80, 3, true);
/*     */       
/* 242 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityWerewolfGuide"), EntityWerewolfGuide.class, "Werewolf Guide", 5, HowlingMoon.instance, 80, 3, true);
/* 243 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityWolfGuide"), EntityWolfGuide.class, "Wolf Guide", 6, HowlingMoon.instance, 80, 3, true);
/*     */       
/* 245 */       EntityRegistry.registerModEntity(new ResourceLocation("howlingmoon", "EntityWolfSpirit"), EntityWolfSpirit.class, "Wolf Spirit", 7, HowlingMoon.instance, 80, 3, true);
/*     */       
/* 247 */       GameRegistry.registerTileEntity(TileEntityHunterBanner.class, "howlingmoon:hunter_banner");
/*     */     }
/*     */     
/*     */     public World getClientWorld() {
/* 251 */       return null;
/*     */     }
/*     */     public void generateScentParticles(Entity theEntity, int color) {}
/*     */     
/*     */     public void generateScentParticles(Entity theEntity, float red, float green, float blue) {}
/*     */     
/*     */     public void generateMoonPearlParticles(double x, double y, double z, float r, float g, float b, float size) {
/* 258 */       generateMoonPearlParticles(x, y, z, r, g, b, size, 5);
/*     */     }
/*     */     
/*     */     public void generateMoonPearlParticles(double x, double y, double z, float r, float g, float b, float size, int maxAge) {
/* 262 */       generateMoonPearlParticles(x, y, z, r, g, b, size, 0.0F, 0.0F, 0.0F, maxAge);
/*     */     }
/*     */ 
/*     */     
/*     */     public void generateMoonPearlParticles(double x, double y, double z, float r, float g, float b, float size, float motionx, float motiony, float motionz, int maxAge) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ClientProxy
/*     */     extends CommonProxy
/*     */   {
/*     */     public void preInit(FMLPreInitializationEvent event) {
/* 274 */       super.preInit(event);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 279 */       CustomWerewolfTextures.setCacheFile(new File((Minecraft.func_71410_x()).field_71412_D, "config/HowlingMoonTextures"));
/* 280 */       MinecraftForge.EVENT_BUS.register(new WerewolfClientEventHandler());
/* 281 */       MinecraftForge.EVENT_BUS.register(new GuiBeastPulse(Minecraft.func_71410_x()));
/*     */       
/* 283 */       RenderingRegistry.registerEntityRenderingHandler(EntityWerewolf.class, new IRenderFactory<EntityWerewolf>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityWerewolf> createRenderFor(RenderManager manager)
/*     */             {
/* 288 */               return (Render<? super EntityWerewolf>)new RenderWerewolf(manager);
/*     */             }
/*     */           });
/*     */       
/* 292 */       RenderingRegistry.registerEntityRenderingHandler(EntityHunter.class, new IRenderFactory<EntityHunter>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityHunter> createRenderFor(RenderManager manager)
/*     */             {
/* 297 */               return (Render<? super EntityHunter>)new RenderHunter(manager);
/*     */             }
/*     */           });
/* 300 */       RenderingRegistry.registerEntityRenderingHandler(EntityStun.class, new IRenderFactory<EntityStun>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityStun> createRenderFor(RenderManager manager)
/*     */             {
/* 305 */               return (Render<? super EntityStun>)new RenderStun(manager);
/*     */             }
/*     */           });
/* 308 */       RenderingRegistry.registerEntityRenderingHandler(EntityWerewolfGuide.class, new IRenderFactory<EntityWerewolfGuide>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityWerewolfGuide> createRenderFor(RenderManager manager)
/*     */             {
/* 313 */               return (Render<? super EntityWerewolfGuide>)new RenderWerewolfGuide(manager);
/*     */             }
/*     */           });
/* 316 */       RenderingRegistry.registerEntityRenderingHandler(EntityWolfGuide.class, new IRenderFactory<EntityWolfGuide>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityWolfGuide> createRenderFor(RenderManager manager)
/*     */             {
/* 321 */               return (Render<? super EntityWolfGuide>)new RenderWolfGuide(manager);
/*     */             }
/*     */           });
/* 324 */       RenderingRegistry.registerEntityRenderingHandler(EntityWolfSpirit.class, new IRenderFactory<EntityWolfSpirit>()
/*     */           {
/*     */             
/*     */             public Render<? super EntityWolfSpirit> createRenderFor(RenderManager manager)
/*     */             {
/* 329 */               return (Render<? super EntityWolfSpirit>)new RenderWolfSpirit(manager);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void init(FMLInitializationEvent event) {
/* 339 */       super.init(event);
/*     */       
/* 341 */       List<IResourcePack> defaultResourcePacks = (List<IResourcePack>)ObfuscationReflectionHelper.getPrivateValue(Minecraft.class, Minecraft.func_71410_x(), new String[] { "defaultResourcePacks", "field_110449_ao" });
/* 342 */       defaultResourcePacks.add(new CustomWerewolfResourcePack());
/*     */       
/* 344 */       MinecraftForge.EVENT_BUS.register(new KeyHandler());
/* 345 */       MinecraftForge.EVENT_BUS.register(ParticleHandler.class);
/*     */       
/* 347 */       ClientRegistry.registerKeyBinding(KeyBindings.menu);
/* 348 */       ClientRegistry.registerKeyBinding(KeyBindings.transform);
/* 349 */       ClientRegistry.registerKeyBinding(KeyBindings.ability1);
/* 350 */       ClientRegistry.registerKeyBinding(KeyBindings.ability2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void postInit(FMLPostInitializationEvent event) {
/* 355 */       super.postInit(event);
/*     */     }
/*     */ 
/*     */     
/*     */     public void registerItemRenderer(Item item, int meta, String id) {
/* 360 */       ModelLoader.setCustomModelResourceLocation(item, meta, new ModelResourceLocation(item.getRegistryName(), id));
/*     */     }
/*     */ 
/*     */     
/*     */     public World getClientWorld() {
/* 365 */       return (World)(FMLClientHandler.instance().getClient()).field_71441_e;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public EntityPlayer getPlayerEntity(MessageContext ctx) {
/* 376 */       return ctx.side.isClient() ? (EntityPlayer)(Minecraft.func_71410_x()).field_71439_g : super.getPlayerEntity(ctx);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void generateScentParticles(Entity theEntity, int color) {
/* 386 */       float r = (color >> 16 & 0xFF);
/* 387 */       float g = (color >> 8 & 0xFF);
/* 388 */       float b = (color >> 0 & 0xFF);
/* 389 */       generateScentParticles(theEntity, r / 255.0F, g / 255.0F, b / 255.0F);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void generateScentParticles(Entity theEntity, float red, float green, float blue) {
/* 395 */       double motionX = theEntity.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
/* 396 */       double motionY = theEntity.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
/* 397 */       double motionZ = theEntity.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 402 */       FXScent fXScent = new FXScent(theEntity.field_70170_p, theEntity.field_70165_t + (theEntity.field_70170_p.field_73012_v.nextFloat() * theEntity.field_70130_N * 2.0F) - theEntity.field_70130_N, theEntity.field_70163_u + (theEntity.field_70170_p.field_73012_v.nextFloat() * theEntity.field_70131_O), theEntity.field_70161_v + (theEntity.field_70170_p.field_73012_v.nextFloat() * theEntity.field_70130_N * 2.0F) - theEntity.field_70130_N, red, green, blue, motionX, motionY, motionZ);
/*     */       
/* 404 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)fXScent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void generateMoonPearlParticles(double x, double y, double z, float r, float g, float b, float size, float motionx, float motiony, float motionz, int maxAge) {
/* 412 */       FXSparkle wisp = new FXSparkle((World)(Minecraft.func_71410_x()).field_71441_e, x, y, z, size, r, g, b, maxAge);
/* 413 */       wisp.setSpeed(motionx, motiony, motionz);
/* 414 */       (Minecraft.func_71410_x()).field_71452_i.func_78873_a((Particle)wisp);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServerProxy extends CommonProxy {}
/*     */ }


/* Location:              C:\Users\lagar\Downloads\How\howlingmoon-1.12.2-0.9.jar!\com\raz\howlingmoon\HowlingMoon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */